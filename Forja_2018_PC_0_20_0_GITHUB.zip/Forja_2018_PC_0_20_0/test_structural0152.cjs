/* Reconhecimento por gramática, sem lista de builds. Testa arquivos reais,
   independência de metadados, corrupção estrutural e regras específicas.
   node test_structural0152.cjs CAMINHO_DO_WORKSPACE */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),core=require('./src/core'),nat=require('./src/native-records'),compat=require('./src/compatibility'),inv=require('./src/inventory'),weapons=require('./src/weapon-levels'),campaign=require('./src/campaign'),ciphers=require('./src/ciphers'),armor=require('./src/armor-template-clone'),plan=require('./src/plan');
const oldRoot=path.join(ws,'Forja_2018_PC_0_15_1'),oldPlan=require(oldRoot+'/src/plan');
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(nat.equal(a,b),m);
const out=path.join(ws,'analysis_0_15_2/testes');fs.mkdirSync(out,{recursive:true});
const sourceName='upload/game(20261024-141341).sav',source=read(sourceName),hash=sha(source),model=core.parse(source),slot=model.latestSlot;
assert.equal(model.build,4397815);assert.equal(model.slots[slot].build,4419126);
const layoutReport=[];
for(const name of [sourceName,'upload/game(20261024-134912).sav','upload/game(10).sav','upload/game(9).sav']){
 const b=read(name),m=core.parse(b);for(const s of m.slots.filter(s=>s.available)){const t=nat.read(b,s.index,m),state=compat.inspect(t);assert.equal(state.available,true,name+':'+s.number+':'+state.reason);layoutReport.push({file:name,slot:s.number,containerBuild:m.build,slotBuild:s.build,primary:t.rows.length,refs:t.refs.length,objects:s.table.count4,mapEntries:t.maps.map(m=>m.entries.length),persistedPrefix:core.hex(t.maps[1].prefix),finals:t.finals.length,profile:state.profile});}
}
assert.ok(layoutReport.some(x=>x.persistedPrefix==='19682628084AEA38'));
assert.equal(new Set(layoutReport.map(x=>x.profile)).size,1);
const state=inv.inspect(source,slot),traveler={type:'inventory-equipment',id:'615B1370AEBED3EA',slot,stage:2};
assert.equal(state.profiles.find(p=>p.id===traveler.id).available,true);
const requests=[traveler];
for(const kind of ['wrist','waist','axe','blades','talisman']){
 const p=state.profiles.find(p=>p.kind===kind&&p.variant==='normal'&&p.available&&!p.owned&&!p.autoFullSet);assert.ok(p,kind);requests.push({type:'inventory-equipment',id:p.id,slot,stage:p.stages.length-1,allowExperimental:true});
}
requests.push({type:armor.TYPE,id:armor.ID,slot,level:9,allowExperimental:true});
const runic=state.profiles.find(p=>p.mode==='runic-quantity-template'&&p.available&&!p.owned);if(runic)requests.push({type:'inventory-equipment',id:runic.id,slot,stage:2,allowExperimental:true});
const cases=[];
function compare(name,index,changes){
 const result=plan.patch(source,changes),probe=source.slice();nat.view(probe).setUint32(model.slots[index].base+12,4757534,true);
 const expected=oldPlan.patch(probe,changes).bytes;nat.view(expected).setUint32(model.slots[index].base+12,4419126,true);same(result.bytes,expected,name);
 assert.equal(result.model.build,model.build);assert.equal(result.model.slots[index].build,4419126);
 same(source.subarray(0,core.HEADER_SIZE),result.bytes.subarray(0,core.HEADER_SIZE));
 for(const s of model.slots)if(s.index!==index)same(source.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end));
 const a=nat.read(source,index),b=nat.read(result.bytes,index);same(a.objectsAndGroups,b.objectsAndGroups);assert.ok(b.finals.length<=512);
 same(source.subarray(Math.max(a.state.activeEnd,b.state.activeEnd)),result.bytes.subarray(Math.max(a.state.activeEnd,b.state.activeEnd)));
 same(plan.patch(result.bytes,changes).bytes,result.bytes);
 const output=path.join(out,name+'.sav');fs.writeFileSync(output,result.bytes);cases.push({name,source:path.resolve(ws,sourceName),output,slot:index,requests:changes,sha256:sha(result.bytes)});return result;
}
const equipment=compare('01_4419126_Equipamentos',slot,requests);
const capacities=[{type:'idunn-apples',id:'idunn-apples',slot,total:9},{type:'blood-mead-horns',id:'blood-mead-horns',slot,total:9},...ciphers.PROFILES.map(p=>({type:ciphers.TYPE,id:p.id,slot,total:4}))];
compare('02_4419126_Capacidades_Cifras',slot,capacities);
assert.equal(weapons.inspect(source,0,'axe-main-level').available,true);assert.equal(weapons.inspect(source,0,'axe-main-level').current,1);
compare('03_4419126_Machado6',0,[{type:weapons.TYPE,id:'axe-main-level',slot:0,level:6}]);
// No slot mais recente os mapas informam nível 1, mas a propriedade de mundo
// ainda não existe. Mostra o nível em consulta e mantém a edição bloqueada.
for(const p of weapons.PROFILES){const s=weapons.inspect(source,slot,p.id);assert.equal(s.current,1);assert.equal(s.recognized,true);assert.equal(s.available,false);assert.throws(()=>plan.patch(source,[{type:weapons.TYPE,id:p.id,slot,level:p.max}]));}
// Números arbitrários nos metadados não determinam o formato reconhecido.
let metadataCases=0;
for(const [globalBuild,slotBuild]of [[9000001,9000002],[0xFFFFFFFF,77]]){
 const b=source.slice();nat.view(b).setUint32(12,globalBuild,true);nat.view(b).setUint32(model.slots[slot].base+12,slotBuild,true);
 assert.equal(compat.inspect(nat.read(b,slot)).available,true);const r=plan.patch(b,requests),expected=equipment.bytes.slice();nat.view(expected).setUint32(12,globalBuild,true);nat.view(expected).setUint32(model.slots[slot].base+12,slotBuild,true);same(r.bytes,expected,'Build foi usado como regra de gravação.');metadataCases++;
}
assert.ok(!/4389704|4397815|4419126|4757534/.test(fs.readFileSync(path.join(__dirname,'src/compatibility.js'),'utf8')));
const originalTx=nat.read(source,slot),bad=[];
function rejected(name,change){const bytes=source.slice();change(bytes,originalTx);let blocked=false;try{const t=nat.read(bytes,slot);blocked=!compat.inspect(t).available;}catch{blocked=true;}assert.equal(blocked,true,name);assert.throws(()=>plan.patch(bytes,[traveler]));bad.push(name);}
rejected('signature',(b,t)=>{b[t.slot.base+0x10409]^=1;});
rejected('stats-size',(b,t)=>{nat.view(b).setUint32(t.state.statsHeader,t.state.statsSize+4,true);});
rejected('object-type',(b,t)=>{b[t.state.objectStart]^=1;});
rejected('group-type',(b,t)=>{b[t.state.groups[0].start]^=1;});
rejected('map-prefix',(b,t)=>{b[t.state.frames[1].start+2]^=1;});
rejected('map-length',(b,t)=>{nat.view(b).setUint16(t.state.frames[0].start,t.state.frames[0].length+1,true);});
rejected('active-size',(b,t)=>{nat.view(b).setUint32(t.slot.base+0x124,t.state.activeSize+16,true);});
rejected('duplicated-map-key',(b,t)=>{const at=t.state.frames[0].start+6;b.set(b.subarray(at,at+4),at+8);});
rejected('queue-overflow',(b,t)=>{const f=t.state.frames[3],count=513,extra=count-t.finals.length;for(let i=0;i<extra;i++)b.set(t.finals[0],t.state.activeEnd+i*16);nat.view(b).setUint16(f.start+2,count*16,true);nat.view(b).setUint32(t.slot.base+0x124,t.state.activeSize+extra*16,true);});
// Gramática conhecida não dispensa coerência dos dados da operação.
const gap=nat.read(source,0);nat.putQuantity(gap,weapons.PROFILES[0].history[1],1,true);const gapBytes=nat.write(gap).bytes;assert.equal(compat.inspect(nat.read(gapBytes,0)).available,true);assert.equal(weapons.inspect(gapBytes,0,'axe-main-level').available,false);
const ambiguous=nat.read(source,slot);nat.putQuantity(ambiguous,traveler.id,1,true);ambiguous.rows.push(ambiguous.rows.at(-1).slice());const ab=nat.write(ambiguous).bytes;assert.equal(compat.inspect(nat.read(ab,slot)).available,true);assert.throws(()=>plan.patch(ab,[traveler]));
// Regressão de arquivos aprovados pelo usuário nas versões anteriores.
const legacy=JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_14_0/testes/manifest.json'))).cases,oldCases=[];
for(const c of legacy.filter(c=>['10_','12_','13_','14_'].some(p=>c.name.startsWith(p)))){assert.equal(sha(plan.patch(read(c.source),c.requests).bytes),c.sha256);oldCases.push(c.name);}
const control=read('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),five=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+').map(p=>({type:'inventory-equipment',id:p.id,slot:14,stage:2}));same(plan.patch(control,five).bytes,read('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav'));
for(const rel of ['src/native-records.js','src/resource-edit.js','src/wallet.js','src/resource-policy.js','src/equipment-record-clone.js','src/enchantments.js','src/enchantment-instance-clone.js','src/plan.js'])same(fs.readFileSync(path.join(__dirname,rel)),fs.readFileSync(path.join(oldRoot,rel)));
for(const f of fs.readdirSync(path.join(__dirname,'data')))same(fs.readFileSync(path.join(__dirname,'data',f)),fs.readFileSync(path.join(oldRoot,'data',f)));
for(const r of JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_15_2/baseline_manifest.json'))))assert.equal(sha(fs.readFileSync(r.path)),r.sha256);
assert.equal(sha(source),hash);
fs.writeFileSync(path.join(ws,'analysis_0_15_2/layout_comparison.json'),JSON.stringify(layoutReport,null,2)+'\n');fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({version:core.VERSION,cases},null,2)+'\n');
const report={version:core.VERSION,profile:compat.PROFILE,realSlotsCompared:layoutReport.length,realContainerBuilds:[...new Set(layoutReport.map(x=>x.containerBuild))],realSlotBuilds:[...new Set(layoutReport.map(x=>x.slotBuild))],allRealSlotsShareRecognizedGrammar:true,thirdPersistedMapPrefixRecognized:true,foreignBuildEquipmentCapacitiesCiphersAndAxeExportPassed:true,exportsMatchPreviousAlgorithm:true,metadataIndependenceCases:metadataCases,noNumericBuildAllowlist:true,malformedLayoutsBlocked:bad,operationSpecificHistoryAndDuplicateChecksKept:true,readOnlyWeaponLevelShownWhenWorldPropertyAbsent:true,previousApprovedExportsByteIdentical:oldCases,fiveHandlesByteIdenticalToApprovedFile:true,serializerResourceWritersAndCatalogsUnchanged:true,originalFilesAndBuildNumbersPreserved:true,newForeignSaveGameTestPending:true};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ESTRUTURAL_0_15_2.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
