'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const core = require('./src/core'), resources = require('./src/resource-edit'), attrs = require('./src/attributes');
const fixtures = process.argv.slice(2, -1), outputPath = process.argv.at(-1);
assert.ok(fixtures.length >= 2 && outputPath);
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes');
let slotsChecked = 0, additionsChecked = 0;
for (const fixture of fixtures) {
  let bytes = fs.readFileSync(fixture), original = Buffer.from(bytes), model = core.parse(bytes), plan = [];
  for (const slot of model.slots) {
    const state = resources.inspect(bytes, slot.index, model); assert.equal(state.available, true, state.reason);
    assert.equal(state.objects.length, slot.table.count4); assert.equal(state.capacity, 32);
    const missing = core.FIELDS.filter(item => !slot.rows.some(row => row.id === item.id));
    assert.equal(missing.length, 7); assert.ok(attrs.DEWS.every(stat => missing.some(item => item.id === stat.id)));
    missing.forEach((item, i) => plan.push({ slot: slot.index, id: item.id, quantity: 500 + slot.index * 10 + i }));
    plan.push({ slot: slot.index, id: 'FCC6B87B4C8E41DC', quantity: 4321 + slot.index });
  }
  let result = resources.patch(bytes, plan); assert.equal(result.log.length, 160);
  assert.equal(result.validation.newRecords, 140); assert.equal(result.validation.inclusionInGameTested, false);
  for (const slot of model.slots) {
    const next = result.model.slots[slot.index], state = resources.inspect(bytes, slot.index, model), after = resources.inspect(result.bytes, slot.index, result.model);
    assert.equal(after.available, true, after.reason); assert.equal(next.rows.length, slot.rows.length + 7);
    for (const row of slot.rows) {
      const updated = next.rows.find(item => item.id === row.id);
      assert.equal(updated.offset, row.offset); assert.equal(updated.auxiliary, row.auxiliary);
      assert.equal(updated.quantity, row.id === 'FCC6B87B4C8E41DC' ? 4321 + slot.index : row.quantity);
    }
    for (const request of plan.filter(request => request.slot === slot.index)) assert.equal(next.rows.find(row => row.id === request.id).quantity, request.quantity);
    same(bytes.subarray(slot.table.end, state.activeEnd), result.bytes.subarray(next.table.end, after.activeEnd));
    same(bytes.subarray(after.activeEnd, slot.end), result.bytes.subarray(after.activeEnd, slot.end));
    assert.equal(after.activeEnd - state.activeEnd, 112);
    slotsChecked++; additionsChecked += 7;
  }
  same(bytes, original); same(core.roundTrip(result.bytes), result.bytes);
  // Reabrir e ajustar uma quantidade acrescentada usa exatamente o gravador antigo.
  const update = [{ slot: 18, id: attrs.DEWS[0].id, quantity: 999 }];
  same(resources.patch(result.bytes, update).bytes, core.patch(result.bytes, update).bytes);
  if (fixture === fixtures.at(-1)) fs.writeFileSync(outputPath, result.bytes);
  console.log('Recursos: 20 slots e 140 inclusões verificados em ' + path.basename(fixture));
  result = null; bytes = null; original = null; if (global.gc) global.gc();
}
let bytes = fs.readFileSync(fixtures.at(-1)), model = core.parse(bytes), original = Buffer.from(bytes);
const dew = attrs.DEWS[0].id, add = { slot: 18, id: dew, quantity: 77 };
// Uma inclusão isolada mantém os outros 19 slots, o cabeçalho e o tamanho.
let result = resources.patch(bytes, [add]); assert.equal(result.bytes.length, bytes.length);
same(bytes.subarray(0, model.slots[18].base), result.bytes.subarray(0, model.slots[18].base));
same(bytes.subarray(model.slots[18].end), result.bytes.subarray(model.slots[18].end));
same(resources.patch(bytes, []).bytes, bytes); same(resources.patch(bytes, [{ ...add, quantity: 0 }]).bytes, bytes);
same(resources.patch(bytes, [{ slot: 0, id: core.FIELDS[1].id, quantity: 123 }]).bytes, core.patch(bytes, [{ slot: 0, id: core.FIELDS[1].id, quantity: 123 }]).bytes);
for (const invalid of [null, {}, { ...add, slot: -1 }, { ...add, quantity: -1 }, { ...add, quantity: .5 },
  { ...add, quantity: NaN }, { ...add, quantity: 2147483648 }, { ...add, id: 'B74F7BCF35641B8F' },
  { ...add, id: '3832900B4A8A614B' }, { ...add, id: dew.toLowerCase() }]) assert.throws(() => resources.patch(bytes, [invalid]));
assert.throws(() => resources.patch(bytes, [add, add]), /duas alterações/);
const padded = Buffer.concat([Buffer.alloc(19), bytes, Buffer.alloc(17)]);
same(resources.patch(padded.subarray(19, 19 + bytes.length), [add]).bytes, result.bytes);
const broken = Buffer.from(bytes), objectStart = resources.inspect(bytes, 18, model).objects[0].start;
broken[objectStart] ^= 1; assert.equal(resources.inspect(broken, 18).available, false);
assert.throws(() => resources.patch(broken, [add]), /instância/);
// Uma disposição de inclusão desconhecida não impede a edição antiga de quantidade.
const scalar = [{ slot: 18, id: core.FIELDS[1].id, quantity: 321 }];
same(resources.patch(broken, scalar).bytes, core.patch(broken, scalar).bytes);
const invalidSize = Buffer.from(bytes); invalidSize.writeUInt32LE(1, model.slots[18].base + 0x124);
assert.equal(resources.inspect(invalidSize, 18).available, false); assert.throws(() => resources.patch(invalidSize, [add]), /tamanho ativo/);
// Exercitar o limite com registros ausentes sintéticos, sem fingir uma coleta real.
const synthetic = Buffer.from(bytes), requests = [];
for (const item of core.FIELDS.slice(2)) {
  const row = model.slots[0].rows.find(row => row.id === item.id);
  if (row) synthetic.writeBigUInt64LE(0xAABB000000000000n + BigInt(row.index), row.offset);
  requests.push({ slot: 0, id: item.id, quantity: 9 });
}
assert.throws(() => resources.patch(synthetic, requests.slice(0, 33)), /máximo 32/);
let maximum = resources.patch(synthetic, requests.slice(0, 32)); assert.equal(maximum.validation.newRecords, 32);
same(bytes, original);
const targetSlot = model.slots[18];
for (const stat of attrs.DEWS) {
  const target = attrs.planTarget(targetSlot, { key: stat.key, currentTotal: 130, desiredTotal: 10000 });
  assert.equal(target.quantity, 4935); assert.equal(target.projectedTotal, 10000); assert.equal(target.exact, true);
}
for (const [rounding, quantity, total] of [['nearest', 4936, 10002], ['above', 4936, 10002], ['below', 4935, 10000]]) {
  const target = attrs.planTarget(targetSlot, { key: 'strength', currentTotal: 130, desiredTotal: 10001, rounding });
  assert.equal(target.quantity, quantity); assert.equal(target.projectedTotal, total); assert.equal(target.exact, false);
}
const reopened = resources.patch(bytes, [add]).model.slots[18];
assert.equal(attrs.planTarget(reopened, { key: 'strength', currentTotal: 284, desiredTotal: 10000 }).quantity, 4935);
for (const input of [{ key: 'missing', currentTotal: 130, desiredTotal: 1000 },
  { key: 'strength', currentTotal: 130, desiredTotal: 129 }, { key: 'strength', currentTotal: .5, desiredTotal: 1000 },
  { key: 'strength', currentTotal: 130, desiredTotal: Infinity }, { key: 'strength', currentTotal: 130, desiredTotal: 1000, rounding: 'bad' }])
  assert.throws(() => attrs.planTarget(targetSlot, input));
assert.throws(() => attrs.planTarget(reopened, { key: 'strength', currentTotal: 1, desiredTotal: 1000 }), /menor/);
const report = { version: '0.9.0', fixtureFiles: fixtures.length, physicalSlotsChecked: slotsChecked, resourceAdditionsChecked: additionsChecked,
  singleSlotIsolationVerified: true, allExistingRowsAndAttributeInstancesPreserved: true, allTrailingFramesPreserved: true,
  existingQuantityWriterUnchanged: true, repeatedOpenAndQuantityEditVerified: true, malformedLayoutsRejectedForInclusion: true,
  maximum32NewResourcesPerSlotVerified: true, bufferByteOffsetsVerified: true, sixDewTargetsAndRoundingVerified: true,
  inputFilesUnchanged: true, inGameTestedHere: false, inclusionConfirmedInGame: false };
fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_RECURSOS_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
