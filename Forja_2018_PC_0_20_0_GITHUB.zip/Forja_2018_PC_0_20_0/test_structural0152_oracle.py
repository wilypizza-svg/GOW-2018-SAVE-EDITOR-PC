"""Leitura Python independente das três exportações do save 4419126.
Uso: python3 test_structural0152_oracle.py CAMINHO_DO_WORKSPACE
"""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys

root=Path(__file__).resolve().parent
workspace=Path(sys.argv[1]).resolve()
reader=root/'test_clone_native_reader.py'
definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']
profiles={p['id']:p for p in json.loads((root/'data/inventory-profiles.json').read_text())['profiles']}
weapons={p['id']:p for p in json.loads((root/'data/weapon-profiles.json').read_text())['profiles']}
armor=json.loads((root/'data/armor-set-template.json').read_text())
counters={
 'idunn-apples':('8EC8B40DE6B3AC68','2085C71C79E4ED7E','B42DDFD1FBD3ED7E','D6833365C3296802'),
 'blood-mead-horns':('E54B545124A5891E','89DADD432CFF222C','1B7F1BA84084222C','1AEEE86352596537'),
 'niflheim-cipher':('BF717A0CBE634AD9','04F506B8591A794C'),
 'muspelheim-cipher':('48ECF23EF868FBE4','3926F91F998D0F89')}
def mapping(raw,number):
    prefix,stride=(8 if number==1 else 0),(8 if number==0 else 9)
    n=struct.unpack_from('<I',raw,2+prefix)[0]
    return {struct.unpack_from('<I',raw,6+prefix+k*stride)[0]:raw[6+prefix+k*stride:6+prefix+(k+1)*stride] for k in range(n)}
results=[]
for case in json.loads((workspace/'analysis_0_15_2/testes/manifest.json').read_text())['cases']:
    source=Path(case['source']).read_bytes();edited=Path(case['output']).read_bytes()
    assert hashlib.sha256(edited).hexdigest()==case['sha256']
    ns['SLOT_INDEX']=case['slot'];a,b=parse(source),parse(edited)
    old={r[:8].hex().upper():r for r in a['rows']};new={r[:8].hex().upper():r for r in b['rows']}
    allowed=set();quantities={};keys=set();scene=None
    for r in case['requests']:
        if r['type']=='inventory-equipment':
            p=profiles.get(r['id']);allowed.add(r['id'])
            if p:
                allowed.update(p['ids']);keys.add(p['key'])
                for id in p['ids'][:r['stage']+1]:quantities[id]=r['stage']+1 if p['mode']=='quantity' else 1
            else:quantities[r['id']]=r['stage']+1
        elif r['type']=='armor-set-template':
            # Exige as três peças de Zeus, com todos os históricos no nível 9.
            for p in armor['parts']:
                allowed.update(p['targetIds'])
                for id in p['targetIds']:quantities[id]=1
            for raw in armor['globalRows']:keys.add(struct.unpack_from('<I',bytes.fromhex(raw))[0])
        elif r['type']=='weapon-level':
            p=weapons[r['id']];allowed.update(p['history']);keys.add(p['key'])
            for id in p['history'][:r['level']-1]:quantities[id]=1
            marker=bytes.fromhex(p['sceneMarker']);start=a['base']+0x400;end=a['base']+0x10400
            assert source.count(marker,start,end)==1
            scene=source.index(marker,start,end)+len(marker)
            assert struct.unpack_from('<I',edited,scene)[0]==r['level']-1
        elif r['id'] in counters:
            ids=counters[r['id']];allowed.update(ids)
            if len(ids)==4:
                piece,menu,card,upgrades=ids
                quantities.update({piece:r['total']%3,menu:r['total'],card:r['total'],upgrades:r['total']//3})
            else:quantities.update({ids[0]:r['total'],ids[1]:1})
        else:raise AssertionError(r['type'])
    assert set(new)-set(old)<=allowed,(case['name'],set(new)-set(old)-allowed)
    for id,row in old.items():
        if id not in allowed:assert new[id]==row,(case['name'],id)
    for id,value in quantities.items():assert struct.unpack_from('<I',new[id],8)[0]==value,(case['name'],id,value)
    for number in range(3):
        aa,bb=mapping(a['frames'][number],number),mapping(b['frames'][number],number)
        assert {k:v for k,v in aa.items() if k not in keys}=={k:v for k,v in bb.items() if k not in keys}
        if number==1:assert a['frames'][number][2:10]==b['frames'][number][2:10]
    assert len(b['finals'][4:])//16<=512
    assert a['objects']==b['objects']
    prefix=bytearray(source[:a['start']]);prefix[a['base']+0x124:a['base']+0x128]=edited[a['base']+0x124:a['base']+0x128]
    if scene is not None:prefix[scene:scene+4]=edited[scene:scene+4]
    assert prefix==edited[:b['start']]
    assert source[max(a['end'],b['end']):]==edited[max(a['end'],b['end']):]
    assert source[:4160]==edited[:4160]
    for slot in range(20):
        if slot!=case['slot']:
            at=4160+slot*1677512;assert source[at:at+1677512]==edited[at:at+1677512]
    results.append({'case':case['name'],'slot':case['slot']+1,'passed':True})
report={'version':'0.15.2','independentLanguage':'Python','passed':True,'cases':results,'grammarCountsObjectsAndMapsVerified':True,'requestedRowsQuantitiesAndWeaponWorldValueVerified':True,'globalAndSlotBuildsUnchanged':True,'unrequestedRowsWorldAndOtherSlotsPreserved':True,'finalQueueWithin512':True,'inGameTestedHere':False}
(root/'VERIFICACAO_INDEPENDENTE_ESTRUTURAL_0_15_2.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
