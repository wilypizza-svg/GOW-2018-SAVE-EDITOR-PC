"""Verifica as cinco exportações com Python, sem importar os escritores JS."""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys

root=Path(__file__).resolve().parent
workspace=Path(sys.argv[1]).resolve()
reader=root/'test_clone_native_reader.py'
definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']

def objects(data,parsed):
    cursor=parsed['row_end']+len(parsed['refs'])
    count=struct.unpack_from('<I',data,parsed['start']+25)[0]
    result=[]
    for _ in range(count):
        at=cursor
        assert data[at:at+8]==bytes.fromhex('3B056E1555DABD5D')
        uid=struct.unpack_from('<I',data,at+48)[0]
        cursor+=72
        for _ in range(2):
            n=struct.unpack_from('<I',data,cursor)[0]
            assert n<=64
            cursor+=4+4*n
        n=struct.unpack_from('<I',data,cursor)[0]
        assert n<=64
        cursor+=4+12*n
        result.append((uid,data[at:cursor]))
    assert len({uid for uid,_ in result})==len(result)
    end=parsed['start']+9+struct.unpack_from('<I',data,parsed['start']+5)[0]
    return result,data[cursor:end]

def mapping(frame,number):
    prefix,stride=(8 if number==1 else 0),(8 if number==0 else 9)
    n=struct.unpack_from('<I',frame,2+prefix)[0]
    return {struct.unpack_from('<I',frame,6+prefix+k*stride)[0]:frame[6+prefix+k*stride:6+prefix+(k+1)*stride] for k in range(n)}

acquisition={p['id']:p for p in json.loads((root/'data/enchantment-acquisition.json').read_text())['profiles']}
inventory={p['id']:p for p in json.loads((root/'data/inventory-profiles.json').read_text())['profiles']}
zeus=json.loads((root/'data/armor-set-template.json').read_text())
split=lambda raw,n:[raw[at:at+n] for at in range(0,len(raw),n)]
results=[]
for case in json.loads((workspace/'analysis_0_16_0/testes/manifest.json').read_text())['cases']:
    source=Path(case['source']).read_bytes();edited=Path(case['output']).read_bytes()
    assert hashlib.sha256(edited).hexdigest()==case['sha256']
    assert edited==Path(case['approvedReference']).read_bytes()
    ns['SLOT_INDEX']=case['slot'];a,b=parse(source),parse(edited)
    old,old_groups=objects(source,a);new,groups=objects(edited,b)
    assert new[:len(old)]==old and groups==old_groups
    additions=[r for r in case['requests'] if r['type']=='enchantment-create']
    assert len(new)==len(old)+len(additions)
    allowed_rows,allowed_refs,allowed_keys=set(),set(),set()
    for at,r in enumerate(additions):
        p=acquisition[r['id']];uid,raw=new[len(old)+at]
        expected=bytearray.fromhex(p['raw']);expected[8:16]=bytes(8)
        struct.pack_into('<III',expected,48,uid,0xFFFFFFFF,0xFFFFFFFF)
        assert raw==bytes(expected)
        assert uid not in dict(old)
        allowed_rows.add(p['id'])
    for r in case['requests']:
        if r['type']=='armor-set-template':
            for p in zeus['parts']:allowed_rows.update(p['targetIds'])
            for raw in zeus['globalRows']:allowed_keys.add(struct.unpack_from('<I',bytes.fromhex(raw))[0])
        elif r['type']=='inventory-equipment':
            p=inventory[r['id']];allowed_rows.update(p['ids']);allowed_refs.update(p['referenceIds']);allowed_keys.add(p['key'])
    before={r[:8].hex().upper():r for r in a['rows']};after={r[:8].hex().upper():r for r in b['rows']}
    assert set(after)-set(before)<=allowed_rows
    for id,row in before.items():
        if id not in allowed_rows:assert after[id]==row
    for id in allowed_rows:assert struct.unpack_from('<I',after[id],8)[0]==1
    for number in range(3):
        aa,bb=mapping(a['frames'][number],number),mapping(b['frames'][number],number)
        assert {k:v for k,v in aa.items() if k not in allowed_keys}=={k:v for k,v in bb.items() if k not in allowed_keys}
        if number==1:assert a['frames'][number][2:10]==b['frames'][number][2:10]
    assert [r for r in split(a['refs'],8) if r.hex().upper() not in allowed_refs]==[r for r in split(b['refs'],8) if r.hex().upper() not in allowed_refs]
    managed=allowed_rows|allowed_refs
    old_final=[r for r in split(a['finals'][4:],16) if r[:8].hex().upper() not in managed]
    new_final=[r for r in split(b['finals'][4:],16) if r[:8].hex().upper() not in managed]
    assert new_final==(old_final[-len(new_final):] if new_final else [])
    assert len(b['finals'][4:])//16<=512
    prefix=bytearray(source[:a['start']]);prefix[a['base']+0x124:a['base']+0x128]=edited[a['base']+0x124:a['base']+0x128]
    assert prefix==edited[:b['start']]
    assert source[max(a['end'],b['end']):]==edited[max(a['end'],b['end']):]
    for slot in range(20):
        if slot!=case['slot']:
            start=4160+slot*1677512;assert source[start:start+1677512]==edited[start:start+1677512]
    results.append({'name':case['name'],'passed':True,'addedEnchantments':len(additions),'finalQueue':len(b['finals'][4:])//16})
report={'version':'0.16.0','independentLanguage':'Python','passed':True,'cases':results,'approvedBinaryExportsMatched':True,'previousInstancesGroupsWorldAndOtherSlotsPreserved':True,'newProfileBodiesAndIdentityFieldsVerified':True,'unrequestedRowsReferencesAndMapsPreserved':True,'finalQueueWithin512':True,'inGameTestsPerformedByUserOnMatchedReferences':True}
(root/'VERIFICACAO_INDEPENDENTE_AQUISICAO_0_16_0.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
