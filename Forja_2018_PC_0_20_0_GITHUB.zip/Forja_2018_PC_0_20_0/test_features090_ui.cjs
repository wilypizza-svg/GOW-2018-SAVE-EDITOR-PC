'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const core=require('./src/core'),policy=require('./src/resource-policy'),slots=require('./src/slots'),stat=require('./src/enchantment-stats');
const [sourceFile]=process.argv.slice(2),input=new Uint8Array(fs.readFileSync(sourceFile)),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const noError=()=>assert.equal($('error').hidden,true,$('error').textContent),choose=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
(async()=>{
 api.loadBytes(input);api.chooseView('slots');assert.equal(query('[data-select-slot]')[0].dataset.selectSlot,'12');assert.ok($('slots-body').innerHTML.includes('slot-latest'));
 api.selectSlot(12);assert.ok($('quantity-count').textContent.includes('67'));
 api.chooseView('kits');await choose('kit-choice','helmets');await $('kit-apply').click();noError();
 let output=api.exportBytes();for(const req of policy.buildKit(core.parse(input).slots[12],'helmets',1))assert.equal(output.model.slots[12].rows.find(r=>r.id===req.id).quantity,1);
 assert.equal(output.model.slots[12].rows.some(r=>r.id===policy.IDS.queen),false);
 await choose('kit-choice','dwarven');await $('kit-apply').click();noError();
 await choose('quantity-item','EC3F370D42DC5103');await choose('quantity-value',2,'input');assert.equal($('quantity-apply').disabled,true);let saved=api.exportBytes().bytes;await $('quantity-apply').click();assert.equal($('error').hidden,false);same(api.exportBytes().bytes,saved);
 await choose('quantity-value',1,'input');await $('quantity-apply').click();noError();
 await choose('kit-choice','main');await $('kit-apply').click();noError();assert.ok(api.getState().log.length>32);
 api.chooseView('attributes');await choose('dews-bulk-bonus',20000,'input');await $('dews-bulk-apply').click();noError();
 output=api.exportBytes();for(const id of ['CC1B3E5C878842B3','623486F325B97A3A','418F903C792C6B9C','6D92A12B3DC4A427','F3CBC3D285BFB35D','6A13DB1C163C952D'])assert.equal(output.model.slots[12].rows.find(r=>r.id===id).quantity,10000);
 api.chooseView('enchantments');assert.equal($('enchantment-stat-controls').hidden,false);
 const entry=stat.entries(input,12).entries.find(x=>x.uid===12&&x.statId==='48B6FD1AC0CB4E01');
 await choose('enchantment-stat-record',entry.id);await choose('enchantment-stat-value',1000,'input');await $('enchantment-stat-apply').click();noError();
 output=api.exportBytes();assert.equal(stat.entries(output.bytes,12).entries.find(x=>x.id===entry.id).value,1000);
 await choose('enchantment-filter-stat',entry.statId);await choose('enchantment-filter-before',3,'input');await choose('enchantment-filter-after',500,'input');await $('enchantment-filter-apply').click();noError();
 assert.equal(api.getState().changes.filter(x=>x.type==='enchantment-stat').length,1);assert.equal(stat.entries(api.exportBytes().bytes,12).entries.find(x=>x.id===entry.id).value,500);
 await $('report-download').click();let report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,core.VERSION);assert.equal(report.validation.uniqueEnchantmentCapsAutomaticallyDetected,false);assert.equal(report.validation.gameCapsAutomaticallyDetected,false);
 api.chooseView('slots');await query('[data-extract-slot]').find(x=>x.dataset.extractSlot==='12').click();const extracted=downloads.at(-1),bundle=new Uint8Array(await extracted.blob.arrayBuffer());assert.ok(extracted.name.endsWith('.forja-slot'));
 const sourceIndex=slots.readBundle(bundle).sourceIndex;assert.equal(sourceIndex,12);
 $('slot-import-file').files=[{name:'subsave.forja-slot',arrayBuffer:async()=>bundle.buffer}];await $('slot-import-file').fire('change');noError();
 await choose('slot-import-destination',13);await $('slot-import-apply').click();noError();assert.equal(api.getState().selected,13);
 output=api.exportBytes();assert.equal(output.model.supported,14);const target=output.model.slots[13];same(output.bytes.subarray(target.base,target.end),slots.readBundle(bundle).body);
 api.selectSlot(13);await choose('quantity-item',policy.IDS.hs);await choose('quantity-value',777,'input');await $('quantity-apply').click();noError();assert.equal(api.exportBytes().model.slots[13].rows.find(x=>x.id===policy.IDS.hs).quantity,777);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),input);
 api.chooseView('changes');await query('[data-undo]').find(x=>x.dataset.undo==='13:subsave').click();noError();assert.equal(api.getState().selected,null);assert.equal(api.exportBytes().model.slots[13].empty,true);
 assert.ok(!api.getState().changes.some(x=>x.slot===13));
 api.chooseView('slots');await query('[data-delete-slot]').find(x=>x.dataset.deleteSlot==='0').click();noError();assert.equal(api.exportBytes().model.slots[0].empty,true);
 await query('[data-undo]').find(x=>x.dataset.undo==='0:subsave').click();noError();assert.equal(api.exportBytes().model.slots[0].available,true);
 await $('reset-changes').click();noError();assert.equal(api.getState().log.length,0);assert.equal($('export-top').disabled,true);
 const bad=bundle.slice();bad[100]^=1;$('slot-import-file').files=[{name:'bad.forja-slot',arrayBuffer:async()=>bad.buffer}];await $('slot-import-file').fire('change');assert.equal($('error').hidden,false);assert.equal($('slot-import-apply').disabled,true);assert.equal(api.getState().log.length,0);
 const reportResult={version:'0.9.0',htmlExecutedInVm:true,newestFirstSlotOrderAndColorClassesChecked:true,all67ResourceChoicesShown:true,
 eightHelmetsExcludeSigrun:true,uniqueItemInvalidForcedClickPreservesDraft:true,largeResourceKitAndAllDewsApplied:true,
 individualAndFilteredEnchantmentEditingChecked:true,completeEditedSubsaveExtractedAndImported:true,importedSlotFurtherEditable:true,
 originalDownloadIsRootInput:true,undoImportAlsoRemovesDependentChanges:true,deleteUndoAndResetChecked:true,corruptImportRejectedWithoutLosingDraft:true,
 limitsAndUnknownsHonestInReport:true,browserVisualTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_NOVA_0_9_0.json'),JSON.stringify(reportResult,null,2));console.log(JSON.stringify(reportResult,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
