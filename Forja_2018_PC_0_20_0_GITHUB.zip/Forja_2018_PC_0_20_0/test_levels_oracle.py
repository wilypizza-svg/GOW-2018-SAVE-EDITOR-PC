"""Confere a edição e a compra real com um leitor independente em Python."""
from pathlib import Path
import struct
import sys
import json

original, edited, native = (Path(p).read_bytes() for p in sys.argv[1:4])
assert len(original) == len(edited) == len(native) == 33554400
base = 4160 + 11 * 1677512
slot_end = base + 1677512
table = base + 66589
u32 = lambda b, p: struct.unpack_from('<I', b, p)[0]
u16 = lambda b, p: struct.unpack_from('<H', b, p)[0]

def layout(data):
    count = u32(data, table - 12)
    table_end = table + count * 16
    refs_end = table_end + u32(data, table - 8) * 8
    stats_end = table - 20 + u32(data, table - 24)
    cursor = stats_end
    frames = []
    for _ in range(3):
        end = cursor + 2 + u16(data, cursor)
        frames.append((cursor, end))
        cursor = end
    assert data[cursor:cursor + 2] == bytes.fromhex('2EFA')
    end = cursor + 4 + u16(data, cursor + 2)
    frames.append((cursor, end))
    assert end == base + 66560 + u32(data, base + 292)
    return count, table_end, refs_end, stats_end, frames

old, new, real = (layout(data) for data in (original, edited, native))
assert new[0] == old[0] + 1 == real[0]
assert u32(edited, table - 8) == u32(original, table - 8) - 1
assert u32(edited, table - 24) == u32(original, table - 24) + 8
assert new[4][-1][1] == old[4][-1][1] + 24
assert original[:base] == edited[:base] and original[slot_end:] == edited[slot_end:]
assert original[new[4][-1][1]:slot_end] == edited[new[4][-1][1]:slot_end]

def rows(data, count):
    result = {}
    for i in range(count):
        p = table + i * 16
        key = data[p:p + 8].hex().upper()
        assert key not in result
        result[key] = (u32(data, p + 8), u32(data, p + 12))
    return result

a, b, c = (rows(data, state[0]) for data, state in ((original, old), (edited, new), (native, real)))
assert all(b[key] == value for key, value in a.items())
assert b['6DD41B327975AF5E'] == (1, old[0])
assert {key: value[0] for key, value in b.items()} == {**{key: value[0] for key, value in c.items()}, 'EDB4476E71735CC3': 4}
assert original[table:old[1]] == edited[table:old[1]]
reference = bytes.fromhex('123C61DD7BE614A1')
refs = original[old[1]:old[2]]
assert refs.count(reference) == 1
assert refs.replace(reference, b'') == edited[new[1]:new[2]] == native[real[1]:real[2]]
assert original[old[2]:old[3]] == edited[new[2]:new[3]]

def values(data, frame, lead, stride):
    start, end = frame
    count = u32(data, start + 2 + lead)
    assert end - start - 2 == lead + 4 + count * stride
    result = {}
    for i in range(count):
        p = start + 2 + lead + 4 + i * stride
        key = u32(data, p)
        assert key not in result
        result[key] = data[p + 4:p + stride]
    return result

for index, lead, stride in [(0, 0, 8), (1, 8, 9)]:
    x = values(original, old[4][index], lead, stride)
    y = values(edited, new[4][index], lead, stride)
    z = values(native, real[4][index], lead, stride)
    assert y == z and u32(x[1], 0) == 4 and u32(y[1], 0) == 5
    assert all(y[key] == value for key, value in x.items() if key != 1)
assert edited[new[4][0][0]:new[4][0][1]] == native[real[4][0][0]:real[4][0][1]]
assert original[old[4][2][0]:old[4][2][1]] == edited[new[4][2][0]:new[4][2][1]]
assert edited[new[4][3][0]:new[4][3][1]] == native[real[4][3][0]:real[4][3][1]]
needle = bytes.fromhex('F6B0E3435B7E14EBC47FE9879611F7CA')
region = original[base + 1024:base + 66560]
assert region.count(needle) == 1
property_offset = base + 1024 + region.index(needle) + len(needle)
assert u32(original, property_offset) == 4 and u32(edited, property_offset) == 5
prefix = bytearray(original[base:table])
for offset, value in [(base + 292, u32(original, base + 292) + 24),
                      (table - 24, u32(original, table - 24) + 8),
                      (table - 12, old[0] + 1),
                      (table - 8, u32(original, table - 8) - 1), (property_offset, 5)]:
    struct.pack_into('<I', prefix, offset - base, value)
assert prefix == edited[base:table]
report = {'version': '0.9.0', 'independentLanguage': 'Python struct', 'nativePairCompared': True,
          'physicalSlot': 12, 'level5To6Confirmed': True, 'threeLevelFieldsVerified': True,
          'allPriorItemsAndAuxiliariesPreserved': True, 'nativeFinalTrackerBytesMatched': True,
          'allReferenceAndOpaqueAttributeBytesCompared': True, 'other19SlotsAndHeaderPreserved': True,
          'frozenFlamesPreservedByDirectEdit': True, 'inGameTestedHere': False}
Path(__file__).with_name('VERIFICACAO_NIVEIS_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
