"""Leitor independente: preservação do arquivo e dos modelos aprovados."""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys

root=Path(__file__).resolve().parent
ws=Path(sys.argv[1]).resolve()
reader=root/'test_clone_native_reader.py'
definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']

def objects(data,p):
    cursor=p['row_end']+len(p['refs']);items=[]
    for _ in range(struct.unpack_from('<I',data,p['start']+25)[0]):
        at=cursor;uid=struct.unpack_from('<I',data,at+48)[0];cursor+=72
        for _ in range(2):
            n=struct.unpack_from('<I',data,cursor)[0];cursor+=4+4*n
        n=struct.unpack_from('<I',data,cursor)[0];cursor+=4+12*n
        items.append((uid,data[at:cursor]))
    assert len(dict(items))==len(items)
    end=p['start']+9+struct.unpack_from('<I',data,p['start']+5)[0]
    return items,data[cursor:end]

def split(raw,n):
    assert len(raw)%n==0
    return [raw[i:i+n] for i in range(0,len(raw),n)]

def normalize(raw):
    b=bytearray(raw);b[8:16]=bytes(8);b[48:60]=bytes(12);return b

profiles={p['id']:p for p in json.loads((root/'data/enchantment-acquisition.json').read_text())['profiles']}
cases=json.loads((ws/'analysis_0_17_0/testes/manifest.json').read_text())['cases'];checked=[]
for c in cases:
    source=Path(c['source']).read_bytes();edited=Path(c['output']).read_bytes()
    assert hashlib.sha256(edited).hexdigest()==c['sha256']
    assert edited==Path(c['approvedReference']).read_bytes()
    ns['SLOT_INDEX']=c['slot'];a,b=parse(source),parse(edited)
    old,old_groups=objects(source,a);new,groups=objects(edited,b)
    assert new[:len(old)]==old and groups==old_groups
    assert len(new)==len(old)+len(c['requests'])
    changed={r['id'] for r in c['requests']}
    for i,r in enumerate(c['requests']):
        uid,raw=new[len(old)+i];expected=bytearray.fromhex(profiles[r['id']]['raw'])
        expected[8:16]=bytes(8);struct.pack_into('<III',expected,48,uid,0xFFFFFFFF,0xFFFFFFFF)
        assert raw==expected and uid not in dict(old)
    before={r[:8].hex().upper():r for r in a['rows']};after={r[:8].hex().upper():r for r in b['rows']}
    assert set(before)<=set(after) and set(after)-set(before)<=changed
    for id,row in before.items():
        if id not in changed:assert after[id]==row
    for id in changed:assert struct.unpack_from('<I',after[id],8)[0]==1
    assert a['refs']==b['refs'] and a['frames']==b['frames']
    queue=split(a['finals'][4:],16)
    for r in c['requests']:
        raw=bytes.fromhex(r['id']+profiles[r['id']]['recipeMetadata'])
        matches=[x for x in queue if x[:8]==raw[:8]]
        if matches:assert matches==[raw]
        else:queue.append(raw)
    assert split(b['finals'][4:],16)==queue[-512:]
    prefix=bytearray(source[:a['start']]);p=a['base']+0x124;prefix[p:p+4]=edited[p:p+4]
    assert prefix==edited[:b['start']]
    assert source[max(a['end'],b['end']):]==edited[max(a['end'],b['end']):]
    for slot in range(20):
        if slot!=c['slot']:
            p=4160+slot*1677512;assert source[p:p+1677512]==edited[p:p+1677512]
    checked.append({'name':c['name'],'newObjects':len(c['requests']),'passed':True})
returns=json.loads((ws/'analysis_0_17_0/retornos_verificados.json').read_text())['returns']
for r in returns:
    data=Path(r['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256']
    ns['SLOT_INDEX']=r['slot'];p=parse(data);objs,_=objects(data,p);rows={x[:8].hex().upper():x for x in p['rows']}
    for item in r['items']:
        raw=dict(objs)[item['uid']]
        assert normalize(raw)==normalize(bytes.fromhex(profiles[item['id']]['raw']))
        assert raw[8:16].hex().upper()==item['bindingId']
        assert struct.unpack_from('<I',rows[item['id']],8)[0]==1
for saved in json.loads((ws/'analysis_0_17_0/baseline_manifest.json').read_text()):
    assert hashlib.sha256(Path(saved['path']).read_bytes()).hexdigest()==saved['sha256']
report={'version':'0.17.0','independentLanguage':'Python','passed':True,'exports':checked,'nativeReturnsVerified':4,'previousObjectsGroupsWorldOtherSlotsAndUnrequestedRecordsPreserved':True,'newBodiesMatchApprovedProfiles':True,'queueMatchesExpectedAndIsWithin512':True,'version0160Preserved':True,'perkActivationNotTestedByOracle':True}
(root/'VERIFICACAO_INDEPENDENTE_0_17_0.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
