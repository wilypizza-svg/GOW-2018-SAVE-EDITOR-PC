# Publicar e manter o Forja no GitHub

Guia para José Murilo, preparado para o Forja 2018 PC 0.20.0 em 26/10/2026. Os caminhos de menus foram conferidos na documentação oficial do GitHub. Os nomes podem aparecer em inglês, conforme sua interface.

## 1. O que você recebeu

O pacote `Forja_2018_PC_0_20_0_GITHUB.zip` contém o projeto completo, com um README novo e arquivos de organização. A lógica do editor e o HTML pronto são os mesmos da entrega 0.20.0.

| Arquivo ou pasta | Como usar |
| --- | --- |
| `README.md` | Apresentação que ficará na página principal do repositório. |
| `src/`, `data/`, `build.py`, testes e relatórios | Código e evidências do projeto, mantendo a estrutura existente. |
| `Abrir_Editor.html` | Editor pronto, também disponível no código-fonte. |
| `.gitignore` | Regras para o Git ignorar saves, cópias, pacotes e arquivos temporários. |
| `.github/ISSUE_TEMPLATE/problema.yml` | Formulário de relato de problemas. |
| `RELEASE_v0.20.0.md` | Texto para colar na descrição da versão publicada. |
| `dist/Forja_2018_PC_0_20_0_SO_EDITOR.zip` | Pacote para anexar à Release. A pasta `dist/` está no `.gitignore`. |

Extraia o pacote. Os arquivos que ficam **dentro** da pasta `Forja_2018_PC_0_20_0` devem ocupar a raiz do repositório. Assim, `README.md`, `build.py`, `src/` e `data/` aparecerão juntos na aba **Code**.

## 2. Escolher o repositório

Se o projeto já está no GitHub, continue usando esse repositório. As versões ficam registradas no histórico e nas Releases do mesmo projeto.

Para um repositório novo, use **+ → New repository** e preencha:

| Campo | Sugestão |
| --- | --- |
| Owner | Sua conta do GitHub. |
| Repository name | `forja-gow-2018-save-editor` |
| Description | `Editor offline de saves de God of War (2018) para PC, com recursos, equipamentos, encantamentos e gerenciamento de subsaves.` |
| Visibility | **Public**, se a intenção é divulgar o projeto e receber usuários. |
| Add README | Pode marcar para iniciar o repositório. Depois substitua pelo README desta entrega. |
| .gitignore | Use o arquivo incluído no pacote. |
| License | Escolha conforme a seção de licença deste guia. |

Clique em **Create repository**. Mantenha a branch padrão atual; em projetos novos, `main` é uma opção simples.

Referência: [criar um repositório](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository).

## 3. Enviar pelo GitHub Desktop

Este é o caminho recomendado para enviar o projeto completo, que contém mais de 100 arquivos.

1. Instale o [GitHub Desktop](https://desktop.github.com/) e entre na sua conta.
2. Abra **File → Clone Repository**. Escolha seu repositório na lista ou informe a URL dele na aba **URL**.
3. Escolha a pasta local e clique em **Clone**.
4. Copie o conteúdo da pasta extraída `Forja_2018_PC_0_20_0` para dentro da pasta clonada. Mantenha também `.gitignore` e `.github`. Em uma cópia que já contém o projeto, substitua os arquivos correspondentes.
5. No Desktop, confira a lista **Changes**. Os arquivos do editor e os documentos devem aparecer; os arquivos de `dist/` e os saves são ignorados pelas regras fornecidas.
6. Em **Summary**, use uma mensagem como `Documenta o Forja 0.20.0 e organiza o repositório`.
7. Clique em **Commit to** seguido do nome da branch e depois em **Push origin**. Abra o repositório no site para conferir o resultado.

**Commit** registra uma revisão local; **push** envia as revisões para o GitHub. Um **clone** é a cópia local ligada ao repositório remoto. Uma **release** apresenta uma versão com seus arquivos de download.

Referências: [clonar pelo Desktop](https://docs.github.com/en/desktop/adding-and-cloning-repositories/cloning-and-forking-repositories-from-github-desktop) e [registrar e enviar mudanças](https://docs.github.com/en/desktop/making-changes-in-a-branch/committing-and-reviewing-changes-to-your-project-in-github-desktop).

## 4. Alternativa pelo navegador

Para trocar apenas o README, abra `README.md` no GitHub, use o botão de editar, substitua o texto pelo arquivo desta entrega, confira a prévia e confirme as alterações. O nome deve continuar `README.md`.

Para enviar arquivos, use **Add file → Upload files**, selecione os arquivos ou pastas extraídos, descreva a alteração e conclua o fluxo de commit. Se a interface oferecer uma nova branch, você pode enviar por ela e depois concluir o pull request para a branch padrão.

O upload pelo navegador aceita até **100 arquivos por vez** e **25 MiB por arquivo**. Envie em lotes menores se usar esse caminho. Selecione os arquivos do projeto; o ZIP de `dist/` será usado na Release.

Referência: [adicionar arquivos pelo site](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).

## 5. Ajustar a apresentação

Na página principal, abra a engrenagem ao lado de **About**. Use a descrição sugerida e adicione tópicos, um por vez:

`god-of-war`, `god-of-war-2018`, `save-editor`, `pc-gaming`, `offline`, `javascript`, `html`, `modding`.

Deixe o campo de site reservado para uma página real do projeto. Quando publicar o vídeo, você pode adicionar o link dele ao README. As imagens e links de demonstração também podem ser acrescentados depois, usando material do próprio editor.

O README fornecido usa links internos para os documentos e não depende de um nome de usuário inventado. Depois de publicar a Release, você pode copiar sua URL real e usá-la em um link de download no README.

Referência: [editar tópicos do repositório](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/classifying-your-repository-with-topics).

## 6. Ativar os relatos de problemas

Em **Settings → General → Features**, mantenha **Issues** habilitado. O arquivo `.github/ISSUE_TEMPLATE/problema.yml` deve estar na branch padrão para compor o formulário de relato.

Depois, abra **Issues → New issue** e confira a opção **Reportar problema**. Ela pede versão, campanha, título do subsave, alterações e momento da falha. Não exige atribuir a Issue a uma conta nem configurar etiquetas específicas.

Referência: [formulários de Issues](https://docs.github.com/en/communities/using-templates-to-encourage-useful-issues-and-pull-requests/syntax-for-issue-forms).

## 7. Publicar o editor pronto em Releases

Primeiro envie o código correspondente à versão. Depois abra **Releases → Draft a new release** e preencha:

| Campo | Valor sugerido |
| --- | --- |
| Tag | `v0.20.0`, caso ainda não exista. |
| Target | A branch ou revisão que contém o código 0.20.0 que você acabou de enviar. |
| Release title | `Forja 2018 PC v0.20.0 — Lâminas do Caos desde o início` |
| Description | Cole o conteúdo de `RELEASE_v0.20.0.md`. |
| Assets | Anexe `dist/Forja_2018_PC_0_20_0_SO_EDITOR.zip`. |

Enquanto o nível 5 direto no início ainda estiver pendente de confirmação no jogo, recomendo marcar **This is a pre-release**. Essa é uma recomendação de apresentação para o estado atual da função, não uma exigência do GitHub. Uma versão anterior já validada pode continuar sendo a versão principal de download.

Confira os arquivos anexados e use **Publish release**, ou **Save draft** para terminar depois. O GitHub também oferece arquivos automáticos de código-fonte referentes à tag; o ZIP `SO_EDITOR` é o download preparado para quem quer usar o editor.

Se `v0.20.0` já estiver publicada, a atualização do README pode ser apenas um novo commit de documentação. Para a próxima mudança funcional, publique outra versão com uma nova tag.

Referências: [gerenciar Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository) e [código-fonte automático das versões](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases).

## 8. Escolher a licença

O pacote de referência não contém um arquivo `LICENSE`, por isso o README não declara uma licença inexistente. Um repositório público permite ver o código; a licença define permissões de uso, modificação e redistribuição.

Se você quiser uma opção permissiva, avalie a [MIT](https://choosealicense.com/licenses/mit/), que permite inclusive uso comercial e exige preservar os avisos de licença e autoria. Escolha considerando também as permissões das listas de IDs e dos dados de referência utilizados.

Para adicionar sua escolha: **Add file → Create new file → LICENSE → Choose a license template**. Leia o modelo, preencha os dados pertinentes e confirme a alteração. Depois, acrescente ao README a licença que efetivamente adotou. Se já houver uma licença no seu repositório, confira seus termos antes de substituí-la.

Referências: [licenciar um repositório](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository) e [adicionar uma licença](https://docs.github.com/en/communities/setting-up-your-project-for-healthy-contributions/adding-a-license-to-a-repository).

## 9. Fazer as próximas atualizações

1. Atualize a cópia local ligada ao GitHub e prepare os arquivos da próxima versão.
2. Atualize a versão documentada no README, o changelog e as notas correspondentes.
3. Confira as mudanças, faça o commit e envie com **Push origin**.
4. Publique a nova Release com sua tag e o ZIP correspondente. Mantenha as anteriores disponíveis para quem precisar voltar a uma versão já validada.

O `.gitignore` fornecido atua sobre arquivos ainda não rastreados pelo Git. Acrescentar uma regra não remove automaticamente um arquivo que já estava versionado.

Referência: [funcionamento do .gitignore](https://docs.github.com/en/get-started/git-basics/ignoring-files).
