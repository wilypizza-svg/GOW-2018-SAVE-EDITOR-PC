"""Confere bytes exportados pelo editor com um leitor Python independente."""
from pathlib import Path
import ast
import hashlib
import json
import struct
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
workspace = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent
reader = root/'test_clone_native_reader.py'
definition = next(n for n in ast.parse(reader.read_text()).body
                  if isinstance(n, ast.FunctionDef) and n.name=='parse')
ns = dict(struct=struct, HEADER=4160, SLOT=1677512, START=0x10400,
          SIZE=33554400, SLOT_INDEX=14)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']
source=workspace/'analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'
expected=workspace/'analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav'
js="""const fs=require('fs'),root=process.argv[1],source=process.argv[2],out=process.argv[3];
const inv=require(root+'/src/inventory'),plan=require(root+'/src/plan');
const requests=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+').map(p=>({slot:14,type:'inventory-equipment',id:p.id,stage:2}));
fs.writeFileSync(out,plan.patch(fs.readFileSync(source),requests).bytes);"""
with tempfile.TemporaryDirectory(prefix='forja_cabos_') as tmp:
    output=Path(tmp)/'game.sav'
    subprocess.run(['node','-e',js,str(root),str(source),str(output)],check=True,capture_output=True)
    before=source.read_bytes();after=output.read_bytes()
    assert after==expected.read_bytes()
    a,b=parse(before),parse(after)
    assert len(b['rows'])==len(a['rows'])+15
    assert b['rows'][:len(a['rows'])]==a['rows']
    assert all(struct.unpack_from('<I',r,8)[0]==1 for r in b['rows'][len(a['rows']):])
    assert b['refs']==a['refs'] and b['objects']==a['objects']
    assert b['frames'][1:]==a['frames'][1:]
    def gm(s):return dict(struct.unpack_from('<II',s['frames'][0],p) for p in range(6,len(s['frames'][0]),8))
    old,new=gm(a),gm(b);assert new.pop(971)==2 and old==new
    assert len(b['finals'])==8196
    assert b['finals'][4:4+500*16]==a['finals'][4+12*16:]
    assert before[:a['base']+0x124]==after[:a['base']+0x124]
    assert before[a['base']+0x128:a['start']]==after[a['base']+0x128:a['start']]
    assert before[b['end']:]==after[b['end']:]
    for index in range(20):
        if index!=14:
            p=4160+index*1677512
            assert before[p:p+1677512]==after[p:p+1677512]
    report={'version':'0.14.3','independentPythonReader':True,
            'exportByteIdenticalToApprovedGameFile':True,
            'allPreviousRowsAndAttributeObjectsPreserved':True,
            'onlyKnownLevelKey971Written':True,'finalQueue512WithOldest12Discarded':True,
            'worldAndOther19SlotsPreserved':True,
            'sha256':hashlib.sha256(after).hexdigest(),'inGameTestedHere':False}
    (root/'VERIFICACAO_INDEPENDENTE_0_14_3.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
