'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,$,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),plan=require('./src/plan');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),id='3E9D5BC6723E3C8F',options=()=>$('inventory-item').children.filter(e=>e.tagName==='option');
const set=async(k,v,event='change')=>{$(k).value=String(v);await $(k).fire(event);},same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async()=>{
 const source=new Uint8Array(fs.readFileSync(ws+'/analysis_0_17_3/fixtures/game(saveCom229Alterações).sav')),slot=core.parse(source).latestSlot;
 api.loadBytes(source,'game.sav');api.selectSlot(slot);api.chooseView('equipment');await set('inventory-kind','axe');await set('inventory-search','Tanngiost','input');await set('inventory-variant','all');assert.equal(options().length,2);
 await set('inventory-variant','normal');assert.equal(options().length,1);assert.equal(options()[0].attrs.value,'8E5C10D3F9EFA690');
 await set('inventory-variant','NG+');assert.equal(options().length,1);assert.equal(options()[0].attrs.value,id);assert.equal($('inventory-stage').children.filter(e=>e.tagName==='option').length,3);assert.equal($('inventory-stage').value,'2');assert.match($('inventory-note').textContent,/confirmação no jogo/);assert.match($('inventory-bulk-note').textContent,/confirmação no jogo/);
 assert.equal($('inventory-apply').disabled,false);await $('inventory-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
 const expected=plan.patch(source,[{slot,type:'inventory-equipment',id,stage:2,allowExperimental:true}]),single=api.exportBytes();assert.equal(single.log.length,1);same(single.bytes,expected.bytes);
 api.chooseView('changes');assert.equal($('change-count').textContent,'1 alteração');await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),expected.bytes);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.17.3');assert.equal(report.changes.length,1);assert.equal(report.changes[0].id,id);
 await $('reset-changes').click();api.chooseView('equipment');await set('inventory-kind','axe');await set('inventory-variant','NG+');await set('inventory-search','Tanngiost','input');await set('inventory-bulk-mode','template-max');assert.equal($('inventory-bulk').disabled,false);await $('inventory-bulk').click();assert.equal($('error').hidden,true,$('error').textContent);same(api.exportBytes().bytes,expected.bytes);
 await set('equipment-search',id,'input');assert.ok($('equipment-body').innerHTML.includes('Pomos')||$('equipment-body').innerHTML.includes('Cabos do machado'));assert.ok($('equipment-body').innerHTML.includes(id));
 api.chooseView('catalog');await set('catalog-search',id,'input');assert.ok($('catalog-body').innerHTML.includes('Grip of Tanngiost'));
 const result={version:core.VERSION,passed:true,executedBuiltHtmlInSimulatedDom:true,normalAndNgpSearchWork:true,newVariantHasThreeStages:true,newNgpPendingGameNoticeVisible:true,individualAndFilteredBulkMatchWriter:true,reviewAndDownloadedSaveAndReportPassed:true};fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_17_3.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
