'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, query, downloads, $ } = require('./test_dom_harness.cjs');
const resources = require('./src/resource-edit'), attrs = require('./src/attributes');
const bytes = new Uint8Array(fs.readFileSync(process.argv[2]));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes');
const noError = () => assert.equal($('error').hidden, true, $('error').textContent);
async function quantity(id, value) {
  $('quantity-category').value = 'all'; $('quantity-search').value = id; await $('quantity-search').fire('input');
  assert.equal($('quantity-item').value, id); await $('quantity-item').fire('change');
  $('quantity-value').value = String(value); await $('quantity-value').fire('input'); await $('quantity-apply').click();
}
(async () => {
  api.loadBytes(bytes); api.selectSlot(18); noError();
  assert.equal(query('[data-dew-apply]').length, 6);
  api.chooseView('attributes'); assert.equal($('attributes-controls').hidden, false);
  assert.ok($('attribute-cards').innerHTML.includes('Inclusão em teste'));
  $('dew-strength').value = '20000'; await query('[data-dew-apply]').find(el => el.dataset.dewApply === 'strength').click(); noError();
  let plan = [{ slot: 18, id: attrs.DEWS[0].id, quantity: 10000 }];
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes); assert.equal(api.getState().log.length, 1);
  let valid = api.exportBytes().bytes;
  $('dew-strength').value = '3'; await query('[data-dew-apply]').find(el => el.dataset.dewApply === 'strength').click();
  assert.equal($('error').hidden, false); same(api.exportBytes().bytes, valid);
  api.chooseView('targets'); assert.equal($('targets-controls').hidden, false);
  $('target-stat').value = 'strength'; $('target-rounding').value = 'nearest';
  $('target-current').value = '130'; $('target-desired').value = '10000'; await $('target-desired').fire('input');
  assert.equal($('target-apply').disabled, false); assert.ok($('target-note').textContent.includes('4.935'));
  await $('target-apply').click(); noError(); plan[0].quantity = 4935;
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes); assert.equal(api.getState().log.length, 1);
  $('target-desired').value = '10001'; $('target-rounding').value = 'above'; await $('target-rounding').fire('change');
  assert.ok($('target-note').textContent.includes('10.002')); await $('target-apply').click(); noError(); plan[0].quantity = 4936;
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  valid = api.exportBytes().bytes; $('target-current').value = '130.5'; await $('target-current').fire('input');
  assert.equal($('target-apply').disabled, true); await $('target-apply').click(); assert.equal($('error').hidden, false); same(api.exportBytes().bytes, valid);
  await quantity(attrs.DEWS[1].id, 111); noError(); plan.push({ slot: 18, id: attrs.DEWS[1].id, quantity: 111 });
  assert.ok($('quantity-note').textContent.includes('Inclusão em teste'));
  api.chooseView('records'); $('record-search').value = attrs.DEWS[0].id; await $('record-search').fire('input');
  assert.ok($('records-body').innerHTML.includes('Ausente')); assert.ok($('records-body').innerHTML.includes('Orvalho de força'));
  api.chooseView('catalog'); $('catalog-search').value = attrs.DEWS[0].id; await $('catalog-search').fire('input');
  assert.ok($('catalog-body').innerHTML.includes('ID encontrado'));
  api.chooseView('changes'); assert.ok($('changes-body').innerHTML.includes('inclusão em teste'));
  await $('export-top').click(); assert.equal(downloads.at(-1).name, 'game.sav');
  same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()), resources.patch(bytes, plan).bytes);
  await $('report-download').click(); const report = JSON.parse(await downloads.at(-1).blob.text());
  assert.equal(report.validation.newRecords, 2); assert.equal(report.validation.inclusionInGameTested, false);
  assert.equal(report.validation.preservesBytesOutsideQuantityFields, false); assert.equal(report.layout[0].addedRecords, 2);
  await query('[data-undo]').find(el => el.dataset.undo === '18:' + attrs.DEWS[0].id).click(); noError(); plan.shift();
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  api.selectSlot(0); assert.equal($('target-current').value, ''); assert.equal($('target-desired').value, '');
  await quantity('42C18C7CF2F1CBF9', 45); noError(); plan.push({ slot: 0, id: '42C18C7CF2F1CBF9', quantity: 45 });
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  await $('reset-changes').click(); noError(); assert.equal(api.getState().log.length, 0); assert.equal($('export-top').disabled, true);
  await quantity(attrs.DEWS[0].id, 0); noError(); assert.equal(api.getState().log.length, 0);
  const reportResult = { version: '0.9.0', sixDewCardsAndValidationVerified: true, absentResourceImplicitlyCreated: true,
    targetUsesOriginalBonusAndReplacesPendingChange: true, targetRoundingAndInvalidInputVerified: true,
    addedRecordsAppearInInventoryAndCatalog: true, additionsCanBeUndone: true, originalSelectionAndMultislotBehaviorPreserved: true,
    downloadAndExperimentalReportVerified: true, zeroForMissingResourceDoesNothing: true,
    visualBrowserTested: false, inGameTestedHere: false };
  fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_NOVAS_TELAS_0_9_0.json'), JSON.stringify(reportResult, null, 2));
  console.log(JSON.stringify(reportResult, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
