'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const inv=require('./src/inventory'),select=require('./src/inventory-selection'),nat=require('./src/native-records'),plan=require('./src/plan'),clone=require('./src/armor-template-clone');
const base=new Uint8Array(fs.readFileSync(process.argv[2])),same=(a,b,m)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),m),index=14;
const brok=select.SETS.find(s=>s.id==='KratosArmor_HuldraBrokSet_Tier06_NGP::NG+'),brokNormal=select.SETS.find(s=>s.id==='KratosArmor_HuldraBrokSet_Tier06::normal');
(async()=>{
 api.loadBytes(base);api.selectSlot(index);api.chooseView('equipment');
 $('inventory-variant').value='NG+';await $('inventory-variant').fire('change');assert.equal($('inventory-set').children.filter(e=>e.tagName==='option').length,15);
 assert.ok($('inventory-item').children.filter(e=>e.tagName==='option').every(e=>inv.PROFILES.find(p=>p.id===e.attrs.value).variant==='NG+'));
 $('inventory-set').value=brok.id;await $('inventory-set').fire('change');assert.equal($('inventory-set-apply').disabled,true);assert.match($('inventory-set-note').textContent,/3 peça\(s\) ausente/);
 $('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');assert.equal($('inventory-set-apply').disabled,false);await $('inventory-set-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
 assert.equal(api.getState().log.length,3);for(const p of brok.parts)assert.equal(nat.quantity(nat.read(api.exportBytes().bytes,index),p.id),1);assert.equal($('inventory-set-apply').disabled,true);
 $('inventory-kind').value='axe';await $('inventory-kind').fire('change');$('inventory-item').value='20079575B16C9CD2';await $('inventory-item').fire('change');$('inventory-stage').value='2';await $('inventory-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
 const expected=plan.patch(base,[...select.buildSet(inv.inspect(base,index),brok.id,'template-max',true).map(r=>({...r,slot:index})),{slot:index,id:'20079575B16C9CD2',type:'inventory-equipment',stage:2,allowExperimental:true}]);same(api.exportBytes().bytes,expected.bytes,'conjunto + pomo no DOM divergiu da API');
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.13.0');assert.equal(report.changes.length,4);
 const undo=query('[data-undo]').find(e=>e.dataset.undo===index+':'+brok.parts[0].id);assert.ok(undo);await undo.click();assert.equal($('error').hidden,true,$('error').textContent);assert.equal(api.getState().log.length,3);assert.equal(nat.quantity(nat.read(api.exportBytes().bytes,index),brok.parts[0].id),null);
 // O filtro normal não pode incluir o peitoral normal de Brok entre os NG+.
 $('inventory-variant').value='normal';await $('inventory-variant').fire('change');assert.equal($('inventory-set').children.filter(e=>e.tagName==='option').length,32);$('inventory-kind').value='chest';await $('inventory-kind').fire('change');assert.ok($('inventory-item').children.some(e=>e.attrs.value==='D3E92FA332CC6A5C'));assert.equal($('inventory-item').children.some(e=>e.attrs.value==='E98DAFCF68C32489'),false);
 $('inventory-set').value=brokNormal.id;await $('inventory-set').fire('change');assert.match($('inventory-set-note').textContent,/Brok/);assert.equal($('inventory-set-note').textContent.includes('Maze'),false);
 await $('reset-changes').click();assert.equal(api.getState().changes.length,0);assert.equal($('inventory-experimental').checked,false);
 // Mesmo o modo base do seletor de conjuntos mantém o molde Zeus no 9.
 $('inventory-variant').value='NG+';await $('inventory-variant').fire('change');$('inventory-set').value=select.SETS.find(s=>s.zeus).id;await $('inventory-set').fire('change');$('inventory-set-mode').value='base';await $('inventory-set-mode').fire('change');assert.match($('inventory-set-note').textContent,/completo no 9/);
 $('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');await $('inventory-set-apply').click();assert.equal($('error').hidden,true,$('error').textContent);assert.equal(api.getState().changes[0].type,clone.TYPE);assert.ok(clone.validate(nat.read(api.exportBytes().bytes,index)).fullyRegistered);
 await $('reset-changes').click();
 // Lote com filtro de variante usa a mesma montagem de pedidos que os conjuntos.
 $('inventory-kind').value='talisman';$('inventory-support').value='base';await $('inventory-kind').fire('change');await $('inventory-support').fire('change');$('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');$('inventory-bulk-mode').value='template-max';assert.equal($('inventory-bulk').disabled,false);await $('inventory-bulk').click();assert.equal($('error').hidden,true,$('error').textContent);assert.ok(api.getState().changes.length>1);assert.ok(api.getState().changes.every(r=>inv.PROFILES.find(p=>p.id===r.id)?.kind==='talisman'&&inv.PROFILES.find(p=>p.id===r.id)?.variant==='NG+'));
 same(nat.read(api.exportBytes().bytes,index).objectsAndGroups,nat.read(base,index).objectsAndGroups);
 await $('reset-changes').click();await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),base);
 assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 const reportUI={version:'0.13.0',executedHtmlInSimulatedDom:true,normalAndNgpFiltersPassed:true,all47SetsListed:true,brokVariantCorrect:true,completeSetAndPommelMatchApiByteForByte:true,retributionMappedKeyUsed:true,ownedPiecesPreserved:true,individualUndoAndResetPassed:true,zeusSetPreservesFixedModel:true,variantFilteredBulkPassed:true,originalDownloadUnchanged:true,browserVisualTested:false,inGameTestedHere:false};fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_13_0.json'),JSON.stringify(reportUI,null,2)+'\n');console.log(JSON.stringify(reportUI));
})().catch(e=>{console.error(e);process.exitCode=1;});
