"""Verifica os campos editados sem importar o parser ou escritor JavaScript."""
from pathlib import Path
import hashlib
import json
import struct
import sys

original_path, edited_path = map(Path, sys.argv[1:3])
original, edited = original_path.read_bytes(), edited_path.read_bytes()
assert len(original) == len(edited) == 33554400
header, stride, table = 4160, 1677512, 0x1041D
plan = [(0, '9E5240D27406E85A', 1234567), (0, '8A9A9B831CF67C9C', 7654321), (18, '04BE0462249E0A4A', 4321)]
fields = []
for slot, ident, desired in plan:
    start = header + slot * stride + table
    count = struct.unpack_from('<I', original, start - 12)[0]
    matches = [offset for offset in range(start, start + count * 16, 16) if original[offset:offset + 8].hex().upper() == ident]
    assert len(matches) == 1
    offset = matches[0] + 8
    assert struct.unpack_from('<I', edited, offset)[0] == desired
    fields.append(offset)
cursor = 0
for offset in sorted(fields):
    assert original[cursor:offset] == edited[cursor:offset]
    cursor = offset + 4
assert original[cursor:] == edited[cursor:]
report = {'version': '0.9.0', 'independentParser': 'Python struct, sem importar o código JavaScript',
          'fieldsChecked': len(fields), 'allBytesOutsideRequestedFieldsIdentical': True,
          'fileSizePreserved': True, 'inGameTestedHere': False,
          'inputSha256': hashlib.sha256(original).hexdigest(), 'outputSha256': hashlib.sha256(edited).hexdigest()}
Path(__file__).with_name('VERIFICACAO_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps(report, ensure_ascii=False, indent=2))
