/* Regressão da quarentena de PinkSet normal com as saídas aprovadas no jogo. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),old=path.join(ws,'Forja_2018_PC_0_17_1');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),selection=require('./src/inventory-selection'),policy=require('./src/inventory-catalog'),plan=require('./src/plan');
const oldInv=require(old+'/src/inventory'),oldSelection=require(old+'/src/inventory-selection'),oldPlan=require(old+'/src/plan');
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const same=(a,b,m)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),m);
const pink=['E777B23D510B6DE1','924731D16B9635D0','4351BAA3FE4070D3'],bonus=['B1DFE124C69AF353','82D3E124C69AF353'];
const codNgp=['3225AAC6C42CC83D','7BD539EBB39080CB','112223BC9F1A3F0C'];
assert.equal(core.VERSION,'0.17.2');assert.deepEqual(policy.EXCLUDED_IDS,[...bonus,...pink]);
assert.deepEqual(oldInv.PROFILES.filter(p=>!inv.PROFILES.some(q=>q.id===p.id)).map(p=>p.id).sort(),[...pink].sort());
assert.equal(inv.PROFILES.length,oldInv.PROFILES.length-3);
for(const p of inv.PROFILES)assert.deepEqual(p,oldInv.PROFILES.find(q=>q.id===p.id),'Perfil alterado: '+p.id);
assert.deepEqual(inv.FACTORIES,oldInv.FACTORIES,'Receitas de encantamento alteradas.');
const normal=inv.PROFILES.filter(p=>p.variant==='normal'&&['chest','wrist','waist'].includes(p.kind));
assert.equal(normal.length,93);for(const kind of ['chest','wrist','waist'])assert.equal(normal.filter(p=>p.kind===kind).length,31);
assert.equal(inv.PROFILES.filter(p=>p.kind==='talisman').length,41);
assert.equal(inv.PROFILES.filter(p=>p.kind.includes('runic')).length,31);
for(const id of codNgp){const p=inv.PROFILES.find(p=>p.id===id);assert.equal(p.variant,'NG+');assert.deepEqual(p,oldInv.PROFILES.find(p=>p.id===id));}
assert.deepEqual(oldSelection.SETS.filter(s=>!selection.SETS.some(t=>s.id===t.id)).map(s=>s.id),['KratosArmor_PinkSet::normal']);
for(const s of selection.SETS)assert.deepEqual(s,oldSelection.SETS.find(t=>s.id===t.id));
assert.ok(selection.SETS.some(s=>s.parts.every(p=>codNgp.includes(p.id))));
for(const id of ['E98AD97035D8CAE3','39F888F5377C1DD1','18287F5181DE8A03'])assert.ok(inv.PROFILES.some(p=>p.id===id),'Família Reinforce retirada.');
const manifest=JSON.parse(fs.readFileSync(path.join(ws,'diagnostico_armaduras_03/manifest.json')));
const source=read(manifest.source),sourceHash=sha(source),slot=core.parse(source).latestSlot;
assert.equal(sourceHash,manifest.sourceSha256);
const state=inv.inspect(source,slot);assert.equal(state.available,true);
for(const id of [...bonus,...pink]){
 assert.ok(!inv.PROFILES.some(p=>p.id===id));
 assert.throws(()=>plan.patch(source,[{type:'inventory-equipment',slot,id,stage:0,allowExperimental:true}]),/receita/);
 assert.throws(()=>selection.buildMissing(state,[id],'base',true),/catálogo/);
 assert.equal(sha(source),sourceHash);
}
assert.throws(()=>selection.buildSet(state,'KratosArmor_PinkSet::normal','base',true),/conjunto/);
const normalRequests=selection.buildMissing(state,normal.map(p=>p.id),'base',true).map(r=>({...r,slot}));
assert.equal(normalRequests.length,73);assert.ok(normalRequests.every(r=>!pink.includes(r.id)));
same(plan.patch(source,normalRequests).bytes,oldPlan.patch(source,normalRequests).bytes,'Lote normal divergiu da rotina anterior.');
const cases=[];
for(let k=1;k<manifest.cases.length;k++){
 const test=manifest.cases[k],result=plan.patch(source,test.requests),expected=read(test.output);
 assert.equal(sha(result.bytes),test.sha256);same(result.bytes,expected,'Saída aprovada alterada: '+test.name);
 same(result.bytes,oldPlan.patch(source,test.requests).bytes,'Gravação divergiu: '+test.name);
 const returnedName=k===1?'game(ARM77_01_BASE(Funcionou)).sav':'game(ARM77_02_ULTIMA_ETAPA(Funcionou)).sav';
 const returned=read('upload/'+returnedName),rm=core.parse(returned),rt=nat.read(returned,rm.latestSlot,rm),generated=nat.read(result.bytes,slot,result.model);
 const rs=inv.inspect(returned,rm.latestSlot,rm);assert.notEqual(sha(returned),sha(expected));
 for(const target of manifest.targets){
  const p=inv.PROFILES.find(p=>p.id===target.id),s=rs.profiles.find(q=>q.id===p.id);
  assert.equal(s.available,true,p.name);assert.equal(s.owned,true,p.name);assert.equal(s.stage,k===1?0:p.stages.length-1,p.name);
  for(const id of p.ids)assert.equal(nat.quantity(rt,id),nat.quantity(generated,id),'Histórico não persistiu: '+p.name);
 }
 for(const id of [...bonus,...pink])assert.equal(nat.quantity(rt,id),null);
 assert.equal(inv.PROFILES.filter(p=>p.kind==='talisman'&&nat.quantity(rt,p.id)===1).length,41);
 cases.push({name:test.name,sha256:sha(result.bytes),byteIdenticalTo0171AndApprovedInput:true,returnedSave:returnedName,returnedSha256:sha(returned),targetArmorsPersisted:77,upgradeRecordsPersisted:k===1?0:136});
}
// Quarentena de inclusão não é uma limpeza automática de saves existentes.
const bad=read('upload/game(ARM_LIMPA_02_PINKSET_3_BASE(CrashouAoTentarEntrarNasArmaduras)).sav'),bm=core.parse(bad);
const changed=plan.patch(bad,[{type:'inventory-equipment',id:'17DB6815F553A0E4',slot:bm.latestSlot,stage:0,allowExperimental:true}]);
const retained=nat.read(changed.bytes,bm.latestSlot,changed.model);for(const id of pink)assert.equal(nat.quantity(retained,id),1);
const allowed=new Set(['src/inventory-catalog.js','src/core.js','src/index.template.html','CHANGELOG.md','COMO_USAR.txt','Abrir_Editor.html']);
const snapshot=JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_17_2/baseline_0171.json'))),unchanged=[];
for(const saved of snapshot){
 assert.equal(sha(fs.readFileSync(saved.path)),saved.sha256,'Versão anterior modificada.');
 const relative=path.relative(old,saved.path);
 if(!allowed.has(relative)){same(fs.readFileSync(saved.path),fs.readFileSync(path.join(__dirname,relative)),'Arquivo fora do escopo alterado: '+relative);unchanged.push(relative);}
}
assert.equal(fs.readFileSync(path.join(__dirname,'src/core.js'),'utf8').replace("'0.17.2'","'0.17.1'"),fs.readFileSync(old+'/src/core.js','utf8'));
assert.equal(fs.readFileSync(path.join(__dirname,'src/index.template.html'),'utf8').replaceAll('0.17.2','0.17.1'),fs.readFileSync(old+'/src/index.template.html','utf8'));
assert.equal(sha(source),sourceHash);
const report={version:core.VERSION,passed:true,newlyQuarantinedIds:pink,previousTalismanBlocksKept:bonus,onlyThreeNormalProfilesRemoved:true,normalArmorProfiles:93,normalPiecesPerKind:31,allOtherProfilesAndSetsIdentical:true,codOfWarNgpPreserved:codNgp,reinforceFamiliesPreserved:true,enchantmentFactoriesPreserved:inv.FACTORIES.length,validTalismans:41,runicProfiles:31,individualAndBulkRequestsRejectExcludedIds:true,validBulkExportByteIdenticalTo0171:true,cases,saveWritersAndAllDataFilesByteIdentical:true,unchangedFiles:unchanged,previous0171FilesVerifiedUnchanged:snapshot.length,oldProblematicItemsNotAutomaticallyRemoved:true};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_0_17_2.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,unchangedFiles:unchanged.length},null,2));
