"""Verificação independente com struct/zlib, sem módulos ou offsets do JS.
Uso: python3 test_features090_oracle.py original.sav pasta_saidas
"""
from pathlib import Path
import json
import struct
import sys
import zlib

original=Path(sys.argv[1]).read_bytes()
folder=Path(sys.argv[2])
HEADER,SIZE,COUNT,TABLE=4160,1677512,20,66589
index=12
base=HEADER+index*SIZE
table=base+TABLE

def u32(b,p):return struct.unpack_from('<I',b,p)[0]
def primary(b):
    count=u32(b,table-12)
    rows=[]
    for p in range(table,table+count*16,16):
        rows.append(dict(id=b[p:p+8].hex().upper(),qty=u32(b,p+8),aux=u32(b,p+12),p=p))
    assert len(set(x['id'] for x in rows))==count
    return rows

requests=json.loads((folder/'wallet_requests.json').read_text())
desired={r['id']:r['quantity'] for r in requests}
before=primary(original)
edited=(folder/'wallet_all.bin').read_bytes()
after=primary(edited)
old_ids={x['id'] for x in before}
added=[x for x in after if x['id'] not in old_ids]
assert len(added)>32
assert [x['id'] for x in after[:len(before)]]==[x['id'] for x in before]
assert set(x['id'] for x in added)==set(desired)-old_ids
assert all(x['qty']==desired[x['id']] for x in added)
assert [x['aux'] for x in added]==list(range(len(before),len(after)))
old_end=base+0x10400+u32(original,base+0x124)
delta=len(added)*16
table_end=table+len(before)*16
new_rows=b''.join(bytes.fromhex(x['id'])+struct.pack('<II',desired[x['id']],len(before)+i) for i,x in enumerate(added))
expected=bytearray(original)
expected[table_end:old_end+delta]=new_rows+original[table_end:old_end]
for row in before:
    if row['id'] in desired:struct.pack_into('<I',expected,row['p']+8,desired[row['id']])
struct.pack_into('<I',expected,table-24,u32(original,table-24)+delta)
struct.pack_into('<I',expected,table-12,len(after))
struct.pack_into('<I',expected,base+0x124,u32(original,base+0x124)+delta)
assert len(expected)==len(edited)==33554400
assert edited==expected,'Diferença fora dos campos e registros de inventário previstos'

bundle=(folder/'subsave.forja-slot').read_bytes()
assert bundle[:8]==b'FORJA18S'
assert struct.unpack_from('<IIIIIII',bundle,8)==(1,SIZE,len(original),u32(original,12),u32(original,base+12),index,zlib.crc32(bundle[64:]))
assert not any(bundle[36:64])
assert bundle[64:]==original[base:base+SIZE]
imported=(folder/'slots_imported.bin').read_bytes()
expected=bytearray(original)
target=HEADER+13*SIZE
expected[target:target+SIZE]=original[base:base+SIZE]
assert imported==expected
deleted=(folder/'slots_deleted.bin').read_bytes()
expected=bytearray(original)
expected[HEADER:HEADER+SIZE]=bytes(SIZE)
assert deleted==expected

# Percorre os objetos variáveis e encontra o atributo sem usar o leitor JS.
count,refs,objects=struct.unpack_from('<III',original,table-12)
p=table+count*16+refs*8
changes=[]
for _ in range(objects):
    assert original[p:p+8]==bytes.fromhex('3B056E1555DABD5D')
    uid=u32(original,p+48)
    q=p+72
    for _ in range(2):q+=4+u32(original,q)*4
    stats=u32(original,q);q+=4
    for _ in range(stats):
        if uid==12 and original[q:q+8]==bytes.fromhex('48B6FD1AC0CB4E01'):
            assert struct.unpack_from('<f',original,q+8)[0]==3
            changes.append(q+8)
        q+=12
    p=q
assert len(changes)==1
expected=bytearray(original)
struct.pack_into('<f',expected,changes[0],1000)
assert (folder/'stat_filtered.bin').read_bytes()==expected
report=dict(version='0.9.0',independentPythonStructOracle=True,walletWholeFileMatchesExpected=True,
            inputRequestsOnlyNoJavascriptOffsetsImported=True,unknownFramesAndOriginalAuxiliaryFieldsPreserved=True,
            completeSubsaveBundleAndCrcVerifiedByZlib=True,wholeFileImportAndDeleteMatchExpected=True,
            filteredEnchantmentChangesExactlyOneFloat32=True,headerOtherSlotsAndTailsPreserved=True,inGameTestedHere=False)
Path(__file__).with_name('VERIFICACAO_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
