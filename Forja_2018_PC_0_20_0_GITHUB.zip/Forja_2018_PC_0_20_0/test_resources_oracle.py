"""Verificação independente das 7 inclusões por slot geradas em test_resources.
Não importa o JavaScript nem usa o relatório do próprio gravador como verdade.
"""
from pathlib import Path
import struct
import json
import sys

original = Path(sys.argv[1]).read_bytes()
edited = Path(sys.argv[2]).read_bytes()
assert len(original) == len(edited) == 33554400
assert original[:4160] == edited[:4160]
ids = {
    '42C18C7CF2F1CBF9', 'CC1B3E5C878842B3', '623486F325B97A3A',
    '418F903C792C6B9C', '6D92A12B3DC4A427', 'F3CBC3D285BFB35D', '6A13DB1C163C952D'
}
get32 = lambda data, p: struct.unpack_from('<I', data, p)[0]
allowed = []
for slot in range(20):
    base = 4160 + slot * 1677512
    table = base + 66589
    count = get32(original, table - 12)
    end = table + count * 16
    old_active_end = base + 66560 + get32(original, base + 292)
    new_active_end = old_active_end + 112
    assert get32(edited, table - 12) == count + 7
    assert get32(edited, table - 24) == get32(original, table - 24) + 112
    assert get32(edited, base + 292) == get32(original, base + 292) + 112
    assert original[table - 8:table] == edited[table - 8:table]
    assert original[end:old_active_end] == edited[end + 112:new_active_end]
    assert original[new_active_end:base + 1677512] == edited[new_active_end:base + 1677512]
    found = set()
    for i in range(7):
        row = end + i * 16
        resource_id = edited[row:row + 8].hex().upper()
        assert resource_id in ids and resource_id not in found
        found.add(resource_id)
        assert get32(edited, row + 8) == 500 + slot * 10 + i
        assert get32(edited, row + 12) == count + i
    assert found == ids
    unstable = []
    for i in range(count):
        row = table + i * 16
        assert original[row:row + 8] == edited[row:row + 8]
        assert original[row + 12:row + 16] == edited[row + 12:row + 16]
        if original[row:row + 8] == bytes.fromhex('FCC6B87B4C8E41DC'):
            assert get32(edited, row + 8) == 4321 + slot
            unstable.append(row + 8)
        else:
            assert original[row + 8:row + 12] == edited[row + 8:row + 12]
    assert len(unstable) == 1
    allowed.extend([(base + 292, base + 296), (table - 24, table - 20),
                    (table - 12, table - 8), (unstable[0], unstable[0] + 4), (end, new_active_end)])
cursor = 0
for start, end in sorted(allowed):
    assert original[cursor:start] == edited[cursor:start]
    cursor = end
assert original[cursor:] == edited[cursor:]
report = {'version': '0.9.0', 'independentLanguage': 'Python struct', 'slotsChecked': 20,
          'newResourceRowsChecked': 140, 'allOldIdsQuantitiesAndAuxiliariesChecked': True,
          'allShiftedAttributeAndFinalDataCompared': True, 'allBytesOutsideAllowedRangesCompared': True,
          'inputFilesUnchanged': True, 'inGameTestedHere': False}
Path(__file__).with_name('VERIFICACAO_INCLUSAO_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
