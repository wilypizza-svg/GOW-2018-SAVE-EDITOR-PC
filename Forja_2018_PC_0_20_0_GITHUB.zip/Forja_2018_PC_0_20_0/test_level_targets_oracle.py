"""Verifica seleções de nível já registrado sem importar o parser JavaScript.
Uso: python3 test_level_targets_oracle.py original.sav editado.sav
A saída de teste esperada é o slot físico 12: machado 2, peitoral base 0.
"""
from pathlib import Path
import json
import struct
import sys

original, edited = [Path(p).read_bytes() for p in sys.argv[1:3]]
assert len(original) == len(edited) == 33554400
base = 4160 + 11 * 1677512
table = base + 66589
stats_end = table - 20 + struct.unpack_from('<I', original, table - 24)[0]
frames = []
cursor = stats_end
for _ in range(3):
    length = struct.unpack_from('<H', original, cursor)[0]
    frames.append((cursor, cursor + 2 + length))
    cursor += 2 + length

def numeric_map(data, index):
    start, end = frames[index]
    prefix, stride = (0, 8) if index == 0 else (8, 9)
    start += 2 + prefix
    count = struct.unpack_from('<I', data, start)[0]
    assert start + 4 + count * stride == end
    result = {}
    for p in range(start + 4, end, stride):
        key, value = struct.unpack_from('<II', data, p)
        assert key not in result
        result[key] = (value, p + 4)
    return result

expected = bytearray(original)
allowed = []
for index in [0, 1]:
    mapping = numeric_map(original, index)
    assert mapping[1][0] == 5 and mapping[607][0] == 2
    for key, value in [(1, 1), (607, 0)]:
        pos = mapping[key][1]
        struct.pack_into('<I', expected, pos, value)
        allowed.append((pos, pos + 4))
marker = bytes.fromhex('F6B0E3435B7E14EBC47FE9879611F7CA')
positions = []
cursor = base + 0x400
while (cursor := original.find(marker, cursor, base + 0x10400)) >= 0:
    positions.append(cursor + 16)
    cursor += 1
assert len(positions) == 1
assert struct.unpack_from('<I', original, positions[0])[0] == 5
struct.pack_into('<I', expected, positions[0], 1)
allowed.append((positions[0], positions[0] + 4))
assert edited == expected, 'Há diferenças além dos cinco campos de nível esperados'
for key, value in [(1, 1), (607, 0)]:
    assert all(numeric_map(edited, index)[key][0] == value for index in [0, 1])
assert edited[table - 24:stats_end] == original[table - 24:stats_end]
# A comparação integral acima já cobre os marcadores, referências e outros slots.
report = dict(version='0.9.0', independentPythonOracle=True, all33554400BytesCompared=True,
              exactlyFiveKnownFieldsPermitted=True, quantitiesHistoryReferencesAndCountsUnchanged=True,
              unknownDataHeaderOtherSlotsAndUnusedTailPreserved=True, noJavaScriptImported=True,
              checksBinaryTransformationOnly=True, inGameTestedHere=False)
Path(__file__).with_name('VERIFICACAO_SELETOR_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
