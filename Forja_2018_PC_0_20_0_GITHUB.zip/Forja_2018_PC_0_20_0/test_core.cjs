'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const core = require('./src/core');
const [beforeFile, afterFile, privateOutput] = process.argv.slice(2);
assert.ok(beforeFile && afterFile && privateOutput, 'Informe os dois saves e um destino privado de teste.');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes.');
const report = { version: core.VERSION, inputFiles: 2, recognizedSlots: 0, editedSlotExports: 0, editedFields: 0,
  roundTripsByteIdentical: 0, originalsOverwritten: false, inGameTestedHere: false, oblivionStoneNameFromCatalog: true };
for (const filename of [beforeFile, afterFile]) {
  const original = new Uint8Array(fs.readFileSync(filename)), originalHash = hash(original), model = core.parse(original);
  assert.equal(model.supported, 20); report.recognizedSlots += model.supported;
  same(core.roundTrip(original), original); same(core.patch(original).bytes, original); report.roundTripsByteIdentical++;
  for (const slot of model.slots) {
    const plan = core.FIELDS.filter(field => slot.rows.some(row => row.id === field.id) && !slot.duplicateIds.includes(field.id)).map((field, index) => ({ slot: slot.index, id: field.id, quantity: 123456 + slot.index * 10 + index }));
    const output = core.patch(original, plan); assert.equal(output.bytes.length, original.length); assert.equal(output.log.length, plan.length);
    for (const entry of plan) assert.equal(output.model.slots[entry.slot].rows.find(row => row.id === entry.id).quantity, entry.quantity);
    same(original.subarray(0, slot.base), output.bytes.subarray(0, slot.base));
    same(original.subarray(slot.end), output.bytes.subarray(slot.end));
    for (const oldSlot of model.slots) if (oldSlot.index !== slot.index)
      same(original.subarray(oldSlot.base, oldSlot.end), output.bytes.subarray(oldSlot.base, oldSlot.end));
    const allowed = output.log.map(entry => entry.offset);
    let cursor = slot.base;
    for (const offset of allowed.sort((a, b) => a - b)) { same(original.subarray(cursor, offset), output.bytes.subarray(cursor, offset)); cursor = offset + 4; }
    same(original.subarray(cursor, slot.end), output.bytes.subarray(cursor, slot.end));
    report.editedSlotExports++; report.editedFields += plan.length;
    if (global.gc) global.gc();
  }
  assert.equal(hash(original), originalHash); assert.equal(hash(fs.readFileSync(filename)), originalHash);
}
const original = new Uint8Array(fs.readFileSync(afterFile)), model = core.parse(original), valid = { slot: 0, id: core.FIELDS[1].id, quantity: 1234567 };
const multiPlan = [valid, { slot: 0, id: core.FIELDS[0].id, quantity: 7654321 }, { slot: 18, id: '04BE0462249E0A4A', quantity: 4321 }];
const multi = core.patch(original, multiPlan); fs.writeFileSync(privateOutput, multi.bytes);
same(core.patch(multi.bytes, [{ ...valid, quantity: 0 }]).bytes.subarray(model.slots[1].base), multi.bytes.subarray(model.slots[1].base));
same(core.patch(original, [{ ...valid, quantity: model.slots[0].rows.find(row => row.id === valid.id).quantity }]).bytes, original);
for (const quantity of [-1, 0.5, NaN, Infinity, 2147483648, '42', null]) assert.throws(() => core.patch(original, [{ ...valid, quantity }]), /inteira/);
for (const slot of [-1, 20, 1.5, '1', null]) assert.throws(() => core.patch(original, [{ ...valid, slot }]), /slot/);
assert.throws(() => core.patch(original, [valid, valid]), /duas alterações/);
assert.throws(() => core.patch(original, [{ ...valid, id: model.slots[0].rows[1].id }]), /consulta/);
assert.throws(() => core.patch(original, {}), /lista/);
assert.throws(() => core.parse(original.subarray(1)), /tamanho/);
const badHeader = original.slice(); new DataView(badHeader.buffer).setUint32(8, 8, true); assert.throws(() => core.parse(badHeader), /cabeçalho/);
const broken = original.slice(), table = model.slots[0].table;
broken[table.start] ^= 1; const brokenModel = core.parse(broken); assert.equal(brokenModel.slots[0].available, false); assert.equal(brokenModel.supported, 19);
assert.throws(() => core.patch(broken, [valid]), /tabela/); same(core.patch(broken, [{ ...valid, slot: 1 }]).bytes.subarray(model.slots[0].base, model.slots[0].end), broken.subarray(model.slots[0].base, model.slots[0].end));
const duplicate = original.slice(), stone = model.slots[0].rows.find(row => row.id === '04BE0462249E0A4A'), replacement = model.slots[0].rows.at(-1);
duplicate.set(original.subarray(stone.offset, stone.offset + 8), replacement.offset);
assert.equal(core.parse(duplicate).slots[0].available, true);
assert.throws(() => core.patch(duplicate, [{ slot: 0, id: stone.id, quantity: 5 }]), /duplicado/);
const missing = original.slice(); missing[stone.offset] ^= 1; assert.throws(() => core.patch(missing, [{ slot: 0, id: stone.id, quantity: 5 }]), /não existe/);
const empty = original.slice(); empty.fill(0, model.slots[0].base, model.slots[0].end); assert.equal(core.parse(empty).slots[0].empty, true); assert.throws(() => core.patch(empty, [valid]), /vazio/);
const hugeCount = original.slice(); new DataView(hugeCount.buffer).setUint32(table.start - 12, 10000000, true); assert.equal(core.parse(hugeCount).slots[0].available, false);
const carrier = Buffer.alloc(original.length + 32); carrier.set(original, 16); const buffer = carrier.subarray(16, 16 + original.length), bufferHash = hash(buffer);
same(core.patch(buffer, [valid]).bytes, core.patch(original, [valid]).bytes); assert.equal(hash(buffer), bufferHash);
Object.assign(report, { allOtherSlotsAndHeaderPreserved: true, onlyRequestedQuantityBytesChanged: true,
  multiSlotPlanVerified: true, zeroAndNoopVerified: true, invalidAndUnknownFieldsBlocked: true,
  duplicateAndMissingResourcesBlocked: true, unsupportedSlotsProtected: true, bufferInputPreserved: true });
fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_BINARIA_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
