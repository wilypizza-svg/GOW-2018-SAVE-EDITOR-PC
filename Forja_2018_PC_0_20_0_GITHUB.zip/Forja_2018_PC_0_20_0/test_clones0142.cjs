/* Regressão das funções aprovadas e hipóteses revisadas de clonagem. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const core=require('./src/core'),nat=require('./src/native-records'),plan=require('./src/plan'),inv=require('./src/inventory'),ench=require('./src/enchantments'),clone=require('./src/enchantment-instance-clone');
const [manifestPath,previousRoot,pedidas,outDir]=process.argv.slice(2),manifest=JSON.parse(fs.readFileSync(manifestPath)),workspace=path.resolve(path.dirname(manifestPath),'../..'),oldPlan=require(path.resolve(previousRoot,'src/plan'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b)=>assert.ok(nat.equal(a,b));
const load=name=>{const b=new Uint8Array(fs.readFileSync(path.join(pedidas,name))),m=core.parse(b);return {name,b,m,index:m.latestSlot,tx:nat.read(b,m.latestSlot,m)};};
const cases=[];fs.mkdirSync(outDir,{recursive:true});
function save(name,source,requests,result){const dir=path.join(outDir,name);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'game.sav'),result.bytes);const s=source.m.slots[source.index];cases.push({name,sourceFilename:source.name,slot:s.number,title:s.title,timestamp:s.timestamp,requests,sha256:sha(result.bytes),inGameResult:'pending'});}
function preserve(source,result){const after=nat.read(result.bytes,source.index);for(const o of source.tx.state.objects){const n=after.state.objects.find(x=>x.uid===o.uid);assert.ok(n);same(source.b.subarray(o.start,o.end),result.bytes.subarray(n.start,n.end));}for(const s of source.m.slots)if(s.index!==source.index)same(source.b.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end));same(source.b.subarray(0,core.HEADER_SIZE),result.bytes.subarray(0,core.HEADER_SIZE));return after;}
const regressions=[];
for(const test of manifest.cases.filter(c=>['10_','12_','13_','14_'].some(p=>c.name.startsWith(p)))){const b=new Uint8Array(fs.readFileSync(path.resolve(workspace,test.source))),r=plan.patch(b,test.requests);assert.equal(sha(r.bytes),test.sha256);regressions.push(test.name);}
const source=load('game(AntesDeComprarEncantamentoDaLoja).sav'),bestla=inv.FACTORIES.find(p=>p.id===inv.BESTLA),kvasir=inv.FACTORIES.find(p=>p.id===inv.KVASIR),menace=inv.FACTORIES.find(p=>p.id===inv.MENACE);
assert.equal(ench.classifyRaw(nat.fromHex(bestla.raw)).classification,'common');assert.equal(ench.classifyRaw(nat.fromHex(kvasir.raw)).classification,'unique');assert.equal(ench.classifyRaw(nat.fromHex(kvasir.raw)).conversion,true);
const built=clone.build(source.tx,bestla,252),oldRaw=nat.fromHex(bestla.raw);same(built.raw,oldRaw);assert.ok(source.tx.state.objects.some(o=>o.uid===built.templateUid));
const originalHash=sha(source.b),request={slot:source.index,id:inv.BESTLA,type:'enchantment-create',count:1};
assert.throws(()=>plan.patch(source.b,[request]),/experimental/);assert.throws(()=>plan.patch(source.b,[{...request,count:2,allowExperimental:true}]),/uma unidade/);
const bestlaResult=plan.patch(source.b,[{...request,allowExperimental:true}]),bt=preserve(source,bestlaResult),oldBestla=oldPlan.patch(source.b,[request]);
assert.notEqual(sha(bestlaResult.bytes),sha(oldBestla.bytes));assert.equal(sha(oldBestla.bytes),'145347bfdbd86b404ed0b0111e15734254e62b08dc60760de13f9168b4a7fa0f');
const uid=bestlaResult.log[0].uids[0],id=Buffer.alloc(8);id.writeUInt32LE(uid);assert.equal(nat.unique(bt.finals,id.toString('hex').toUpperCase()),null);
assert.equal(nat.quantity(bt,inv.BESTLA),1);assert.ok(bestlaResult.log[0].localTemplate);assert.equal(bestlaResult.log[0].classification,'common');
const oldTx=nat.read(oldBestla.bytes,source.index);assert.deepEqual(bt.rows,oldTx.rows);assert.deepEqual(bt.refs,oldTx.refs);assert.deepEqual(bt.maps,oldTx.maps);same(bt.objectsAndGroups,oldTx.objectsAndGroups);
assert.deepEqual(bt.finals,oldTx.finals.filter(r=>nat.idOf(r)!==id.toString('hex').toUpperCase()));
const nativeSettled=load('game(DepoisDeRetirarOEncantamentoDoPeitoralDoZeus).sav'),settled=ench.inspect(nativeSettled.b,nativeSettled.index).objects.find(o=>o.uid===252),newObject=ench.inspect(bestlaResult.bytes,source.index).objects.find(o=>o.uid===uid);same(bestlaResult.bytes.subarray(newObject.start,newObject.end),nativeSettled.b.subarray(settled.start,settled.end));
save('18_Bestla_Clonagem_Local_Sem_Aviso',source,[{...request,allowExperimental:true}],bestlaResult);
for(const count of [1,2,10]){const changes=[{slot:source.index,id:inv.MENACE,type:'enchantment-create',count}];same(plan.patch(source.b,changes).bytes,oldPlan.patch(source.b,changes).bytes);}
const choices=inv.duplicateChoices(source.b,source.index),unique=choices.choices.find(o=>ench.classifyRaw(o.raw).unique);assert.ok(unique);
const duplicate=o=>({slot:source.index,type:'enchantment-duplicate',id:inv.duplicateId(o.sourceSlot,o.uid,o.raw),templateUid:o.uid,templateBytes:o.raw,sourceBuild:o.sourceBuild,sourceSlot:o.sourceSlot,count:1,allowExperimental:true,sourceName:'Comum (nome forjado)'});
assert.throws(()=>plan.patch(source.b,[duplicate(unique)]),/único/);
const ko=ench.inspect(source.b,source.index).objects.find(o=>o.sampleName==='Perfect Mark of Kvasir +');assert.ok(ko);
const kchoice={uid:ko.uid,raw:source.b.slice(ko.start,ko.end),sourceSlot:source.index,sourceBuild:4757534};
assert.throws(()=>plan.patch(source.b,[duplicate(kchoice)]),/único/);
const ordinary=choices.choices.find(o=>o.sampleName==='Symbol of Menace');assert.ok(ordinary);same(plan.patch(source.b,[duplicate(ordinary)]).bytes,oldPlan.patch(source.b,[duplicate(ordinary)]).bytes);
assert.throws(()=>plan.patch(source.b,[{slot:source.index,id:inv.KVASIR,type:'enchantment-create',count:1}]),/já foi registrada/);
assert.equal(sha(source.b),originalHash);
const cursedSource=load('game(AntesDeConseguirCaboNivel8).sav'),p=inv.PROFILES.find(p=>p.id==='B19A13C4B34FA37F'),cursedRequest={slot:cursedSource.index,id:p.id,type:'inventory-equipment',stage:2};
assert.throws(()=>plan.patch(cursedSource.b,[cursedRequest]),/experimental/);
const cursedResult=plan.patch(cursedSource.b,[{...cursedRequest,allowExperimental:true}]),ct=preserve(cursedSource,cursedResult),oldCursed=oldPlan.patch(cursedSource.b,[cursedRequest]);assert.notEqual(sha(cursedResult.bytes),sha(oldCursed.bytes));
assert.equal(sha(oldCursed.bytes),'1e2631f720e36c2a5a878e64a18de39244417d2bbd4a63f21c73cbe963d60263');
assert.equal(nat.view(nat.mapEntry(ct,0,971)).getUint32(4,true),2);for(const id of p.ids)assert.equal(nat.quantity(ct,id),1);
assert.equal(nat.unique(ct.finals,p.id),null);for(const id of p.referenceIds){assert.equal(nat.unique(ct.finals,id),null);assert.equal(nat.unique(ct.refs,id),null);}
assert.ok(cursedResult.log[0].nativeRecordClone);assert.ok(cursedResult.log[0].experimentalAcquisition);
assert.equal(cursedResult.log[0].acquisitionOrigin,'chest');assert.equal(inv.ACQUISITION_ORIGINS['23D287FFCB336671'],'shop');
save('17_Cursed_Clonagem_Sem_Aquisicao',cursedSource,[{...cursedRequest,allowExperimental:true}],cursedResult);
for(const profile of inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+'&&p.experimentalTemplate))assert.throws(()=>plan.patch(cursedSource.b,[{...cursedRequest,id:profile.id,allowExperimental:true}]),/suspensa/);
for(const type of ['attach-enchantment','enchantment-copy','enchantment-stat'])assert.throws(()=>plan.patch(source.b,[{type}]),/removida/);
const result={version:'0.14.2',reportedFailedTests15And16MatchedExactly:true,successfulPreparedOutputsByteIdentical:regressions,
 localCloneUsesDestinationInstance:true,localCloneAloneMatchesPreviouslyFailedObject:true,changedBestlaSerialization:'Only the new-instance final marker is omitted; other mapped inventory data is identical.',
 bestlaInstanceMatchesNativeAfterUnequipping:true,knownUniqueDuplicateBlockedRegardlessOfName:true,kvasirAlreadyOwnedBlocked:true,menaceCreationAndOrdinaryDuplicationByteIdentical:true,
 cursedUsesSameRecordClonerAndSettledFinalsAsEquipment:true,cursedOwnKey971Written:true,experimentalOptInRequired:true,
 oldInstancesAndOtherSlotsPreserved:true,inGameFixConfirmed:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_CLONAGEM_0_14_2.json'),JSON.stringify(result,null,2)+'\n');fs.writeFileSync(path.join(outDir,'manifest.json'),JSON.stringify({version:'0.14.2',cases},null,2)+'\n');console.log(JSON.stringify(result,null,2));
