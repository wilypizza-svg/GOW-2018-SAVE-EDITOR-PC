"""Gera o editor offline em um único HTML, sem dependências externas."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
html = (root / 'src/index.template.html').read_text(encoding='utf-8')
for marker, name in [('/*__STYLE__*/', 'style.css'), ('/*__CATALOG__*/', 'catalog.js'), ('/*__LOOT__*/', 'loot-catalog.js'), ('/*__CORE__*/', 'core.js'), ('/*__COMPATIBILITY__*/', 'compatibility.js'), ('/*__RESOURCES__*/', 'resource-edit.js'), ('/*__ATTRIBUTES__*/', 'attributes.js'), ('/*__LEVELS__*/', 'levels.js'), ('/*__EQUIPMENT__*/', 'equipment.js'), ('/*__ENCHANTMENTS__*/', 'enchantments.js'), ('/*__ARMOR_LEVELS__*/', 'armor-levels.js'), ('/*__ANCIENTS__*/', 'armor-ancients.js'), ('/*__LEVEL_TARGETS__*/', 'level-targets.js'), ('/*__ID_LIST__*/', 'id-list.js'), ('/*__RESOURCE_POLICY__*/', 'resource-policy.js'), ('/*__WALLET__*/', 'wallet.js'), ('/*__SLOTS__*/', 'slots.js'), ('/*__NATIVE_RECORDS__*/', 'native-records.js'), ('/*__WEAPON_LEVELS__*/', 'weapon-levels.js'), ('/*__CAMPAIGN__*/', 'campaign.js'), ('/*__INVENTORY_CATALOG__*/', 'inventory-catalog.js'), ('/*__EQUIPMENT_CLONE__*/', 'equipment-record-clone.js'), ('/*__ARMOR_CLONE__*/', 'armor-template-clone.js'), ('/*__ENCHANTMENT_CLONE__*/', 'enchantment-instance-clone.js'), ('/*__INVENTORY__*/', 'inventory.js'), ('/*__INVENTORY_SELECTION__*/', 'inventory-selection.js'), ('/*__PLAN__*/', 'plan.js'), ('/*__UI__*/', 'ui.js')]:
    source = (root / 'src' / name).read_text(encoding='utf-8')
    assert '</script' not in source.lower()
    assert html.count(marker) == 1
    html = html.replace(marker, source)
for marker,name in [('/*__REMOVAL__*/','inventory-removal.js'),('/*__RUNICS__*/','runics.js'),('/*__CIPHERS__*/','ciphers.js'),('/*__BLADES_UNLOCK__*/','blades-unlock.js'),('/*__ENCHANTMENT_ACQUISITION__*/','enchantment-acquisition.js')]:
    source=(root/'src'/name).read_text(encoding='utf-8')
    assert '</script' not in source.lower() and html.count(marker)==1
    html=html.replace(marker,source)
runics=json.loads((root/'data/runic-catalog.json').read_text(encoding='utf-8'))
assert html.count('/*__RUNIC_DATA__*/')==1
html=html.replace('/*__RUNIC_DATA__*/',json.dumps(runics,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('&','\\u0026'))
acquisition=json.loads((root/'data/enchantment-acquisition.json').read_text(encoding='utf-8'))
assert html.count('/*__ENCHANTMENT_ACQUISITION_DATA__*/')==1
html=html.replace('/*__ENCHANTMENT_ACQUISITION_DATA__*/',json.dumps(acquisition,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('&','\\u0026'))
removal=json.loads((root/'data/inventory-removal.json').read_text(encoding='utf-8'))
assert html.count('/*__REMOVAL_DATA__*/')==1
html=html.replace('/*__REMOVAL_DATA__*/',json.dumps(removal,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('&','\\u0026'))
data = json.loads((root / 'data/catalog.json').read_text(encoding='utf-8'))
assert html.count('/*__CATALOG_DATA__*/') == 1
html = html.replace('/*__CATALOG_DATA__*/', json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
loot = json.loads((root / 'data/loot-table.json').read_text(encoding='utf-8'))
assert html.count('/*__LOOT_DATA__*/') == 1
html = html.replace('/*__LOOT_DATA__*/', json.dumps(loot, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
inventory = json.loads((root / 'data/inventory-profiles.json').read_text(encoding='utf-8'))
assert html.count('/*__INVENTORY_DATA__*/') == 1
html = html.replace('/*__INVENTORY_DATA__*/', json.dumps(inventory, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
clone = json.loads((root / 'data/armor-set-template.json').read_text(encoding='utf-8'))
assert html.count('/*__ARMOR_CLONE_DATA__*/') == 1
html = html.replace('/*__ARMOR_CLONE_DATA__*/', json.dumps(clone, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
equipment_clone = json.loads((root / 'data/equipment-record-templates.json').read_text(encoding='utf-8'))
assert html.count('/*__EQUIPMENT_CLONE_DATA__*/') == 1
html = html.replace('/*__EQUIPMENT_CLONE_DATA__*/', json.dumps(equipment_clone, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
weapons = json.loads((root / 'data/weapon-profiles.json').read_text(encoding='utf-8'))
assert html.count('/*__WEAPON_DATA__*/') == 1
html = html.replace('/*__WEAPON_DATA__*/', json.dumps(weapons, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
blades = json.loads((root / 'data/blades-acquisition.json').read_text(encoding='utf-8'))
assert html.count('/*__BLADES_ACQUISITION_DATA__*/') == 1
html = html.replace('/*__BLADES_ACQUISITION_DATA__*/', json.dumps(blades, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026'))
assert '/*__' not in html
(root / 'Abrir_Editor.html').write_text(html, encoding='utf-8')
print(root / 'Abrir_Editor.html')
