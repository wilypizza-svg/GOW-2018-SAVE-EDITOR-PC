/* Corrige apenas as duas entradas de catálogo; compara os demais escritores. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),oldRoot=path.join(ws,'diagnostico_armaduras_01/editor_original/Forja_2018_PC_0_17_0');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),selection=require('./src/inventory-selection'),plan=require('./src/plan'),oldInv=require(oldRoot+'/src/inventory'),oldPlan=require(oldRoot+'/src/plan'),policy=require('./src/inventory-catalog');
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
assert.equal(core.VERSION,'0.17.1');const blocked=['B1DFE124C69AF353','82D3E124C69AF353'];assert.deepEqual(policy.EXCLUDED_IDS,blocked);
assert.deepEqual(oldInv.PROFILES.filter(p=>!inv.PROFILES.some(q=>q.id===p.id)).map(p=>p.id),blocked);
for(const p of inv.PROFILES)assert.deepEqual(p,oldInv.PROFILES.find(q=>q.id===p.id));
const source=read('upload/game(AposRemoverOsDoisItensSuspeitos).sav'),model=core.parse(source),slot=model.latestSlot,sourceHash=sha(source),state=inv.inspect(source,slot,model);
const profiles=inv.PROFILES.filter(p=>p.kind==='talisman');assert.equal(profiles.length,41);
const ids=profiles.map(p=>p.id),requests=selection.buildMissing(state,ids,'template-max',true).map(r=>({...r,slot}));assert.equal(requests.length,26);
const result=plan.patch(source,requests),reference=oldPlan.patch(source,requests);same(result.bytes,reference.bytes);
assert.equal(result.model.slots[slot].table.count,548);assert.equal(sha(source),sourceHash);
for(const id of blocked){assert.ok(!inv.PROFILES.some(p=>p.id===id));assert.throws(()=>plan.patch(source,[{type:'inventory-equipment',slot,id,stage:0,allowExperimental:true}]),/receita/);assert.equal(sha(source),sourceHash);}
const returnedPath='upload/game(TodosOsTaslimãsDoJogo(AposRemoverOsItensSuspeitos)(Funcionou)).sav',returned=read(returnedPath),rm=core.parse(returned),rt=nat.read(returned,rm.latestSlot,rm),expected=nat.read(result.bytes,slot,result.model),rs=inv.inspect(returned,rm.latestSlot,rm);
for(const p of profiles){const r=rs.profiles.find(q=>q.id===p.id);assert.equal(r.owned,true,p.name);for(const id of p.ids)assert.equal(nat.quantity(rt,id),nat.quantity(expected,id),p.name);}
for(const id of blocked)assert.equal(nat.quantity(rt,id),null);
const unchanged=[];for(const name of fs.readdirSync(path.join(__dirname,'src'))){if(['core.js','inventory-catalog.js','ui.js','index.template.html'].includes(name))continue;same(fs.readFileSync(path.join(__dirname,'src',name)),fs.readFileSync(path.join(oldRoot,'src',name)));unchanged.push(name);}
// Armaduras, rúnicos, pomos, cabos e instâncias seguem os mesmos perfis e módulos.
for(const f of JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_17_1/baseline.json'))))assert.equal(sha(fs.readFileSync(f.path)),f.sha256);
const out=path.join(ws,'analysis_0_17_1/testes');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'Talismas_Validos_41.sav'),result.bytes);
fs.writeFileSync(path.join(out,'talismas_manifest.json'),JSON.stringify({source:path.resolve(ws,'upload/game(AposRemoverOsDoisItensSuspeitos).sav'),slot,output:path.join(out,'Talismas_Validos_41.sav'),profiles:profiles.filter(p=>requests.some(r=>r.id===p.id)),requests,sha256:sha(result.bytes)},null,2)+'\n');
const report={version:core.VERSION,passed:true,onlyExcludedProfileIds:blocked,allOtherProfilesIdentical:true,validTalismans:41,normalTalismans:profiles.filter(p=>p.variant==='normal').length,ngplusTalismans:profiles.filter(p=>p.variant==='NG+').length,bulkAdds26MissingProfilesWithoutExcludedItems:true,exportByteIdenticalTo0170ForSameValidRequests:true,userReturnedAll41TalismansAndTheirProgressionMatch:true,directRequestsForExcludedIdsRejected:true,originalBytesUnchanged:true,unchangedModules:unchanged,old0170SourcePreserved:true,oldBadIdsNotAutomaticallyDeletedFromSaves:true};fs.writeFileSync(path.join(__dirname,'VERIFICACAO_0_17_1.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
