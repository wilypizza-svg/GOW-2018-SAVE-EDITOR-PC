/* DOM simulado: confere eventos e dados; não substitui inspeção visual. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const elements = [], ids = new Map(), downloads = [], blobURLs = new Map();
class Element {
  constructor(tag, attrs = {}) {
    this.tagName = tag; this.attrs = attrs; this.id = attrs.id || '';
    this.value = attrs.value || ''; this.disabled = Object.hasOwn(attrs, 'disabled');
    this.hidden = Object.hasOwn(attrs, 'hidden'); this.checked = false;
    this.dataset = {}; this.listeners = {}; this.children = []; this.textContent = '';
    for (const [k, v] of Object.entries(attrs)) if (k.startsWith('data-')) this.dataset[k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = v;
    const classes = new Set((attrs.class || '').split(/\s+/));
    this.classList = { add: x => classes.add(x), remove: x => classes.delete(x), toggle: (x, v) => v ? classes.add(x) : classes.delete(x), contains: x => classes.has(x) };
    elements.push(this); if (this.id) ids.set(this.id, this);
  }
  addEventListener(event, fn) { (this.listeners[event] ||= []).push(fn); }
  async fire(event, extra = {}) { for (const fn of this.listeners[event] || []) await fn({ target: this, preventDefault() {}, ...extra }); }
  click() { if (this.tagName === 'a') downloads.push({ name: this.download, blob: blobURLs.get(this.href) }); else return this.fire('click'); }
  focus() {}
  remove() {}
  append() {}
  set innerHTML(html) {
    for (const old of this.children) { old.removed = true; if (old.id && ids.get(old.id) === old) ids.delete(old.id); }
    this.children = parseHTML(html);
    if (this.tagName === 'select') this.value = this.children.find(x => x.tagName === 'option')?.attrs.value || '';
    this._html = html;
  }
  get innerHTML() { return this._html || ''; }
}
function parseHTML(html) {
  const result = [];
  for (const match of html.matchAll(/<([a-z][\w-]*)(\s[^<>]*?)?\/?\s*>/gi)) {
    const attrs = {};
    for (const a of (match[2] || '').matchAll(/([\w-]+)(?:="([^"]*)")?/g)) attrs[a[1]] = (a[2] || '').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
    result.push(new Element(match[1], attrs));
  }
  return result;
}
const template = fs.readFileSync(path.join(__dirname, 'src/index.template.html'), 'utf8').split('<script>')[0];
parseHTML(template);
const query = selector => elements.filter(el => !el.removed && (selector.startsWith('.') ? el.classList.contains(selector.slice(1)) : selector.startsWith('[') ? Object.hasOwn(el.attrs, selector.slice(1, -1)) : false));
const document = { getElementById: id => ids.get(id), querySelectorAll: query, querySelector: s => query(s)[0],
  createElement: tag => new Element(tag), body: { append() {} } };

const context={ document, structuredClone, Intl, Number, Object, String, JSON, Date, Blob, Uint8Array, ArrayBuffer, DataView, TextDecoder,
 URL:{ createObjectURL(blob){const key='blob:'+blobURLs.size;blobURLs.set(key,blob);return key;},revokeObjectURL(){} },
 setTimeout(){return 1;},clearTimeout(){} };
context.window=context;vm.createContext(context);
const html=fs.readFileSync(path.join(__dirname,'Abrir_Editor.html'),'utf8');
for(const script of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)){
 if(script[1].includes('application/json'))document.getElementById(script[1].match(/id="([^"]+)"/)[1]).textContent=script[2];
 else vm.runInContext(script[2],context);
}
const $=id=>{const element=ids.get(id);if(!element)throw new Error('Controle ausente: '+id);return element;};
module.exports={api:context.Forja2018Editor,context,document,query,downloads,$};
