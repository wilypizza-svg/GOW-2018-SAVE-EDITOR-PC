"""Extrai metadados da planilha, sem alterá-la ou executar fórmulas/comandos.
Uso: python3 import_loot_table.py 'God of War Loot Table.xlsx'
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

source = Path(sys.argv[1])
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(source) as z:
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si', ns):
            shared.append(''.join(t.text or '' for t in si.findall('.//s:t', ns)))
    rels = {r.attrib['Id']: r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheet = next(s for s in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet', ns) if s.attrib['name'] == 'RESOURCES_PERM_DATA')
    target = rels[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
    target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
    rows = []
    for row in ET.fromstring(z.read(target)).findall('s:sheetData/s:row', ns):
        cells = {}
        for cell in row.findall('s:c', ns):
            v = cell.find('s:v', ns)
            value = v.text if v is not None else None
            if cell.attrib.get('t') == 's' and value is not None:
                value = shared[int(value)]
            elif cell.attrib.get('t') == 'inlineStr':
                value = ''.join(t.text or '' for t in cell.findall('.//s:t', ns))
            cells[re.sub(r'\d', '', cell.attrib['r'])] = value
        rows.append((int(row.attrib['r']), cells))

text_fields = dict(internalName='D', gameName='E', owner='F', set='G', category='H', subCategory='I', rarity='J', inventoryHash='C')
numeric_fields = dict(sourceIndex='B', level='L', sockets='M', strength='N', runic='O', defense='P', vitality='Q', luck='R', cooldown='S')
groups = {}
for row, cells in rows:
    perm = (cells.get('A') or '').strip().upper()
    if not re.fullmatch('[0-9A-F]{16}', perm):
        continue
    id = bytes.fromhex(perm)[::-1].hex().upper()
    group = groups.setdefault(id, dict(id=id, permHash=perm, sourceRows=[], values={}))
    group['sourceRows'].append(row)
    for field, col in text_fields.items():
        value = (cells.get(col) or '').strip()
        if value and value.upper() not in ['PLACEHOLDER', 'UNKNOWN', 'NONE']:
            group['values'].setdefault(field, set()).add(value)
    for field, col in numeric_fields.items():
        try:
            value = float(cells.get(col))
        except (ValueError, TypeError):
            continue
        group['values'].setdefault(field, set()).add(value)

items = []
for id, group in sorted(groups.items()):
    values = group.pop('values')
    conflicts = {}
    for field, choices in values.items():
        if len(choices) == 1:
            group[field] = next(iter(choices))
        else:
            conflicts[field] = sorted(choices)
    if conflicts:
        group['sourceConflicts'] = conflicts
    assert group.get('internalName'), id
    items.append(group)

data = dict(sourceFile=source.name, sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(), sheet='RESOURCES_PERM_DATA',
            idByteOrder='PERM_Hash reversed by bytes for literal save order', indexIsNotLevelMapKey=True, items=items)
destination = Path(__file__).parent / 'data/loot-table.json'
destination.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(uniqueIds=len(items), sourceConflicts=sum('sourceConflicts' in x for x in items), destination=str(destination))))
