# Forja 2018 PC 0.19.0 — implementação e evidências

Data: 25/10/2026. Os testes no jogo são os relatados pelo José; a análise automatizada foi feita nos arquivos binários.

## Catálogo e inclusão em lote

O catálogo passa de 17 para **107 perfis**, com **92 NG normal** e **15 NG+**. São **90 modelos novos do NG normal**: **72 comuns e 18 únicos**, observados integralmente nas amostras. Os sete pares controlados também foram incorporados, inclusive o Signo Robusto de Sorte, cuja primeira lista contém dois códigos. Nenhuma lista foi reduzida a um único identificador.

Entre os nomes associados estão Heart of Vanaheim, Heart of Midgard, Heart of the Valkyrie, Njord's Temporal Stone, Muspelheim's Eye of Power, Hroodr's Frozen Shard e Signo Robusto de Sorte. Parte das associações vem do catálogo e da combinação de nível/atributos; a interface pede a conferência quando o nome não foi confirmado. Perfis ambíguos são descritos pelos atributos.

Os modelos novos têm cabeçalho, tipo, listas de efeitos e atributos completos. São reservadas identidades novas, com vínculo e encaixe livres. Um construtor completo observado pode ser reproduzido na mesma gramática PC sem transplantar o estado de mundo. Nas três aquisições que mostram uma flag de criação específica, essa flag e sua metadata foram mapeadas; nos outros casos não se inventa um item/contador binário a partir do código lógico usado pelo catálogo.

A seleção identifica o perfil pelos campos completos e pelas duas listas. Perfis de níveis/efeitos diferentes que compartilham um código deixam de ser confundidos. Um exemplar existente é preservado, inclusive seus atributos aleatórios. A inclusão entrega uma unidade por perfil ausente; não acrescenta cópias extras de únicos.

**Os 90 modelos novos ainda aguardam teste de inclusão pelo editor no jogo.** O fato de existirem em saves nativos e passarem em leitores independentes não substitui esse teste. Os 17 perfis anteriores continuam com suas evidências anteriores de inclusão e persistência.

## Conversões e coexistência

A orientação para converter marcas pelo jogo é **PREFERÍVEL**, sem bloquear o usuário que escolhe a inclusão pelo editor. As cinco marcas podem ser adicionadas mesmo havendo ingredientes/peças. Nenhum material, equipamento ou Hacksilver é consumido por essa inclusão.

Retorno `game(MarcaPerfeitaDoTYR+SETCOMPLETODOTYR).sav`:

- SHA-256: `993b00ffb7aa47c3941ea33449a05362ebdbb7965e1929a9f8355311ce8c978d`.
- Slot interno 11, build original 4438700.
- Marca Perfeita de Týr +, UID 57, vinculada ao peitoral de Týr.
- Peitoral, braçadeiras e cintura de Týr + presentes, com todos os upgrades em 1.
- Foto fornecida mostra o peitoral nível 9 equipado e a marca em seu encaixe.

Isso comprova a coexistência testada de Týr. Não é uma garantia universal para conversões de outras marcas. O editor não simula nem altera as regras da loja.

## Armas NG+ incorporadas

O ensaio aprovado é reproduzido byte a byte: Machado 2→6 e Lâminas 1→5. O retorno nativo `game(NGP_01_ARMAS_MAXIMAS(Funcionou)).sav` preservou os mapas e todos os registros de melhoria. SHA-256: `d9d4a4bd2002b985b9ca318d8b896de4f42e8b4387ca5a63bb82b4d311796f4c`. O jogo regravou o salvamento no slot interno 17; o controle estava no 7.

As referências isoladas das propriedades se deslocaram 159 bytes depois da regravação, mantendo seus contextos. A identificação usa esses contextos completos, as duas flags de NG+, os dois mapas sincronizados e um histórico contínuo. Não usa um offset fixo nem libera por número de build.

Referências adicionais, contextos desconhecidos, mapas divergentes, ausência de flag NG+ e lacunas continuam bloqueados. O mundo fica intacto no modo de dois mapas. O caso com Machado originalmente nível 1 permanece fora desta ampliação; a amostra aprovada começou no 2. Não libera armas da história nem o menu NG+.

## Verificações

- Todos os 90 perfis novos foram exercitados numa fixture técnica sem seus exemplares anteriores. Essa fixture não é um save declarado válido para jogar.
- Sete pares nativos controlados: modelos encontrados antes/depois e inclusões estruturalmente conferidas.
- Três lotes em saves reais, com 16, 88, 104 inclusões, respectivamente. Uma segunda aplicação preserva o arquivo sem duplicar instâncias.
- Lote e aplicação sequencial geram os mesmos bytes.
- Todos os 17 perfis antigos geram os mesmos bytes da 0.18.0 nos casos de regressão.
- Leitor Python independente confirma gramática, novos blocos completos, identidades, limites e preservação dos registros anteriores nos três lotes.
- As cinco marcas com todos os IDs de ingredientes presentes são incluídas sem bloquear nem consumir os IDs ou Hacksilver.
- Interface executada em DOM simulado: filtros, busca com acento, inclusão individual/em lote, revisão, desfazer, exportação, relatório, recomendação sem bloqueio e ajustes NG+.
- Oito testes negativos das armas, além da regressão de Machado e Lâminas no NG normal.
- Os oito ensaios de remoção continuam byte a byte iguais, com as oito proteções negativas preservadas. Reinclusão do pomo vendido continua funcionando.
- As saídas dos ensaios anteriores de capacidades de vida/fúria e Ivaldi normal com cabos também coincidem com os arquivos aprovados.
- O HTML final foi executado novamente para conferir a classificação e os 107 nomes distintos depois da revisão de rótulos.

O gravador nativo mantém o limite de 32 novas instâncias por escrita. Lotes maiores são compostos em etapas internas; os intermediários não são exportados. O limite de 512 registros auxiliares e a reserva de espaço nativa continuam sendo verificados.

## Preservação e pendências

Os modelos e IDs de armaduras, pomos, cabos, talismãs e rúnicos não foram ampliados nem alterados nesta versão. Recursos, atributos, campanha, cifras e a rotina de remoção mantêm seus módulos. A comparação de preservação e os oito ensaios de remoção constam nos relatórios desta versão.

Continuam pendentes: inclusão dos novos modelos NG no jogo; nomes restantes; Machado NG+ inicialmente no nível 1; roupas de Atreus; rúnicos de Atreus; ativação do menu NG+ por amostra isolada; outros modos de dificuldade. As amostras já coletadas dessas funções continuam registradas em `RELATORIO_IMPLEMENTACAO_0_18_0.md`. A inclusão direta em encaixes continua retirada; o usuário equipa pelo jogo.

Os saves pessoais não acompanham o pacote de código-fonte. Os relatórios históricos permanecem identificados pela versão.
