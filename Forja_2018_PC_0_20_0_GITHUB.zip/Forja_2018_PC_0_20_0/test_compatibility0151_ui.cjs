/* Executa o HTML final com o save antigo que reproduziu os bloqueios. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,$,query,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),native=require('./src/native-records'),inventory=require('./src/inventory'),oldPlan=require('../Forja_2018_PC_0_15_0/src/plan');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),load=p=>new Uint8Array(fs.readFileSync(path.join(ws,p))),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const ok=()=>assert.equal($('error').hidden,true,$('error').textContent),change=async(id,value)=>{$(id).value=String(value);await $(id).fire('change');};
(async()=>{
 const original=load('upload/game(20261024-134912).sav'),model=core.parse(original),slot=model.latestSlot;
 api.loadBytes(original,'game.sav');api.selectSlot(slot);api.chooseView('levels');
 assert.equal($('level-original').textContent,'Nível 3');assert.equal($('level-target').disabled,false);assert.equal($('blades-level-target').disabled,true);assert.match($('blades-level-note').textContent,/registros das Lâminas/);
 assert.match($('armor-level-note').textContent,/Esse peitoral não consta/);
 api.chooseView('equipment');await change('inventory-item','615B1370AEBED3EA');assert.equal($('inventory-apply').disabled,false);assert.match($('inventory-note').textContent,/Compatibilidade/);
 await $('inventory-apply').click();ok();assert.match($('changes-body').innerHTML,/Breastplate of the Traveler/);assert.equal(api.exportBytes().model.slots[slot].build,4389704);
 const state=inventory.inspect(original,slot),pommel=state.profiles.find(p=>p.kind==='axe'&&p.variant==='normal'&&!p.owned&&p.available);
 assert.ok(pommel);$('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');await change('inventory-kind','axe');await change('inventory-item',pommel.id);await $('inventory-apply').click();ok();
 api.chooseView('levels');await change('level-target',6);await $('level-apply').click();ok();assert.equal($('level-edited').textContent,'Nível 6');
 api.chooseView('campaign');assert.equal($('apples-total').disabled,false);assert.equal($('horns-total').disabled,false);assert.equal($('niflheim-cipher-total').disabled,false);assert.equal($('muspelheim-cipher-total').disabled,false);
 $('apples-total').value='9';await $('apples-apply').click();ok();$('horns-total').value='9';await $('horns-apply').click();ok();
 $('niflheim-cipher-total').value='4';await $('niflheim-cipher-apply').click();ok();$('muspelheim-cipher-total').value='4';await $('muspelheim-cipher-apply').click();ok();
 const edited=api.exportBytes();assert.equal(edited.model.build,4389704);assert.equal(edited.model.slots[slot].build,4389704);assert.equal(edited.log.length,7);
 api.chooseView('changes');assert.equal($('change-count').textContent,'7 alterações');await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),edited.bytes);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.15.1');assert.equal(report.changes.length,7);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),original);
 const undo=query('[data-undo]').find(e=>e.dataset.undo===slot+':615B1370AEBED3EA');assert.ok(undo);await undo.click();ok();assert.equal(api.getState().log.length,6);
 await $('reset-changes').click();ok();assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 // Slots de início não possuem todos os contadores; zero é inferido como
 // nas amostras da versão nova, e os campos são criados pela mesma rotina.
 api.selectSlot(10);api.chooseView('campaign');assert.equal($('apples-total').value,'1');assert.equal($('apples-total').disabled,false);assert.equal($('horns-total').disabled,false);
 $('apples-total').value='9';await $('apples-apply').click();ok();assert.equal(api.exportBytes().model.slots[10].build,4389704);
 // Mantém a edição NG+ que já funcionava na versão anterior.
 const ngp=load('upload/game(10).sav'),nm=core.parse(ngp);api.loadBytes(ngp,'game.sav');api.selectSlot(nm.latestSlot);api.chooseView('levels');assert.equal($('level-original').textContent,'Nível 6');await change('level-target',5);await $('level-apply').click();ok();
 same(api.exportBytes().bytes,oldPlan.patch(ngp,[{slot:nm.latestSlot,type:'weapon-level',id:'axe-main-level',level:5}]).bytes);
 const result={version:core.VERSION,executedBuiltHtmlInSimulatedDom:true,old4389704Axe3Shown:true,equipmentAndArmorAdditionEnabled:true,mixedEquipmentWeaponCapacitiesAndCiphersPassed:true,buildNumbersPreserved:true,missingBladesAndAbsentArmorMessagesSpecific:true,earlyCounterCreationEnabled:true,reviewUndoResetOriginalSaveAndReportPassed:true,previous4757534NgpExportByteIdentical:true,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_COMPATIBILIDADE_INTERFACE_0_15_1.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
