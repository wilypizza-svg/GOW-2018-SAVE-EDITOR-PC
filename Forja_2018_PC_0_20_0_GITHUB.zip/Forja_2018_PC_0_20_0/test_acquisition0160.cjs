/* Regressão pelos arquivos aprovados no jogo e limites da nova aquisição. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),core=require('./src/core'),nat=require('./src/native-records'),acq=require('./src/enchantment-acquisition'),ench=require('./src/enchantments'),inv=require('./src/inventory'),plan=require('./src/plan'),oldPlan=require(path.join(ws,'Forja_2018_PC_0_15_2/src/plan'));
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m='Bytes divergentes')=>assert.ok(nat.equal(a,b),m),out=path.join(ws,'analysis_0_16_0/testes');fs.mkdirSync(out,{recursive:true});
const previous=n=>JSON.parse(fs.readFileSync(path.join(ws,n))),r1=previous('analysis_encantamentos_01/verificacao_javascript.json'),r2=previous('analysis_encantamentos_02/verificacao_javascript.json'),r3=previous('analysis_encantamentos_03/verificacao_javascript.json'),cases=[];
const request=(id,slot)=>({type:'enchantment-create',id,slot,count:1});
function approve(name,source,index,requests,reference){
 const b=read(source),hash=sha(b),m=core.parse(b),result=plan.patch(b,requests);same(result.bytes,read(reference),name);
 const a=nat.read(b,index,m),n=nat.read(result.bytes,index,result.model);for(const o of a.state.objects){const next=n.state.objects.find(v=>v.uid===o.uid);assert.ok(next);same(b.subarray(o.start,o.end),result.bytes.subarray(next.start,next.end));}
 for(const s of m.slots)if(s.index!==index)same(b.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end));assert.ok(n.finals.length<=512);
 same(plan.patch(result.bytes,requests).bytes,result.bytes,'Repetir o plano deve preservar os existentes.');assert.equal(sha(fs.readFileSync(path.resolve(ws,source))),hash);
 const output=path.join(out,name+'.sav');fs.writeFileSync(output,result.bytes);cases.push({name,source:path.resolve(ws,source),slot:index,output,sha256:sha(result.bytes),requests,approvedReference:path.resolve(ws,reference)});return result;
}
approve('Bestla_B_Aprovado',r1.source,r1.slot-1,[request(inv.BESTLA,r1.slot-1)],r1.cases.find(c=>c.name.startsWith('ENC_02_B')).output);
for(const c of r2.cases.filter(c=>c.items.length))approve(c.name,r2.source,c.slot,c.items.map(p=>request(p.id,c.slot)),c.output);
approve('Misto_Aprovado',r3.source,r3.slot,[...r3.gearRequests,request(inv.BESTLA,r3.slot)],r3.output);
const source=read(r2.source),model=core.parse(source),slot=model.latestSlot,all=acq.PROFILES.map(p=>request(p.id,slot)),batch=plan.patch(source,all);
let sequential=source;for(const r of all)sequential=plan.patch(sequential,[r]).bytes;same(batch.bytes,sequential,'O lote e as inclusões sequenciais divergem.');
for(const r of all){const state=acq.inspectTx(nat.read(batch.bytes,slot),r.id);assert.equal(state.owned,true);assert.equal(state.quantity,1);}
same(plan.patch(batch.bytes,all).bytes,batch.bytes);
for(const count of [0,2,-1,1.5,'1'])assert.throws(()=>plan.patch(source,[{...all[0],count}]),/uma unidade/);
assert.throws(()=>plan.patch(source,[all[0],all[0]]),/dois pedidos/);
assert.throws(()=>plan.patch(source,[{...all[0],id:'0000000000001234'}]),/receita/);
const fakeCounter=nat.read(source,slot);nat.putQuantity(fakeCounter,inv.BESTLA,1,true);const fake=nat.write(fakeCounter).bytes;assert.equal(acq.inspectTx(nat.read(fake,slot),inv.BESTLA).available,false);assert.throws(()=>plan.patch(fake,[all[0]]),/contador|instância/);
const first=plan.patch(source,[all[0]]),multiple=nat.read(first.bytes,slot),object=multiple.state.objects.find(o=>o.uid===first.log[0].uids[0]),copy=first.bytes.slice(object.start,object.end);nat.view(copy).setUint32(48,10000,true);multiple.newObjects=[copy];nat.putQuantity(multiple,inv.BESTLA,2);const multi=nat.write(multiple).bytes;assert.equal(acq.inspectTx(nat.read(multi,slot),inv.BESTLA).available,false);assert.throws(()=>plan.patch(multi,[all[0]]),/múltiplos/);
const notification=nat.read(source,slot),uid=new Uint8Array(8);nat.view(uid).setUint32(0,9000,true);nat.ensureFinal(notification,core.hex(uid),'02000000F37F0000');const notice=nat.write(notification).bytes,reserved=plan.patch(notice,[all[0]]);assert.equal(reserved.log[0].uids[0],9001);
const missing=source.slice(),mt=nat.read(source,slot),type=nat.fromHex(acq.lookup(inv.BESTLA).raw).subarray(64,72);let changed=0;
for(const o of mt.state.objects)if(nat.equal(missing.subarray(o.start+64,o.start+72),type)){missing.fill(0x11,o.start+64,o.start+72);changed++;}
assert.ok(changed);assert.equal(acq.inspectTx(nat.read(missing,slot),inv.BESTLA).available,false);assert.throws(()=>plan.patch(missing,[all[0]]),/bloco.*compatível/);
const ngp=read(r1.source),ngpm=core.parse(ngp),ngpt=nat.read(ngp,ngpm.latestSlot,ngpm);assert.equal(acq.inspectTx(ngpt,inv.BESTLA).available,true);const guard=acq.inspectTx(ngpt,'55BDD9C3C4D9A673');assert.equal(guard.available,false);assert.match(guard.reason,/conversão/);
const rawUnique=nat.fromHex(acq.lookup('55BDD9C3C4D9A673').raw),rule=ench.classifyRaw(rawUnique);assert.equal(rule.unique,true);assert.equal(rule.name,'Marca Perfeita do Viajante +');
const target=JSON.parse(fs.readFileSync(path.join(ws,'entrega_encantamentos_03/GOW2018_Encantamentos_Perfis_Confirmados.json'))).profiles.find(p=>p.id==='D8D691E895C29078');assert.equal(ench.classifyRaw(nat.fromHex(target.raw)).unique,true);
const metadata=source.slice();nat.view(metadata).setUint32(12,9000001,true);nat.view(metadata).setUint32(model.slots[slot].base+12,9000002,true);const meta=plan.patch(metadata,all),expected=batch.bytes.slice();nat.view(expected).setUint32(12,9000001,true);nat.view(expected).setUint32(model.slots[slot].base+12,9000002,true);same(meta.bytes,expected,'Build usado como bloqueio.');
// O retorno misto guarda os três perfis em Zeus; reaplicar não duplica nada.
const returnedName='upload/game(ENC_06_Misto_Bestla_Zeus_Retribuicao(Funcionou)).sav',returned=read(returnedName),rm=core.parse(returned),rt=nat.read(returned,rm.latestSlot,rm),re=ench.inspect(returned,rm.latestSlot,rm);assert.ok(rt.finals.length<=512);const returnedItems=[];
for(const p of acq.PROFILES){const state=acq.inspectTx(rt,p.id);assert.equal(state.owned,true);const o=re.objects.find(o=>o.uid===state.uid);assert.equal(o.bindingId,'4339AAC6C42CC83D');returnedItems.push({id:p.id,uid:o.uid,socket:o.socket+1,armor:o.armorName,quantity:1});}
assert.deepEqual(returnedItems.map(i=>i.socket).sort(),[1,2,3]);same(plan.patch(returned,acq.PROFILES.map(p=>request(p.id,rm.latestSlot))).bytes,returned);
// Regressões dos escritores que não foram alterados.
const oldCases=[];for(const c of previous('analysis_0_14_0/testes/manifest.json').cases.filter(c=>['10_','12_','13_','14_'].some(n=>c.name.startsWith(n)))){assert.equal(sha(plan.patch(read(c.source),c.requests).bytes),c.sha256);oldCases.push(c.name);}
const control=read('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),five=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+').map(p=>({type:'inventory-equipment',id:p.id,slot:14,stage:2}));same(plan.patch(control,five).bytes,oldPlan.patch(control,five).bytes);
const legacy=[{type:'enchantment-create',id:inv.MENACE,slot:ngpm.latestSlot,count:1}];same(plan.patch(ngp,legacy).bytes,oldPlan.patch(ngp,legacy).bytes);
for(const file of ['native-records.js','resource-edit.js','wallet.js','resource-policy.js','equipment-record-clone.js','armor-template-clone.js','enchantment-instance-clone.js','plan.js'])same(fs.readFileSync(path.join(__dirname,'src',file)),fs.readFileSync(path.join(ws,'Forja_2018_PC_0_15_2/src',file)),file);
for(const p of previous('analysis_0_16_0/baseline_manifest.json'))assert.equal(sha(fs.readFileSync(p.path)),p.sha256,p.path);
const report={version:core.VERSION,approvedOutputsByteIdentical:cases.map(c=>c.name),mixedReturnVerified:{sha256:sha(returned),slot:rm.latestSlot+1,queue:rt.finals.length,items:returnedItems},batchAndSequentialIdentical:true,existingInstancesNeverDuplicated:true,invalidCountsPartialCountersDuplicateInstancesAndMissingTemplateBlocked:true,conversionIngredientCoexistenceBlocked:true,newIdentitySkipsPendingNotification:true,uniqueClassificationVerified:true,noBuildAllowlist:true,oldApprovedExportsByteIdentical:oldCases,resourceAndEquipmentWritersUnchanged:true,legacyMenaceWriterUnchanged:true,old0152Preserved:true,uiCoverageReportedSeparately:true};
fs.writeFileSync(path.join(ws,'analysis_0_16_0/testes/manifest.json'),JSON.stringify({version:core.VERSION,cases},null,2)+'\n');fs.writeFileSync(path.join(__dirname,'VERIFICACAO_AQUISICAO_0_16_0.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
