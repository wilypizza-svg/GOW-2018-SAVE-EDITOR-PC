'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const ancients=require('./src/armor-ancients'),targets=require('./src/level-targets'),plan=require('./src/plan'),baseCatalog=require('./src/catalog'),loot=require('./src/loot-catalog');
const [baseFile,lastFile,oldFile]=process.argv.slice(2),read=p=>new Uint8Array(fs.readFileSync(p));
const same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b))),id=ancients.PROFILE.id;
const choose=async value=>{$('armor-level-target').value=String(value);await $('armor-level-target').fire('change');};
(async()=>{
 api.chooseView('catalog');await $('catalog-download').click();let txt=await downloads.at(-1).blob.text();assert.ok(txt.includes('1683 de 1683 IDs'));assert.ok(txt.includes('Atreus Power I'));
 $('catalog-search').value='Njord';await $('catalog-search').fire('input');assert.ok($('catalog-body').innerHTML.includes("Njord&#39;s Temporal Stone"));
 await $('catalog-download').click();txt=await downloads.at(-1).blob.text();assert.ok(txt.includes("Njord's Temporal Stone"));assert.ok(!txt.includes('Hacksilver'));
 $('catalog-search').value='9E8ADECDD9C87B97';await $('catalog-search').fire('input');assert.ok($('catalog-body').innerHTML.includes('Nível na tabela: 3'));assert.ok($('catalog-body').innerHTML.includes('Encaixes na tabela: 1'));
 const input=read(baseFile);api.loadBytes(input);api.selectSlot(12);api.chooseView('levels');
 assert.equal($('armor-level-profile').value,id);assert.ok($('armor-level-name').textContent.includes('Pauldron of the Ancients'));assert.equal($('armor-level-target').value,'0');
 assert.equal($('armor-level-target').children.filter(e=>e.tagName==='option'&&!e.disabled).length,3);
 await choose(2);assert.equal($('armor-level-apply').disabled,false);await $('armor-level-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
 same(api.exportBytes().bytes,plan.patch(input,[{slot:12,id,type:'level-target',target:2}]).bytes);assert.equal(api.getState().layout.length,2);
 assert.equal($('armor-level-edited').textContent,'Melhoria 2');
 await $('report-download').click();let report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.9.0');assert.equal(report.layout.length,2);
 await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
 await choose(1);await $('armor-level-apply').click();assert.equal(targets.inspect(api.exportBytes().bytes,12,id).registeredMax,1);assert.equal(api.getState().changes.length,1);
 await choose(0);await $('armor-level-apply').click();assert.equal(api.getState().log.length,0);
 $('armor-level-profile').value='armor-defender-chest';await $('armor-level-profile').fire('change');assert.equal($('armor-level-apply').disabled,true);
 $('armor-level-target').value='2';await $('armor-level-apply').click();assert.equal($('error').hidden,false);assert.equal(api.getState().log.length,0);
 api.loadBytes(read(lastFile));api.selectSlot(12);api.chooseView('levels');await choose(0);await $('armor-level-apply').click();
 const lowered=api.exportBytes().bytes;api.loadBytes(lowered);api.selectSlot(12);api.chooseView('levels');assert.equal($('armor-level-target').value,'0');
 await choose(2);await $('armor-level-apply').click();same(api.exportBytes().bytes,read(lastFile));
 await query('[data-undo]').find(e=>e.dataset.undo==='12:'+id).click();assert.equal($('armor-level-edited').textContent,'Base · sem reforço');
 api.loadBytes(read(oldFile));api.selectSlot(11);api.chooseView('levels');assert.equal($('armor-level-profile').value,'armor-defender-chest');
 const enriched=loot.catalog.items.filter(x=>!baseCatalog.lookup(x.id)?.hasCleanName&&baseCatalog.lookup(x.id)&&x.hasCleanName);
 assert.equal(enriched.length,219);assert.equal(loot.catalog.items.length,1683);assert.equal(baseCatalog.items.length,1682);
 const reportResult={version:'0.9.0',htmlExecutedInVM:true,autoSelectsRecognizedArmorInPhysicalSlot13:true,baseToOneAndTwoChoicesShown:true,
 directTwoStepsDownloadAndReportChecked:true,pendingChangeReplacementAndCancellationChecked:true,reopeningLoweredHistoryAndReturningChecked:true,
 unsupportedArmorCannotChangeDraft:true,oldDefenderSelectionStillWorks:true,catalogReadableNamesAdded:219,catalogTotal:1683,
 unfilteredAndFilteredTextIdDownloadsChecked:true,lootReferenceLevelAndSocketsDisplayed:true,coreCatalogAndWriteWhitelistUnchanged:true,
 visualBrowserTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ANCESTRAIS_INTERFACE_0_9_0.json'),JSON.stringify(reportResult,null,2));console.log(JSON.stringify(reportResult,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
