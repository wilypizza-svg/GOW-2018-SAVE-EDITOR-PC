'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const {api,$,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),nat=require('./src/native-records');
const workspace=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const load=p=>new Uint8Array(fs.readFileSync(path.join(workspace,p))),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const original=load('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),approved=load('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav');
const change=async(id,value)=>{$(id).value=value;await $(id).fire('change');},ok=()=>assert.equal($('error').hidden,true,$('error').textContent);
(async()=>{
 api.loadBytes(original,'game.sav');api.selectSlot(14);api.chooseView('equipment');
 await change('inventory-kind','blades');await change('inventory-variant','NG+');
 assert.equal($('inventory-item').children.filter(x=>x.tagName==='option').length,5);
 assert.equal($('inventory-experimental').checked,false);
 await change('inventory-item','A8850E68CC1A3CB4');assert.equal($('inventory-stage').value,'2');
 const options=$('inventory-stage').children.filter(x=>x.tagName==='option');assert.equal(options.length,3);assert.equal(options[0].disabled,true);assert.equal(options[1].disabled,true);assert.equal(options[2].disabled,false);
 assert.equal($('inventory-apply').disabled,false);assert.match($('inventory-note').textContent,/nível 9/);
 await $('inventory-apply').click();ok();assert.equal(nat.quantity(nat.read(api.exportBytes().bytes,14),'A8850E68CC1A3CB4'),1);
 assert.equal($('inventory-apply').disabled,true);assert.equal(nat.read(api.exportBytes().bytes,14).finals.length,512);
 await $('reset-changes').click();ok();
 await change('inventory-item','A8850E68CC1A3CB4');await change('inventory-stage','0');assert.equal(api.getState().changes.length,0);await $('inventory-apply').click();assert.equal($('error').hidden,false);assert.equal(api.getState().changes.length,0);assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 // O lote pela interface deve exportar o mesmo arquivo já aprovado no jogo.
 api.loadBytes(original,'game.sav');api.selectSlot(14);api.chooseView('equipment');await change('inventory-kind','blades');await change('inventory-variant','NG+');
 await change('inventory-bulk-mode','mapped-max');assert.equal($('inventory-bulk').disabled,false);await $('inventory-bulk').click();ok();
 const out=api.exportBytes();same(out.bytes,approved);assert.equal(out.log.length,5);assert.equal(nat.read(out.bytes,14).finals.length,512);
 await $('export-top').click();const sav=downloads.at(-1);assert.ok(sav);same(new Uint8Array(await sav.blob.arrayBuffer()),approved);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.14.3');assert.equal(report.changes.length,5);
 await $('reset-changes').click();ok();await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),original);
 const played=load('upload/game(Cursed_F_Cinco_Cabos_NGmais_Nivel9(Funcionou)).sav');api.loadBytes(played,'game.sav');api.selectSlot(core.parse(played).latestSlot);api.chooseView('equipment');await change('inventory-kind','blades');await change('inventory-variant','NG+');
 assert.equal($('inventory-bulk').disabled,true);await change('inventory-item','A8850E68CC1A3CB4');assert.equal($('inventory-apply').disabled,true);assert.equal(api.getState().changes.length,0);assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 const result={version:'0.14.3',executedBuiltHtmlInSimulatedDom:true,fiveNgpChoicesAvailableWithoutExperimentalOptIn:true,maximumOnlyStagesEnforced:true,
 individualAdditionAndDuplicatePreventionPassed:true,forcedUnsupportedStagePreservesDraft:true,bulkExportByteIdenticalToGameApprovedFile:true,saveDownloadOriginalDownloadResetAndReportPassed:true,
 gameResavedOwnedHandlesPreserved:true,actualBrowserVisualTest:false,newBuildRunInGameHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_14_3.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
