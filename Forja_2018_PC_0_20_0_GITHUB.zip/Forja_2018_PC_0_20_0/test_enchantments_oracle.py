"""Oráculo binário independente: nenhuma importação dos módulos JavaScript.
Uso: python3 test_enchantments_oracle.py original editado slot '[ [alvo, modelo], ... ]'
Slot = índice físico com base zero. Verifica toda a transformação e os bytes externos.
"""
from pathlib import Path
import json
import struct
import sys

original, edited = map(lambda name: Path(name).read_bytes(), sys.argv[1:3])
slot_index = int(sys.argv[3])
requests = json.loads(sys.argv[4])
base = 4160 + slot_index * 1677512
table = base + 66589
stats_header = table - 24

def u32(data, pos):
    return struct.unpack_from('<I', data, pos)[0]

def objects(data):
    count, refs, instances = struct.unpack_from('<III', data, table - 12)
    cursor = table + count * 16 + refs * 8
    result = {}
    for _ in range(instances):
        start = cursor
        assert data[start:start + 8] == bytes.fromhex('3B056E1555DABD5D')
        uid = u32(data, start + 48)
        assert uid not in result
        cursor += 72
        for _ in range(2):
            length = u32(data, cursor)
            assert length <= 64
            cursor += 4 + length * 4
        length = u32(data, cursor)
        assert length <= 64
        cursor += 4 + length * 12
        result[uid] = (start, cursor)
    return result

before, after = objects(original), objects(edited)
assert set(before) == set(after)
edits = []
for target_uid, template_uid in requests:
    start, end = before[target_uid]
    source, source_end = before[template_uid]
    copy = bytearray(original[source:source_end])
    copy[8:16] = original[start + 8:start + 16]
    copy[48:64] = original[start + 48:start + 64]
    edits.append((start, end, copy))
    new_start, new_end = after[target_uid]
    assert edited[new_start:new_end] == copy

old_end = base + 0x10400 + u32(original, base + 0x124)
delta = sum(len(copy) - (end - start) for start, end, copy in edits)
new_end = old_end + delta
expected = bytearray(original)
cursor = base
chunks = []
for start, end, copy in sorted(edits):
    assert start >= cursor
    chunks.extend((original[cursor:start], copy))
    cursor = end
chunks.append(original[cursor:old_end])
expected[base:new_end] = b''.join(chunks)
struct.pack_into('<I', expected, stats_header, u32(original, stats_header) + delta)
struct.pack_into('<I', expected, base + 0x124, u32(original, base + 0x124) + delta)
assert len(edited) == len(original) == 33554400
assert edited == expected, 'Diferenças fora da reconstrução prevista'
assert edited[:base] == original[:base]
assert edited[new_end:] == original[new_end:]
assert struct.unpack_from('<III', edited, table - 12) == struct.unpack_from('<III', original, table - 12)
for uid in before.keys() - {target for target, _ in requests}:
    a, z = before[uid]
    b, y = after[uid]
    assert original[a:z] == edited[b:y], f'Registro original alterado: {uid}'
report = dict(version='0.9.0', independentPythonOracle=True, byteForByteExpectedFile=True,
              fileSizePreserved=True, allOtherSlotsAndUnusedTailPreserved=True,
              originalObjectCountsAndModelsPreserved=True, replacements=len(requests),
              addedBytes=delta, noJavaScriptParserImported=True, inGameTestedHere=False)
Path(__file__).with_name('VERIFICACAO_ENCANTAMENTOS_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
