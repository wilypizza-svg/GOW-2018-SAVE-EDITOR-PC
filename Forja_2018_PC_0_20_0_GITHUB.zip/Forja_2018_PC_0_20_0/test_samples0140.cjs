/* Testes contra as amostras nativas. Uso:
   node test_samples0140.cjs PASTA_PEDIDAS PASTA_FALTANTES CODIGO_0_13_0 SAIDAS */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),camp=require('./src/campaign'),weapons=require('./src/weapon-levels'),ench=require('./src/enchantments'),selection=require('./src/inventory-selection'),plan=require('./src/plan');
const [pedidas,faltantes,oldRoot,outArg]=process.argv.slice(2),out=path.resolve(outArg);fs.mkdirSync(out,{recursive:true});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),m),hex=core.hex;
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):e.name.endsWith('.sav')?[path.join(dir,e.name)]:[]);}
const all=[...files(pedidas),...files(faltantes)],byName=new Map();
for(const p of all){const n=path.basename(p);if(byName.has(n))assert.equal(hash(fs.readFileSync(p)),hash(fs.readFileSync(byName.get(n))));else byName.set(n,p);}
const read=p=>new Uint8Array(fs.readFileSync(p)),witness=name=>{const file=byName.get(name);assert.ok(file,'amostra ausente: '+name);const b=read(file),m=core.parse(b);return {file,b,m,index:m.latestSlot};};
const prefix=n=>witness([...byName.keys()].find(name=>name.toLowerCase().startsWith(('game('+n).toLowerCase())));
function preservation(a,b,index,{rows=[],refs=[],finals=[],keys=[],scene=[],newObjects=0}={}){
 const x=nat.read(a,index),y=nat.read(b,index),rowIds=new Set(rows),refIds=new Set(refs),finalIds=new Set(finals),mapKeys=new Set(keys);
 assert.equal(b.length,a.length);
 for(const row of x.rows)if(!rowIds.has(nat.idOf(row)))same(row,nat.unique(y.rows,nat.idOf(row),true),'registro existente alterado');
 for(const row of y.rows)assert.ok(rowIds.has(nat.idOf(row))||x.rows.some(r=>nat.idOf(r)===nat.idOf(row)),'novo registro não solicitado');
 assert.deepEqual(x.refs.filter(r=>!refIds.has(nat.idOf(r))),y.refs.filter(r=>!refIds.has(nat.idOf(r))),'referências externas alteradas');
 assert.deepEqual(x.finals.filter(r=>!finalIds.has(nat.idOf(r))),y.finals.filter(r=>!finalIds.has(nat.idOf(r))),'marcadores externos alterados');
 for(let k=0;k<3;k++)assert.deepEqual(x.maps[k].entries.filter(r=>!mapKeys.has(nat.view(r).getUint32(0,true))),y.maps[k].entries.filter(r=>!mapKeys.has(nat.view(r).getUint32(0,true))),'mapa externo alterado');
 if(!newObjects)same(x.objectsAndGroups,y.objectsAndGroups,'instâncias alteradas');
 else{
  assert.equal(y.state.objects.length,x.state.objects.length+newObjects);
  for(const o of x.state.objects){const next=y.state.objects.find(p=>p.uid===o.uid);assert.ok(next);same(a.subarray(o.start,o.end),b.subarray(next.start,next.end),'instância antiga alterada');}
  x.state.groups.forEach((g,k)=>same(a.subarray(g.start,g.end),b.subarray(y.state.groups[k].start,y.state.groups[k].end),'grupo opaco alterado'));
 }
 const expected=a.slice();nat.view(expected).setUint32(x.slot.base+0x124,nat.view(b).getUint32(x.slot.base+0x124,true),true);
 for(const offset of scene)expected.set(b.subarray(offset,offset+4),offset);
 same(expected.subarray(0,x.slot.base+0x10400),b.subarray(0,y.slot.base+0x10400),'mundo ou cabeçalhos alterados');
 const activeHeader=x.prefix.slice(),header=nat.view(activeHeader);header.setUint32(5,y.state.statsSize,true);header.setUint32(17,y.rows.length,true);header.setUint32(21,y.refs.length,true);header.setUint32(25,y.slot.table.count4,true);
 same(activeHeader,y.prefix,'outro campo do cabeçalho ativo alterado');
 same(a.subarray(Math.max(x.state.activeEnd,y.state.activeEnd)),b.subarray(Math.max(x.state.activeEnd,y.state.activeEnd)),'cauda alterada');
 for(const slot of x.model.slots)if(slot.index!==index)same(a.subarray(slot.base,slot.end),b.subarray(slot.base,slot.end),'outro slot alterado');
 return y;
}
let latestSlots=0;for(const file of all){const b=read(file),m=core.parse(b);nat.read(b,m.latestSlot,m);latestSlots++;}
const early=prefix('UnicoProblema'),earlyHash=hash(early.b);
assert.equal(camp.totals(early.m.slots[early.index],camp.APPLES).total,1);
assert.deepEqual(camp.totals(early.m.slots[early.index],camp.APPLES).missing,['upgrades']);
assert.equal(camp.totals(early.m.slots[early.index],camp.HORNS).inferredZeroCounters,4);
let capacityCases=0;
for(const [type,ids]of [['idunn-apples',camp.APPLES],['blood-mead-horns',camp.HORNS]])for(let total=0;total<=9;total++){
 const request={slot:early.index,id:type,type,total},r=plan.patch(early.b,[request]);
 assert.equal(camp.totals(r.model.slots[early.index],ids).total,total);
 preservation(early.b,r.bytes,early.index,{rows:Object.values(ids)});
 same(plan.patch(r.bytes,[request]).bytes,r.bytes,'capacidade não idempotente');capacityCases++;
}
const capacities=[{slot:early.index,id:'idunn-apples',type:'idunn-apples',total:9},{slot:early.index,id:'blood-mead-horns',type:'blood-mead-horns',total:9}],maxCapacity=plan.patch(early.b,capacities);
preservation(early.b,maxCapacity.bytes,early.index,{rows:[...Object.values(camp.APPLES),...Object.values(camp.HORNS)]});
const broken=early.b.slice(),menu=early.m.slots[early.index].rows.find(r=>r.id===camp.APPLES.menu);nat.view(broken).setUint32(menu.valueOffset,2,true);
assert.throws(()=>plan.patch(broken,[capacities[0]]),/divergem/);
const partial=nat.read(early.b,early.index);partial.rows=partial.rows.filter(r=>nat.idOf(r)!==camp.APPLES.card);const missingNonzero=nat.write(partial).bytes;
assert.throws(()=>plan.patch(missingNonzero,[capacities[0]]),/divergem/);
for(const total of [-1,10,NaN,2.5,'9'])assert.throws(()=>plan.patch(early.b,[{...capacities[0],total}]));
assert.equal(hash(early.b),earlyHash);
console.log('Capacidades iniciais e guardas: OK');

const newProfiles=inv.MAPPED_PROFILES.slice(22);assert.equal(newProfiles.length,6);let nativeInventoryCases=0;
for(const p of newProfiles){
 const initialNames={971:'AntesDeConseguirCaboNivel8',83:'AntesDeConseguirCabonivel5',84:'AntesDeConseguirCabonivel6',670:'AntesDeConseguirOPeitoral',671:'AntesDeConseguirABraçadeira',672:'AntesDeConseguirACintura'};
 const initial=prefix(initialNames[p.key]);
 for(let stage=0;stage<p.stages.length;stage++){
  const r={slot:initial.index,id:p.id,type:'inventory-equipment',stage},result=plan.patch(initial.b,[r]),t=preservation(initial.b,result.bytes,initial.index,{rows:p.ids,refs:p.referenceIds,finals:[...p.ids,...p.referenceIds],keys:[p.key]}),native=witness(p.stages[stage].witness),nt=nat.read(native.b,native.index,native.m);
  assert.equal(inv.inspect(result.bytes,initial.index).profiles.find(x=>x.id===p.id).stage,stage);
  assert.equal(nat.view(nat.mapEntry(t,0,p.key)).getUint32(4,true),stage);
  for(let k=0;k<=stage;k++)assert.equal(nat.quantity(t,p.ids[k]),nat.quantity(nt,p.ids[k]));
  const ids=new Set([...p.ids,...p.referenceIds]);
  assert.deepEqual(t.refs.map(nat.idOf).filter(id=>p.referenceIds.includes(id)),nt.refs.map(nat.idOf).filter(id=>p.referenceIds.includes(id)));
  assert.deepEqual(t.finals.filter(r=>ids.has(nat.idOf(r))).map(hex).sort(),nt.finals.filter(r=>ids.has(nat.idOf(r))).map(hex).sort(),'marcadores não correspondem à amostra nativa');
  same(plan.patch(result.bytes,[r]).bytes,result.bytes);
  const down=plan.patch(result.bytes,[{...r,stage:0}]),dt=nat.read(down.bytes,initial.index);assert.deepEqual(t.rows,dt.rows);assert.deepEqual(t.refs,dt.refs);assert.deepEqual(t.finals,dt.finals);
  nativeInventoryCases++;
 }
}
const bladeProfiles=inv.PROFILES.filter(p=>p.kind==='blades');assert.equal(bladeProfiles.length,21);assert.equal(bladeProfiles.filter(p=>p.variant==='NG+').length,5);
for(const p of bladeProfiles.filter(p=>p.variant==='NG+'))assert.deepEqual(p.stages.map(s=>s.label),['8','8+','9']);
const bladeBase=prefix('AntesDeConseguirCaboNivel8');
const eligible=inv.inspect(bladeBase.b,bladeBase.index).profiles.filter(p=>p.kind==='blades'&&p.available&&!p.owned),bladeReqs=selection.buildMissing(inv.inspect(bladeBase.b,bladeBase.index),eligible.map(p=>p.id),'template-max',true).map(r=>({...r,slot:bladeBase.index}));
const bladeBatch=plan.patch(bladeBase.b,bladeReqs);for(const r of bladeReqs)assert.equal(inv.inspect(bladeBatch.bytes,bladeBase.index).profiles.find(p=>p.id===r.id).stage,r.stage);
preservation(bladeBase.b,bladeBatch.bytes,bladeBase.index,{rows:eligible.flatMap(p=>p.ids),refs:eligible.flatMap(p=>p.referenceIds),finals:eligible.flatMap(p=>[...p.ids,...p.referenceIds]),keys:eligible.filter(p=>p.key!==null).map(p=>p.key)});
console.log('Seis perfis nativos e lote de cabos: OK');

let weaponCases=0;
for(const p of weapons.PROFILES){
 const start=prefix(p.id==='axe-main-level'?'DepoisDoPrimeiroUpgradeMachado':'AntesDoPrimeiroUpgradeBlades');
 for(const step of p.steps){
  const native=witness(step.witness),state=weapons.inspect(native.b,native.index,p.id,native.m);assert.equal(state.current,step.level,'nível nativo não reconhecido');
  if(step.level<=weapons.inspect(start.b,start.index,p.id).current)continue;
  const r={slot:start.index,id:p.id,type:weapons.TYPE,level:step.level},result=plan.patch(start.b,[r]);
  const marker=Buffer.from(p.sceneMarker,'hex'),offset=Buffer.from(start.b).indexOf(marker,start.m.slots[start.index].base+0x400)+marker.length;
  const allowedRefs=[...p.recipeReferenceIds,...p.steps.flatMap(s=>s.refs.map(r=>r.id))];
  const t=preservation(start.b,result.bytes,start.index,{rows:p.history,refs:allowedRefs,finals:[...p.history,...allowedRefs],keys:[p.key],scene:[offset]});
  assert.equal(weapons.inspect(result.bytes,start.index,p.id).current,step.level);
  const nt=nat.read(native.b,native.index,native.m);
  for(let k=0;k<step.level-1;k++)assert.equal(nat.quantity(t,p.history[k]),nat.quantity(nt,p.history[k]));
  assert.deepEqual(t.refs.map(nat.idOf).filter(id=>p.recipeReferenceIds.includes(id)).sort(),nt.refs.map(nat.idOf).filter(id=>p.recipeReferenceIds.includes(id)).sort());
  same(plan.patch(result.bytes,[r]).bytes,result.bytes);
  const down=plan.patch(result.bytes,[{...r,level:1}]),dt=nat.read(down.bytes,start.index);assert.deepEqual(dt.rows,t.rows);assert.deepEqual(dt.refs,t.refs);assert.deepEqual(dt.finals,t.finals);
  assert.equal(weapons.inspect(down.bytes,start.index,p.id).registeredMax,step.level);weaponCases++;
 }
}
const firstAxe=prefix('AntesDoPrimeiroUpgradeMachado');assert.equal(weapons.inspect(firstAxe.b,firstAxe.index,'axe-main-level').available,false);
assert.throws(()=>plan.patch(firstAxe.b,[{slot:firstAxe.index,id:'axe-main-level',type:weapons.TYPE,level:6}]),/4757534/);
assert.throws(()=>plan.patch(early.b,[{slot:early.index,id:'axe-main-level',type:weapons.TYPE,level:6}]),/primeiro upgrade/);
assert.equal(weapons.inspect(early.b,early.index,'blades-main-level').available,false);
console.log('Transições de armas e bloqueios de formato: OK');

const beforeEnch=prefix('AntesDeComprarEncantamentoDaLoja'),nativeEnch=prefix('DepoisDeComprarEncatamentoLoja'),recipe=inv.FACTORIES.find(p=>p.id==='7DD0A7B4B01F5116');assert.ok(recipe);
const er={slot:beforeEnch.index,type:'enchantment-create',id:recipe.id,count:1},created=plan.patch(beforeEnch.b,[er]),uid=created.log[0].uids[0],idBuffer=Buffer.alloc(8);idBuffer.writeUInt32LE(uid);
const et=preservation(beforeEnch.b,created.bytes,beforeEnch.index,{rows:[recipe.id],finals:[recipe.id,idBuffer.toString('hex').toUpperCase()],newObjects:1});
const object=ench.inspect(created.bytes,beforeEnch.index).objects.find(o=>o.uid===uid),no=ench.inspect(nativeEnch.b,nativeEnch.index).objects.find(o=>o.uid===252);assert.equal(object.sampleName,recipe.name);
const normalized=created.bytes.slice(object.start,object.end);nat.view(normalized).setUint32(48,252,true);same(normalized,nativeEnch.b.subarray(no.start,no.end),'nova instância difere da compra nativa');
for(const prefixName of ['DepoisDeEncaixarNoPrimeiro','DepoisDeRetirarOEncantamento']){const s=prefix(prefixName);assert.equal(ench.inspect(s.b,s.index).objects.find(o=>o.uid===252).sampleName,recipe.name);}
const stone=prefix('RepondoDepois'),st={slot:3,id:'berserker-stone',type:'berserker-stone'},restored=plan.patch(stone.b,[st]),nativeStone=nat.read(stone.b,4),outStone=preservation(stone.b,restored.bytes,3,{rows:[camp.STONES[2],'024373073A80CFB5'],refs:['9CACC83BC2F1FDD4']});
assert.ok(camp.berserkerState(restored.bytes,3).owned);assert.equal(nat.quantity(outStone,camp.STONES[2]),nat.quantity(nativeStone,camp.STONES[2]));assert.deepEqual(outStone.finals,nativeStone.finals);same(plan.patch(restored.bytes,[st]).bytes,restored.bytes);
console.log('Encantamento e reposição de pedra: OK');

const oldPlan=require(path.resolve(oldRoot,'src/plan')),oldInv=require(path.resolve(oldRoot,'src/inventory'));let legacyCases=0;
for(const p of oldInv.MAPPED_PROFILES)for(const stage of [0,p.stages.length-1]){
 const r={slot:early.index,id:p.id,type:'inventory-equipment',stage,allowExperimental:true};let previous,error;
 try{previous=oldPlan.patch(early.b,[r]);}catch(e){error=e;}
 if(error){assert.throws(()=>plan.patch(early.b,[r]));continue;}
 same(plan.patch(early.b,[r]).bytes,previous.bytes,'regressão de perfil anterior '+p.id);legacyCases++;
}
const resources=[{slot:early.index,id:'9E5240D27406E85A',quantity:12345},{slot:early.index,id:'CC1B3E5C878842B3',quantity:4321}];
same(plan.patch(early.b,resources).bytes,oldPlan.patch(early.b,resources).bytes,'recursos divergiram');
const later=prefix('AntesDoPrimeiroUpgradeBlades');for(const type of ['idunn-apples','blood-mead-horns']){const r={slot:later.index,id:type,type,total:9};same(plan.patch(later.b,[r]).bytes,oldPlan.patch(later.b,[r]).bytes,'capacidade já completa divergente');}
const zeus=[{slot:early.index,type:'armor-set-template',id:'zeus-codofwar-max-clone',level:9,allowExperimental:true}];
const clone=require('./src/armor-template-clone');zeus[0].id=clone.ID;same(plan.patch(early.b,zeus).bytes,oldPlan.patch(early.b,zeus).bytes,'molde Zeus anterior divergente');

const cases=[];function save(name,s,requests){const result=plan.patch(s.b,requests),dir=path.join(out,name);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'game.sav'),result.bytes);const slot=s.m.slots[s.index];cases.push({name,source:s.file,sourceSha256:hash(s.b),sha256:hash(result.bytes),slot:s.index+1,title:slot.title,timestamp:slot.timestamp,requests,log:result.log});}
save('10_Vida_Furia_Save_Inicial',early,capacities);
save('11_Cabos_NGmais_e_Bestla',bladeBase,[...bladeReqs.filter(r=>inv.PROFILES.find(p=>p.id===r.id).variant==='NG+'),{...er,slot:bladeBase.index}]);
const normal=prefix('AntesDeConseguirCaboNivel6'),set=selection.SETS.find(s=>s.id==='KratosArmor_NifTankSet_Tier06::normal');assert.ok(set);
save('12_Ivaldi_Normal_e_Cabos',normal,[...selection.buildSet(inv.inspect(normal.b,normal.index),set.id,'template-max',true).map(r=>({...r,slot:normal.index})),...inv.inspect(normal.b,normal.index).profiles.filter(p=>p.kind==='blades'&&p.variant==='normal'&&p.available&&!p.owned).map(p=>({slot:normal.index,id:p.id,type:'inventory-equipment',stage:p.stages.length-1,allowExperimental:true}))]);
const wb=prefix('AntesDoPrimeiroUpgradeBlades');save('13_Laminas_Nivel_5',wb,[{slot:wb.index,id:'blades-main-level',type:weapons.TYPE,level:5}]);
const wa=prefix('DepoisDoPrimeiroUpgradeMachado');save('14_Machado_Nivel_6',wa,[{slot:wa.index,id:'axe-main-level',type:weapons.TYPE,level:6}]);
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({version:core.VERSION,cases},null,2));
const report={version:core.VERSION,archiveSamples:all.length,latestSlotsParsed:latestSlots,earlyCapacityCases:capacityCases,nativeInventoryCases,weaponCases,
 bladeProfiles:bladeProfiles.length,bladeProfilesMapped:bladeProfiles.filter(p=>!p.experimentalTemplate).length,bladeBatchAdditions:bladeReqs.length,
 legacyByteIdenticalCases:legacyCases,resourcesAndZeusByteIdentical:true,completeCountersByteIdentical:true,initialZeroCountersSupported:true,nonzeroDivergenceRejected:true,
 oldObjectsWorldResourcesAndOtherSlotsPreserved:true,bestlaNativeObjectByteExact:true,bestlaEquipAndUnequipRecognized:true,berserkerRestockMatchesNativeMarkers:true,
 firstAxeUpgradeMissingPropertyBlocked:true,lockedBladesBlocked:true,capacityChangesNotCurrentHealthOrRage:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_AMOSTRAS_0_14_0.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
