"""Oráculo independente. Não importa JavaScript nem relatórios do gravador.
Uso: python3 test_ancients_oracle.py base.sav melhoria1.sav melhoria2.sav pasta_saidas
"""
from pathlib import Path
import json
import struct
import sys

samples = [Path(p).read_bytes() for p in sys.argv[1:4]]
out_dir = Path(sys.argv[4])
base = 4160 + 12 * 1677512
table = base + 66589
BASE = '9E8ADECDD9C87B97'
FLAGS = ['447C88023A4B7596', 'B50188023A4B7596']
ANCHOR = 'E6767C713DB60238'
REF = bytes.fromhex('F7727C713DB60238')

def u32(b, p):
    return struct.unpack_from('<I', b, p)[0]

def parse(b):
    count, refs_count, obj_count = struct.unpack_from('<III', b, table-12)
    end = table+count*16
    rows = {b[p:p+8].hex().upper(): (u32(b,p+8), u32(b,p+12), p) for p in range(table,end,16)}
    assert len(rows) == count
    refs = [b[p:p+8].hex().upper() for p in range(end,end+refs_count*8,8)]
    stats = u32(b,table-24)
    cursor = table-20+stats
    frames = []
    for _ in range(3):
        size = struct.unpack_from('<H',b,cursor)[0]
        frames.append((cursor,cursor+2+size))
        cursor += size+2
    assert b[cursor:cursor+2] == bytes.fromhex('2EFA')
    size = struct.unpack_from('<H',b,cursor+2)[0]
    frames.append((cursor,cursor+4+size))
    assert frames[-1][1] == base+0x10400+u32(b,base+0x124)
    maps = []
    for i,(start,stop) in enumerate(frames[:3]):
        prefix,stride = (8,9) if i==1 else (0,8) if i==0 else (0,9)
        p=start+2+prefix
        n=u32(b,p)
        assert p+4+n*stride == stop
        entries={}
        for p in range(p+4,stop,stride):
            key,value=struct.unpack_from('<II',b,p)
            assert key not in entries
            entries[key]=(value,b[p+8] if i else None,p+4)
        maps.append(entries)
    return dict(count=count,refs_count=refs_count,obj_count=obj_count,end=end,rows=rows,refs=refs,stats=stats,frames=frames,maps=maps)

def expected_step(original):
    a=parse(original)
    stage=a['maps'][0][649][0]
    assert a['maps'][1][649][0] == stage and stage in [0,1]
    target=stage+1
    old_id=BASE if stage==0 else FLAGS[0]
    row=bytearray(original[a['rows'][old_id][2]:a['rows'][old_id][2]+16])
    row[:8]=bytes.fromhex(FLAGS[target-1])
    struct.pack_into('<II',row,8,1,a['count'])
    final_start,old_end=a['frames'][3]
    # Metadados do novo marcador conferem com um marcador de melhoria existente.
    old_flag_id=bytes.fromhex('5898550D079A0AE1')
    old_flag=next(original[p:p+16] for p in range(final_start+4,old_end,16) if original[p:p+8]==old_flag_id)
    assert old_flag[8:] == bytes.fromhex('00000000F67F0000')
    tracker=bytes.fromhex(FLAGS[target-1])+old_flag[8:]
    ref_delta=8 if stage==0 else 0
    stats_delta=16+ref_delta
    total=stats_delta+16
    if stage==0:
        pos=a['end']+(a['refs'].index(ANCHOR)+1)*8
        payload=row+original[a['end']:pos]+REF+original[pos:old_end]+tracker
    else:
        payload=row+original[a['end']:old_end]+tracker
    result=bytearray(original)
    result[a['end']:old_end+total]=payload
    for p,val in [(table-24,a['stats']+stats_delta),(table-12,a['count']+1),(table-8,a['refs_count']+ref_delta//8),(base+0x124,u32(original,base+0x124)+total)]:
        struct.pack_into('<I',result,p,val)
    struct.pack_into('<H',result,final_start+stats_delta+2,old_end-final_start-4+16)
    for i in [0,1]:
        struct.pack_into('<I',result,a['maps'][i][649][2]+stats_delta,target)
    return bytes(result)

def verify_native(original,edited,native):
    a,b,c=map(parse,[original,edited,native])
    for i in range(3):
        assert {k:v[:2] for k,v in b['maps'][i].items()} == {k:v[:2] for k,v in c['maps'][i].items()}
    assert b['refs'] == c['refs']
    for i in [0,3]:
        assert edited[slice(*b['frames'][i])] == native[slice(*c['frames'][i])]
    assert edited[b['end']+b['refs_count']*8:b['frames'][0][0]] == original[a['end']+a['refs_count']*8:a['frames'][0][0]]
    for id,(qty,aux,_) in a['rows'].items():
        assert b['rows'][id][:2] == (qty,aux)
    assert edited[:base] == original[:base]
    assert edited[b['frames'][3][1]:] == original[b['frames'][3][1]:]

first=(out_dir/'base_to_1.bin').read_bytes()
second=(out_dir/'one_to_2.bin').read_bytes()
direct=(out_dir/'base_to_2.bin').read_bytes()
assert first == expected_step(samples[0])
assert second == expected_step(samples[1])
assert direct == expected_step(expected_step(samples[0]))
for a,b,c in [(samples[0],first,samples[1]),(samples[1],second,samples[2]),(samples[0],direct,samples[2])]:
    assert len(a)==len(b)==33554400
    verify_native(a,b,c)
down=(out_dir/'registered_down.bin').read_bytes()
expected=bytearray(samples[2])
for i in [0,1]:
    struct.pack_into('<I',expected,parse(samples[2])['maps'][i][649][2],0)
assert down==expected
report=dict(version='0.9.0',independentPythonOracle=True,wholeFileExpectedByteExactForAllThreeExports=True,
            directBaseToTwoCheckedWithTwoNativeSteps=True,nativeMapsReferencesAndTrackersMatch=True,
            quantitiesAuxiliaryValuesAndAttributeObjectsPreserved=True,registeredDowngradeOnlyTwoKnownFields=True,
            unknownBytesHeaderAllOtherSlotsAndTailPreserved=True,noJavaScriptOrGeneratedReportImported=True,inGameTestedHere=False)
Path(__file__).with_name('VERIFICACAO_ANCESTRAIS_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
