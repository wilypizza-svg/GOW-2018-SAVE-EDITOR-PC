'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('node:assert/strict');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),old=path.join(ws,'Forja_2018_PC_0_17_2');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),selection=require('./src/inventory-selection'),clone=require('./src/equipment-record-clone'),plan=require('./src/plan');
const oldInv=require(old+'/src/inventory'),oldPlan=require(old+'/src/plan'),oldClone=require(old+'/src/equipment-record-clone');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),m);
const ids=['3E9D5BC6723E3C8F','5111E2DE1C0493F0','07DE698EB81F9FF0'],p=inv.PROFILES.find(p=>p.id===ids[0]);
assert.equal(core.VERSION,'0.17.3');assert.ok(p);assert.equal(p.name,'Grip of Tanngiost +');assert.equal(p.kind,'axe');assert.equal(p.variant,'NG+');assert.deepEqual(p.ids,ids);assert.deepEqual(p.stages.map(s=>s.label),['8','8+','9']);
assert.equal(inv.PROFILES.length,oldInv.PROFILES.length+1);
for(const before of oldInv.PROFILES)assert.deepEqual(inv.PROFILES.find(p=>p.id===before.id),before,'Perfil existente alterado: '+before.id);
assert.deepEqual(inv.FACTORIES,oldInv.FACTORIES);assert.deepEqual(selection.SETS,require(old+'/src/inventory-selection').SETS);
assert.deepEqual(require('./src/inventory-catalog').EXCLUDED_IDS,require(old+'/src/inventory-catalog').EXCLUDED_IDS);
const model=clone.modelFor(p),donor=oldClone.models.find(t=>t.id==='20079575B16C9CD2');
assert.equal(model.sourceId,donor.id);assert.equal(model.exactIdentity,false);assert.deepEqual(model.sourceRows,donor.sourceRows);assert.deepEqual(model.sourceIds,donor.sourceIds);assert.deepEqual(model.sourceFinalRows,donor.sourceFinalRows);assert.equal(model.boundInstances,0);
assert.equal(clone.models.length,oldClone.models.length+1);for(const m of oldClone.models)assert.deepEqual(clone.models.find(t=>t.id===m.id),m);
const oldCat=JSON.parse(fs.readFileSync(old+'/data/catalog.json')),newCat=JSON.parse(fs.readFileSync(path.join(__dirname,'data/catalog.json')));
assert.equal(oldCat.items.length,newCat.items.length);for(const item of oldCat.items)if(!ids.includes(item.id))assert.deepEqual(newCat.items.find(p=>p.id===item.id),item);
const sourcePath=path.join(ws,'analysis_0_17_3/fixtures/game(saveCom229Alterações).sav'),source=new Uint8Array(fs.readFileSync(sourcePath)),sourceHash=sha(source),sm=core.parse(source),slot=sm.latestSlot,original=nat.read(source,slot,sm);
for(const id of ids)assert.equal(nat.quantity(original,id),null);const out=path.join(ws,'analysis_0_17_3/testes');fs.mkdirSync(out,{recursive:true});const cases=[];let maxResult;
for(let stage=0;stage<3;stage++){
 const requests=[{slot,type:'inventory-equipment',id:p.id,stage,allowExperimental:true}],result=plan.patch(source,requests),next=nat.read(result.bytes,slot,result.model),state=inv.inspect(result.bytes,slot,result.model).profiles.find(q=>q.id===p.id);
 assert.equal(state.available,true);assert.equal(state.owned,true);assert.equal(state.stage,stage);assert.equal(next.rows.length,original.rows.length+stage+1);
 const before=new Map(original.rows.map(r=>[nat.idOf(r),r])),after=new Map(next.rows.map(r=>[nat.idOf(r),r]));
 for(const [id,row]of before)same(row,after.get(id),'Registro anterior alterado: '+id);
 assert.deepEqual([...after.keys()].filter(id=>!before.has(id)),ids.slice(0,stage+1));
 for(let k=0;k<3;k++)assert.equal(nat.quantity(next,ids[k]),k<=stage?1:null);
 same(original.objectsAndGroups,next.objectsAndGroups);assert.deepEqual(original.refs,next.refs);assert.deepEqual(original.maps,next.maps);
 assert.deepEqual(next.finals.slice(0,original.finals.length),original.finals);assert.ok(next.finals.slice(original.finals.length).every(r=>ids.slice(1,stage+1).includes(nat.idOf(r))));assert.equal(next.finals.length,original.finals.length+stage);
 assert.ok(result.layout.some(r=>r.oldestFinalRowsDiscarded===0));
 for(const s of sm.slots)if(s.index!==slot)same(source.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end));
 const prefix=source.slice(0,original.slot.base+0x10400);prefix.set(result.bytes.subarray(original.slot.base+0x124,original.slot.base+0x128),original.slot.base+0x124);same(prefix,result.bytes.subarray(0,prefix.length));
 const tail=Math.max(original.state.activeEnd,next.state.activeEnd);same(source.subarray(tail),result.bytes.subarray(tail));
 const output=path.join(out,'Tanngiost_NGmais_'+['8','8plus','9'][stage]+'.sav');fs.writeFileSync(output,result.bytes);
 cases.push({stage,label:p.stages[stage].label,source:sourcePath,slot,output,sha256:sha(result.bytes),rows:next.rows.length,queue:next.finals.length,allOtherRecordsAndSlotsPreserved:true});if(stage===2)maxResult=result;
}
const base=new Uint8Array(fs.readFileSync(cases[0].output)),upgrade=plan.patch(base,[{slot,type:'inventory-equipment',id:p.id,stage:2,allowExperimental:true}]);same(upgrade.bytes,maxResult.bytes,'Melhoria sequencial divergiu.');
same(plan.patch(maxResult.bytes,[{slot,type:'inventory-equipment',id:p.id,stage:2,allowExperimental:true}]).bytes,maxResult.bytes,'Repetição duplicou registros.');
assert.throws(()=>plan.patch(maxResult.bytes,[{slot,type:'inventory-equipment',id:p.id,stage:0,allowExperimental:true}]),/redução|Redução/);
// Mesmo pedido de recurso na versão anterior: nenhuma mudança no gravador comum.
const hs='9E5240D27406E85A',quantity=(nat.quantity(original,hs)||100)-1,resource=[{slot,id:hs,quantity}];same(plan.patch(source,resource).bytes,oldPlan.patch(source,resource).bytes);
const allowed=new Set(['src/core.js','src/ui.js','src/index.template.html','data/catalog.json','data/equipment-record-templates.json','CHANGELOG.md','COMO_USAR.txt','Abrir_Editor.html']);
const baseline=JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_17_3/baseline_0172.json')));let unchanged=0;
for(const item of baseline){assert.equal(sha(fs.readFileSync(item.path)),item.sha256);const rel=path.relative(old,item.path);if(!allowed.has(rel)){same(fs.readFileSync(item.path),fs.readFileSync(path.join(__dirname,rel)),rel);unchanged++;}}
assert.equal(sha(source),sourceHash);
const report={version:core.VERSION,passed:true,source:sourcePath,sourceSha256:sourceHash,slot,newProfile:p,newModel:model,previousProfilesUnchanged:oldInv.PROFILES.length,normalTanngiostUnchanged:true,oldCloneModelsAndOtherCatalogRowsUnchanged:true,allPreviousWritersAndDataOutsideScopeUnchanged:true,oldSourceFilesVerified:baseline.length,unchangedFiles:unchanged,resourceExportMatches0172:true,sequentialUpgradeAndRepeatPassed:true,gameValidationPendingForNewNgpItem:true,cases};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_0_17_3.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({version:core.VERSION,passed:true,previousProfilesUnchanged:oldInv.PROFILES.length,sourceRows:original.rows.length,cases:cases.map(c=>({label:c.label,rows:c.rows,queue:c.queue,sha256:c.sha256})),gameValidationPendingForNewNgpItem:true},null,2));
