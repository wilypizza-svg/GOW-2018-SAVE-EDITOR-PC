'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const targets=require('./src/level-targets'),axe=require('./src/levels'),armor=require('./src/armor-levels'),writer=require('./src/plan');
const [afterFile,axeBeforeFile,normalFile]=process.argv.slice(2),read=p=>new Uint8Array(fs.readFileSync(p));
const after=read(afterFile),axeBefore=read(axeBeforeFile),normal=read(normalFile),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const choose=async(prefix,value)=>{$(prefix+'-target').value=String(value);await $(prefix+'-target').fire('change');};
(async()=>{
  api.loadBytes(after);api.selectSlot(11);api.chooseView('levels');
  assert.equal($('level-target').value,'6');assert.equal($('level-apply').disabled,true);
  assert.equal($('level-target').children.filter(e=>e.tagName==='option'&&!e.disabled).length,6);
  assert.equal($('armor-level-target').children.filter(e=>e.tagName==='option'&&!e.disabled).length,3);
  await choose('level',2);assert.equal($('level-apply').disabled,false);await $('level-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
  assert.equal($('level-edited').textContent,'Nível 2');assert.equal(api.getState().changes.length,1);
  await choose('level',3);await $('level-apply').click();assert.equal(api.getState().changes.length,1);assert.equal($('level-edited').textContent,'Nível 3');
  await choose('level',6);await $('level-apply').click();assert.equal(api.getState().log.length,0);assert.equal($('level-edited').textContent,'Nível 6');
  await choose('level',2);await $('level-apply').click();await choose('armor-level',0);await $('armor-level-apply').click();
  assert.equal($('armor-level-edited').textContent,'Base · sem reforço');
  const requests=[{slot:11,id:axe.ID,type:'level-target',target:2},{slot:11,id:armor.PROFILE.id,type:'level-target',target:0}];
  same(api.exportBytes().bytes,writer.patch(after,requests).bytes);
  await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());
  assert.equal(report.version,'0.9.0');assert.equal(report.validation.levelHistoryPreserved,true);assert.equal(report.validation.newlyRegisteredLevelTransitions,0);
  await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
  const lowerFile=api.exportBytes().bytes;api.loadBytes(lowerFile);api.selectSlot(11);api.chooseView('levels');
  assert.equal($('level-target').value,'2');assert.equal($('armor-level-target').value,'0');
  await choose('level',6);await $('level-apply').click();await choose('armor-level',2);await $('armor-level-apply').click();same(api.exportBytes().bytes,after);
  await query('[data-undo]').find(e=>e.dataset.undo==='11:'+axe.ID).click();assert.equal($('level-edited').textContent,'Nível 2');
  await $('reset-changes').click();assert.equal(api.getState().log.length,0);
  api.loadBytes(axeBefore);api.selectSlot(11);api.chooseView('levels');await choose('level',6);await $('level-apply').click();
  assert.equal(api.getState().log.find(e=>e.id===axe.ID).mode,'mapped-upgrade');
  same(api.exportBytes().bytes,axe.patch(axeBefore,[{slot:11,id:axe.ID,type:'axe-level',level:6}]).bytes);
  await choose('level',3);await $('level-apply').click();assert.equal(api.getState().log.find(e=>e.id===axe.ID).mode,'registered');
  assert.equal(targets.inspect(api.exportBytes().bytes,11,axe.ID).registeredMax,5);
  api.loadBytes(normal);api.selectSlot(11);api.chooseView('levels');
  assert.equal($('level-target').children.find(e=>e.attrs.value==='5').disabled,true);
  $('quantity-item').value='9E5240D27406E85A';await $('quantity-item').fire('change');$('quantity-value').value='123';await $('quantity-value').fire('input');await $('quantity-apply').click();
  const saved=api.exportBytes().bytes;await choose('level',5);assert.equal($('level-apply').disabled,true);await $('level-apply').click();assert.equal($('error').hidden,false);same(api.exportBytes().bytes,saved);
  await choose('level','');await $('level-apply').click();same(api.exportBytes().bytes,saved);
  const summary={version:'0.9.0',htmlExecutedInVM:true,selectorsReplaceFixedUpgradeButtons:true,defaultIsCurrentLevel:true,
    everyRegisteredAxeAndArmorOptionShown:true,downgradeAndReturnAfterReopeningVerified:true,pendingTargetReplacesPrevious:true,
    cancelingPendingTargetDoesNotKeepUncommittedUpgrade:true,mappedNewUpgradePreserved:true,undoResetReportAndDownloadVerified:true,
    disabledAndForgedOptionsCannotChangeDraft:true,visualBrowserTested:false,inGameTestedHere:false};
  fs.writeFileSync(path.join(__dirname,'VERIFICACAO_SELETOR_INTERFACE_0_9_0.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
