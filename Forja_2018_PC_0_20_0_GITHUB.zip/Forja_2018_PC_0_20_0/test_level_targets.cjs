'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const core=require('./src/core'),targets=require('./src/level-targets'),axe=require('./src/levels'),armor=require('./src/armor-levels');
const resources=require('./src/resource-edit'),enchants=require('./src/enchantments'),plan=require('./src/plan');
const [beforeFile,afterFile,axeBeforeFile,normalFile,ngFile,stableRoot,outDir]=process.argv.slice(2);
const read=p=>new Uint8Array(fs.readFileSync(p)),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const before=read(beforeFile),after=read(afterFile),axeBefore=read(axeBeforeFile),normal=read(normalFile),ng=read(ngFile),pristine=after.slice();
const request=(id,target,slot=11)=>({slot,id,type:'level-target',target});
const options=s=>s.options.filter(o=>o.available).map(o=>o.value);
assert.deepEqual(options(targets.inspect(after,11,axe.ID)),[1,2,3,4,5,6]);
assert.deepEqual(options(targets.inspect(after,11,armor.PROFILE.id)),[0,1,2]);
assert.deepEqual(options(targets.inspect(normal,11,axe.ID)),[1,2,3,4]);
assert.equal(targets.inspect(ng,18,axe.ID).available,false); // terceiro campo da cena não foi reconhecido nesta amostra
let roundTrips=0;
for(const [id,values,originalLevel] of [[axe.ID,[1,2,3,4,5,6],6],[armor.PROFILE.id,[0,1,2],2]]){
  const initial=targets.inspect(after,11,id);
  for(const level of values){
    const down=targets.patch(after,[request(id,level)]),current=targets.inspect(down.bytes,11,id);
    assert.equal(current.current,level);assert.equal(current.registeredMax,initial.registeredMax);
    assert.equal(down.bytes.length,after.length);assert.equal(down.layout.length,0);
    assert.deepEqual(down.model.slots[11].table,core.parse(after).slots[11].table);
    same(targets.patch(down.bytes,[request(id,originalLevel)]).bytes,after);roundTrips++;
  }
}
const down=targets.patch(after,[request(axe.ID,2),request(armor.PROFILE.id,0)]);
fs.mkdirSync(outDir,{recursive:true});fs.writeFileSync(path.join(outDir,'registered_down.bin'),down.bytes);
same(targets.patch(down.bytes,[request(axe.ID,6),request(armor.PROFILE.id,2)]).bytes,after);
assert.equal(down.validation.newlyRegisteredLevelTransitions,0);assert.equal(down.validation.levelTargetChanges,2);
const nativeAxe=targets.patch(axeBefore,[request(axe.ID,6)]),oldAxe=axe.patch(axeBefore,[{slot:11,id:axe.ID,type:'axe-level',level:6}]);same(nativeAxe.bytes,oldAxe.bytes);
fs.writeFileSync(path.join(outDir,'native_axe.bin'),nativeAxe.bytes);
const nativeArmor=targets.patch(before,[request(armor.PROFILE.id,2)]),oldArmor=armor.patch(before,[{slot:11,id:armor.PROFILE.id,type:'armor-level',stage:2}]);same(nativeArmor.bytes,oldArmor.bytes);
fs.writeFileSync(path.join(outDir,'native_armor.bin'),nativeArmor.bytes);
assert.equal(nativeAxe.validation.newlyRegisteredLevelTransitions,1);assert.equal(nativeArmor.validation.newlyRegisteredLevelTransitions,1);
const axeLow=targets.patch(axeBefore,[request(axe.ID,1)]),armorLow=targets.patch(before,[request(armor.PROFILE.id,0)]);
assert.equal(targets.inspect(axeLow.bytes,11,axe.ID).registeredMax,5);assert.equal(targets.inspect(armorLow.bytes,11,armor.PROFILE.id).registeredMax,1);
same(targets.patch(axeLow.bytes,[request(axe.ID,6)]).bytes,oldAxe.bytes);
same(targets.patch(armorLow.bytes,[request(armor.PROFILE.id,2)]).bytes,oldArmor.bytes);
assert.equal(targets.patch(nativeAxe.bytes,[request(axe.ID,1)]).bytes.length,nativeAxe.bytes.length);
const registeredAgain=targets.patch(targets.patch(nativeAxe.bytes,[request(axe.ID,1)]).bytes,[request(axe.ID,6)]);
same(registeredAgain.bytes,nativeAxe.bytes);assert.equal(registeredAgain.validation.newlyRegisteredLevelTransitions,0);
const good=request(axe.ID,2);
for(const bad of [null,{...good,id:'unknown'},{...good,target:-1},{...good,target:0},{...good,target:7},{...good,target:2.5},{...good,target:'2'},
  {...good,target:NaN},{...good,target:Infinity},{...good,target:null},{...good,slot:12},{...good,slot:-1},{...good,type:'other'},request(armor.PROFILE.id,3)]) assert.throws(()=>targets.patch(after,[bad]));
assert.throws(()=>targets.patch(normal,[request(axe.ID,5)]));assert.throws(()=>targets.patch(after,[good,good]));
assert.throws(()=>plan.patch(after,[good,{slot:11,id:axe.ID,type:'axe-level',level:6}]));
assert.throws(()=>plan.patch(after,[request(armor.PROFILE.id,1),{slot:11,id:armor.PROFILE.id,type:'armor-level',stage:2}]));
const state=targets.inspect(after,11,axe.ID),badMaps=after.slice();new DataView(badMaps.buffer).setUint32(state.fields[1],3,true);
assert.equal(targets.inspect(badMaps,11,axe.ID).available,false);assert.throws(()=>targets.patch(badMaps,[good]));
const hole=after.slice(),row=core.parse(hole).slots[11].rows.find(r=>r.id==='3EC01B327975AF5E');new DataView(hole.buffer).setUint32(row.valueOffset,0,true);
assert.equal(targets.inspect(hole,11,axe.ID).available,false);assert.throws(()=>targets.patch(hole,[good]));
const duplicateScene=after.slice(),scene=state.fields.find(o=>o<state.slot.base+0x10400);
duplicateScene.set(after.subarray(scene-16,scene+4),state.slot.base+0x10000);
assert.equal(targets.inspect(duplicateScene,11,axe.ID).available,false);
assert.equal(resources.patch(duplicateScene,[{slot:11,id:'9E5240D27406E85A',quantity:123}]).model.slots[11].rows.find(r=>r.id==='9E5240D27406E85A').quantity,123);
const resourceRequests=[{slot:11,id:'CC1B3E5C878842B3',quantity:22},{slot:11,id:'9E5240D27406E85A',quantity:12345}],levelRequests=[request(axe.ID,2),request(armor.PROFILE.id,0)];
const enchantRequest={slot:11,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73};
const mixed=plan.patch(after,[...resourceRequests,...levelRequests,enchantRequest]);
const a=resources.patch(after,resourceRequests),b=targets.patch(a.bytes,levelRequests),c=enchants.patch(b.bytes,[enchantRequest]);same(mixed.bytes,c.bytes);
assert.equal(targets.inspect(mixed.bytes,11,axe.ID).current,2);assert.equal(targets.inspect(mixed.bytes,11,armor.PROFILE.id).current,0);
assert.equal(mixed.validation.newRecords,1);assert.equal(mixed.validation.enchantmentReplacements,1);
const oldPlan=require(path.resolve(stableRoot,'src/plan.js'));
for(const [bytes,requests] of [[after,resourceRequests],[axeBefore,[{slot:11,id:axe.ID,type:'axe-level',level:6}]],[before,[{slot:11,id:armor.PROFILE.id,type:'armor-level',stage:2}]],[after,[enchantRequest,...resourceRequests]]])same(plan.patch(bytes,requests).bytes,oldPlan.patch(bytes,requests).bytes);
const multi=targets.patch(normal,[request(axe.ID,1,0),request(axe.ID,2,5),request(axe.ID,3,11)]);
for(const [slot,level] of [[0,1],[5,2],[11,3]])assert.equal(targets.inspect(multi.bytes,slot,axe.ID).current,level);
const offset=Buffer.alloc(after.length+16);offset.set(after,8);const saved=Buffer.from(offset);
same(targets.patch(offset.subarray(8,after.length+8),[good]).bytes,targets.patch(after,[good]).bytes);same(offset,saved);same(after,pristine);
same(targets.patch(after,[]).bytes,after);same(targets.patch(after,[request(axe.ID,6),request(armor.PROFILE.id,2)]).bytes,after);
const report={version:'0.9.0',profiles:3,registeredLevelRoundTrips:roundTrips,allAxeLevels1Through6Checked:true,armorBaseAndBothReinforcementsChecked:true,
  historyAndStructurePreservedOnRegisteredSelections:true,wholeFileRestoredExactlyOnReturn:true,mappedNewLevelsByteIdenticalTo0_6_0:true,
  lowerActiveLevelCanReachMappedNewStage:true,returnDoesNotRegisterSameUpgradeTwice:true,unmappedAndAmbiguousInputsBlocked:true,
  legacyExportsUnchanged:true,multiSlotResourceEnchantmentCombinationVerified:true,originalAndOffsetBufferUnmodified:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_SELETOR_NIVEIS_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
