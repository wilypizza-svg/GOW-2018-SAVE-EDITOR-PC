"""Oráculo independente: lê o binário com struct e compara o arquivo inteiro.
Não importa parsers, posições calculadas ou resultados internos do JavaScript.
Uso: python test_samples0100_oracle.py pasta_das_amostras pasta_dos_resultados
"""
from pathlib import Path
import hashlib
import json
import struct
import sys

SLOT_SIZE = 1677512
HEADER = 4160
START = 66560
TABLE = 66589
u16 = lambda b, p: struct.unpack_from('<H', b, p)[0]
u32 = lambda b, p: struct.unpack_from('<I', b, p)[0]
put32 = lambda b, p, v: struct.pack_into('<I', b, p, v)
ident = lambda b: b.hex().upper()
rawid = bytes.fromhex


def decode(b, index):
    base = HEADER + index * SLOT_SIZE
    start = base + START
    table = base + TABLE
    stats_size = u32(b, start + 5)
    stats_end = start + 9 + stats_size
    assert b[start:start + 2] == b'\x01\0' and b[start + 3:start + 5] == b'\xfa\xff'
    assert b[start + 2] == u32(b, base + 272)
    assert b[table - 20:table - 12] == rawid('5F2243C695480000')
    count, refs_count, objects_count = struct.unpack_from('<III', b, table - 12)
    rows = {}
    for i in range(count):
        p = table + 16 * i
        id_ = ident(b[p:p + 8])
        assert id_ not in rows
        rows[id_] = dict(offset=p, quantity=u32(b, p + 8), raw=b[p:p + 16])
    row_end = table + count * 16
    refs = [dict(offset=row_end + 8 * i, id=ident(b[row_end + 8 * i:row_end + 8 * i + 8])) for i in range(refs_count)]
    p = row_end + refs_count * 8
    object_start = p

    def objects(n):
        nonlocal p
        found = {}
        for _ in range(n):
            beginning = p
            assert b[p:p + 8] == rawid('3B056E1555DABD5D')
            uid = u32(b, p + 48)
            assert uid not in found
            p += 72
            for _ in range(2):
                size = u32(b, p)
                assert size <= 64
                p += 4 + size * 4
            n_stats = u32(b, p)
            assert n_stats <= 64
            p += 4 + n_stats * 12
            assert p <= stats_end
            found[uid] = dict(start=beginning, end=p, raw=b[beginning:p])
        return found

    items = objects(objects_count)
    for marker in ['EA2555A4149BE338', '4B30662F58A15983', 'B0BDD5E2372DB672']:
        assert b[p:p + 8] == rawid(marker)
        nr, ne, no = struct.unpack_from('<III', b, p + 8)
        p += 20 + nr * 16 + ne * 8
        objects(no)
    assert p == stats_end
    maps = []
    for i in range(3):
        length = u16(b, p)
        prefix = 8 if i == 1 else 0
        stride = 9 if i else 8
        n = u32(b, p + 2 + prefix)
        assert length == prefix + 4 + n * stride
        entries = []
        for k in range(n):
            q = p + 2 + prefix + 4 + k * stride
            entries.append(dict(key=u32(b, q), value=u32(b, q + 4), offset=q, raw=b[q:q + stride]))
        assert len({x['key'] for x in entries}) == len(entries)
        maps.append(dict(start=p, end=p + length + 2, entries=entries, count_offset=p + 2 + prefix, length=length))
        p += length + 2
    assert b[p:p + 2] == b'\x2e\xfa'
    final_length = u16(b, p + 2)
    assert final_length % 16 == 0
    final_start = p
    end = p + 4 + final_length
    assert end == start + u32(b, base + 292)
    finals = []
    for q in range(p + 4, end, 16):
        finals.append(dict(id=ident(b[q:q + 8]), offset=q, raw=b[q:q + 16]))
    return dict(base=base, start=start, table=table, stats_size=stats_size, stats_end=stats_end,
                row_end=row_end, rows=rows, count=count, refs=refs, objects=items, object_start=object_start,
                maps=maps, final_start=final_start, final_length=final_length, finals=finals, end=end)


def field_patch(b, fields):
    out = bytearray(b)
    for offset, data in fields:
        out[offset:offset + len(data)] = data
    return out


def rebuild_by_splices(b, d, edits, fields):
    """Espera mudanças por inserção/remoção, sem recompor mapas ou objetos."""
    edits = sorted(edits, key=lambda x: x[0])
    parts = []
    cursor = d['start']
    for begin, end, content in edits:
        assert cursor <= begin <= end <= d['end']
        parts.extend([b[cursor:begin], content])
        cursor = end
    parts.append(b[cursor:d['end']])
    body = b''.join(parts)
    out = bytearray(b)
    out[d['start']:d['start'] + len(body)] = body

    def relocated(offset):
        delta = 0
        for begin, end, content in edits:
            assert not begin <= offset < end
            if end <= offset:
                delta += len(content) - (end - begin)
        return offset + delta

    for offset, width, value, shifts in fields:
        target = relocated(offset) if shifts else offset
        struct.pack_into('<H' if width == 2 else '<I', out, target, value)
    return out


def only(xs, predicate):
    found = [x for x in xs if predicate(x)]
    assert len(found) == 1
    return found[0]


def main():
    source_dir, result_dir = map(Path, sys.argv[1:3])
    names = list(source_dir.glob('*.sav'))
    load = lambda prefix: only(names, lambda p: p.name.startswith('game(' + prefix)).read_bytes()
    cases = []

    def verify(name, expected, index):
        actual = (result_dir / (name + '.bin')).read_bytes()
        assert actual == expected, name + ': diferença no arquivo completo'
        decode(actual, index)
        cases.append(dict(name=name, bytesCompared=len(actual), sha256=hashlib.sha256(actual).hexdigest()))

    b = load('antesDeAlterar')
    d = decode(b, 13)
    verify('difficulty', field_patch(b, [(d['base'] + 272, struct.pack('<I', 2)), (d['start'] + 2, b'\x02')]), 13)

    b = load('AntesDepegar')
    d = decode(b, 12)
    values = {'8EC8B40DE6B3AC68': 0, '2085C71C79E4ED7E': 6, 'B42DDFD1FBD3ED7E': 6, 'D6833365C3296802': 2}
    verify('apples', field_patch(b, [(d['rows'][id_]['offset'] + 8, struct.pack('<I', n)) for id_, n in values.items()]), 12)

    b = load('AntesDeEquipar')
    d = decode(b, 11)
    row = only(d['maps'][1]['entries'], lambda x: x['key'] == 613)
    verify('equip', field_patch(b, [(row['offset'], struct.pack('<II', 607, 2))]), 11)

    stone_id = 'CB0E900B4A8A614B'
    stone_ref = '101A353D83F1212E'
    used_ref = 'CE0BFA08B3CE47F9'
    b = load('SemPedra')
    d = decode(b, 11)
    template = bytearray(d['rows']['8A9A9B831CF67C9C']['raw'])
    template[:8] = rawid(stone_id)
    put32(template, 8, 1)
    put32(template, 12, d['count'])
    anchor = only(d['refs'], lambda x: x['id'] == '47A41A0AAF5B1BD4')['offset'] + 8
    finals = rawid(stone_id + '00000000F77F0000' + stone_ref + '01000000F37F0000')
    expected = rebuild_by_splices(b, d, [(d['row_end'], d['row_end'], template), (anchor, anchor, rawid(stone_ref)), (d['end'], d['end'], finals)], [
        (d['start'] + 5, 4, d['stats_size'] + 24, False), (d['table'] - 12, 4, d['count'] + 1, False),
        (d['table'] - 8, 4, len(d['refs']) + 1, False), (d['base'] + 292, 4, d['end'] - d['start'] + 56, False),
        (d['rows']['024373073A80CFB5']['offset'] + 8, 4, 0, False), (d['final_start'] + 2, 2, d['final_length'] + 32, True)])
    verify('stone', expected, 11)

    b = load('AposUsar')
    d = decode(b, 11)
    ref = only(d['refs'], lambda x: x['id'] == used_ref)
    final = only(d['finals'], lambda x: x['id'] == used_ref)
    expected = rebuild_by_splices(b, d, [(ref['offset'], ref['offset'] + 8, rawid(stone_ref)), (final['offset'], final['offset'] + 16, b''),
                                         (d['end'], d['end'], rawid(stone_id + '00000000F77F0000'))], [
        (d['rows'][stone_id]['offset'] + 8, 4, 1, False), (d['rows']['024373073A80CFB5']['offset'] + 8, 4, 0, False)])
    verify('stone-restored', expected, 11)

    b = load('AntesDeComprar')
    d = decode(b, 11)
    armor, ref = 'C3BB0F4EA2814358', '1A471745F887768B'
    row = bytearray(d['rows']['8A9A9B831CF67C9C']['raw'])
    row[:8] = rawid(armor)
    put32(row, 8, 1)
    put32(row, 12, d['count'])
    anchor = only(d['refs'], lambda x: x['id'] == '4305393E4800FED9')['offset'] + 8
    new_map = struct.pack('<II', 650, 0)
    insertion = next((x['offset'] for x in d['maps'][0]['entries'] if x['key'] > 650), d['maps'][0]['end'])
    finals = rawid(armor + '00000000F77F0000' + ref + '01000000F37F0000' + '5395046D84ED7B280300000000000000')
    expected = rebuild_by_splices(b, d, [(d['row_end'], d['row_end'], row), (anchor, anchor, rawid(ref)),
                                         (insertion, insertion, new_map), (d['end'], d['end'], finals)], [
        (d['start'] + 5, 4, d['stats_size'] + 24, False), (d['table'] - 12, 4, d['count'] + 1, False),
        (d['table'] - 8, 4, len(d['refs']) + 1, False), (d['base'] + 292, 4, d['end'] - d['start'] + 80, False),
        (d['maps'][0]['start'], 2, d['maps'][0]['length'] + 8, True),
        (d['maps'][0]['count_offset'], 4, len(d['maps'][0]['entries']) + 1, True),
        (d['final_start'] + 2, 2, d['final_length'] + 48, True)])
    verify('acquisition', expected, 11)

    b = load('semEncatamentos')
    d = decode(b, 14)
    for uid in [75, 33]:
        obj = d['objects'][uid]
        verify('attach-' + str(uid), field_patch(b, [(obj['start'] + 8, rawid('B74F7BCF35641B8F')), (obj['start'] + 56, struct.pack('<I', 0))]), 14)

    report = dict(version='0.10.0', independentLanguage='Python struct', javascriptParserOrOffsetsImported=False,
                  wholeFileCases=cases, wholeFileEqualityPassed=True, independentObjectAndMapGrammarPassed=True,
                  allOtherSlotsHeaderAndUnusedBytesPreserved=True, nativeCountersAndAttachmentsComparedSeparatelyInJs=True,
                  browserVisualTested=False, inGameTestedHere=False)
    (Path(__file__).parent / 'VERIFICACAO_INDEPENDENTE_0_10_0.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
