"""Confere os arquivos exportados com um leitor binário Python independente."""
from pathlib import Path
import ast
import hashlib
import json
import struct
import sys

PROJECT = Path(__file__).resolve().parent
WORK = PROJECT.parent / 'analysis_0_20_0'
FIXTURES = Path(sys.argv[1]) if len(sys.argv) > 1 else WORK / 'recovered'
report = json.loads((PROJECT / 'VERIFICACAO_LAMINAS_0_20_0.json').read_text())
data = json.loads((PROJECT / 'data/blades-acquisition.json').read_text())
weapons = json.loads((PROJECT / 'data/weapon-profiles.json').read_text())
profile = next(item for item in weapons['profiles'] if item['id'] == 'blades-main-level')
tree = ast.parse((PROJECT / 'test_clone_native_reader.py').read_text())
fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'parse')
env = dict(struct=struct, HEADER=4160, SLOT=1677512, START=0x10400, SIZE=33554400, SLOT_INDEX=7)
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<independent-python>', 'exec'), env)
parse = env['parse']
native = (FIXTURES / 'game(AntesDePegarAsBlades).sav').read_bytes()
control = Path(next(item['file'] for item in report['outputs'] if item['kind'] == 'control')).read_bytes()

def frame(raw, index):
    prefix, stride = (8 if index == 1 else 0), (8 if index == 0 else 9)
    count = struct.unpack_from('<I', raw, 2+prefix)[0]
    entries = [raw[6+prefix+k*stride:6+prefix+(k+1)*stride] for k in range(count)]
    return raw[2:2+prefix], {struct.unpack_from('<I', row)[0]: row for row in entries}

results = []
for item in report['outputs']:
    raw = Path(item['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item['sha256']
    assert len(raw) == 33554400
    index = item['slot']
    base = control if item['name'].startswith('early_') else native
    env['SLOT_INDEX'] = index
    before, after = parse(base), parse(raw)
    b = before['base']
    assert raw[:4160] == base[:4160]
    assert raw[4160:b] == base[4160:b]
    assert raw[b+1677512:] == base[b+1677512:]
    assert raw[b:b+0x124] == base[b:b+0x124]
    assert raw[b+0x128:b+0x10400] == base[b+0x128:b+0x10400]
    assert before['objects'] == after['objects']
    assert before['frames'][2] == after['frames'][2]
    assert raw[after['end']:b+1677512] == base[after['end']:b+1677512]
    old_rows = {row[:8]: row for row in before['rows']}
    new_rows = {row[:8]: row for row in after['rows']}
    assert len(new_rows) == len(after['rows'])
    for identifier, row in old_rows.items():
        assert new_rows[identifier][8:12] == row[8:12]
    all_refs = [after['refs'][offset:offset+8] for offset in range(0, len(after['refs']), 8)]
    old_refs = [before['refs'][offset:offset+8] for offset in range(0, len(before['refs']), 8)]
    assert set(old_refs).issubset(set(all_refs))
    for frame_index in (0, 1):
        previous_prefix, previous_maps = frame(before['frames'][frame_index], frame_index)
        current_prefix, current_maps = frame(after['frames'][frame_index], frame_index)
        assert previous_prefix == current_prefix
        for key, row in previous_maps.items():
            assert current_maps[key] == row
        if item['kind'] != 'control':
            assert struct.unpack_from('<I', current_maps[3], 4)[0] == (4 if item['kind'] == 'max' else 0)
            assert struct.unpack_from('<I', current_maps[80], 4)[0] == 0
            if frame_index == 1:
                assert current_maps[3][8] == current_maps[80][8] == 1
    expected = set()
    if item['kind'] != 'control':
        for template in data['primaryRows']:
            identifier = bytes.fromhex(template[:16])
            assert struct.unpack_from('<I', new_rows[identifier], 8)[0] == 1
            expected.add(identifier)
        for identifier in data['references']:
            assert all_refs.count(bytes.fromhex(identifier)) == 1
    for identifier in profile['history']:
        key = bytes.fromhex(identifier)
        if item['kind'] == 'max':
            assert struct.unpack_from('<I', new_rows[key], 8)[0] == 1
            expected.add(key)
        else:
            assert key not in new_rows
    assert set(new_rows)-set(old_rows) == expected-set(old_rows)
    assert len(after['finals'][4:])//16 <= 512
    if item['name'] == 'early_granted_approved':
        assert item['sha256'] == '59cc5e73c1b4c45430578c198eb93898c74a2683736b89b63147d4ddf94145f3'
    results.append(dict(name=item['name'], slot=index+1, sha256=item['sha256'], passed=True))

result = dict(passed=True, version='0.20.0', reader='Independent Python grammar; no JavaScript executed',
              outputs=results, exactApprovedEarlyTrialVerified=True, ownershipAndAllFourUpgradeFlagsVerified=True,
              bothLevelMapsVerified=True, originalQuantitiesAndReferencesPreserved=True,
              worldInstancesSelectionAndOtherSlotsPreserved=True, maximumLevelGameTestPending=True)
(PROJECT/'VERIFICACAO_INDEPENDENTE_0_20_0.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(passed=True, verifiedOutputs=len(results), maximumGameTestPending=True)))
