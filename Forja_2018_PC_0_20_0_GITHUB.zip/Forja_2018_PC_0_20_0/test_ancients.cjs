'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const core=require('./src/core'),resources=require('./src/resource-edit'),ancients=require('./src/armor-ancients'),targets=require('./src/level-targets');
const enchantments=require('./src/enchantments'),plan=require('./src/plan');
const [baseFile,firstFile,lastFile,oldBefore,oldAfter,normalFile,stableRoot,outDir]=process.argv.slice(2);
const read=p=>new Uint8Array(fs.readFileSync(p)),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const samples=[baseFile,firstFile,lastFile].map(read),originalHashes=samples.map(b=>Buffer.from(b));
const id=ancients.PROFILE.id,req=(target,slot=12)=>({slot,type:'level-target',id,target}),nativeReq=stage=>({slot:12,type:'armor-ancients-level',id,stage});
fs.mkdirSync(outDir,{recursive:true});
function canonical(bytes,frame,index){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),prefix=index===1?8:0,stride=index?9:8,p=frame.start+2+prefix,count=view.getUint32(p,true),out=[];
 for(let i=0;i<count;i++){const k=p+4+stride*i;out.push([view.getUint32(k,true),view.getUint32(k+4,true),index?bytes[k+8]:null]);}
 return out.sort((a,b)=>a[0]-b[0]);
}
function validate(before,output,native,target){
 const a=ancients.inspect(before,12),b=ancients.inspect(output,12),c=ancients.inspect(native,12);
 assert.equal(b.available,true,b.reason);assert.equal(b.stage,target);assert.equal(c.stage,target);
 assert.equal(b.slot.table.count,a.slot.table.count+target-a.stage);
 const refDelta=a.stage===0?1:0;
 assert.equal(b.slot.table.count8,a.slot.table.count8+refDelta);assert.equal(b.slot.table.count4,a.slot.table.count4);
 assert.equal(b.state.activeSize,a.state.activeSize+(target-a.stage)*32+refDelta*8);
 for(let i=0;i<3;i++)assert.deepEqual(canonical(output,b.state.frames[i],i),canonical(native,c.state.frames[i],i));
 same(output.subarray(b.state.frames[0].start,b.state.frames[0].end),native.subarray(c.state.frames[0].start,c.state.frames[0].end));
 same(output.subarray(b.slot.table.end,b.state.objectStart),native.subarray(c.slot.table.end,c.state.objectStart));
 same(output.subarray(b.state.frames[3].start,b.state.frames[3].end),native.subarray(c.state.frames[3].start,c.state.frames[3].end));
 same(output.subarray(b.state.objectStart,b.state.statsEnd),before.subarray(a.state.objectStart,a.state.statsEnd));
 same(output.subarray(b.state.objectStart,b.state.statsEnd),native.subarray(c.state.objectStart,c.state.statsEnd));
 same(output.subarray(b.state.frames[2].start,b.state.frames[2].end),before.subarray(a.state.frames[2].start,a.state.frames[2].end));
 same(output.subarray(b.state.activeEnd),before.subarray(b.state.activeEnd));
 same(output.subarray(0,a.slot.base),before.subarray(0,a.slot.base));
 same(output.subarray(a.slot.base+0x400,a.slot.base+0x10400),before.subarray(a.slot.base+0x400,a.slot.base+0x10400));
 for(const row of a.slot.rows){const next=b.slot.rows.find(x=>x.id===row.id);assert.equal(next.quantity,row.quantity);assert.equal(next.auxiliary,row.auxiliary);}
}
const first=plan.patch(samples[0],[req(1)]),last=plan.patch(samples[1],[req(2)]),direct=plan.patch(samples[0],[req(2)]);
for(const [before,result,native,target,name] of [[samples[0],first,samples[1],1,'base_to_1.bin'],[samples[1],last,samples[2],2,'one_to_2.bin'],[samples[0],direct,samples[2],2,'base_to_2.bin']]){
 validate(before,result.bytes,native,target);fs.writeFileSync(path.join(outDir,name),result.bytes);
}
same(ancients.patch(ancients.patch(samples[0],[nativeReq(1)]).bytes,[nativeReq(2)]).bytes,direct.bytes);
assert.equal(direct.layout.length,2);assert.equal(first.layout[0].addedBytes,40);assert.equal(last.layout[0].addedBytes,32);
for(let source=0;source<3;source++){
 const state=targets.inspect(samples[source],12,id);assert.equal(state.current,source);assert.equal(state.registeredMax,source);
 assert.deepEqual(state.options.filter(o=>o.available).map(o=>o.value),[0,1,2]);
 for(let target=0;target<=source;target++){
  const lowered=targets.patch(samples[source],[req(target)]);assert.equal(lowered.layout.length,0);assert.equal(targets.inspect(lowered.bytes,12,id).registeredMax,source);
  same(targets.patch(lowered.bytes,[req(source)]).bytes,samples[source]);
 }
}
const down=targets.patch(samples[2],[req(0)]);fs.writeFileSync(path.join(outDir,'registered_down.bin'),down.bytes);
const lowFirst=targets.patch(samples[1],[req(0)]);same(targets.patch(lowFirst.bytes,[req(2)]).bytes,last.bytes);
same(targets.patch(targets.patch(direct.bytes,[req(0)]).bytes,[req(2)]).bytes,direct.bytes);
same(targets.patch(samples[0],[]).bytes,samples[0]);same(targets.patch(samples[2],[req(2)]).bytes,samples[2]);
const good=req(2);
for(const bad of [null,{...good,id:'other'},{...good,target:-1},{...good,target:3},{...good,target:'1'},{...good,target:1.5},{...good,slot:-1},{...good,slot:1.5},{...good,type:'item-add'}]) assert.throws(()=>targets.patch(samples[0],[bad]));
assert.throws(()=>targets.patch(samples[0],[good,good]));
const state=ancients.inspect(samples[0],12),firstState=ancients.inspect(samples[1],12);
function corrupt(source,fn){const b=source.slice();fn(b,new DataView(b.buffer));return b;}
const invalid=[corrupt(samples[0],(b,v)=>v.setUint32(state.stored.offset,1,true)),
 corrupt(samples[0],b=>b.fill(0,state.referenceInsertion-8,state.referenceInsertion)),
 corrupt(samples[0],b=>b.set(Buffer.from(ancients.PROFILE.addedReference,'hex'),state.referenceInsertion)),
 corrupt(samples[1],b=>b.fill(0,firstState.referenceInsertion,firstState.referenceInsertion+8)),
 corrupt(samples[1],(b,v)=>v.setUint32(firstState.slot.rows.find(r=>r.id===ancients.PROFILE.history[0]).valueOffset,0,true)),
 corrupt(samples[1],b=>{b[firstState.flagTemplate+8]^=1;})];
for(const b of invalid){assert.equal(ancients.inspect(b,12).canUpgrade,false);assert.throws(()=>targets.patch(b,[good]));
 assert.equal(resources.patch(b,[{slot:12,id:'9E5240D27406E85A',quantity:123}]).model.slots[12].rows.find(r=>r.id==='9E5240D27406E85A').quantity,123);}
const changes=[{slot:12,id:'418F903C792C6B9C',quantity:33},{slot:12,id:'9E5240D27406E85A',quantity:777},req(2),
 {slot:12,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73}];
const mixed=plan.patch(samples[0],changes),a=resources.patch(samples[0],changes.slice(0,2)),b=targets.patch(a.bytes,[req(2)]),c=enchantments.patch(b.bytes,[changes[3]]);same(mixed.bytes,c.bytes);
assert.equal(mixed.validation.newRecords,1);assert.equal(mixed.validation.enchantmentReplacements,1);
assert.equal(targets.inspect(mixed.bytes,12,id).current,2);
const stablePlan=require(path.resolve(stableRoot,'src/plan'));
for(const file of [oldBefore,oldAfter,normalFile]){
 const input=read(file),model=core.parse(input),requests=[{slot:11,id:'9E5240D27406E85A',quantity:123}];
 const axe=require('./src/levels'),armor=require('./src/armor-levels');
 if(targets.inspect(input,11,axe.ID).options.some(o=>o.value===2&&o.available))requests.push({slot:11,id:axe.ID,type:'level-target',target:2});
 if(targets.inspect(input,11,armor.PROFILE.id).options.some(o=>o.value===2&&o.available))requests.push({slot:11,id:armor.PROFILE.id,type:'level-target',target:2});
 same(plan.patch(input,requests).bytes,stablePlan.patch(input,requests).bytes);
 assert.equal(model.supported,core.parse(plan.patch(input,requests).bytes).supported);
}
const clone=samples[0].slice(),base=core.HEADER_SIZE+15*core.SLOT_SIZE;clone.set(samples[0].subarray(state.slot.base,state.slot.end),base);
const multi=targets.patch(clone,[req(2),req(1,15)]);assert.equal(targets.inspect(multi.bytes,12,id).current,2);assert.equal(targets.inspect(multi.bytes,15,id).current,1);
const offset=Buffer.alloc(samples[0].length+16);offset.set(samples[0],8);const saved=Buffer.from(offset);same(targets.patch(offset.subarray(8,samples[0].length+8),[good]).bytes,direct.bytes);same(offset,saved);
samples.forEach((b,i)=>same(b,originalHashes[i]));
const report={version:'0.9.0',profile:id,physicalSlot:13,nativeEdgesCompared:2,directBaseToTwoViaBothEdges:true,
 nativeLevelMapsReferencesAndTrackersMatch:true,attributeObjectsAndGroupsPreserved:true,resourcesAndAuxiliaryFieldsPreserved:true,
 registeredLevelRoundTripsChecked:6,wholeFileReturnsExactly:true,loweredHistoryCanTakeNextMappedUpgrade:true,
 noDoubleRegistration:true,invalidMapsReferencesAndHistoryBlocked:true,independentOtherQuantityEditsStillAvailable:true,
 resourceInclusionAndEnchantmentMixedPlanChecked:true,multiSlotSyntheticCopyChecked:true,legacyExportsByteIdenticalTo0_7_0:true,
 originalsAndOffsetBufferUnmodified:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ANCESTRAIS_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
