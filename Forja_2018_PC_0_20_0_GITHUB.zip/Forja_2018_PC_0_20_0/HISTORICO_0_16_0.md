# Forja 2018 PC · 0.16.0

Editor independente e offline de `game.sav` de God of War 2018 para PC. Abra
`Abrir_Editor.html` no navegador, carregue o arquivo completo e escolha o slot
pela descrição e pela data. A exportação gera uma cópia do arquivo completo.
Mantenha o original separado. A 0.15.2 permanece preservada.

## Adicionar encantamentos

Em **Encantamentos → Adicionar encantamento ao inventário**, os modelos
validados são Bestla's Frozen Shard+, Marca Perfeita do Viajante+ e Marca
Perfeita dos Anciões+. Escolha um perfil ausente e prepare a inclusão.
Cada pedido acrescenta uma unidade solta, para equipar pelo próprio jogo.
O relatório registra a inclusão. Perfis já presentes são preservados.

As inclusões reproduzem, byte a byte, os arquivos aprovados pelo usuário:
Bestla B, Viajante isolado, Anciões isolado, os dois juntos e o cenário com
Zeus e Retribuição+. O último retorno do jogo contém os três encantamentos
no peitoral de Zeus, com identidades e efeitos preservados, Zeus 9 e
Retribuição+ 9. A confirmação do usuário cobre esses cenários; outros perfis
não foram liberados por semelhança ou apenas pela presença de um ID no catálogo.

A nova instância usa um cabeçalho compatível do próprio slot e o perfil
completo validado, com uma identidade livre. O contador e o marcador da
receita acompanham o objeto. A rotina usa a variante sem aviso de nova
instância aprovada no jogo e o limite comum de 512 registros auxiliares.
As instâncias anteriores, seus encaixes, o mundo e os outros slots são
preservados. O gravador comum e os escritores de recursos/equipamentos
permanecem iguais aos da 0.15.2.

As verificações bloqueiam contadores sem instância correspondente, perfis
ambíguos, cópias adicionais, falta de um molde compatível e números inválidos.
A criação das duas marcas também exige ausência das peças NG+ usadas em
sua conversão. A coexistência com esses ingredientes ainda não foi validada;
a interface explica o impedimento. A conversão anterior de Kvasir e a
criação anterior de Symbol of Menace conservam suas próprias regras.
A duplicação genérica continua experimental.

O reconhecimento permanece estrutural, sem lista de builds. Os testes no
jogo desta função usaram o build 4757534, em campanhas normal e NG+ conforme
o perfil. Outros builds reconhecidos são indicados no relatório como cobertura
a confirmar. As verificações não representam garantia para qualquer arquivo.

Testes desta revisão:

```text
python3 build.py
node test_acquisition0160.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
node test_acquisition0160_ui.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
python3 test_acquisition0160_oracle.py CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
```

Os testes dependem das amostras pessoais, que não acompanham o pacote de código.
Os relatórios atuais são `VERIFICACAO_AQUISICAO_0_16_0.json`,
`VERIFICACAO_INTERFACE_AQUISICAO_0_16_0.json` e
`VERIFICACAO_INDEPENDENTE_AQUISICAO_0_16_0.json`.
A interface foi exercitada pelo HTML final em DOM simulado. Os relatórios
anteriores são históricos.

## Reconhecimento pela estrutura

A 0.15.1 liberava as ações por uma lista de dois números de build. Essa
restrição impedia operações em outros saves que já seguiam o mesmo formato.
A 0.15.2 reconhece a gramática binária: assinaturas, tamanhos, contagens,
objetos, grupos, mapas de progressão e fila auxiliar. O número de build fica
como informação e é preservado no cabeçalho geral e em cada slot.

Foram comparados 62 slots válidos de quatro arquivos reais, cobrindo builds
de slot 4389704, 4419126 e 4757534. Todos passam pelo mesmo leitor estrutural.
As quantidades de registros e objetos variam com o conteúdo; três prefixos
observados do mapa persistido são reconhecidos. A leitura usa as contagens
e os limites do próprio arquivo, sem depender de posições fixas dos itens.
Essa cobertura não garante compatibilidade com qualquer save futuro ou
malformado. Estruturas desconhecidas continuam bloqueadas.

As verificações de cada ação permanecem. Históricos incompletos, IDs
repetidos, mapas divergentes, quantidades inválidas e vínculos parciais não
são liberados só porque a estrutura geral foi reconhecida. A clonagem usa os
mesmos moldes e o mesmo gravador da versão anterior. Recursos, fila auxiliar
de no máximo 512 registros, catálogos e arquivos originais estão preservados.

### Níveis das armas e progresso

O novo arquivo tem build geral 4397815 e slots 4419126. No slot mais recente,
os mapas e históricos indicam Machado e Lâminas no nível 1, mas faltam as
propriedades adicionais do mundo. Os níveis agora aparecem em consulta;
a edição permanece bloqueada nesses slots. Para o Machado, faça a primeira
melhoria pelo jogo e abra o save novamente. Outro slot desse mesmo arquivo
já contém a propriedade e permite a melhoria pelo editor.

O formato NG+ com histórico completo, duas flags explícitas e ausência da
propriedade adicional continua usando o ajuste dos dois mapas da 0.15.0.
A ausência de um campo de progresso é diferente de um formato incompatível;
o reconhecimento estrutural não inventa campos do mundo que ainda não
foram observados nesse estado.

### Cobertura e validação

A mudança cobre equipamentos, armaduras, pomos, cabos, talismãs, rúnicos,
níveis das armas, cifras e contadores de maçãs/chifres. Os limites e requisitos
específicos dos perfis continuam. A criação e duplicação complexas de
encantamentos permanecem com a cobertura anterior e seu desenvolvimento adiado.

Testes desta revisão:

```text
python3 build.py
node test_structural0152.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
node test_structural0152_ui.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
python3 test_structural0152_oracle.py CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
```

Os testes usam as amostras pessoais locais, que não acompanham o pacote.
Comparam exportações com o gravador anterior, verificam os arquivos aprovados
pelo usuário, exercitam metadados independentes do formato e rejeitam nove
alterações estruturais inválidas. Um leitor Python independente confere as
três saídas do novo arquivo. A interface é exercitada pelo HTML final em DOM
simulado; esse teste não equivale a inspeção visual em navegador.

Relatórios atuais: `VERIFICACAO_ESTRUTURAL_0_15_2.json`,
`VERIFICACAO_INTERFACE_ESTRUTURAL_0_15_2.json` e
`VERIFICACAO_INDEPENDENTE_ESTRUTURAL_0_15_2.json`.
Os relatórios das revisões anteriores são históricos. A validação no jogo
das novas exportações 4419126 ainda depende de teste pelo usuário.

## Funções da 0.15.0 preservadas

- Catálogo de inclusão com 31 ataques rúnicos: 16 do Machado Leviatã e 15 das
  Lâminas do Caos. Os mesmos ataques aparecem nos filtros normal e NG+.
- Os quatro ataques com índice PC mapeado mantêm os níveis 1–3 e a rotina da
  0.14.3. As outras 27 inclusões ficam experimentais e fixas no nível 3.
- Cifras de Niflheim e Muspelheim, com total de partes até 4 e marca de cifra
  completa sincronizada. Cifras já coletadas não podem ser removidas.
- Reconhecimento das armas principais no NG+ que possui os dois mapas de
  nível e o histórico completo, mas não a propriedade adicional do mundo.

## Como testar as alterações novas

**Rúnicos:** em Equipamentos e melhorias, selecione “Todos os rúnicos ·
machado” ou “Todos os rúnicos · lâminas”. Escolha um ataque ausente. Para os
27 ataques novos, marque a opção de inclusão experimental e inclua no nível
3. O lote inclui somente os ausentes; ataques já possuídos são preservados.
É necessário pelo menos um ataque rúnico registrado no próprio save para
servir de molde. Teste carregar, equipar um ataque leve e um pesado de cada
arma, usá-los, fechar o inventário, salvar e carregar novamente.

As 27 inclusões novas copiam um registro rúnico do próprio save e trocam o
ID e o contador. Não inventam índices PC, não alteram os ataques existentes
e não copiam receitas da loja. A ausência de teste no jogo está explícita na
interface. Oito ataques ainda aparecem pelo nome interno porque os arquivos
de IDs fornecidos não identificam seus nomes visíveis. Invocações de Atreus
aguardam amostras e não foram incluídas.

**Cifras:** em Campanha e inventário, escolha o total de partes de Niflheim
ou Muspelheim, de 0 a 4. O editor permite aumentar o total e registra a cifra
completa ao chegar a 4. O par nativo de Niflheim confirma a primeira parte;
outros slots nativos confirmam o estado final 4 partes + 1 cifra completa.
Confira também o acesso ao reino na sala de viagem, depois salve e carregue
novamente. O editor não copia eventos de abertura de baú ou progresso de
missões. A suficiência desses registros para liberar a viagem ainda precisa
ser testada no jogo.

**Níveis no NG+:** o save informado tem Machado 6 e Lâminas 5 nos dois mapas,
com histórico completo. Nesse formato, o ajuste altera somente os dois
valores da arma escolhida. Não cria a propriedade ausente nem copia mundo
de uma campanha normal. Valide uma redução de nível, o inventário, o uso da
arma e o salvamento/recarregamento. A alteração desse formato NG+ ainda não
foi testada no jogo. Mapas divergentes, histórico incompleto, flags NG+
ausentes e propriedade duplicada ou deslocada continuam bloqueados.

## Cobertura anterior preservada

A versão 0.14.3 permanece separada. O gravador comum conserva a fila auxiliar
de no máximo 512 registros, correção confirmada pelos testes de cabos NG+.
As exportações dos cinco cabos e dos cenários anteriores de recursos,
capacidades, Ivaldi, cabos normais e upgrades das armas são comparadas com
os arquivos aprovados pelo usuário. A ampliação dos rúnicos não altera os
escritores de recursos, os moldes de equipamentos ou os módulos de
encantamentos. O desenvolvimento de encantamentos permanece adiado.

## Código e verificações

Execute `python3 build.py` para gerar o HTML offline. As verificações atuais:

```text
node test_release0150.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
node test_release0150_ui.cjs CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
python3 test_release0150_oracle.py CAMINHO_DO_WORKSPACE_DE_AMOSTRAS
```

Os saves pessoais e os arquivos de diagnóstico não fazem parte deste pacote
de código. Os testes anteriores e seus relatórios são históricos; a cobertura
da revisão atual é descrita em `VERIFICACAO_0_15_0.json`,
`VERIFICACAO_INTERFACE_0_15_0.json` e `VERIFICACAO_INDEPENDENTE_0_15_0.json`.
Verificação estrutural não substitui teste no jogo.
