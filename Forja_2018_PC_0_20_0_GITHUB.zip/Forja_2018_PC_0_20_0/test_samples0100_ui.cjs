'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs'),campaign=require('./src/campaign'),stat=require('./src/enchantment-stats'),core=require('./src/core');
const dir=process.argv[2],names=fs.readdirSync(dir).filter(n=>n.endsWith('.sav'));
const read=prefix=>new Uint8Array(fs.readFileSync(path.join(dir,names.find(n=>n.startsWith('game('+prefix)))));
const noError=()=>assert.equal($('error').hidden,true,$('error').textContent);
const same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const choose=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
(async()=>{
 const diff=read('antesDeAlterar');api.loadBytes(diff);api.selectSlot(13);api.chooseView('campaign');
 assert.equal($('campaign-controls').hidden,false);assert.equal($('difficulty-choice').disabled,false);
 await choose('difficulty-choice',2);await $('difficulty-apply').click();noError();
 assert.equal(campaign.difficulty(api.exportBytes().bytes,13).code,2);assert.ok($('slots-body').innerHTML.includes('Give Me a Challenge'));
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),diff);
 await $('reset-changes').click();noError();assert.equal(api.getState().log.length,0);
 const apple=read('AntesDepegar');api.loadBytes(apple);api.selectSlot(12);api.chooseView('campaign');
 assert.equal($('apples-total').value,'5');await choose('apples-total',9,'input');await $('apples-apply').click();noError();
 assert.equal(campaign.totals(api.exportBytes().model.slots[12],campaign.APPLES).total,9);
 const saved=api.exportBytes().bytes;await choose('apples-total',10,'input');await $('apples-apply').click();assert.equal($('error').hidden,false);same(api.exportBytes().bytes,saved);
 await $('reset-changes').click();noError();
 api.loadBytes(read('SemPedra'));api.selectSlot(11);api.chooseView('campaign');assert.equal($('stone-apply').disabled,false);
 await $('stone-apply').click();noError();assert.ok(campaign.stoneState(api.exportBytes().bytes,11).owned);assert.equal($('stone-apply').disabled,true);
 await query('[data-undo]').find(b=>b.dataset.undo==='11:superior-stone').click();noError();assert.equal($('stone-apply').disabled,false);assert.equal(api.getState().log.length,0);
 api.loadBytes(read('AntesDeEquipar'));api.selectSlot(11);api.chooseView('campaign');await choose('equip-chest-choice','EEA7E31201646AAF');await $('equip-chest-apply').click();noError();assert.equal(campaign.equipmentState(api.exportBytes().bytes,11).current.id,'EEA7E31201646AAF');
 const buy=read('AntesDeComprar');api.loadBytes(buy);api.selectSlot(11);api.chooseView('quantities');await choose('quantity-item','FCC6B87B4C8E41DC');await choose('quantity-value',123,'input');await $('quantity-apply').click();noError();
 api.chooseView('campaign');await $('acquire-wrist-apply').click();noError();let output=api.exportBytes();assert.equal(output.model.slots[11].rows.find(r=>r.id==='FCC6B87B4C8E41DC').quantity,123);assert.ok(campaign.acquisitionState(output.bytes,11).owned);assert.equal($('acquire-wrist-apply').disabled,true);
 const empty=read('semEncatamentos');api.loadBytes(empty);api.selectSlot(14);api.chooseView('campaign');assert.equal($('attach-apply').disabled,false);assert.ok($('attach-choice').innerHTML.includes('Symbol of Shadows'));
 await choose('attach-choice',75);await $('attach-apply').click();noError();assert.equal($('attach-apply').disabled,true);
 api.chooseView('enchantments');assert.ok($('enchantment-target').innerHTML.includes('75'));assert.ok($('enchantment-original').textContent.includes('Symbol of Shadows')||$('enchantment-model').innerHTML.includes('Symbol of Shadows'));
 const entry=stat.entries(api.exportBytes().bytes,14).entries.find(x=>x.uid===75);await choose('enchantment-stat-record',entry.id);await choose('enchantment-stat-value',321,'input');await $('enchantment-stat-apply').click();noError();
 assert.equal(stat.entries(api.exportBytes().bytes,14).entries.find(x=>x.id===entry.id).value,321);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,core.VERSION);assert.equal(report.validation.currentRageEdited,false);
 api.chooseView('changes');await query('[data-undo]').find(b=>b.dataset.undo==='14:attach-enchantment').click();noError();assert.equal(api.getState().log.length,0);assert.ok(!api.getState().changes.some(x=>['attach-enchantment','enchantment-stat'].includes(x.type)));
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),empty);
 const result={version:core.VERSION,htmlExecutedInVm:true,campaignControlsAndDifficultyMetadataChecked:true,difficultyApplyResetAndOriginalBackupPassed:true,
 appleCountersAndInvalidForcedClickDraftPreservationPassed:true,stoneApplyAndUndoPassed:true,ownedChestSwapPassed:true,
 resourceInsertionAndArmorAcquisitionCombinedPassed:true,namedExistingEnchantmentAttachedToEmptySocket:true,
 attachedEnchantmentCanBeEditedInSameDraft:true,undoAttachmentRemovesDependentStatChanges:true,reportsAndRootBackupsChecked:true,
 currentRageExcluded:true,browserVisualTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_10_0.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
