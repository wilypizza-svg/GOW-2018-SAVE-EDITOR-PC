'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const ws=path.resolve(process.argv[2]||'..'),core=require('./src/core'),nat=require('./src/native-records'),rem=require('./src/inventory-removal'),inv=require('./src/inventory'),plan=require('./src/plan');
const old=require(ws+'/testes_forja_remocao_20261025/source/Forja_2018_PC_0_17_3/src/plan'),manifest=JSON.parse(fs.readFileSync(ws+'/testes_forja_remocao_20261025/delivery_manifest.json'));
const cases=[];let negatives=0;
const rejects=fn=>{assert.throws(fn);negatives++;};
for(const e of manifest.files.filter(f=>f.type==='test')){
 const source=new Uint8Array(fs.readFileSync(e.source.file)),slot=core.parse(source).latestSlot,requests=e.operations.map(o=>o.operation==='remove-equipment'?{slot,type:rem.EQUIPMENT,id:o.id,confirmUnequipped:true}:{slot,type:rem.ENCHANTMENT,id:'enchantment-'+o.uid,uid:o.uid});
 const result=plan.patch(source,requests);assert.equal(Buffer.compare(Buffer.from(result.bytes),fs.readFileSync(e.file)),0,e.key);assert.equal(result.log.length,e.operations.length);
 const repeat=rem.patch(result.bytes,requests);assert.equal(repeat.log.length,0);assert.deepEqual(repeat.bytes,result.bytes);
 const resource={slot,id:'9E5240D27406E85A',quantity:7654321};const beforeHash=Buffer.from(source).toString('base64');assert.deepEqual(plan.patch(source,[resource]).bytes,old.patch(source,[resource]).bytes);
 const mixed=plan.patch(source,[resource,...requests]),mixedTx=nat.read(mixed.bytes,slot);assert.equal(nat.quantity(mixedTx,resource.id),resource.quantity);
 assert.equal(Buffer.from(source).toString('base64'),beforeHash,'Input changed');
 if(e.key==='02_BRACADEIRA_ARES_NGMAIS'){
  rejects(()=>rem.patch(source,[{slot,type:rem.EQUIPMENT,id:'19CD39EBB39080CB'}]));
  rejects(()=>rem.patch(source,[{slot,type:rem.EQUIPMENT,id:'not-an-item',confirmUnequipped:true}]));
  rejects(()=>plan.patch(source,[requests[0],requests[0]]));
  rejects(()=>plan.patch(source,[requests[0],{slot,type:'inventory-equipment',id:requests[0].id,stage:2,allowExperimental:true}]));
  const tx=nat.read(source,slot),unique=tx.state.objects.find(o=>require('./src/enchantments').classifyRaw(source.subarray(o.start,o.end)).unique);assert(unique);
  rejects(()=>rem.patch(source,[{slot,type:rem.ENCHANTMENT,id:'enchantment-'+unique.uid,uid:unique.uid}]));
  rejects(()=>rem.patch(source,[{slot,type:rem.ENCHANTMENT,id:'enchantment--1',uid:-1}]));
  const equipped=rem.inspect(source,slot).equipment.find(p=>p.owned&&!p.available&&/equipada/.test(p.reason));if(equipped)rejects(()=>rem.patch(source,[{slot,type:rem.EQUIPMENT,id:equipped.id,confirmUnequipped:true}]));
 }
 if(e.key==='07_PEITORAL_ARES_DEVOLVER_ENCANTAMENTOS')rejects(()=>rem.patch(source,[{slot,type:rem.ENCHANTMENT,id:'enchantment-110',uid:110}]));
 cases.push({case:e.key,byteIdenticalToGameValidatedTrial:true,idempotent:true,legacyResourceWriterByteIdentical:true,mixedResourceAndRemovalPassed:true});console.log(e.key,'OK');
}
const returned=new Uint8Array(fs.readFileSync(ws+'/upload/game(03_POMO_RETRIBUICAO_NGMAIS(Funcionou)).sav')),model=core.parse(returned),slot=model.latestSlot,state=inv.inspect(returned,slot,model).profiles.find(p=>p.id==='20079575B16C9CD2');assert(state.available&&!state.owned&&state.nativeSoldState);
const readd=plan.patch(returned,[{slot,type:'inventory-equipment',id:state.id,stage:2,allowExperimental:true}]),tx=nat.read(readd.bytes,slot);state.ids.forEach(id=>assert.equal(nat.quantity(tx,id),1));assert.equal(nat.view(nat.mapEntry(tx,0,966)).getUint32(4,true),2);
const ordinary=new Uint8Array(fs.readFileSync(manifest.files.find(f=>f.key==='00_CONTROLE_NGMAIS').file)),ms=core.parse(ordinary).latestSlot;
for(const request of [{slot:ms,type:'inventory-equipment',id:'20079575B16C9CD2',stage:1,allowExperimental:true},{slot:ms,type:'idunn-apples',total:9},{slot:ms,type:'realm-cipher',id:'niflheim',total:4}]){
 try{const a=old.patch(ordinary,[request]),b=plan.patch(ordinary,[request]);assert.deepEqual(a.bytes,b.bytes);}catch(e){if(e.code==='ERR_ASSERTION')throw e;}
}
fs.writeFileSync(__dirname+'/VERIFICACAO_REMOCOES_0_19_0.json',JSON.stringify({version:core.VERSION,passed:true,cases,negativeGuards:negatives,nativeSoldPommelCanBeReadded:true},null,2));console.log('Native sold item re-add OK; negative guards',negatives);
