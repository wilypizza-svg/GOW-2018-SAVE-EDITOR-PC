"""Verifica a expansão sem importar o leitor/gravador JavaScript."""
import ast
import hashlib
import json
import struct
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
# Reutiliza só as definições do leitor Python independente da versão anterior.
tree=ast.parse((root/'test_inventory_oracle.py').read_text())
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.FunctionDef) and n.name=='decode')
scope={};exec(compile(ast.Module(body=tree.body[:cut+1],type_ignores=[]),'independent_binary_reader','exec'),scope)
decode=scope['decode'];hx=lambda b:b.hex().upper()
manifest=json.loads(Path(sys.argv[1]).read_text());results=[]
for case in manifest:
 a=Path(case['source']).read_bytes();b=Path(case['output']).read_bytes();assert hashlib.sha256(a).hexdigest()==case['sourceSha256'];assert hashlib.sha256(b).hexdigest()==case['outputSha256']
 x,y=decode(a,case['index']),decode(b,case['index']);assert len(a)==len(b)==33554400
 assert a[:x['base']+0x124]==b[:x['base']+0x124]
 assert a[x['base']+0x128:x['start']]==b[x['base']+0x128:x['start']]
 assert a[y['end']:]==b[y['end']:]
 assert x['maps']==y['maps'] and x['refs']==y['refs'] and x['groups']==y['groups']
 allowed={r['id'] for r in case['requests'] if 'type' not in r};new_templates=[]
 for r in case['requests']:
  if r.get('type')=='inventory-equipment':
   allowed.update(r['expectedIds'])
   for id in r['expectedIds']:assert y['rows'][id][0]==1
  elif r.get('type')=='enchantment-duplicate':new_templates.extend([bytes.fromhex(r['templateHex'])]*r['count'])
  elif 'type' not in r:assert y['rows'][r['id']][0]==r['quantity']
  else:raise AssertionError(r['type'])
 for id,row in x['rows'].items():
  if id not in allowed:assert y['rows'][id][1]==row[1]
 for id,(_,raw,offset) in y['rows'].items():
  if id not in x['rows']:
   assert id in allowed
   assert struct.unpack_from('<I',raw,12)[0]==(offset-y['start']-29)//16
 assert y['objects'][:len(x['objects'])]==x['objects']
 new=y['objects'][len(x['objects']):];assert len(new)==len(new_templates)
 changedfinals=set(allowed)
 for o,template in zip(new,new_templates):
  raw=o['raw'];assert raw[:8]==template[:8] and raw[16:48]==template[16:48] and raw[60:]==template[60:]
  assert raw[8:16]==b'\0'*8 and struct.unpack_from('<II',raw,52)==(0xffffffff,0xffffffff)
  assert o['uid'] not in [o['uid'] for o in x['objects']]
  id=hx(struct.pack('<Q',o['uid']));changedfinals.add(id);assert hx(y['finals'][id][8:])=='02000000F37F0000'
 for id,raw in x['finals'].items():assert y['finals'][id]==raw
 for id,raw in y['finals'].items():
  if id not in x['finals']:
   assert id in changedfinals
   if id in allowed:assert struct.unpack_from('<I',raw,8)[0]==0
 results.append(dict(name=case['name'],wholeFileEnvelopePreserved=True,unmappedMapsAndReferencesPreserved=True,oldObjectsAndGroupsPreserved=True,ownIdsAndInstanceBodiesChecked=True))
report=dict(version='0.12.0',language='Python',independentOfJavascript=True,cases=results,inGameTestedHere=False)
(root/'VERIFICACAO_INDEPENDENTE_0_12_0.json').write_text(json.dumps(report,indent=2));print(json.dumps({'passed':True,'cases':len(results)}))
