'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const core = require('./src/core'), resources = require('./src/resource-edit'), armor = require('./src/armor-levels');
const axe = require('./src/levels'), enchants = require('./src/enchantments'), writer = require('./src/plan');
const [beforePath, afterPath, axeBeforePath, normalPath, ngPath, stableRoot, outPath, mixedPath] = process.argv.slice(2);
const read = file => new Uint8Array(fs.readFileSync(file)), same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const before = read(beforePath), after = read(afterPath), axeBefore = read(axeBeforePath), normal = read(normalPath), ng = read(ngPath), pristine = before.slice();
const profile = armor.PROFILE, request = { slot: 11, id: profile.id, type: 'armor-level', stage: 2 };
const state = armor.inspect(before, 11), native = armor.inspect(after, 11);
assert.equal(state.available, true, state.reason); assert.equal(state.canUpgrade, true); assert.equal(state.stage, 1);
assert.equal(native.available, true, native.reason); assert.equal(native.canUpgrade, false); assert.equal(native.stage, 2);
const result = armor.patch(before, [request]), edited = armor.inspect(result.bytes, 11), editedSlot = result.model.slots[11];
fs.writeFileSync(outPath, result.bytes);
assert.equal(edited.stage, 2); assert.equal(edited.canUpgrade, false); assert.equal(result.log.length, 1);
assert.equal(editedSlot.table.count, state.slot.table.count + 1); assert.equal(editedSlot.table.count8, state.slot.table.count8 - 1);
assert.equal(editedSlot.table.count4, state.slot.table.count4); assert.equal(edited.state.activeSize, state.state.activeSize + 40);
assert.equal(edited.state.statsSize, state.state.statsSize + 8); assert.equal(result.bytes.length, before.length);
same(result.bytes.subarray(edited.state.frames[0].start, edited.state.frames[0].end), after.subarray(native.state.frames[0].start, native.state.frames[0].end));
const canonical = map => map.map(entry => [entry.key, entry.value, entry.flag]).sort((a, b) => a[0] - b[0]);
assert.deepEqual(canonical(edited.storedMap), canonical(native.storedMap));
same(result.bytes.subarray(editedSlot.table.end, edited.state.objectStart), after.subarray(native.slot.table.end, native.state.objectStart));
same(result.bytes.subarray(edited.state.objectStart, edited.state.statsEnd), before.subarray(state.state.objectStart, state.state.statsEnd));
same(result.bytes.subarray(edited.state.objectStart, edited.state.statsEnd), after.subarray(native.state.objectStart, native.state.statsEnd));
same(result.bytes.subarray(edited.state.frames[3].start, edited.state.frames[3].end), after.subarray(native.state.frames[3].start, native.state.frames[3].end));
same(result.bytes.subarray(edited.state.frames[2].start, edited.state.frames[2].end), before.subarray(state.state.frames[2].start, state.state.frames[2].end));
for (const row of state.slot.rows) {
  const next = editedSlot.rows.find(item => item.id === row.id); assert.equal(next.quantity, row.quantity); assert.equal(next.auxiliary, row.auxiliary);
}
same(result.bytes.subarray(state.slot.base, state.slot.base + 0x10400).slice(0x400), before.subarray(state.slot.base + 0x400, state.slot.base + 0x10400));
same(armor.patch(before, []).bytes, before); same(armor.patch(after, [request]).bytes, after); same(armor.patch(result.bytes, [request]).bytes, result.bytes);
for (const bad of [null, { ...request, id: 'another-chest' }, { ...request, stage: 0 }, { ...request, stage: 1 }, { ...request, stage: 3 },
  { ...request, slot: 12 }, { ...request, slot: -1 }, { ...request, slot: 1.5 }, { ...request, type: 'item-add' }]) assert.throws(() => armor.patch(before, [bad]));
assert.throws(() => armor.patch(before, [request, request]));
assert.equal(armor.inspect(before, 11, 'another-chest').available, false);
function corrupted(change) { const copy = before.slice(); change(copy, new DataView(copy.buffer)); return copy; }
for (const bytes of [
  corrupted((b, v) => v.setUint32(state.stored.valueOffset, 2, true)),
  corrupted(b => b.fill(0, state.referenceOffset, state.referenceOffset + 8)),
  corrupted(b => b.set(b.subarray(state.referenceOffset, state.referenceOffset + 8), state.referenceOffset + 16)),
  corrupted(b => { b[state.flagTemplate + 8] ^= 1; }),
  corrupted((b, v) => v.setUint32(state.slot.rows.find(row => row.id === profile.previousId).valueOffset, 0, true))
]) {
  assert.equal(armor.inspect(bytes, 11).canUpgrade, false); assert.throws(() => armor.patch(bytes, [request]));
  assert.equal(resources.patch(bytes, [{slot:11,id:'9E5240D27406E85A',quantity:123}]).model.slots[11].rows.find(row=>row.id==='9E5240D27406E85A').quantity,123);
}
const axeSlot = core.parse(before).slots.find(slot => slot.index !== 11 && axe.inspect(before, slot.index).canUpgrade)?.index;
assert.ok(Number.isInteger(axeSlot));
const resourceChanges = [{slot:11,id:'CC1B3E5C878842B3',quantity:22},{slot:11,id:'9E5240D27406E85A',quantity:12345}];
const axeChange = {slot:axeSlot,id:axe.ID,type:'axe-level',level:6}, enchantmentChange = {slot:11,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73};
const mixed = writer.patch(before, [request,...resourceChanges,axeChange,enchantmentChange]); fs.writeFileSync(mixedPath,mixed.bytes);
const a = resources.patch(before,resourceChanges), b = axe.patch(a.bytes,[axeChange]), c = armor.patch(b.bytes,[request]), d = enchants.patch(c.bytes,[enchantmentChange]);
same(mixed.bytes,d.bytes); assert.equal(mixed.validation.armorLevelTransitions,1); assert.equal(mixed.validation.axeLevelTransitions,1);
assert.equal(mixed.validation.enchantmentReplacements,1); assert.equal(mixed.validation.newRecords,1);
const old = require(path.resolve(stableRoot,'src/plan.js'));
for (const [bytes,changes] of [[before,resourceChanges],[axeBefore,[{slot:11,id:axe.ID,type:'axe-level',level:6}]],[before,[enchantmentChange,...resourceChanges]]]) same(writer.patch(bytes,changes).bytes,old.patch(bytes,changes).bytes);
// Copia um slot válido para testar duas posições físicas; não é uma amostra do jogo.
const fixture = before.slice(), cloneIndex = 12, cloneBase = core.HEADER_SIZE + cloneIndex * core.SLOT_SIZE;
fixture.set(before.subarray(state.slot.base,state.slot.end),cloneBase);
const multi = armor.patch(fixture,[request,{...request,slot:cloneIndex}]); assert.equal(multi.log.length,2);
assert.equal(armor.inspect(multi.bytes,11).stage,2); assert.equal(armor.inspect(multi.bytes,cloneIndex).stage,2);
let checked = 0;
for (const bytes of [before,after,normal,ng]) for (const slot of core.parse(bytes).slots.filter(slot=>slot.available)) {
  const inspection = armor.inspect(bytes,slot.index); checked++;
  if (!inspection.canUpgrade && inspection.stage !== 2) assert.throws(()=>armor.patch(bytes,[{...request,slot:slot.index}]));
}
const buffer = Buffer.alloc(before.length+16);buffer.set(before,8);const saved=Buffer.from(buffer);
same(armor.patch(buffer.subarray(8,before.length+8),[request]).bytes,result.bytes);same(buffer,saved);same(before,pristine);
const report={version:'0.9.0',profile:profile.id,observedTransition:'Reinforce1 -> Reinforce2',explicitPhysicalSlot:12,
  recognisedSlotsChecked:checked,nativeGlobalMapByteExact:true,nativeStoredMapEquivalentByKey:true,nativeReferencesByteExact:true,nativeFinalSectionByteExact:true,
  existingAttributeObjectsByteExact:true,resourcesAndExistingRowsPreserved:true,unknownThirdMapPreserved:true,invalidAndAmbiguousProfilesBlocked:true,
  otherQuantityEditsStillWorkWhenArmorBlocked:true,alreadyUpgradedIsNoOp:true,resourceAxeArmorAndEnchantmentPlanVerified:true,legacyExportsByteIdenticalTo0_5_0:true,
  multiSlotVerifiedWithSyntheticSlotCopy:true,offsetBufferAndOriginalUnmodified:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ARMADURA_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
