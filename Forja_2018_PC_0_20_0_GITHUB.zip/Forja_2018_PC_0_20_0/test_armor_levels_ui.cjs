'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, query, downloads, $ } = require('./test_dom_harness.cjs');
const armor = require('./src/armor-levels'), writer = require('./src/plan');
const bytes = new Uint8Array(fs.readFileSync(process.argv[2])), upgraded = new Uint8Array(fs.readFileSync(process.argv[3]));
const same = (a,b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async()=>{
  api.loadBytes(bytes); api.chooseView('levels'); assert.equal($('levels-controls').hidden,true);
  await $('armor-level-apply').click();assert.equal(api.getState().log.length,0);assert.equal($('error').hidden,false);
  api.selectSlot(11);api.chooseView('levels');assert.equal($('levels-controls').hidden,false);
  assert.equal($('armor-level-original').textContent,'Melhoria 1');assert.equal($('armor-level-apply').disabled,true);
  $('armor-level-target').value='2';await $('armor-level-target').fire('change');assert.equal($('armor-level-apply').disabled,false);
  await $('armor-level-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
  const request={slot:11,id:armor.PROFILE.id,type:'armor-level',stage:2};
  same(api.exportBytes().bytes,writer.patch(bytes,[request]).bytes);assert.equal($('armor-level-edited').textContent,'Melhoria 2');
  assert.equal($('armor-level-apply').disabled,true);assert.ok($('changes-body').innerHTML.includes('Melhoria 2'));
  $('quantity-item').value='CC1B3E5C878842B3';await $('quantity-item').fire('change');$('quantity-value').value='22';
  await $('quantity-value').fire('input');await $('quantity-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
  $('enchantment-target').value='12';await $('enchantment-target').fire('change');$('enchantment-model').value='73';await $('enchantment-model').fire('change');
  await $('enchantment-apply').click();assert.equal($('error').hidden,true,$('error').textContent);
  const other=[{slot:11,id:'CC1B3E5C878842B3',quantity:22},{slot:11,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73}];
  same(api.exportBytes().bytes,writer.patch(bytes,[request,...other]).bytes);
  await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());
  assert.equal(report.validation.newlyRegisteredLevelTransitions,1);assert.equal(report.validation.levelTargetsInGameTested,false);
  assert.equal(report.validation.levelHistoryPreserved,true);
  await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
  await query('[data-undo]').find(button=>button.dataset.undo==='11:'+armor.PROFILE.id).click();
  same(api.exportBytes().bytes,writer.patch(bytes,other).bytes);assert.equal($('armor-level-edited').textContent,'Melhoria 1');
  await $('reset-changes').click();assert.equal(api.getState().log.length,0);
  api.selectSlot(0);api.chooseView('levels');assert.equal($('armor-level-apply').disabled,true);
  await $('armor-level-apply').click();assert.equal($('error').hidden,false);assert.equal(api.getState().log.length,0);
  api.loadBytes(upgraded);api.selectSlot(11);api.chooseView('levels');assert.equal($('armor-level-original').textContent,'Melhoria 2');assert.equal($('armor-level-apply').disabled,true);
  const summary={version:'0.9.0',htmlExecutedInVM:true,explicitPhysicalSlot12Selection:true,armorButtonAndBeforeAfterDisplayed:true,
    mixedResourcesAndEnchantmentsVerified:true,undoResetReportAndDownloadVerified:true,missingProfileAndUnchangedTargetDisabled:true,
    forcedInvalidClickDoesNotChangeDraft:true,visualBrowserTested:false,inGameTestedHere:false};
  fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ARMADURA_INTERFACE_0_9_0.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
