'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const core = require('./src/core'), resources = require('./src/resource-edit'), levels = require('./src/levels');
const enchants = require('./src/enchantments'), equipment = require('./src/equipment'), catalog = require('./src/catalog'), plan = require('./src/plan');
const [armorPath, normalPath, ngPath, axePath, outPath] = process.argv.slice(2);
const read = p => new Uint8Array(fs.readFileSync(p));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const request = (slot, targetUid, templateUid) => ({ slot, targetUid, templateUid, id: enchants.recordId(targetUid), type: 'enchantment-copy' });
const before = read(armorPath), pristine = before.slice(), normal = read(normalPath), ng = read(ngPath), axe = read(axePath);
assert.equal(equipment.upgrades.length, 475);
assert.equal(equipment.families.length, 263);
for (const upgrade of equipment.upgrades) assert.equal(equipment.lookup(upgrade.id).stage.id, upgrade.id);
assert.equal(equipment.lookup('4B9C550D079A0AE1').stage.order, 1);
assert.equal(equipment.lookup('5898550D079A0AE1').stage.order, 2);
assert.equal(equipment.lookup('6DD41B327975AF5E').stage.stage, 'Nível 6');
assert.equal(equipment.armorKind('EEA7E31201646AAF'), 'chest');
assert.equal(equipment.armorKind('1F0B470B60D483EF'), null);
assert.equal(equipment.lookup('5D18B5C7D67AEABC'), null); // criador de encantamento não é uma peça de armadura
same(enchants.patch(before, []).bytes, before);
let occupied = 0, replacements = 0, grew = false, shrank = false, equalLength = false;
for (const bytes of [before, normal, ng]) {
  const model = core.parse(bytes);
  for (const slot of model.slots.filter(slot => slot.available)) {
    occupied++;
    const current = enchants.inspect(bytes, slot.index, model);
    assert.equal(current.available, true, current.reason);
    for (const target of current.targets) {
      assert.ok(target.kind); assert.notEqual(target.link, 0xFFFFFFFF); assert.ok(target.socket < 3);
      // Cobertura dos três tamanhos sem confundir releitura com validade no jogo.
      const candidates = enchants.compatible(current, target.uid), selected = [];
      for (const predicate of [template => template.length < target.length, template => template.length === target.length, template => template.length > target.length]) {
        const template = candidates.find(predicate); if (template && !selected.some(item => item.uid === template.uid)) selected.push(template);
      }
      // Todos os alvos do slot mais recente; nos demais, um alvo por slot.
      for (const template of (slot.index === model.latestSlot || bytes === before && slot.index === 11 ? selected : selected.slice(0, 1))) {
        const result = enchants.patch(bytes, [request(slot.index, target.uid, template.uid)]), after = enchants.inspect(result.bytes, slot.index, result.model);
        const next = after.targets.find(item => item.uid === target.uid);
        assert.equal(next.length, template.length); assert.equal(next.bindingId, target.bindingId);
        assert.equal(next.uid, target.uid); assert.equal(next.link, target.link); assert.equal(next.socket, target.socket);
        same(result.bytes.subarray(next.start + 16, next.start + 48), bytes.subarray(template.start + 16, template.start + 48));
        same(result.bytes.subarray(next.start + 64, next.end), bytes.subarray(template.start + 64, template.end));
        assert.equal(result.bytes.length, bytes.length); assert.equal(result.model.slots[slot.index].rows.length, slot.rows.length);
        assert.equal(result.model.slots[slot.index].table.count8, slot.table.count8); assert.equal(result.model.slots[slot.index].table.count4, slot.table.count4);
        const donorAfter = after.objects.find(item => item.uid === template.uid);
        same(result.bytes.subarray(donorAfter.start, donorAfter.end), bytes.subarray(template.start, template.end));
        replacements++; grew ||= template.length > target.length; shrank ||= template.length < target.length; equalLength ||= template.length === target.length;
      }
    }
  }
}
assert.ok(grew && shrank && equalLength);
// Dois destinos, incluindo um modelo que também é destino: ambos usam o original.
const chain = [request(11, 12, 34), request(11, 34, 73)], result = enchants.patch(before, chain);
fs.writeFileSync(outPath, result.bytes);
assert.equal(result.validation.enchantmentReplacements, 2);
assert.equal(result.validation.enchantmentNewSocketsCreated, 0);
const state = enchants.inspect(before, 11), outputState = enchants.inspect(result.bytes, 11);
for (const change of chain) {
  const target = outputState.objects.find(object => object.uid === change.targetUid), source = state.objects.find(object => object.uid === change.templateUid);
  same(result.bytes.subarray(target.start + 64, target.end), before.subarray(source.start + 64, source.end));
}
const simple = request(11, 12, 73);
for (const invalid of [null, {...simple, type:'other'}, {...simple, slot:12}, {...simple, slot:-1}, {...simple,id:'enchantment-34'},
  {...simple,targetUid:72,id:'enchantment-72'}, {...simple,targetUid:77,id:'enchantment-77'}, {...simple,templateUid:999999},
  {...simple,templateUid:12}, {...simple,templateUid:-1}, {...simple,targetUid:1.5}]) assert.throws(() => enchants.patch(before, [invalid]));
assert.throws(() => enchants.patch(before, [simple, simple]));
assert.throws(() => plan.patch(before, [{ ...simple, type: 'armor-level', level: 2 }]));
assert.throws(() => plan.patch(before, [{ slot:11,id:'4B9C550D079A0AE1',quantity:1 }]));
const corrupt = before.slice(), target = state.objects.find(object => object.uid === 12);
new DataView(corrupt.buffer).setUint32(target.start + 52, 0xFFFFFFFF, true);
assert.throws(() => enchants.patch(corrupt, [simple]));
const corruptUid = before.slice(); new DataView(corruptUid.buffer).setUint32(target.start + 48, 34, true);
assert.throws(() => enchants.patch(corruptUid, [simple]));
const badStat = before.slice(), donor = state.objects.find(object => object.uid === 73);
new DataView(badStat.buffer).setFloat32(donor.end - 4, NaN, true);
assert.throws(() => enchants.patch(badStat, [simple]));
const duplicateSocket = before.slice(), other = state.objects.find(object => object.uid === 34), cv = new DataView(duplicateSocket.buffer);
duplicateSocket.set(before.subarray(target.start + 8, target.start + 16), other.start + 8); cv.setUint32(other.start + 56, target.socket, true);
assert.throws(() => enchants.patch(duplicateSocket, [simple]));
const mixed = [{ slot:11,id:'CC1B3E5C878842B3',quantity:22 },{ slot:11,id:'EDB4476E71735CC3',quantity:3 },
  { slot:11,id:levels.ID,type:'axe-level',level:6 }, simple];
const composed = plan.patch(axe, mixed), resourceOnly = resources.patch(axe, mixed.slice(0, 2));
const levelOnly = levels.patch(resourceOnly.bytes, [mixed[2]]), enchantOnly = enchants.patch(levelOnly.bytes, [simple]);
same(composed.bytes, enchantOnly.bytes);
assert.equal(composed.validation.newRecords, 1); assert.equal(composed.validation.axeLevelTransitions, 1); assert.equal(composed.validation.enchantmentReplacements, 1);
for (const [bytes, changes] of [[before,[{slot:11,id:'9E5240D27406E85A',quantity:12345}]], [axe,mixed.slice(0,3)]]) {
  const oldPlan = require(path.resolve(process.argv[7] || path.join(__dirname, '../../../../deliverables/Forja_2018_PC_0_4_0'), 'src/plan.js'));
  same(plan.patch(bytes, changes).bytes, oldPlan.patch(bytes, changes).bytes);
}
const multi = enchants.patch(before, [simple,request(1,12,73)]); assert.equal(multi.log.length, 2);
const offsetBuffer = Buffer.alloc(before.length + 16); offsetBuffer.set(before, 8);
const bufferInput = offsetBuffer.subarray(8, before.length + 8), saved = Buffer.from(offsetBuffer);
same(enchants.patch(bufferInput, [simple]).bytes, enchants.patch(before, [simple]).bytes); same(saved, offsetBuffer); same(before, pristine);
const report = { version:'0.9.0', occupiedSlotsChecked:occupied, replacementExportsChecked:replacements,
  templateGrowthAndShrinkAndSameLengthChecked:grew && shrank && equalLength, catalogueFamilies:equipment.families.length,
  allListedUpgradeIdsGrouped:equipment.upgrades.length, originalModelUsedForChainedRequests:true,
  bindingUidAndSocketPreserved:true, modelsPreserved:true, mixedResourceAxeAndEnchantmentPlanVerified:true,
  legacyResourceAndAxeExportsByteIdentical:true, invalidRequestsRejected:true, newArmorSocketsCreated:0,
  sourceAndOffsetBufferUnmodified:true, inGameTestedHere:false, armorLevelWriterImplemented:false };
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ENCANTAMENTOS_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
