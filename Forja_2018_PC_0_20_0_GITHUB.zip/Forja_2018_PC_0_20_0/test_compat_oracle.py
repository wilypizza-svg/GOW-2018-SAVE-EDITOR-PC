"""Verificação independente da campanha normal, sem importar JavaScript."""
from pathlib import Path
import struct
import sys
import json

before, after = (Path(p).read_bytes() for p in sys.argv[1:3])
assert len(before) == len(after) == 33554400
assert before[:4160] == after[:4160]
read32 = lambda data, p: struct.unpack_from('<I', data, p)[0]
add_ids = ['CC1B3E5C878842B3', '623486F325B97A3A', '418F903C792C6B9C',
           '6D92A12B3DC4A427', 'F3CBC3D285BFB35D', 'FCC6B87B4C8E41DC']
ranges = []
for slot in range(12):
    base = 4160 + slot * 1677512
    table = base + 66589
    count = read32(before, table - 12)
    end = table + count * 16
    active_end = base + 66560 + read32(before, base + 292)
    assert read32(after, table - 12) == count + 6
    assert read32(after, table - 24) == read32(before, table - 24) + 96
    assert read32(after, base + 292) == read32(before, base + 292) + 96
    assert before[end:active_end] == after[end + 96:active_end + 96]
    assert before[active_end + 96:base + 1677512] == after[active_end + 96:base + 1677512]
    assert before[table - 8:table] == after[table - 8:table]
    for i, resource_id in enumerate(add_ids):
        pos = end + i * 16
        assert after[pos:pos + 8].hex().upper() == resource_id
        assert read32(after, pos + 8) == (500 + slot * 10 + i if i < 5 else 1000 + slot)
        assert read32(after, pos + 12) == count + i
    quantities_changed = set()
    for i in range(count):
        pos = table + i * 16
        assert before[pos:pos + 8] == after[pos:pos + 8]
        assert before[pos + 12:pos + 16] == after[pos + 12:pos + 16]
        resource_id = before[pos:pos + 8].hex().upper()
        if resource_id in {'9E5240D27406E85A', '6A13DB1C163C952D'}:
            expected = 2000000 + slot if resource_id == '9E5240D27406E85A' else 505 + slot * 10
            assert read32(after, pos + 8) == expected
            quantities_changed.add(resource_id)
            ranges.append((pos + 8, pos + 12))
        else:
            assert before[pos + 8:pos + 12] == after[pos + 8:pos + 12]
    assert len(quantities_changed) == 2
    ranges.extend([(base + 292, base + 296), (table - 24, table - 20),
                   (table - 12, table - 8), (end, active_end + 96)])
cursor = 0
for start, end in sorted(ranges):
    assert before[cursor:start] == after[cursor:start]
    cursor = end
assert before[cursor:] == after[cursor:]
assert before[4160 + 12 * 1677512:] == after[4160 + 12 * 1677512:]
report = {'version': '0.9.0', 'independentLanguage': 'Python struct', 'occupiedSlotsChecked': 12,
          'newRowsChecked': 72, 'existingFieldsChecked': 24, 'globalHeaderAnd8EmptySlotsIntact': True,
          'allShiftedDataAndUnchangedBytesCompared': True, 'inGameTestedHere': False}
Path(__file__).with_name('VERIFICACAO_NORMAL_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
