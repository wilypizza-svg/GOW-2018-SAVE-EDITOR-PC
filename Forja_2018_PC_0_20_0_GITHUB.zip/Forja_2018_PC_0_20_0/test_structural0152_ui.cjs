/* Exercita o HTML distribuído com metadados diferentes e o mesmo formato. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,$,query,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),inventory=require('./src/inventory'),oldPlan=require('../Forja_2018_PC_0_15_1/src/plan');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),load=p=>new Uint8Array(fs.readFileSync(path.join(ws,p))),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const ok=()=>assert.equal($('error').hidden,true,$('error').textContent),change=async(id,value)=>{$(id).value=String(value);await $(id).fire('change');};
(async()=>{
 const original=load('upload/game(20261024-141341).sav'),model=core.parse(original),slot=model.latestSlot;
 api.loadBytes(original,'game.sav');api.selectSlot(slot);api.chooseView('levels');
 for(const prefix of ['level','blades-level']){
  assert.equal($(prefix+'-original').textContent,'Nível 1');assert.equal($(prefix+'-target').disabled,true);
  assert.match($(prefix+'-note').textContent,/registro secundário|propriedade|mundo|melhoria/);assert.doesNotMatch($(prefix+'-note').textContent,/versão PC.*mapeada/);
 }
 api.chooseView('equipment');await change('inventory-item','615B1370AEBED3EA');assert.equal($('inventory-apply').disabled,false);assert.match($('inventory-note').textContent,/Formato estrutural reconhecido/);
 await $('inventory-apply').click();ok();assert.match($('changes-body').innerHTML,/Breastplate of the Traveler/);
 const state=inventory.inspect(original,slot),pommel=state.profiles.find(p=>p.kind==='axe'&&p.variant==='normal'&&!p.owned&&p.available);
 assert.ok(pommel);$('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');await change('inventory-kind','axe');await change('inventory-item',pommel.id);await $('inventory-apply').click();ok();
 api.chooseView('campaign');
 for(const id of ['apples','horns','niflheim-cipher','muspelheim-cipher']){assert.equal($(id+'-total').disabled,false);$(id+'-total').value=id.includes('cipher')?'4':'9';await $(id+'-apply').click();ok();}
 const edited=api.exportBytes();assert.equal(edited.model.build,4397815);assert.equal(edited.model.slots[slot].build,4419126);assert.equal(edited.log.length,6);
 api.chooseView('changes');assert.equal($('change-count').textContent,'6 alterações');await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),edited.bytes);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.15.2');assert.equal(report.changes.length,6);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),original);
 const undo=query('[data-undo]').find(e=>e.dataset.undo===slot+':615B1370AEBED3EA');assert.ok(undo);await undo.click();ok();assert.equal(api.getState().log.length,5);
 await $('reset-changes').click();ok();assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 // Mesmo arquivo: outro slot já contém a propriedade que permite editar o Machado.
 api.selectSlot(0);api.chooseView('levels');assert.equal($('level-original').textContent,'Nível 1');assert.equal($('level-target').disabled,false);await change('level-target',6);await $('level-apply').click();ok();assert.equal($('level-edited').textContent,'Nível 6');assert.equal(api.exportBytes().model.slots[0].build,4419126);
 await $('reset-changes').click();api.selectSlot(2);api.chooseView('equipment');await change('inventory-item','615B1370AEBED3EA');assert.equal($('inventory-apply').disabled,false);
 // Mantém os dois formatos reais que já abriam na revisão anterior.
 const old=load('upload/game(20261024-134912).sav');api.loadBytes(old,'game.sav');api.selectSlot(core.parse(old).latestSlot);api.chooseView('levels');assert.equal($('level-original').textContent,'Nível 3');assert.equal($('level-target').disabled,false);
 const ngp=load('upload/game(10).sav'),nm=core.parse(ngp);api.loadBytes(ngp,'game.sav');api.selectSlot(nm.latestSlot);api.chooseView('levels');assert.equal($('level-original').textContent,'Nível 6');await change('level-target',5);await $('level-apply').click();ok();
 same(api.exportBytes().bytes,oldPlan.patch(ngp,[{slot:nm.latestSlot,type:'weapon-level',id:'axe-main-level',level:5}]).bytes);
 const result={version:core.VERSION,executedBuiltHtmlInSimulatedDom:true,foreign4419126EquipmentAndCapacitiesEnabled:true,missingWorldPropertyShowsReadOnlyLevel1:true,sameFileOtherSlotAxeUpgradeEnabled:true,thirdPersistedMapPrefixEnabled:true,globalAndSlotBuildNumbersPreserved:true,reviewUndoResetOriginalAndReportPassed:true,old4389704Level3Recognized:true,previous4757534NgpExportByteIdentical:true,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_ESTRUTURAL_0_15_2.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
