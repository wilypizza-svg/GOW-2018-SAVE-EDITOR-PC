from pathlib import Path
import json
import hashlib
import shutil
import zipfile

BASE=Path(__file__).resolve().parent
WS=BASE.parent
PROJECT=WS/'Forja_2018_PC_0_19_0'
OUT=BASE/'delivery'
OUT.mkdir(exist_ok=True)
for name in ['VERIFICACAO_CATALOGO_0_19_0.json','VERIFICACAO_NGMAIS_0_19_0.json','VERIFICACAO_INTERFACE_0_19_0.json','VERIFICACAO_INDEPENDENTE_0_19_0.json','VERIFICACAO_REMOCOES_0_19_0.json','VERIFICACAO_PRESERVACAO_0_19_0.json']:
    assert json.loads((PROJECT/name).read_text())['passed'],name
html=OUT/'Forja_2018_PC_0_19_0.html'
shutil.copyfile(PROJECT/'Abrir_Editor.html',html)
text=html.read_text()
assert '0.19.0' in text and '/*__' not in text
for file in ['ROTEIRO_0_19_0.md','RELATORIO_0_19_0.md','CATALOGO_ENCANTAMENTOS_0_19_0.md']:
    shutil.copyfile(PROJECT/file,OUT/file)
instructions='''FORJA 2018 PC — 0.19.0

Abra Forja_2018_PC_0_19_0.html no navegador. Funciona offline.
Feche o jogo e mantenha uma cópia do game.sav original.

NOVO: 107 perfis de encantamento, com 92 NG normal e 15 NG+.
Em Encantamentos, escolha a campanha/tipo e use a busca. Para incluir
em lote, clique em Preparar ausentes do filtro e confira Alterações.

Os 90 modelos novos do NG normal vêm de blocos completos observados em
saves do jogo. Os testes estruturais passaram; a inclusão deles pelo
editor ainda precisa da confirmação dentro do jogo. Quando o nome não
está confirmado, o catálogo descreve o nível e os atributos observados.

Marcas perfeitas: é PREFERÍVEL fazer a conversão pelo jogo, mas você
pode incluí-las pelo editor mesmo possuindo as peças e os materiais.
Esses itens são preservados. Týr com seu set completo coexistiu no
teste do usuário; isso não garante todas as combinações.

NG+: o ajuste de armas do último ensaio foi incorporado. O caso aprovado
tinha Machado 2 e Lâminas 1. Não ativa o menu NG+ nem libera armas.

Equipe os encantamentos pelo jogo. Salve e recarregue depois de testar.
O roteiro, o catálogo e o relatório acompanham este pacote.
'''
(OUT/'LEIA_PRIMEIRO.txt').write_text(instructions)
editor=OUT/'Forja_2018_PC_0_19_0_SO_EDITOR.zip'
with zipfile.ZipFile(editor,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in [html,OUT/'LEIA_PRIMEIRO.txt',OUT/'ROTEIRO_0_19_0.md',OUT/'CATALOGO_ENCANTAMENTOS_0_19_0.md',OUT/'RELATORIO_0_19_0.md']:
        z.write(f,f.name)
code=OUT/'Forja_2018_PC_0_19_0_CODIGO.zip'
with zipfile.ZipFile(code,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(PROJECT.rglob('*')):
        if f.is_file() and f.suffix.lower() not in ['.sav','.zip'] and '__pycache__' not in f.parts and not f.name.startswith('.'):
            z.write(f,'Forja_2018_PC_0_19_0/'+str(f.relative_to(PROJECT)))
    for name in ['inspect_returns.cjs','analyse_catalog.cjs','expand_catalog.cjs','native_returns.json','catalog_samples.json','catalog_expansion.json','baseline_0180.json','package_release.py']:
        z.write(BASE/name,'Forja_2018_PC_0_19_0/ensaios_e_evidencias/'+name)
for f in [editor,code]:
    with zipfile.ZipFile(f) as z:
        assert z.testzip() is None
        assert not any(n.lower().endswith('.sav') for n in z.namelist())
    assert f.stat().st_size<12_000_000
ordered=[html,editor,code,OUT/'ROTEIRO_0_19_0.md',OUT/'RELATORIO_0_19_0.md',OUT/'CATALOGO_ENCANTAMENTOS_0_19_0.md']
manifest={'version':'0.19.0','passed':True,'files':[{'file':str(f),'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in ordered]}
(BASE/'delivery_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for f in manifest['files']:print(f['name'],f['bytes'],f['sha256'])
