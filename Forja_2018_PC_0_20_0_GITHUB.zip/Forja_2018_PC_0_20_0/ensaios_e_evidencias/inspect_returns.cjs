const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const A=require('../testes_forja_remocao_20261025/analyse.cjs'),proj=path.resolve(__dirname,'../Forja_2018_PC_0_18_0'),weapon=require(proj+'/src/weapon-levels'),acq=require(proj+'/src/enchantment-acquisition'),inv=require(proj+'/src/inventory');
const out={date:'2026-10-25',returns:[]};
for(const file of ['game(NGP_01_ARMAS_MAXIMAS(Funcionou)).sav','game(MarcaPerfeitaDoTYR+SETCOMPLETODOTYR).sav']){
 const r=A.read(path.resolve(__dirname,'../upload',file)),t=r.tx,info=A.info(r);
 const weapons=weapon.PROFILES.map(p=>({id:p.id,history:p.history.map(id=>({id,quantity:A.nat.quantity(t,id)})),maps:[0,1].map(frame=>{const row=A.nat.mapEntry(t,frame,p.key);return row?{frame,key:p.key,value:A.v(row).getUint32(4,true),raw:A.hex(row)}:null}),releasedState:weapon.inspect(r.bytes,t.slot.index,p.id,r.model)}));
 const tyr=acq.lookup('A1A21B2E7ACA7460'),s=acq.inspectTx(t,tyr.id),object=s.uid===undefined?null:t.state.objects.find(o=>o.uid===s.uid),pieces=inv.PROFILES.filter(p=>tyr.ingredientIds.includes(p.id)).map(p=>({id:p.id,name:p.name,ids:p.ids,quantities:p.ids.map(id=>A.nat.quantity(t,id))}));
 out.returns.push({...info,weapons,tyrMark:{state:s,object:object?A.object(t,object):null},tyrPieces:pieces});
 console.log(JSON.stringify({file,slot:t.slot.number,build:t.slot.build,flags:info.ngpFlags,weapons:weapons.map(w=>({id:w.id,maps:w.maps,history:w.history.map(x=>x.quantity)})),tyr:{owned:s.owned,uid:s.uid,binding:object?A.hex(t.bytes.subarray(object.start+8,object.start+16)):null,pieces}}));
}
const ng=out.returns[0];for(const w of ng.weapons){assert(w.history.every(h=>h.quantity===1));const max=weapon.PROFILES.find(p=>p.id===w.id).max;assert(w.maps.every(m=>m.value===max-1));}
const tyr=out.returns[1];assert.equal(tyr.tyrMark.state.owned,true);assert.equal(tyr.tyrPieces.length,3);assert(tyr.tyrPieces.every(p=>p.quantities.every(q=>q===1)));out.passed=true;
fs.writeFileSync(path.join(__dirname,'native_returns.json'),JSON.stringify(out,null,2)+'\n');
