const fs=require('fs'),path=require('path');
const A=require('../testes_forja_remocao_20261025/analyse.cjs');
const files=fs.readdirSync(__dirname+'/fixtures/nova_leva/AmostrasDosSavesPedidos').filter(n=>/Encantamento/i.test(n)&&n.endsWith('.sav')),folder=__dirname+'/fixtures/nova_leva/AmostrasDosSavesPedidos';
const loot=require('../Forja_2018_PC_0_18_0/data/loot-table.json').items,report=[];
for(const file of files.filter(n=>/antes/i.test(n))){
 const suffix=file.slice(file.toLowerCase().indexOf('conseguir')+9).replace(/\.sav$/,'');
 const after=files.find(n=>/depois/i.test(n)&&n.includes(suffix))||files.find(n=>/depois/i.test(n)&&suffix==='EncantamentoNivel7(naoUnico))'&&n.includes('SignoRobustoDeSorte'));
 if(!after)throw Error('Par ausente '+file);
 const a=A.read(path.join(folder,file)),b=A.read(path.join(folder,after)),d=A.delta(a,b),oldUIDs=new Set(a.tx.state.objects.map(o=>o.uid)),newObjects=b.tx.state.objects.filter(o=>!oldUIDs.has(o.uid)).map(o=>A.object(b.tx,o));
 const creators=d.quantities.filter(q=>q.internalName?.startsWith('RuneCreator')).map(q=>({...q,loot:loot.find(x=>x.id===q.id)}));
 const finals=b.tx.finals.filter(r=>creators.some(c=>c.id===A.nat.idOf(r))).map(A.hex);
 const entry={before:d.before,after:d.after,newObjects,creators,finals};report.push(entry);
 console.log(JSON.stringify({file,after,newObjects:newObjects.map(o=>({uid:o.uid,lists:o.lists,type:o.type,stats:o.stats,bits:o.raw.slice(32,96)})),creators,finals}));
}
fs.writeFileSync(__dirname+'/catalog_samples.json',JSON.stringify(report,null,2)+'\n');
