'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const A=require('../testes_forja_remocao_20261025/analyse.cjs'),project=path.resolve(__dirname,'../Forja_2018_PC_0_19_0');
const data=require('../Forja_2018_PC_0_18_0/data/enchantment-acquisition.json'),loot=require('../Forja_2018_PC_0_18_0/data/loot-table.json').items,samples=require('./catalog_samples.json');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),parseRaw=raw=>{const v=A.v(raw),lists=[];let at=72;for(let k=0;k<2;k++){const n=v.getUint32(at,true);at+=4;const l=[];for(let j=0;j<n;j++,at+=4)l.push(v.getUint32(at,true));lists.push(l);}return {bits:A.hex(raw.subarray(16,48)),type:A.hex(raw.subarray(64,72)),lists};};
const signature=o=>JSON.stringify({bits:o.raw.slice(32,96),type:o.type,lists:o.lists});
const seen=new Set(data.profiles.map(p=>{const parsed=parseRaw(A.nat.fromHex(p.raw));return JSON.stringify(parsed);}));
const observed=new Map();
function record(o,provenance){const sig=signature(o);const e=observed.get(sig)||{o,provenance:[]};e.provenance.push(provenance);observed.set(sig,e);}
const normal=A.read(path.resolve(__dirname,'../entrega_encantamentos_02/ENC_02_CONTROLE_Normal.sav'));
for(const object of normal.tx.state.objects){const o=A.object(normal.tx,object);record(o,{file:path.basename(normal.file),sha256:normal.sha256,slot:normal.tx.slot.number,build:normal.tx.slot.build,uid:o.uid,kind:'native-normal-inventory'});}
// O par controlado tem prioridade sobre uma instância de progressão anterior.
for(const s of samples){assert.equal(s.newObjects.length,1);const o=s.newObjects[0],sig=signature(o);observed.delete(sig);record(o,{file:path.basename(s.after.file),sha256:s.after.sha256,slot:s.after.slot,build:s.after.build,uid:o.uid,kind:'native-before-after-acquisition',beforeSha256:s.before.sha256});observed.get(sig).sample=s;}
const statKeys={'7A00D0F01CCEAB3A':'strength','48B6FD1AC0CB4E01':'runic','0B72D37F6DC3F0F0':'defense','CBC51FB77C16F8F3':'vitality','93E62C7A854C0000':'luck','57B8D16AF17D1E01':'cooldown'};
const levels=[[2,.05],[3,.075],[4,.108],[5,.14],[6,.165],[7,.1925],[7,.196]];
const added=[];
for(const [sig,e]of observed){const o=e.o,raw=A.nat.fromHex(o.raw),visible=o.stats.filter(s=>s.name),prefix=o.raw.slice(32,48);let classification;
 if(['0294E61C5C772BCE','710C689D1EB9AA86','3BC88FC1AFA8C7AD'].includes(o.type)&&prefix==='00000040'+(o.type==='0294E61C5C772BCE'?'10000800':o.type==='710C689D1EB9AA86'?'20000800':'40000800'))classification='common';
 else if(o.type==='BC2620ED969D2F3F'&&prefix.startsWith('00800040'))classification='unique';
 else if(e.sample&&/Epico\(Unico\)/.test(e.sample.after.file))classification='unique';
 else continue;
 if(o.flag!==1||!visible.length||!o.lists[0].length||o.stats.some(s=>!Number.isFinite(s.value)||s.value<0||s.value>1000000))continue;
 const parsed=parseRaw(raw);if(seen.has(JSON.stringify(parsed)))continue;
 const hidden=o.stats.find(s=>s.id==='E3028191D00F7116')?.value,level=levels.find(([,v])=>Math.abs(hidden-v)<1e-6)?.[0];if(!level)continue;
 const stats=Object.fromEntries(visible.map(s=>[statKeys[s.id],s.value])),candidates=loot.filter(i=>i.subCategory==='Enchantments'&&i.gameName&&!i.internalName.endsWith('_NGP')&&i.level===level&&Object.values(statKeys).every(k=>(i[k]||0)===(stats[k]||0)));
 const creator=e.sample?.creators.length===1?e.sample.creators[0]:null;
 const specificallyNamed=e.sample?.after.file.includes('SignoRobustoDeSorte')?'Signo Robusto de Sorte':creator?.loot?.gameName||(classification==='unique'&&candidates.length===1?candidates[0].gameName:null);
 const statsText=visible.map(s=>s.name+' '+new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2}).format(s.value)).join(' / ');
 const id='ng-enchantment-'+sha(sig).slice(0,20);
 const p={id,name:specificallyNamed?specificallyNamed+' · nível '+level:(classification==='unique'?'Único':'Comum')+' · nível '+level+' · '+statsText,variant:'Normal',level,classification,build:e.provenance[0].build,raw:o.raw,ingredientIds:[],nativeModel:true,acquisitionMode:'instance',counterId:creator?.id||null,recipeMetadata:creator?e.sample.finals[0]?.slice(16):null,validatedAcquisition:true,gameValidated:false,confirmedCases:[],validationStatus:'native-model-catalogued-awaiting-editor-inclusion-game-test',signature:parsed,nativeVisibleStats:visible,nameAssociation:{basis:creator?'native-creation-flag-and-loot-table':specificallyNamed==='Signo Robusto de Sorte'?'user-labelled-native-pair':specificallyNamed?'unique-stat-and-level-match-in-loot-table':'descriptive-native-attributes',individualConfirmationPending:!!specificallyNamed&&specificallyNamed!=='Signo Robusto de Sorte'},sourceEvidence:e.provenance};
 assert(!p.counterId||/^[A-F0-9]{16}$/.test(p.counterId));if(p.counterId)assert(/^[A-F0-9]{16}$/.test(p.recipeMetadata));
 data.profiles.push(p);seen.add(JSON.stringify(parsed));added.push(p);
}
const groupsByName=new Map();for(const p of added){if(!groupsByName.has(p.name))groupsByName.set(p.name,[]);groupsByName.get(p.name).push(p);}
for(const group of groupsByName.values())if(group.length>1)for(const p of group)if(p.nameAssociation.basis==='unique-stat-and-level-match-in-loot-table'){
 p.suggestedNameFromLoot=p.name;p.name=(p.classification==='unique'?'Único':'Comum')+' · nível '+p.level+' · '+p.nativeVisibleStats.map(s=>s.name+' '+new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2}).format(s.value)).join(' / ');p.nameAssociation={basis:'descriptive-native-attributes-ambiguous-loot-name',individualConfirmationPending:false};
}
const displayNames=new Map();for(const p of added){if(!displayNames.has(p.name))displayNames.set(p.name,[]);displayNames.get(p.name).push(p);}
for(const group of displayNames.values())if(group.length>1)group.forEach((p,i)=>p.name+=' · modelo '+(i+1));
for(const p of data.profiles){if(!p.variant)p.variant=p.name.includes('+')?'NG+':'Normal';if(p.gameValidated===undefined)p.gameValidated=true;}
const tyr=data.profiles.find(p=>p.id==='A1A21B2E7ACA7460');tyr.nameAssociation={basis:'user-screenshot-and-native-resave',individualConfirmationPending:false};
tyr.coexistenceEvidence=[{file:'game(MarcaPerfeitaDoTYR+SETCOMPLETODOTYR).sav',sha256:require('./native_returns.json').returns[1].sha256,markUid:57,threeArmorPiecesAndAllUpgradesPresent:true,userConfirmed:true}];
data.version='0.19.0';data.scope='Catálogo de modelos completos observados no PC: perfis anteriores e ampliação NG normal. Uma unidade por perfil ausente; equipar no jogo. Conversões são preferíveis no jogo, sem bloquear a inclusão nem consumir equipamentos.';
fs.writeFileSync(project+'/data/enchantment-acquisition.json',JSON.stringify(data,null,2)+'\n');
const report={version:data.version,previousProfiles:17,total:data.profiles.length,normal:data.profiles.filter(p=>p.variant==='Normal').length,ngplus:data.profiles.filter(p=>p.variant==='NG+').length,newProfiles:added.map(p=>({id:p.id,name:p.name,classification:p.classification,level:p.level,counterId:p.counterId,sourceEvidence:p.sourceEvidence})),newInclusionsGameTested:false,allRawTemplatesObservedInNativeSaves:true};fs.writeFileSync(__dirname+'/catalog_expansion.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({total:report.total,normal:report.normal,ngplus:report.ngplus,new:added.length,common:added.filter(p=>p.classification==='common').length,unique:added.filter(p=>p.classification==='unique').length,controlledPairs:added.filter(p=>p.sourceEvidence.some(e=>e.kind==='native-before-after-acquisition')).length}));
