# 0.20.0 — 26/10/2026

- Aquisição antecipada das Lâminas do Caos, com cabo padrão, integrada em Níveis. A saída reproduz os ensaios BL_01 e BL_04 aprovados no jogo.
- Escolha de níveis 1 a 5 desde o início para as Lâminas adquiridas e coerentes, usando as etapas mapeadas sem criar propriedades de mundo ausentes. O máximo direto nesse ponto ainda precisa de confirmação no jogo.
- Aquisição e nível aparecem separadamente na revisão; desfazer a aquisição também retira o ajuste de nível dependente.
- Aviso para evitar cifras de Muspelheim/Niflheim antes da primeira viagem a Alfheim, devido ao travamento relatado na cena da ponte de Týr. Visível nos controles, na revisão e em Como usar; incluído no relatório JSON.
- Mantém a regra inicial do Machado, o reconhecimento anterior do NG+ e os dados e gravadores de equipamentos, recursos, rúnicos, encantamentos e remoções.

# 0.19.0 — 25/10/2026

- 107 perfis de encantamento, sendo 92 NG normal e 15 NG+; 90 modelos novos com atributos e efeitos completos das amostras nativas.
- Filtros, busca e inclusão dos ausentes do filtro em lote, com uma linha por inclusão na revisão.
- Conversão de marcas perfeitas passa a ser uma recomendação, preservando a opção de inclusão e os ingredientes.
- Persistência da coexistência Marca Perfeita de Týr + conjunto completo registrada por evidência nativa.
- NG+ parcial das armas reconhecido pelos contextos testados, com saída idêntica ao ensaio aprovado no jogo.
- Limite de 32 instâncias por escrita mantido por composição interna dos lotes, sem modificar o gravador nativo.
- Distinção entre modelos NG recém catalogados e inclusões já confirmadas no jogo.

# 0.18.0 — 25/10/2026

Integra as remoções aprovadas em R01..R08, a devolução dos três encantamentos comuns e a retirada de uma instância comum solta. Acrescenta controles, revisão, desfazer e exportação. Reconhece o estado nativo vendido de equipamentos mapeados. Preserva gravadores e catálogo da 0.17.3. Mantém a regra NG+ parcial fora do editor, em ensaio separado.

# 0.17.3

- Acrescenta Grip of Tanngiost + (Punho de Tanngiost +) ao filtro de pomos do machado NG+, usando os três IDs da tabela de loot.
- Corrige somente a classificação e os nomes dessa família, que estavam como efeitos/habilidades.
- Usa as linhas nativas de Retribuição + como molde da mesma categoria, variante e progressão 8 → 8+ → 9. Não herda índices de nível, referências de compra ou instâncias do doador.
- Mantém a versão normal do Punho de Tanngiost, os demais perfis, os bloqueios de PinkSet/Trinket e os gravadores existentes.
- A nova variante possui conferência local e indicação na interface para confirmação no jogo. O sucesso anterior de outros pomos não substitui o teste deste item.

# 0.17.2

- Retira apenas as três entradas normais PinkSet das inclusões individuais, conjuntos, lotes e listas visíveis. O grupo falhou em dois testes separados; cada peça isolada ainda não foi testada.
- Preserva as variantes Cod of War NG+, as três famílias SpeedSet_Tier01_Reinforce e todos os outros perfis válidos.
- Registra o sucesso dos testes ARM77_01_BASE e ARM77_02_ULTIMA_ETAPA: as 77 peças persistiram após a gravação pelo jogo; o segundo manteve também os 136 registros de melhorias solicitados.
- Mantém os bloqueios de Trinket_Bonus01/02 da 0.17.1 e todos os gravadores, modelos binários, verificações estruturais e regras de nível existentes.
- Não limpa saves antigos automaticamente. Use um original ou uma cópia confirmada funcionando se já tiver incluído entradas problemáticas.

# 0.17.1

Retira as duas entradas Trinket_Bonus01/02 das opções de inclusão e das listas visíveis. Não altera escritores de save nem outros perfis.

# 0.17.0

17 perfis de encantamento integrados após os testes ENC_07–10. Interface simplificada: controles antigos retirados da tela, clonagem de equipamentos implícita e remoção dos rótulos gerais de teste. Aviso para fabricar marcas perfeitas pelo jogo quando houver peças de conversão. Escritores de recursos e equipamentos preservados.

# 0.16.0 — Inclusão de encantamentos validados

- Integra Bestla+, Marca Perfeita do Viajante+ e Marca Perfeita dos Anciões+ ao painel de inclusão, com uma unidade ausente por perfil.
- Reproduz cinco exportações aprovadas no jogo, incluindo a combinação com Zeus e Retribuição+.
- Reconhece Viajante e Anciões como únicos e protege suas instâncias contra a duplicação genérica.
- Preserva os encantamentos existentes e seus encaixes; as novas unidades ficam soltas para equipar pelo jogo.
- Bloqueia registros parciais, modelos locais ausentes e coexistência ainda não validada com as peças da conversão.
- Mantém o reconhecimento estrutural, o gravador comum, o limite de 512 registros e os escritores de recursos/equipamentos da 0.15.2.
- Preserva os fluxos anteriores de Kvasir e Symbol of Menace e a versão 0.15.2.

# 0.15.2 — Reconhecimento estrutural dos saves PC

- Substitui a lista de builds pela validação de assinaturas, contagens, objetos, grupos, mapas e limites da seção ativa.
- Reconhece os 62 slots comparados de quatro saves reais com a mesma gramática, incluindo o arquivo com slots 4419126.
- Preserva os números de build do cabeçalho geral e dos slots; nenhuma conversão ou falsificação é realizada.
- Exibe o nível reconhecido da arma em consulta quando falta sua propriedade adicional, mantendo a edição bloqueada e o motivo específico visível.
- Mantém as verificações de cada ação, os moldes binários, o gravador de recursos, o serializador e o limite de 512 registros auxiliares.
- Confere exportações do novo arquivo por comparação com o algoritmo anterior e por leitor Python independente, além das regressões aprovadas no jogo.
- Mantém a criação e duplicação complexas de encantamentos com a cobertura anterior. As novas exportações do build 4419126 ainda precisam de validação no jogo.

# 0.15.1 — Compatibilidade de builds de PC

- Reconhece os builds 4389704 e 4757534 em equipamentos, armas e contadores de campanha, mantendo as validações estruturais.
- Remove o bloqueio indevido de saves antigos sem alterar ou falsificar o build armazenado.
- Mantém a rotina de recursos e o gravador comum com fila de 512 registros.
- Esclarece quando as Lâminas ainda não possuem registros e quando o peitoral do controle legado não consta no slot.
- Identifica no relatório as operações de compatibilidade com build diferente da amostra original; validação no jogo do build antigo continua pendente.

# 0.15.0 — Rúnicos, cifras e reconhecimento de armas no NG+

- Acrescenta 27 inclusões rúnicas experimentais no nível 3, totalizando 31 ataques das duas armas; os quatro perfis controlados mantêm sua rotina.
- Compartilha os rúnicos entre os filtros normal e NG+, preserva ataques já possuídos e deixa Atreus para futuras amostras.
- Adiciona controles de cifras de Niflheim e Muspelheim com contadores coerentes e sem copiar eventos de baús.
- Reconhece o formato NG+ com os dois mapas de nível, histórico completo e ausência da propriedade adicional do mundo; o ajuste nesse formato permanece em teste.
- Mantém o gravador e o limite de 512 registros auxiliares da 0.14.3, com regressão dos arquivos aprovados.
- Preserva os módulos de encantamentos e os escritores existentes de recursos e equipamentos.

# 0.14.3 — Cabos NG+ e fila auxiliar

- Limita a fila final a 512 no gravador comum, descartando os registros mais antigos como na aquisição nativa e protegendo operações combinadas.
- Reintegra Cursed Flame + à aquisição mapeada e libera os quatro demais cabos NG+ ausentes no nível 9.
- Mantém a alteração de níveis já registrados desses quatro cabos pelo jogo, sem inventar seus índices PC.
- Dispensa a opção experimental para as inclusões de cabos NG+ validadas.
- Confere a exportação dos cinco cabos com o mesmo arquivo F aprovado no jogo, byte a byte.
- Preserva os quatro cenários anteriores aprovados e os módulos de encantamentos.

# Alterações

## 0.14.2

- Registra que os testes isolados 15 (Cursed Flame +) e 16 (Bestla) falharam no jogo; ambos os arquivos recebidos são idênticos às saídas preparadas.
- Separa a clonagem dos registros de posse/melhoria da finalização de aquisição. Cursed Flame + passa a usar a finalização de equipamento já reconhecido, mantendo seu índice próprio, em inclusão experimental.
- Acrescenta clonagem local de instância para Bestla, com perfil completo e identidade nova, preservando o modelo. A variante omite o marcador de instância recém-adquirida e exige ativação experimental.
- Classifica explicitamente os perfis comuns e únicos conhecidos. Bloqueia duplicação genérica de únicos reconhecidos, incluindo Kvasir e Heart of the Valkyrie.
- Mantém a conversão de Kvasir e a criação anterior de Menace. A classificação de perfis desconhecidos continua não confirmada.
- Corrige a origem dos cabos NG+: Forgotten Flame + é da loja; os outros quatro são de baús, conforme informado pelo usuário. A origem não implica uma referência de compra.
- Preserva as quatro saídas aprovadas 10, 12, 13 e 14 e as rotinas de gravação existentes.
- Testes 17–18 são hipóteses revisadas; a correção dos crashes ainda não foi confirmada no jogo.

## 0.14.1

- Suspende a edição dos quatro cabos NG+ sem índice PC próprio após o teste isolado de Grips of the Valkyrie + também falhar no jogo. Cursed Flame + continua com seu perfil mapeado; cabos normais permanecem disponíveis.

- Remove o encaixe de encantamentos pelo editor, a substituição de perfil em encaixes e a edição individual ou em lote de seus atributos.
- Entrega os encantamentos novos e duplicados soltos no inventário para equipar pelo jogo, preservando os modelos e as instâncias anteriores.
- Remove os escritores de encaixes e rejeita pedidos antigos dessas operações antes de iniciar a edição.
- Preserva as rotinas de recursos, armaduras, pomos, cabos, talismãs, níveis, capacidades e pedras.
- Registra o sucesso informado nos testes 10, 12, 13 e 14. A falha do teste 11, com cabos NG+ e Bestla solto, continua sem causa isolada; esta revisão não afirma corrigi-la.

## 0.14.0

- Aceita contadores iniciais ausentes de maçãs e chifres como zero quando o estado é coerente, e cria os registros necessários ao aplicar outro total.
- Preserva a gravação anterior quando todos os contadores existem.
- Acrescenta seis perfis mapeados: três cabos das Lâminas e as três peças normais de Ivaldi Endless Mist.
- Amplia a lista para 21 cabos, com cinco variantes NG+ em 8 → 8+ → 9. Perfis sem índice próprio permanecem experimentais.
- Acrescenta criação e reconhecimento de Bestla's Frozen Shard+, incluindo encaixe e retirada.
- Acrescenta reposição de pedra berserker no estado observado após o consumo.
- Torna visível a seção Níveis e acrescenta controles das armas principais. A primeira melhoria do Machado permanece bloqueada quando a propriedade secundária ainda não existe.
- Mantém quatro rúnicos mapeados; a inclusão dos demais não foi ampliada.
- Preserva os originais, a 0.13.0, os 217 modelos anteriores, os catálogos brutos e o serializador existente.

## 0.13.0

- Seleção de 47 conjuntos, filtro normal/NG+ e clonagem de equipamentos.
- Chave de progressão de Retribuição + identificada em saves regravados pelo jogo.
- Correção de classificação do conjunto normal de Brok.
- Usuário confirmou os testes 07–09, a inclusão de Zeus com outros equipamentos e um save com 67 alterações combinadas.
