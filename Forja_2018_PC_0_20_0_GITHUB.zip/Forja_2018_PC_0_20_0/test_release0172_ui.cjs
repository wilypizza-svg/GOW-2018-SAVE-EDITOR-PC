'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const core=require('./src/core'),inv=require('./src/inventory'),selection=require('./src/inventory-selection'),plan=require('./src/plan');
const {api,$,downloads}=require('./test_dom_harness.cjs'),ws=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const oldPlan=require(ws+'/Forja_2018_PC_0_17_1/src/plan'),blocked=['B1DFE124C69AF353','82D3E124C69AF353','E777B23D510B6DE1','924731D16B9635D0','4351BAA3FE4070D3'];
const same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const set=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
const options=id=>$(id).children.filter(e=>e.tagName==='option'),ok=()=>assert.equal($('error').hidden,true,$('error').textContent);
(async()=>{
 const manifest=JSON.parse(fs.readFileSync(ws+'/diagnostico_armaduras_03/manifest.json')),source=new Uint8Array(fs.readFileSync(manifest.source)),slot=core.parse(source).latestSlot;
 api.loadBytes(source,'game.sav');api.selectSlot(slot);api.chooseView('equipment');
 for(const id of blocked){
  await set('inventory-search',id,'input');assert.equal(options('inventory-item').length,0);assert.equal($('inventory-apply').disabled,true);
  await set('equipment-search',id,'input');assert.ok(!$('equipment-body').innerHTML.includes(id));
  api.chooseView('catalog');await set('catalog-search',id,'input');assert.ok(!$('catalog-body').innerHTML.includes(id));api.chooseView('equipment');
 }
 await set('inventory-search','Cod of War','input');await set('inventory-variant','normal');assert.equal(options('inventory-item').length,0);assert.ok(!$('inventory-set').innerHTML.includes('KratosArmor_PinkSet::normal'));
 await set('inventory-variant','NG+');assert.equal(options('inventory-item').length,3);assert.ok($('inventory-set').innerHTML.includes('KratosArmor_Bonus01::NG+'));
 await set('equipment-search','3225AAC6C42CC83D','input');assert.ok($('equipment-body').innerHTML.includes('3225AAC6C42CC83D'));
 api.chooseView('catalog');await set('catalog-search','3225AAC6C42CC83D','input');assert.ok($('catalog-body').innerHTML.includes('3225AAC6C42CC83D'));api.chooseView('equipment');
 await set('inventory-search','','input');await set('inventory-variant','all');await set('inventory-kind','talisman');assert.equal(options('inventory-item').length,41);
 await set('inventory-kind','axe-runics-all');assert.equal(options('inventory-item').length,16);await set('inventory-kind','blades-runics-all');assert.equal(options('inventory-item').length,15);
 api.chooseView('enchantments');assert.equal(options('enchantment-create-item').length,17);api.chooseView('equipment');
 // Uma inclusão individual real, revisão e retorno ao estado original.
 await set('inventory-kind','chest');await set('inventory-variant','normal');assert.equal(options('inventory-item').length,31);
 await set('inventory-item','615B1370AEBED3EA');await set('inventory-stage','0');assert.equal($('inventory-apply').disabled,false);await $('inventory-apply').click();ok();
 const individual=[{slot,id:'615B1370AEBED3EA',type:'inventory-equipment',stage:0,allowExperimental:true}];same(api.exportBytes().bytes,oldPlan.patch(source,individual).bytes);
 await $('reset-changes').click();assert.throws(()=>api.exportBytes(),/Nenhuma alteração para exportar/);
 // Adiciona os três tipos pelos botões de lote, preservando a seleção anterior.
 const requests=[];const initialState=inv.inspect(source,slot);await set('inventory-bulk-mode','base');
 for(const kind of ['chest','wrist','waist']){
  await set('inventory-kind',kind);assert.equal(options('inventory-item').length,31);
  requests.push(...selection.buildMissing(initialState,inv.PROFILES.filter(p=>p.variant==='normal'&&p.kind===kind).map(p=>p.id),'base',true).map(r=>({...r,slot})));
  assert.equal($('inventory-bulk').disabled,false);await $('inventory-bulk').click();ok();
 }
 const result=api.exportBytes();assert.equal(requests.length,73);assert.equal(result.log.length,73);assert.ok(result.log.every(r=>!blocked.includes(r.id)));
 same(result.bytes,plan.patch(source,requests).bytes);same(result.bytes,oldPlan.patch(source,requests).bytes);
 api.chooseView('changes');assert.equal($('change-count').textContent,'73 alterações');await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),result.bytes);
 await $('report-download').click();const exported=JSON.parse(await downloads.at(-1).blob.text());assert.equal(exported.version,'0.17.2');assert.equal(exported.changes.length,73);assert.ok(exported.changes.every(r=>!blocked.includes(r.id)));
 const report={version:core.VERSION,passed:true,executedBuiltHtmlInSimulatedDom:true,excludedIdsAbsentFromIndividualEquipmentSetsAndCatalog:true,codOfWarNgpStillVisibleInAllViews:true,normalArmorChoicesPerKind:31,talismanChoices:41,axeRunicChoices:16,bladesRunicChoices:15,enchantmentChoices:17,individualAcquisitionMatches0171:true,bulkAdds73ValidMissingNormalArmors:true,bulkExportMatches0171:true,reviewExportAndReportPassed:true};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_17_2.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
