'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, query, downloads, $ } = require('./test_dom_harness.cjs');
const resources = require('./src/resource-edit');
const bytes = new Uint8Array(fs.readFileSync(process.argv[2]));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
async function quantity(id, value) {
  $('quantity-category').value = 'all'; $('quantity-search').value = id; await $('quantity-search').fire('input');
  $('quantity-item').value = id; await $('quantity-item').fire('change'); $('quantity-value').value = String(value);
  await $('quantity-value').fire('input'); assert.equal($('quantity-apply').disabled, false); await $('quantity-apply').click();
  assert.equal($('error').hidden, true, $('error').textContent);
}
(async () => {
  api.loadBytes(bytes, 'game(2).sav'); assert.equal($('error').hidden, true);
  assert.ok($('slot-count').textContent.startsWith('12 de 20 slots reconhecidos'));
  assert.equal(query('[data-select-slot]').length, 20);
  assert.equal(query('[data-select-slot]').filter(button => button.disabled).length, 8);
  assert.throws(() => api.selectSlot(12), /reconhecido/);
  api.selectSlot(1);
  await quantity('9E5240D27406E85A', 10000);
  await quantity('CC1B3E5C878842B3', 100);
  const plan = [{ slot: 1, id: '9E5240D27406E85A', quantity: 10000 }, { slot: 1, id: 'CC1B3E5C878842B3', quantity: 100 }];
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  api.chooseView('attributes'); assert.ok($('attribute-cards').innerHTML.includes('Registro existente'));
  assert.equal($('dew-cooldown').value, '2');
  api.chooseView('targets'); $('target-stat').value = 'cooldown'; $('target-rounding').value = 'nearest';
  $('target-current').value = '20'; $('target-desired').value = '100'; await $('target-desired').fire('input');
  assert.ok($('target-note').textContent.includes('41')); await $('target-apply').click();
  plan.push({ slot: 1, id: '6A13DB1C163C952D', quantity: 41 });
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  await $('export-top').click(); assert.equal(downloads.at(-1).name, 'game.sav');
  same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()), resources.patch(bytes, plan).bytes);
  await $('original-download').click(); same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()), bytes);
  await query('[data-undo]').find(button => button.dataset.undo === '1:CC1B3E5C878842B3').click(); plan.splice(1, 1);
  same(api.exportBytes().bytes, resources.patch(bytes, plan).bytes);
  await $('reset-changes').click(); assert.equal(api.getState().log.length, 0);
  const report = { version: '0.9.0', normalSaveLoadedInHTML: true, twelveSlotsSelectableAndEightEmptyProtected: true,
    existingAndAbsentResourcesVerified: true, existingDewBonusAndTargetVerified: true,
    downloadBackupUndoAndResetVerified: true, visualBrowserTested: false, inGameTestedHere: false };
  fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_NORMAL_INTERFACE_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
