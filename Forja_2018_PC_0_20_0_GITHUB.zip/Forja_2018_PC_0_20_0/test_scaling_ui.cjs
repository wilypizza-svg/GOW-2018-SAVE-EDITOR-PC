'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const inv=require('./src/inventory'),nat=require('./src/native-records'),ench=require('./src/enchantments');
const fixtures=JSON.parse(fs.readFileSync(process.argv[2])),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const read=prefix=>{const s=fixtures.find(s=>s.path&&s.file.startsWith('game('+prefix));return {...s,bytes:new Uint8Array(fs.readFileSync(s.path))};};
const choose=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);},ok=()=>assert.equal($('error').hidden,true,$('error').textContent);
(async()=>{
 const normal=read('AntesDeComprarUmPeitoral');api.loadBytes(normal.bytes);api.selectSlot(normal.index);api.chooseView('equipment');
 assert.ok($('inventory-catalog-count').textContent.includes('223'));assert.equal($('inventory-experimental').checked,false);
 await choose('inventory-kind','chest');await choose('inventory-item','4339AAC6C42CC83D');assert.ok($('inventory-stage').innerHTML.includes('8+'));
 assert.equal($('inventory-apply').disabled,true);await $('inventory-apply').click();assert.equal($('error').hidden,false);assert.equal(api.getState().log.length,0);
 $('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');await choose('inventory-stage',2);
 $('inventory-materials').checked=true;await $('inventory-apply').click();ok();let result=api.exportBytes(),tx=nat.read(result.bytes,normal.index);
 const zeus=inv.PROFILES.find(p=>p.id==='4339AAC6C42CC83D');for(const id of zeus.ids)assert.equal(nat.quantity(tx,id),1);
 assert.deepEqual(tx.maps,nat.read(normal.bytes,normal.index).maps);assert.ok(nat.quantity(tx,'9E5240D27406E85A')>=2000000000);
 assert.equal(api.getState().log.find(e=>e.id===zeus.id).actualLevelVerified,false);
 await choose('inventory-kind','wrist');await choose('inventory-support','base');await choose('inventory-bulk-mode','template-max');await $('inventory-bulk').click();ok();
 result=api.exportBytes();assert.ok(api.getState().log.filter(e=>e.experimentalTemplate).length>20);
 await $('reset-changes').click();ok();assert.equal(api.getState().log.length,0);assert.equal($('inventory-experimental').checked,false);
 const target=read('AntesDeConseguirUmEncantamentoUnico(Kvasir)'),donor=read('DepoisDeComprarUmEncatamentoComum');api.loadBytes(target.bytes);api.selectSlot(target.index);api.chooseView('enchantments');
 await $('duplicate-file').fire('change',{target:{files:[{name:'origem.sav',arrayBuffer:async()=>donor.bytes.buffer}]}});ok();assert.equal($('duplicate-origin').value,'donor');
 await choose('duplicate-slot',donor.index);const choices=inv.duplicateChoices(donor.bytes,donor.index),model=choices.choices.find(o=>o.sampleName==='Symbol of Menace');assert.ok(model);await choose('duplicate-item',model.uid);
 assert.equal($('duplicate-apply').disabled,true);$('duplicate-experimental').checked=true;await $('duplicate-experimental').fire('change');await choose('duplicate-count',2,'input');await $('duplicate-apply').click();ok();
 result=api.exportBytes();const entry=api.getState().log.find(e=>e.type==='enchantment-duplicate');assert.equal(entry.uids.length,2);assert.equal(entry.sourceFilename,'origem.sav');
 const saved=result.bytes;await choose('duplicate-count',11,'input');await $('duplicate-apply').click();assert.equal($('error').hidden,false);same(api.exportBytes().bytes,saved);
 await $('duplicate-file').fire('change',{target:{files:[{name:'invalido.sav',arrayBuffer:async()=>new Uint8Array(100).buffer}]}});assert.equal($('error').hidden,false);same(api.exportBytes().bytes,saved);
 const targets=ench.inspect(saved,target.index).targets;assert.ok(targets.length);await choose('enchantment-target',targets[0].uid);await choose('enchantment-model',entry.uids[0]);await $('enchantment-apply').click();ok();assert.ok(api.getState().log.some(e=>e.type==='enchantment-copy'));
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.validation.experimentalEnchantmentDuplicates,1);assert.ok(report.changes.some(e=>e.warning==='Talvez corrompa seu save'));
 await query('[data-undo]').find(b=>b.dataset.undo===target.index+':'+entry.id).click();ok();assert.equal(api.getState().log.length,0);assert.equal(api.getState().changes.length,0);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),target.bytes);
 $('duplicate-experimental').checked=true;api.selectSlot(target.index);assert.equal($('duplicate-experimental').checked,false);
 const summary={version:'0.12.0',htmlExecutedInVm:true,broadCatalogInActualControls:true,level8To8PlusTo9TemplateSelectable:true,
 templateUpgradeAndResourceFallbackPassed:true,bulkAddsMissingWithoutReplacingOwnedGear:true,experimentalOptionsUncheckedByDefault:true,
 externalDonorLoadingAndDuplicateControlsPassed:true,invalidInputsPreserveDraft:true,undoDuplicateRemovesDependentCopies:true,
 sourceBackupUnchanged:true,warningRecordedInReport:true,browserVisualTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_12_0.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
