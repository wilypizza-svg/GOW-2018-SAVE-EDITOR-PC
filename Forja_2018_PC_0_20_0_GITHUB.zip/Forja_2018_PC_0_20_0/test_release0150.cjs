/* Regressão dos arquivos aprovados e validação das três alterações novas.
   node test_release0150.cjs [workspace] */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),sel=require('./src/inventory-selection'),runics=require('./src/runics'),ciphers=require('./src/ciphers'),weapons=require('./src/weapon-levels'),plan=require('./src/plan');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),out=path.join(ws,'analysis_0_15_0/testes');fs.mkdirSync(out,{recursive:true});
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(nat.equal(a,b),m);
const normal=read('upload/game(9).sav'),ngp=read('upload/game(10).sav'),nm=core.parse(normal),gm=core.parse(ngp),ni=nm.latestSlot,gi=gm.latestSlot;
const oldPlan=require(path.join(ws,'Forja_2018_PC_0_14_3/src/plan'));
function protectedSections(a,b,index){
 const x=nat.read(a,index),y=nat.read(b,index),head=a.slice(x.slot.base,x.slot.base+0x10400);
 nat.view(head).setUint32(0x124,nat.view(b).getUint32(x.slot.base+0x124,true),true);
 same(head,b.subarray(x.slot.base,x.slot.base+0x10400),'Mundo ou cabeçalho não solicitado mudou.');
 same(x.objectsAndGroups,y.objectsAndGroups,'Instâncias ou grupos opacos mudaram.');
 for(const s of x.model.slots)if(s.index!==index)same(a.subarray(s.base,s.end),b.subarray(s.base,s.end),'Outro slot mudou.');
 same(a.subarray(Math.max(x.state.activeEnd,y.state.activeEnd)),b.subarray(Math.max(x.state.activeEnd,y.state.activeEnd)),'Cauda não utilizada mudou.');
 assert.ok(y.finals.length<=512);return {x,y};
}
const cases=[];
function save(name,source,index,requests,result){
 const file=path.join(out,name+'.sav');fs.writeFileSync(file,result.bytes);
 cases.push({name,source:path.resolve(ws,source),output:file,slot:index,requests,sha256:sha(result.bytes),log:result.log});
}
// Todos os 31 IDs estão presentes no arquivo regravado e aprovado pelo jogo.
const approved=read('upload/game(Cursed_F_Cinco_Cabos_NGmais_Nivel9(Funcionou)).sav'),am=core.parse(approved),at=nat.read(approved,am.latestSlot,am);
assert.equal(runics.items.length,31);assert.equal(runics.profiles.length,27);
for(const p of runics.items)assert.equal(nat.quantity(at,p.id),3,p.id);
assert.ok(runics.items.every(p=>/^(FrostSpecialAxe|BladeSpecial)/.test(p.internalName)));
assert.ok(!inv.PROFILES.some(p=>/^Summon/.test(p.internalName||'')));
for(const variant of ['all','normal','NG+']){
 assert.equal(sel.filterProfiles({kind:'axe-runics-all',variant}).length,16);
 assert.equal(sel.filterProfiles({kind:'blades-runics-all',variant}).length,15);
}
const missing=runics.profiles.filter(p=>!inv.profileState(nat.read(normal,ni),p).owned),runicRequests=missing.map(p=>({type:'inventory-equipment',slot:ni,id:p.id,stage:2,allowExperimental:true}));
const added=plan.patch(normal,runicRequests),{x:rx,y:ry}=protectedSections(normal,added.bytes,ni);
assert.equal(added.log.length,missing.length);assert.equal(ry.rows.length,rx.rows.length+missing.length);
assert.deepEqual(ry.rows.slice(0,rx.rows.length),rx.rows);
assert.deepEqual(ry.maps,rx.maps);assert.deepEqual(ry.refs,rx.refs);assert.deepEqual(ry.finals,rx.finals);
for(const p of missing)assert.equal(nat.quantity(ry,p.id),3);
same(plan.patch(added.bytes,runicRequests).bytes,added.bytes,'Inclusão repetida não é inócua.');
for(const p of runics.profiles.filter(p=>inv.profileState(rx,p).owned))assert.equal(nat.quantity(ry,p.id),nat.quantity(rx,p.id));
const target=missing[0],req=runicRequests[0];assert.ok(target);
assert.throws(()=>plan.patch(normal,[{...req,allowExperimental:false}]),/experimental/);
for(const stage of [0,1])assert.throws(()=>plan.patch(normal,[{...req,stage}]),/nível 3/);
const low=runics.profiles.find(p=>[1,2].includes(nat.quantity(rx,p.id)));assert.ok(low);
assert.throws(()=>plan.patch(normal,[{...req,id:low.id}]),/já existe/);
const malformed=nat.read(normal,ni);nat.putQuantity(malformed,target.id,7,true);
assert.equal(inv.inspect(nat.write(malformed).bytes,ni).profiles.find(p=>p.id===target.id).available,false);
const empty=nat.read(normal,ni);empty.rows=empty.rows.filter(r=>!runics.items.some(p=>p.id===nat.idOf(r)));
assert.throws(()=>plan.patch(nat.write(empty).bytes,[req]),/pelo menos um ataque/);
const beforeHash=sha(normal);assert.throws(()=>plan.patch(normal,[...runicRequests,{...req,id:low.id}]),/já existe/);assert.equal(sha(normal),beforeHash);
const allProfiles=inv.PROFILES.filter(p=>p.kind.includes('runic')),allMissing=sel.buildMissing(inv.inspect(normal,ni),allProfiles.map(p=>p.id),'template-max',true).map(r=>({...r,slot:ni})),all=plan.patch(normal,allMissing);
protectedSections(normal,all.bytes,ni);
for(const p of allProfiles){const before=nat.quantity(rx,p.id);assert.equal(nat.quantity(nat.read(all.bytes,ni),p.id),before??3);}
save('Runicos_Ausentes_Machado_e_Laminas','upload/game(9).sav',ni,allMissing,all);
// As quatro receitas de rúnicos anteriores mantêm exatamente os mesmos bytes.
for(const p of inv.MAPPED_PROFILES.filter(p=>p.mode==='quantity'))for(const stage of [0,1,2]){
 const request={type:'inventory-equipment',slot:ni,id:p.id,stage};
 same(plan.patch(normal,[request]).bytes,oldPlan.patch(normal,[request]).bytes,p.name+' alterou sua rotina anterior.');
}
// O NG+ usa só as quatro posições dos dois mapas. Nenhum mundo é criado.
const weaponReqs=[{type:weapons.TYPE,slot:gi,id:'axe-main-level',level:5},{type:weapons.TYPE,slot:gi,id:'blades-main-level',level:4}],ngResult=plan.patch(ngp,weaponReqs),gx=nat.read(ngp,gi),gy=nat.read(ngResult.bytes,gi),allowed=[];
for(const p of weapons.PROFILES){
 const state=weapons.inspect(ngp,gi,p.id);assert.equal(state.available,true);assert.equal(state.current,p.max);assert.equal(state.sceneMode,'ngp-maps-only');
 for(const frame of [0,1]){const f=gx.state.frames[frame],prefix=frame===1?8:0,stride=frame===0?8:9,index=gx.maps[frame].entries.findIndex(r=>nat.view(r).getUint32(0,true)===p.key);allowed.push(f.start+2+prefix+4+index*stride+4);}
}
const expected=ngp.slice();for(const at of allowed)expected.set(ngResult.bytes.subarray(at,at+4),at);
same(expected,ngResult.bytes,'O ajuste NG+ mudou bytes fora dos quatro valores de nível.');
assert.ok(ngResult.log.every(l=>l.synchronizedLevelFields===2&&!l.worldPropertyCreated));
same(plan.patch(ngResult.bytes,weapons.PROFILES.map(p=>({slot:gi,id:p.id,type:weapons.TYPE,level:p.max}))).bytes,ngp,'Subir novamente ao máximo deve restaurar os bytes originais.');
same(plan.patch(ngResult.bytes,weaponReqs).bytes,ngResult.bytes);
for(const mutation of ['map','flag','history','relocated','duplicated']){
 const tx=nat.read(ngp,gi),p=weapons.PROFILES[0];let bytes;
 if(mutation==='map')nat.view(nat.mapEntry(tx,1,p.key)).setUint32(4,3,true);
 if(mutation==='flag')nat.putQuantity(tx,'5343978C802835DB',0);
 if(mutation==='history')nat.putQuantity(tx,p.history.at(-1),0);
 bytes=nat.write(tx).bytes;
 if(mutation==='relocated')bytes.set(nat.fromHex(p.sceneMarker),tx.slot.base+0x105000);
 if(mutation==='duplicated'){bytes.set(nat.fromHex(p.sceneMarker),tx.slot.base+0x400);bytes.set(nat.fromHex(p.sceneMarker),tx.slot.base+0x440);}
 assert.equal(weapons.inspect(bytes,gi,p.id).available,false,mutation+' deveria bloquear o ajuste.');
}
save('NGmais_Machado5_Laminas4','upload/game(10).sav',gi,weaponReqs,ngResult);
// Cifras: par nativo de Niflheim, estados parciais e conclusão 4+1.
const beforeFile='analysis_0_14_0/pedidas/AmostrasDosSavesPedidos/game(AntesDeConseguirCifraNilfHeim).sav',afterFile=beforeFile.replace('Antes','Depois'),cb=read(beforeFile),ca=read(afterFile),ci=core.parse(cb).latestSlot;
assert.equal(ciphers.inspect(cb,ci,'niflheim-cipher').total,0);assert.equal(ciphers.inspect(ca,ci,'niflheim-cipher').total,1);
let cipherCases=0;
for(const p of ciphers.PROFILES){
 const start=ciphers.inspect(cb,ci,p.id).total;
 for(let total=start;total<=4;total++){
  const request={type:ciphers.TYPE,slot:ci,id:p.id,total},r=plan.patch(cb,[request]),{x,y}=protectedSections(cb,r.bytes,ci),state=ciphers.inspect(r.bytes,ci,p.id);
  assert.equal(state.available,true);assert.equal(state.total,total);assert.equal(state.complete,total===4);
  const ids=new Set([p.piece,p.complete]);for(const row of x.rows)if(!ids.has(nat.idOf(row)))same(row,nat.unique(y.rows,nat.idOf(row),true));
  assert.deepEqual(x.maps,y.maps);assert.deepEqual(x.refs,y.refs);
  assert.deepEqual(x.finals.filter(r=>!ids.has(nat.idOf(r))),y.finals.filter(r=>!ids.has(nat.idOf(r))));
  same(plan.patch(r.bytes,[request]).bytes,r.bytes);
  if(total===1&&p.id==='niflheim-cipher'){const source=nat.read(ca,ci);assert.equal(nat.quantity(y,p.piece),nat.quantity(source,p.piece));same(nat.unique(y.finals,p.piece,true),nat.unique(source.finals,p.piece,true));}
  cipherCases++;
 }
 const full=plan.patch(cb,[{type:ciphers.TYPE,slot:ci,id:p.id,total:4}]);
 for(const total of [-1,5,2.5,'4',NaN])assert.throws(()=>plan.patch(cb,[{type:ciphers.TYPE,slot:ci,id:p.id,total}]));
 assert.throws(()=>plan.patch(full.bytes,[{type:ciphers.TYPE,slot:ci,id:p.id,total:3}]),/remoção/);
 const broken=nat.read(cb,ci);nat.putQuantity(broken,p.complete,1,true);assert.equal(ciphers.inspect(nat.write(broken).bytes,ci,p.id).available,false);
}
const cipherReqs=ciphers.PROFILES.map(p=>({type:ciphers.TYPE,id:p.id,slot:ci,total:4})),cipherResult=plan.patch(cb,cipherReqs);save('Cifras_Niflheim_Muspelheim',''+beforeFile,ci,cipherReqs,cipherResult);
// Proteção confirmada da 0.14.3 e exportações antigas aprovadas.
const control=read('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),five=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+').map(p=>({slot:14,id:p.id,type:'inventory-equipment',stage:2}));
same(plan.patch(control,five).bytes,read('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav'));
const manifest=JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_14_0/testes/manifest.json'))),regressions=[];
for(const c of manifest.cases.filter(c=>['10_','12_','13_','14_'].some(prefix=>c.name.startsWith(prefix)))){assert.equal(sha(plan.patch(read(c.source),c.requests).bytes),c.sha256,c.name);regressions.push(c.name);}
for(const rel of ['src/native-records.js','src/resource-edit.js','src/wallet.js','src/campaign.js','src/enchantments.js','src/enchantment-instance-clone.js','src/equipment-record-clone.js','src/armor-template-clone.js'])same(fs.readFileSync(path.join(__dirname,rel)),fs.readFileSync(path.join(ws,'Forja_2018_PC_0_14_3',rel)),rel);
const combinedReqs=[...runicRequests,...ciphers.PROFILES.map(p=>({type:ciphers.TYPE,id:p.id,slot:ni,total:4}))],combined=plan.patch(normal,combinedReqs);protectedSections(normal,combined.bytes,ni);save('Runicos_e_Cifras_Combinados','upload/game(9).sav',ni,combinedReqs,combined);
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({version:core.VERSION,cases},null,2)+'\n');
const report={version:core.VERSION,weaponRunicIds:31,additionalExperimentalProfiles:27,referenceGameResaveHasAll31:true,normalAndNgpFiltersIncludeSharedRunics:true,newRunicsAdded:missing.length,newRunicsDoNotWriteGuessedKeys:true,ownedRunicsPreserved:true,runicGuardsAndNoOpPassed:true,fourMappedRunicsByteIdenticalToPreviousVersion:true,ngpAxes6AndBlades5Recognized:true,ngpDowngradeChangesOnlyFourMapValues:true,ngpRestoringMaximumRestoresOriginalBytes:true,ngpInvalidStatesBlocked:true,cipherCases,niflheimFirstPieceMatchesNativeRecord:true,cipherFourPiecesAndCompleteFlagSynchronized:true,cipherRemovalBlocked:true,fiveHandlesExportByteIdenticalToGameApprovedFile:true,oldApprovedExportsByteIdentical:regressions,commonWriterAndExistingEnchantmentModulesUnchanged:true,combinedRunicsAndCiphersPassed:true,newFeaturesRunInGameHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_0_15_0.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
