'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, query, downloads, $ } = require('./test_dom_harness.cjs');
const writer = require('./src/plan'), levels = require('./src/levels');
const bytes = new Uint8Array(fs.readFileSync(process.argv[2]));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async () => {
  api.chooseView('equipment'); assert.ok($('equipment-count').textContent.includes('475'));
  $('equipment-search').value = 'KratosArmorChest_TankSet_Tier03'; await $('equipment-search').fire('input');
  for (const id of ['EEA7E31201646AAF','4B9C550D079A0AE1','5898550D079A0AE1']) assert.ok($('equipment-body').innerHTML.includes(id));
  api.chooseView('enchantments'); assert.equal($('enchantments-controls').hidden,true);
  api.loadBytes(bytes); api.selectSlot(11); api.chooseView('enchantments');
  assert.equal($('enchantments-controls').hidden,false);
  $('enchantment-target').value='12'; await $('enchantment-target').fire('change');
  $('enchantment-model').value='73'; await $('enchantment-model').fire('change');
  assert.ok($('enchantment-original').textContent.includes('Força 3')); assert.equal($('enchantment-preview').textContent,'Rúnico 3');
  await $('enchantment-apply').click(); assert.equal($('error').hidden,true,$('error').textContent);
  assert.equal($('enchantment-edited').textContent,'Rúnico 3'); assert.ok($('changes-body').innerHTML.includes('Força 3'));
  const replacement = {slot:11,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73};
  same(api.exportBytes().bytes,writer.patch(bytes,[replacement]).bytes);
  $('enchantment-model').value='74'; await $('enchantment-model').fire('change'); await $('enchantment-apply').click();
  assert.equal(api.getState().changes.filter(change=>change.type==='enchantment-copy').length,1);
  assert.equal($('enchantment-edited').textContent,'Recarga 3');
  $('enchantment-model').value='73'; await $('enchantment-model').fire('change'); await $('enchantment-apply').click();
  same(api.exportBytes().bytes,writer.patch(bytes,[replacement]).bytes);
  $('quantity-item').value='CC1B3E5C878842B3'; await $('quantity-item').fire('change'); $('quantity-value').value='22';
  await $('quantity-value').fire('input'); await $('quantity-apply').click();
  api.chooseView('levels'); $('level-target').value='6'; await $('level-target').fire('change'); await $('level-apply').click(); assert.equal($('error').hidden,true,$('error').textContent);
  const plan=[replacement,{slot:11,id:'CC1B3E5C878842B3',quantity:22},{slot:11,id:levels.ID,type:'axe-level',level:6}];
  same(api.exportBytes().bytes,writer.patch(bytes,plan).bytes);
  await $('report-download').click(); const report=JSON.parse(await downloads.at(-1).blob.text());
  assert.equal(report.validation.enchantmentInGameTested,false); assert.equal(report.validation.enchantmentBindingsPreserved,true);
  assert.equal(report.validation.enchantmentNewSocketsCreated,0); assert.equal(report.validation.preservesBytesOutsideQuantityFields,false);
  assert.ok(report.changes.find(change=>change.type==='enchantment-copy').afterLabel.includes('Rúnico 3'));
  await $('export-top').click(); same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
  await query('[data-undo]').find(button=>button.dataset.undo==='11:enchantment-12').click();
  same(api.exportBytes().bytes,writer.patch(bytes,plan.slice(1)).bytes);
  api.chooseView('enchantments'); assert.ok($('enchantment-edited').textContent.includes('Força 3'));
  // Evento forçado em botão desabilitado: backend também precisa recusar.
  const previous=api.exportBytes().bytes;
  $('enchantment-model').value='999999'; await $('enchantment-model').fire('change'); assert.equal($('enchantment-apply').disabled,true);
  await $('enchantment-apply').click(); assert.equal($('error').hidden,false); same(api.exportBytes().bytes,previous);
  await $('reset-changes').click(); assert.equal(api.getState().log.length,0);
  $('equipment-search').value='6DD41B327975AF5E'; await $('equipment-search').fire('input'); assert.ok($('equipment-body').innerHTML.includes('Nível 6'));
  assert.ok($('armor-level-apply')); 
  const result={version:'0.9.0',htmlExecutedInVM:true, equipmentCatalogueAvailableWithoutSave:true,
    allStagesOfChestFamilyShown:true, enchantmentSelectionAndPreviewVerified:true, sameTargetRequestReplacesPrevious:true,
    mixedPlanAndUndoVerified:true, reportsAndSaveDownloadVerified:true, forcedInvalidRequestPreservesDraft:true,
    armorLevelControlPresent:true, visualBrowserTested:false,inGameTestedHere:false};
  fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ENCANTAMENTOS_INTERFACE_0_9_0.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
