'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const core=require('./src/core'),resources=require('./src/resource-edit'),native=require('./src/native-records'),campaign=require('./src/campaign');
const plan=require('./src/plan'),enchants=require('./src/enchantments'),stat=require('./src/enchantment-stats'),slots=require('./src/slots');
const [dir,outDir,stableRoot,normalFile,ngFile]=process.argv.slice(2);
fs.mkdirSync(outDir,{recursive:true});
const names=fs.readdirSync(dir).filter(n=>n.endsWith('.sav'));
const read=prefix=>new Uint8Array(fs.readFileSync(path.join(dir,names.find(n=>n.startsWith('game('+prefix)))));
const same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b))),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const req=(type,slot,more={})=>({type,id:type,slot,...more});
const manifest=[];
function save(name,input,output,changes){fs.writeFileSync(path.join(outDir,name+'.bin'),output);manifest.push({name,changes,sourceSha256:hash(input),outputSha256:hash(output)});}
function onlyFields(a,b,fields){const expected=a.slice(),dv=native.view(expected);for(const f of fields){if(f.width===1)dv.setUint8(f.offset,f.value);else dv.setUint32(f.offset,f.value,true);}same(expected,b);}
let recognizedSlots=0;
for(const name of names){const b=new Uint8Array(fs.readFileSync(path.join(dir,name))),m=core.parse(b);for(const s of m.slots.filter(s=>s.available)){const state=resources.inspect(b,s.index,m);assert.equal(state.available,true,name+' slot '+s.number+': '+state.reason);recognizedSlots++;}}
const diffBefore=read('antesDeAlterar'),diffNative=read('DepoisDeAlterar'),dm=core.parse(diffBefore),ds=dm.slots[13];
const difficulty=plan.patch(diffBefore,[req('difficulty',13,{code:2})]);
onlyFields(diffBefore,difficulty.bytes,[{offset:ds.base+0x110,width:4,value:2},{offset:ds.base+0x10402,width:1,value:2}]);
assert.equal(campaign.difficulty(difficulty.bytes,13).code,campaign.difficulty(diffNative,13).code);
same(plan.patch(difficulty.bytes,[req('difficulty',13,{code:1})]).bytes,diffBefore);
assert.throws(()=>plan.patch(diffBefore,[req('difficulty',13,{code:3})]));
const split=diffBefore.slice();native.view(split).setUint32(ds.base+0x110,2,true);assert.throws(()=>plan.patch(split,[req('difficulty',13,{code:2})]));
assert.equal(resources.inspect(split,13).available,false);
const structuralZero=diffBefore.slice();native.view(structuralZero).setUint32(ds.base+0x110,0,true);structuralZero[ds.base+0x10402]=0;
assert.equal(resources.inspect(structuralZero,13).available,true);assert.equal(campaign.difficulty(structuralZero,13).available,false);
assert.throws(()=>plan.patch(structuralZero,[req('difficulty',13,{code:1})]));
save('difficulty',diffBefore,difficulty.bytes,[req('difficulty',13,{code:2})]);
const appleBefore=read('AntesDepegar'),appleNative=read('DepoisDePegar'),am=core.parse(appleBefore),as=am.slots[12];
const appleReq=req('idunn-apples',12,{total:6}),apples=plan.patch(appleBefore,[appleReq]);
const nativeTotals=campaign.totals(core.parse(appleNative).slots[12],campaign.APPLES);assert.equal(nativeTotals.total,6);
for(const [key,id]of Object.entries(campaign.APPLES))assert.equal(apples.model.slots[12].rows.find(r=>r.id===id).quantity,nativeTotals[key]);
onlyFields(appleBefore,apples.bytes,Object.entries(campaign.APPLES).map(([key,id])=>({offset:as.rows.find(r=>r.id===id).valueOffset,width:4,value:nativeTotals[key]})));
for(let total=0;total<=9;total++){const r=plan.patch(appleBefore,[req('idunn-apples',12,{total})]),s=campaign.totals(r.model.slots[12],campaign.APPLES);assert.equal(s.total,total);assert.equal(s.upgrades,Math.floor(total/3));assert.equal(s.piece,total%3);}
for(const total of [-1,10,1.5,NaN,'6'])assert.throws(()=>plan.patch(appleBefore,[req('idunn-apples',12,{total})]));
const badApple=appleBefore.slice();native.view(badApple).setUint32(as.rows.find(r=>r.id===campaign.APPLES.menu).valueOffset,7,true);assert.throws(()=>plan.patch(badApple,[appleReq]));
same(plan.patch(apples.bytes,[req('idunn-apples',12,{total:5})]).bytes,appleBefore);
save('apples',appleBefore,apples.bytes,[appleReq]);
const equipBefore=read('AntesDeEquipar'),equipNative=read('depoisDeEquipar'),equipReq=req('equip-chest',11,{targetId:'EEA7E31201646AAF'}),equip=plan.patch(equipBefore,[equipReq]);
assert.equal(campaign.equipmentState(equip.bytes,11).current.id,campaign.equipmentState(equipNative,11).current.id);
const et=native.read(equipBefore,11),ef=et.state.frames[1],er=native.mapEntry(et,1,613),eo=ef.start+14+et.maps[1].entries.indexOf(er)*9;
onlyFields(equipBefore,equip.bytes,[{offset:eo,width:4,value:607},{offset:eo+4,width:4,value:2}]);
same(plan.patch(equip.bytes,[req('equip-chest',11,{targetId:'41C19E30CAE5761D'})]).bytes,equipBefore);
assert.throws(()=>plan.patch(equipBefore,[req('equip-chest',11,{targetId:campaign.GAUNTLETS.id})]));
save('equip',equipBefore,equip.bytes,[equipReq]);
const stoneBefore=read('SemPedra'),stoneNative=read('AposComprar'),stoneUsed=read('AposUsar'),stoneReq=req('superior-stone',11),stone=plan.patch(stoneBefore,[stoneReq]),stoneRestored=plan.patch(stoneUsed,[stoneReq]);
for(const result of [stone,stoneRestored]){assert.ok(campaign.stoneState(result.bytes,11).owned);const t=native.read(result.bytes,11);assert.equal(native.quantity(t,campaign.STONES[1]),1);assert.equal(native.quantity(t,'024373073A80CFB5'),0);assert.equal(native.unique(t.refs,'CE0BFA08B3CE47F9'),null);assert.ok(native.unique(t.refs,'101A353D83F1212E'));assert.equal(core.hex(native.unique(t.finals,campaign.STONES[1]).subarray(8)),'00000000F77F0000');same(plan.patch(result.bytes,[stoneReq]).bytes,result.bytes);}
assert.equal(stone.layout[0].addedBytes,56);assert.equal(stoneRestored.layout[0].addedBytes,0);
const sn=native.read(stoneNative,11),sr=native.read(stone.bytes,11);for(const id of [campaign.STONES[1],'101A353D83F1212E'])same(native.unique(sr.finals,id),native.unique(sn.finals,id));
save('stone',stoneBefore,stone.bytes,[stoneReq]);save('stone-restored',stoneUsed,stoneRestored.bytes,[stoneReq]);
const buyBefore=read('AntesDeComprar'),buyNative=read('DepoisDeComprar'),buyReq=req('acquire-ancients-wrist',11),buy=plan.patch(buyBefore,[buyReq]),bt=native.read(buy.bytes,11),bn=native.read(buyNative,11);
assert.equal(native.quantity(bt,campaign.GAUNTLETS.id),1);assert.equal(native.view(native.mapEntry(bt,0,650)).getUint32(4,true),0);
for(const id of [campaign.GAUNTLETS.id,campaign.GAUNTLETS.ref,'5395046D84ED7B28'])same(native.unique(bt.finals,id),native.unique(bn.finals,id));
const old=native.read(buyBefore,11);for(const row of old.rows)same(row,native.unique(bt.rows,native.idOf(row)));same(bt.objectsAndGroups,old.objectsAndGroups);
assert.deepEqual(bt.maps[2].entries,old.maps[2].entries);assert.equal(buy.layout[0].addedBytes,80);same(plan.patch(buy.bytes,[buyReq]).bytes,buy.bytes);
save('acquisition',buyBefore,buy.bytes,[buyReq]);
const empty=read('semEncatamentos'),shop=read('ApósColocar'),unique=read('ColocandoUm');
for(const [b,uid,name,link]of [[shop,75,'Symbol of Shadows',0xFFFFFFFF],[unique,33,'Heart of the Valkyrie',15]]){const state=enchants.inspect(b,14),o=state.targets.find(o=>o.uid===uid);assert.equal(o.sampleName,name);assert.equal(o.link,link);assert.ok(stat.entries(b,14).entries.some(x=>x.uid===uid));}
const assigned=[];
for(const [uid,nativeInput]of [[75,shop],[33,unique]]){
 const request=req('attach-enchantment',14,{targetUid:uid}),attached=plan.patch(empty,[request]),a=enchants.inspect(attached.bytes,14).targets.find(o=>o.uid===uid),n=enchants.inspect(nativeInput,14).targets.find(o=>o.uid===uid),before=enchants.inspect(empty,14).objects.find(o=>o.uid===uid);
 same(attached.bytes.subarray(a.start,a.end),nativeInput.subarray(n.start,n.end));
 const binding=native.view(native.fromHex('B74F7BCF35641B8F'));
 onlyFields(empty,attached.bytes,[{offset:before.start+8,width:4,value:binding.getUint32(0,true)},{offset:before.start+12,width:4,value:binding.getUint32(4,true)},{offset:before.start+56,width:4,value:0}]);
 const entry=stat.entries(attached.bytes,14).entries.find(e=>e.uid===uid),scalar={slot:14,type:'enchantment-stat',id:entry.id,targetUid:uid,statId:entry.statId,value:1234,expected:entry.value};
 const combined=plan.patch(empty,[request,scalar]);assert.equal(stat.entries(combined.bytes,14).entries.find(e=>e.id===entry.id).value,1234);
 assigned.push({uid,name:a.sampleName});save('attach-'+uid,empty,attached.bytes,[request]);
}
assert.throws(()=>plan.patch(shop,[req('attach-enchantment',14,{targetUid:33})]));assert.throws(()=>plan.patch(empty,[req('attach-enchantment',14,{targetUid:34})]));
// Rejeitar tipos/valores indevidos preserva a entrada, inclusive Buffer com offset.
const untouched=hash(buyBefore);for(const bad of [null,req('current-rage',11),req('superior-stone',19),{...buyReq,id:'wrong'}, {...buyReq,slot:1.5}])assert.throws(()=>plan.patch(buyBefore,[bad]));assert.equal(hash(buyBefore),untouched);
assert.throws(()=>plan.patch(appleBefore,[appleReq,appleReq]));
const offset=Buffer.alloc(buyBefore.length+16);offset.set(buyBefore,8);same(plan.patch(offset.subarray(8,8+buyBefore.length),[buyReq]).bytes,buy.bytes);
const stable=require(path.resolve(stableRoot,'src/plan'));for(const file of [normalFile,ngFile]){const b=new Uint8Array(fs.readFileSync(file)),m=core.parse(b),index=m.latestSlot,changes=[{slot:index,id:'9E5240D27406E85A',quantity:12345},{slot:index,id:'CC1B3E5C878842B3',quantity:4321}];same(plan.patch(b,changes).bytes,stable.patch(b,changes).bytes);}
for(const b of [diffBefore,diffNative,equipBefore])same(native.write(native.read(b,core.parse(b).latestSlot)).bytes,b);
// Importar o perfil com dificuldade 1/2 e continuar editando não altera a raiz.
const bundle=slots.extract(diffNative,13),importReq={slot:19,type:'slot-import',id:'subsave',bundle:bundle.bytes},imported=plan.patch(diffBefore,[importReq,req('difficulty',19,{code:1})]);assert.equal(campaign.difficulty(imported.bytes,19).code,1);
const mixed=plan.patch(buyBefore,[buyReq,{slot:11,id:'FCC6B87B4C8E41DC',quantity:999},req('idunn-apples',11,{total:9})]);assert.equal(mixed.model.slots[11].rows.find(r=>r.id==='FCC6B87B4C8E41DC').quantity,999);assert.equal(campaign.totals(mixed.model.slots[11],campaign.APPLES).total,9);assert.ok(campaign.acquisitionState(mixed.bytes,11).owned);
fs.writeFileSync(path.join(outDir,'cases.json'),JSON.stringify(manifest,null,2));
const report={version:core.VERSION,archiveSamples:names.length,recognizedSlots,allRecognizedSlotsHaveCompleteStructure:true,
 difficultyTwoFieldsAndNativeComparisonPassed:true,difficultyRoundTripAndDivergenceGuardPassed:true,allTenAppleTotalsAndFourCountersPassed:true,
 appleFiveToSixMatchesNativeCounters:true,appleChestProgressTrackersPreserved:true,nativeChestSwapAndRoundTripPassed:true,
 superiorStoneAcquisitionAndConsumptionReversalPassed:true,stoneFlagReferencesAndFinalMarkersVerified:true,
 ancientsGauntletsAcquisitionMappedIndividually:true,existingEquipmentResourcesAndUnknownMapsPreserved:true,
 identifiedEnchantmentNames:assigned,shopSentinelLinkRecognized:true,emptySocketAttachmentMatchesNativeObjectByteForByte:true,
 attachmentCombinedWithScalarStatsPassed:true,occupiedAndUnmappedAttachmentRejected:true,allMutationsAreOnCopies:true,
 legacyResourceExportsByteIdenticalTo090:true,importAndResourceCombinationPassed:true,invalidInputsAndOffsetBuffersChecked:true,
 currentRageExcluded:true,currentHealthAndNgpMenuUnlockNotInvented:true,browserVisualTested:false,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_AMOSTRAS_0_10_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
