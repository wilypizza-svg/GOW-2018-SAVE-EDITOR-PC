"""Confere as saídas com leitor Python, sem importar os módulos JavaScript.
Uso: python3 test_release0150_oracle.py CAMINHO_DO_WORKSPACE
"""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys

root=Path(__file__).resolve().parent
workspace=Path(sys.argv[1]).resolve()
reader=root/'test_clone_native_reader.py'
definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']
mapped={p['id']:p for p in json.loads((root/'data/inventory-profiles.json').read_text())['profiles']}
runics={p['id'] for p in json.loads((root/'data/runic-catalog.json').read_text())['items']}
weapons={p['id']:p for p in json.loads((root/'data/weapon-profiles.json').read_text())['profiles']}
ciphers={'niflheim-cipher':('BF717A0CBE634AD9','04F506B8591A794C'),'muspelheim-cipher':('48ECF23EF868FBE4','3926F91F998D0F89')}
split=lambda b,n:[b[p:p+n] for p in range(0,len(b),n)]
def mapping(raw,number):
    prefix,stride=(8 if number==1 else 0),(8 if number==0 else 9)
    n=struct.unpack_from('<I',raw,2+prefix)[0]
    return {struct.unpack_from('<I',raw,6+prefix+k*stride)[0]:raw[6+prefix+k*stride:6+prefix+(k+1)*stride] for k in range(n)}
results=[]
for case in json.loads((workspace/'analysis_0_15_0/testes/manifest.json').read_text())['cases']:
    source=Path(case['source']).read_bytes()
    edited=Path(case['output']).read_bytes()
    assert hashlib.sha256(edited).hexdigest()==case['sha256']
    ns['SLOT_INDEX']=case['slot']
    a,b=parse(source),parse(edited)
    old_rows={r[:8].hex().upper():r for r in a['rows']}
    new_rows={r[:8].hex().upper():r for r in b['rows']}
    allowed_rows,allowed_refs,allowed_finals,allowed_keys=set(),set(),set(),set()
    quantities,values={},{}
    for r in case['requests']:
        if r['type']=='inventory-equipment':
            assert r['id'] in runics
            p=mapped.get(r['id'])
            allowed_rows.add(r['id']);quantities[r['id']]=r['stage']+1
            if p:
                assert p['mode']=='quantity'
                allowed_refs.update(p['referenceIds'])
                allowed_finals.update(p['ids']+p['referenceIds'])
                allowed_keys.add(p['key']);values[(0,p['key'])]=r['stage']
                if p['key'] in mapping(a['frames'][1],1):values[(1,p['key'])]=r['stage']
        elif r['type']=='weapon-level':
            p=weapons[r['id']]
            allowed_keys.add(p['key'])
            values[(0,p['key'])]=r['level']-1;values[(1,p['key'])]=r['level']-1
            assert bytes.fromhex(p['sceneMarker'][16:]) not in source[a['base']:a['base']+1677512]
            for id in p['history']:assert struct.unpack_from('<I',old_rows[id],8)[0]==1
        elif r['type']=='realm-cipher':
            piece,complete=ciphers[r['id']]
            allowed_rows.update((piece,complete));allowed_finals.update((piece,complete))
            quantities[piece]=r['total']
            if r['total']==4:quantities[complete]=1
        else:
            raise AssertionError(r['type'])
    assert set(new_rows)-set(old_rows)<=allowed_rows
    for id,row in old_rows.items():
        if id not in allowed_rows:assert new_rows[id]==row,(case['name'],id)
    for id,value in quantities.items():assert struct.unpack_from('<I',new_rows[id],8)[0]==value
    for number in range(3):
        aa,bb=mapping(a['frames'][number],number),mapping(b['frames'][number],number)
        assert {k:v for k,v in aa.items() if k not in allowed_keys}=={k:v for k,v in bb.items() if k not in allowed_keys}
        for (frame,key),value in values.items():
            if frame==number:assert struct.unpack_from('<I',bb[key],4)[0]==value
        assert a['frames'][number][2:10 if number==1 else 2]==b['frames'][number][2:10 if number==1 else 2]
    assert [r for r in split(a['refs'],8) if r.hex().upper() not in allowed_refs]==[r for r in split(b['refs'],8) if r.hex().upper() not in allowed_refs]
    old_final,new_final=split(a['finals'][4:],16),split(b['finals'][4:],16)
    assert len(new_final)<=512
    assert [r for r in old_final if r[:8].hex().upper() not in allowed_finals]==[r for r in new_final if r[:8].hex().upper() not in allowed_finals]
    assert a['objects']==b['objects']
    prefix=bytearray(source[:a['start']])
    prefix[a['base']+0x124:a['base']+0x128]=edited[a['base']+0x124:a['base']+0x128]
    assert prefix==edited[:b['start']]
    assert source[max(a['end'],b['end']):]==edited[max(a['end'],b['end']):]
    for slot in range(20):
        if slot==case['slot']:continue
        start=4160+slot*1677512
        assert source[start:start+1677512]==edited[start:start+1677512]
    if 'NGmais' in case['name']:
        assert a['rows']==b['rows'] and a['refs']==b['refs'] and a['finals']==b['finals']
        assert sum(x!=y for x,y in zip(source,edited))==4
    results.append({'case':case['name'],'slot':case['slot']+1,'passed':True})
report={'version':'0.15.0','independentLanguage':'Python','passed':True,'cases':results,'worldObjectsOtherSlotsPreserved':True,'runicIdsAndQuantitiesVerified':True,'ngpMapOnlyChangesVerified':True,'cipherCountersVerified':True,'inGameTestedHere':False}
(root/'VERIFICACAO_INDEPENDENTE_0_15_0.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
