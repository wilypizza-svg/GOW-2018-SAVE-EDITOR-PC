# Relatório de implementação — Forja 2018 PC 0.18.0

## Resultado incorporado

O usuário confirmou sucesso nos oito ensaios de remoção e enviou os arquivos regravados pelo próprio jogo. A leitura dos retornos confirmou a persistência de todas as retiradas. Nos casos 07 e 08, os três encantamentos devolvidos mantêm identidades e efeitos; seus vínculos já não apontam para o peitoral retirado.

A 0.18.0 integra a retirada dos equipamentos reconhecidos e suas melhorias, a devolução dos encantamentos comuns dos formatos observados e a exclusão individual de uma instância comum solta. As novas saídas reproduzem byte a byte os ensaios aprovados. Foram verificadas revisão, desfazer, download do relatório e exportação no HTML executado em DOM simulado.

| Caso | Retorno nativo do usuário | SHA-256 |
|---|---|---|
| 01_WYRMSKIN_NG | game(01_WYRMSKIN_NG(Funcionou)).sav | `c88149c71afb7c71f8e1bdb213ceed7fa475827d453158dd6888cfcfe660494d` |
| 02_BRACADEIRA_ARES_NGMAIS | game(02_BRACADEIRA_ARES_NGMAIS(Funcionou)).sav | `2a021185f146f64b5b7e46390fd7e6b880c784f1ed6cbac4d2995bda71aecb41` |
| 03_POMO_RETRIBUICAO_NGMAIS | game(03_POMO_RETRIBUICAO_NGMAIS(Funcionou)).sav | `9a3155a1deab2d058c872d48cac27edd4a9abd000d7e0ace7bf0d49c49085bd0` |
| 04_CABO_VALQUIRIAS_NGMAIS | game(04_CABO_VALQUIRIAS_NGMAIS(Funcionou)).sav | `e462261642018b460363b03696af4de3497eb89fddc7c180e7304a93fd2f57b2` |
| 05_TALISMA_NGMAIS | game(05_TALISMA_NGMAIS(Funcionou)).sav | `cfd36efed29e32c4da0c44e6115eb11d7cb6bca79d9c50bbe931c4d59f3668b8` |
| 06_ENCANTAMENTO_COMUM | game(06_ENCANTAMENTO_COMUM(Funcionou)).sav | `38877fd7726d5db60189eeae8fa706440dbd64de8bac44eed9c332d2d3189394` |
| 07_PEITORAL_ARES_DEVOLVER_ENCANTAMENTOS | game(07_PEITORAL_ARES_DEVOLVER_ENCANTAMENTOS(Funcionou)).sav | `75fb42e75471a20063196f12170b5f094883f089b7db2857a756b9cc6ff93e63` |
| 08_REMOCOES_COMBINADAS_NGMAIS | game(08_REMOCOES_COMBINADAS_NGMAIS(Funcionou)).sav | `7373faa6a4c1544d9c40441e01784d84c6d1704c279b6f4a8eeeee17baee62b2` |

Os oito hashes diferem dos arquivos de teste entregues, confirmando que são retornos novos. Os dados completos, IDs de referência e verificações estão em `data/removal-validation.json` e `data/inventory-removal.json`. Os saves pessoais ficam separados da distribuição de código.

## Regras da remoção

- Equipamentos: zera os registros existentes da base e das melhorias, retira seus avisos pendentes e preserva os mapas de nível, as referências e as outras instâncias.
- Encantamento comum: retira somente a instância selecionada, recalcula o contador e os tamanhos estruturais, e preserva as outras identidades.
- Peça com encantamentos: solta os comuns reconhecidos, mantendo efeitos e identidades. Os únicos e os formatos não classificados bloqueiam a retirada da peça até serem desequipados pelo jogo.
- Peça equipada com chave conhecida: bloqueia a retirada. Para peças sem chave ativa mapeada, exige a confirmação de que já foram desequipadas no jogo.
- Item vendido: aceita somente o estado coerente com base zerada, histórico zerado compatível, mapa preservado, ausência no mapa de equipamento atual e ausência de vínculos. Os outros estados parciais continuam bloqueados.
- A retirada não simula preço de venda nem cria estoque de recompra. Hacksilver e materiais são preservados, salvo alterações próprias solicitadas pelo usuário.

## Preservação e limites

Os módulos `native-records.js`, `resource-edit.js`, `wallet.js`, `weapon-levels.js`, `campaign.js`, `runics.js`, `enchantment-acquisition.js` e os catálogos anteriores permanecem iguais à 0.17.3. A interface de inclusão de itens mantém os fluxos anteriores. Os únicos reconhecidos não entram na remoção individual de encantamentos.

A conferência automatizada atesta os registros e o arquivo; os testes no jogo foram realizados pelo usuário nos oito ensaios equivalentes. Isso não equivale a uma garantia para toda combinação possível de itens e saves.

## NG+ — último teste isolado solicitado

Foi recuperado o save `game(20261025-031453).sav`, referência `libfile_e7e02b34fa988191946f7ccd6a96754e`, SHA-256 `65653b50aaadb9c76dfaa7d8bae224e701d5485260baf4b1f764005b6b3704af`.

Ele contém ambas as flags explícitas de NG+, Machado nível 2 e Lâminas nível 1. Os dois mapas de nível são coerentes; o histórico está incompleto e a propriedade completa esperada no mundo não foi encontrada. Existem ocorrências isoladas do hash dessa propriedade em outras estruturas. Por isso a proteção atual do editor continua ativa.

O ensaio separado registra as etapas mapeadas e sincroniza apenas os dois mapas: Machado 6 e Lâminas 5. Preserva o mundo, não cria propriedades, não altera a história e não ativa a opção NG+ do menu. As proteções relaxadas existem somente numa VM de teste limitada ao SHA de origem; `src/weapon-levels.js` distribuído continua intacto.

Controle: `65653b50aaadb9c76dfaa7d8bae224e701d5485260baf4b1f764005b6b3704af`.
Teste: `cda934e98bcf54c4c2cb208483a5a8ab69ba0717fb5d1727928f09183ada0c77`.
Ambos os arquivos mantêm o subsave interno 7, título `Midgard - Wildwoods - Hunt with Atreus`.

**Pendente:** confirmar níveis e uso das armas no jogo, salvar, recarregar e enviar o retorno nativo. O arquivo não representa um Machado originalmente no nível 1; esse cenário ainda não foi coletado. A ampliação da regra não está integrada ao editor 0.18.0.

## Amostras já disponíveis para as próximas funções

| Função | Evidência já analisada | Situação e próximo passo |
|---|---|---|
| Traje de Atirador Superior do Atreus | ID `2E5E5D6AA1DB012C`, chave PC 475; aquisição observada no NG normal e no NG+ | Preparar ensaios de inclusão antes da integração. Mesma posse, mapa e marcador de aquisição nas duas campanhas. |
| Túnica do Campeão NG+ do Atreus | ID `1E583D180E1D3836`, chave PC 1019; par de compra NG+ | Preparar ensaio de inclusão. Não inferir variante apenas pelo sufixo do nome interno. |
| Invocação do cervo do Atreus (`SummonDeer`) | ID `DAEDCF731F461790`, chave PC 66; aquisição inicial observada | Inclusão inicial mapeada; testar antes da integração. Faltam amostras dos upgrades e vínculos dos demais rúnicos do Atreus. |
| Expansão de encantamentos | Sete pares do RAR `AmostrasDosSavesPedidos(novaLeva).rar`: cinco únicos e dois comuns | Os blocos novos, atributos, listas de efeitos e tipos foram identificados. Preparar inclusões separadas; os perfis atuais da 0.18.0 continuam sendo os 17 validados. |
| Story ↔ Balanced Experience | Par nominal: códigos 0 → 1 nos dois campos de dificuldade | O código nominal foi identificado; ampliar a seleção após ensaio próprio. A 0.18.0 preserva a cobertura anterior. |
| Give Me God of War | Amostras mencionadas envolvem reinício de campanha | Não generalizar uma diferença de campanha inteira para uma troca de dificuldade. |
| Liberação da opção NG+ no menu | Amostras citadas anteriormente | Relacionar e validar o par que isole o desbloqueio do menu. As flags de campanha NG+ não comprovam esse estado do menu. |
| Grip of the Maze + | ID `74D96151C6A7865C` já conhecido | Falta integrar a classificação e o molde de inclusão. |
| Horn of Heimdall + | ID `24F16CA904962E7F` já conhecido | Falta integrar a classificação e o molde de inclusão. |

Referências adicionais: RAR `libfile_acd786b4a3a08191bd07e50cafaec030`; trajes NG normal `libfile_eba495ccc1b8819196995077e34c0ce9` / `libfile_89c35f3015d08191beade2545a5c2871`; invocação do Atreus `libfile_77864342984081918915fb32c6518fb0` / `libfile_22d0aec24c008191866487fa2dd05625`.

### Perfis adicionais de encantamento identificados

| Amostra | Primeiro conjunto de efeitos | Segundo conjunto | Observação |
|---|---|---|---|
| Épico nível 4, único | 19409 | 815 | Nova instância isolada entre recompensas de combate. |
| Épico nível 7, único | 26433 | 782 | Nova instância isolada entre recompensas de combate. |
| Lendário nível 5, único | 19403 | 858 | Nova instância isolada entre recompensas de combate. |
| Lendário nível 6, único | 36291 | 749 | Outros pares também normalizam atributos de uma instância antiga; separar esse ruído. |
| Lendário nível 6, comum | 19410 | 781 | Registro `RuneCreator_Unique_WeaponSpecial01`; o nome interno “Unique” não decide a classificação. |
| Épico nível 6, único | 19402 | 847 | Registro `RuneCreator_Unique_Musp`; preservar o perfil completo. |
| Nível 7, comum — Signo Robusto de Sorte | 24294 e 24346 | 806 | Primeiro conjunto tem dois códigos; não reduzir o molde a um ID único. |

As amostras de venda de encantamentos únicos foram descartadas da coleta porque o usuário verificou que o jogo não permite essa venda. Escudos, armaduras do Atreus além dos perfis acima, vida/fúria atual, preenchimento de lore/bestiário e desbloqueio de habilidades continuam fora da implementação atual. A edição direta de encaixes permanece retirada.
