'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),selection=require('./src/inventory-selection'),plan=require('./src/plan');
const workspace=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(workspace,p))),same=(a,b,m)=>assert.ok(nat.equal(a,b),m),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const base=read('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),hash=sha(base),expected=read('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav');
const profiles=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+'),requests=profiles.map(p=>({slot:14,id:p.id,type:'inventory-equipment',stage:2}));
assert.equal(profiles.length,5);assert.equal(inv.BLADE_FINAL_LIMIT,512);assert.equal(profiles.filter(inv.maximumOnly).length,4);
for(const p of profiles)assert.equal(inv.requiresExperimental(p),false);
const result=plan.patch(base,requests),before=nat.read(base,14),after=nat.read(result.bytes,14);
same(result.bytes,expected,'O editor precisa reproduzir exatamente o lote F aprovado no jogo.');
assert.equal(after.finals.length,512);assert.equal(result.layout[0].oldestFinalRowsDiscarded,12);
assert.deepEqual(after.finals.slice(0,500),before.finals.slice(12));
assert.deepEqual(after.rows.slice(0,before.rows.length),before.rows);assert.deepEqual(after.refs,before.refs);
same(after.objectsAndGroups,before.objectsAndGroups);assert.deepEqual(after.maps.slice(1),before.maps.slice(1));
assert.equal(after.maps[0].entries.length,before.maps[0].entries.length+1);
assert.equal(nat.view(nat.mapEntry(after,0,971)).getUint32(4,true),2);
assert.equal(new Set(after.rows.map(nat.idOf)).size,after.rows.length);
for(const p of profiles)for(const id of p.ids)assert.equal(nat.quantity(after,id),1);
for(const slot of core.parse(base).slots)if(slot.index!==14)same(base.subarray(slot.base,slot.end),result.bytes.subarray(slot.base,slot.end));
same(base.subarray(after.state.activeEnd),result.bytes.subarray(after.state.activeEnd));
same(plan.patch(result.bytes,requests).bytes,result.bytes,'Repetir a inclusão deve ser inócuo.');
const played=read('upload/game(Cursed_F_Cinco_Cabos_NGmais_Nivel9(Funcionou)).sav'),playedModel=core.parse(played),playedTx=nat.read(played,playedModel.latestSlot,playedModel);
for(const key of [970,971,972,973,974])assert.equal(nat.view(nat.mapEntry(playedTx,0,key)).getUint32(4,true),2);
for(const p of profiles)for(const id of p.ids)assert.equal(nat.quantity(playedTx,id),1);
same(plan.patch(played,requests.map(r=>({...r,slot:playedModel.latestSlot}))).bytes,played);
for(const p of profiles.filter(inv.maximumOnly))for(const stage of [0,1])assert.throws(()=>plan.patch(base,[{slot:14,id:p.id,type:'inventory-equipment',stage}]),/nível 9/);
const unmapped=profiles.find(inv.maximumOnly),oldAssembler=require(path.join(workspace,'Forja_2018_PC_0_14_0/src/inventory'));
const alreadyOwned=oldAssembler.patch(base,[{slot:14,id:unmapped.id,type:'inventory-equipment',stage:0,allowExperimental:true}]).bytes,ownedHash=sha(alreadyOwned);
assert.throws(()=>plan.patch(alreadyOwned,[{slot:14,id:unmapped.id,type:'inventory-equipment',stage:2}]),/já existe/);
assert.equal(sha(alreadyOwned),ownedHash);
for(const mode of ['base','mapped-max','template-max']){
 const chosen=selection.buildMissing(inv.inspect(base,14),profiles.map(p=>p.id),mode,false);
 for(const r of chosen.filter(r=>inv.maximumOnly(profiles.find(p=>p.id===r.id))))assert.equal(r.stage,2);
}
const cursed=profiles.find(p=>p.id==='B19A13C4B34FA37F'),boundary=[];
const overflowTx=nat.read(base,14),extra=nat.fromHex(cursed.id+'0000000000000000');overflowTx.finals.push(extra);
const boundedDirect=nat.read(nat.write(overflowTx).bytes,14);assert.equal(boundedDirect.finals.length,512);assert.deepEqual(boundedDirect.finals,overflowTx.finals.slice(1));
for(const count of [510,511,512]){
 const tx=nat.read(base,14);tx.finals=tx.finals.slice(-count);const source=nat.write(tx).bytes,src=nat.read(source,14);
 const r=plan.patch(source,[{slot:14,id:cursed.id,type:'inventory-equipment',stage:0}]),out=nat.read(r.bytes,14),drop=Math.max(0,count+2-512);
 assert.equal(out.finals.length,Math.min(512,count+2));assert.deepEqual(out.finals.slice(0,count-drop),src.finals.slice(drop));
 assert.equal(r.layout[0].oldestFinalRowsDiscarded,drop);assert.equal(nat.quantity(out,cursed.id),1);assert.equal(nat.view(nat.mapEntry(out,0,971)).getUint32(4,true),0);
 boundary.push({before:count,added:2,after:out.finals.length,discarded:drop});
}
// A aquisição mínima corrigida corresponde à estrutura do teste D aprovado.
const d=nat.read(read('analysis_cabos/diagnostico_fila512/Cursed_D_Nivel8_Fila512.sav'),14),newD=nat.read(plan.patch(base,[{slot:14,id:cursed.id,type:'inventory-equipment',stage:0}]).bytes,14);
for(const key of ['rows','refs','maps','finals'])assert.deepEqual(newD[key],d[key]);same(newD.objectsAndGroups,d.objectsAndGroups);
// Os fluxos de recursos, vida/fúria, cabos normais, Ivaldi e armas principais
// já aprovados pelo usuário precisam continuar exportando os mesmos bytes.
const manifest=JSON.parse(fs.readFileSync(path.join(workspace,'analysis_0_14_0/testes/manifest.json'))),regressions=[];
for(const c of manifest.cases.filter(c=>['10_','12_','13_','14_'].some(prefix=>c.name.startsWith(prefix)))){
 const source=read(c.source),r=plan.patch(source,c.requests);assert.equal(sha(r.bytes),c.sha256,c.name);regressions.push(c.name);
}
for(const rel of ['src/resource-edit.js','src/wallet.js','src/campaign.js','src/weapon-levels.js','src/enchantments.js','src/enchantment-instance-clone.js','src/equipment-record-clone.js','src/armor-template-clone.js','src/plan.js']){
 same(fs.readFileSync(path.join(__dirname,rel)),fs.readFileSync(path.join(workspace,'Forja_2018_PC_0_14_2',rel)),rel);
}
for(const file of fs.readdirSync(path.join(__dirname,'data')))same(fs.readFileSync(path.join(__dirname,'data',file)),fs.readFileSync(path.join(workspace,'Forja_2018_PC_0_14_2/data',file)));
assert.equal(sha(base),hash);
const report={version:core.VERSION,successfulFiveHandleOutputByteIdentical:true,successfulFileSha256:sha(expected),fourMaximumOnlyProfiles:true,unknownLevelKeysNotGuessed:true,
 gameResaveHasAllFiveNativeLevelKeysAt2:true,reapplyingToPreparedAndGameResavedFilesIsNoOp:true,unsupportedIntermediateStagesRejected:true,ownedLowerLevelWithoutMappedKeyPreserved:true,boundaryCases:boundary,
 minimalLevel8MatchesApprovedDStructure:true,commonWriterRejectsOverflowByDroppingOldest:true,previousApprovedExportsByteIdentical:regressions,existingQuantityWritersAndEnchantmentModulesUnchanged:true,dataCatalogsUnchanged:true,
 unrelatedInventoryRowsObjectsWorldAndSlotsPreserved:true,gameBatchReportedPassedByUser:true,newBuildRunInGameHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_CABOS_0_14_3.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
