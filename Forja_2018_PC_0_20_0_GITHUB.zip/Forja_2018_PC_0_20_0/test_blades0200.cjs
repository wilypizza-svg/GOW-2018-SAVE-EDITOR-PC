'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const root=path.resolve(__dirname,'..'),work=path.join(root,'analysis_0_20_0'),fixtures=path.resolve(process.argv[2]||work+'/recovered');
const core=require('./src/core'),nat=require('./src/native-records'),unlock=require('./src/blades-unlock'),weapons=require('./src/weapon-levels'),plan=require('./src/plan'),slots=require('./src/slots'),inv=require('./src/inventory'),removal=require('./src/inventory-removal'),ciphers=require('./src/ciphers');
const oldRoot=path.resolve(process.argv[3]||work+'/reference/Forja_2018_PC_0_19_0'),oldPlan=require(oldRoot+'/src/plan'),oldWeapon=require(oldRoot+'/src/weapon-levels');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),same=(a,b,label)=>assert(nat.equal(a,b),label),read=name=>new Uint8Array(fs.readFileSync(path.join(fixtures,name)));
const blade=weapons.PROFILES.find(p=>p.id==='blades-main-level'),recipe=require('./data/blades-acquisition.json');
const source=read('game(AntesDePegarAsBlades).sav'),model=core.parse(source),hash=sha(source),outDir=path.join(work,'test_output');fs.mkdirSync(outDir,{recursive:true});
assert.equal(hash,'5e0f53914b4a56a2aeb041607e1650bf1a861e6532dc29128c16c63f1e8ff1a3');
const grant=slot=>({slot,type:unlock.TYPE,id:unlock.ID}),level=(slot,n)=>({slot,type:weapons.TYPE,id:blade.id,level:n});
const checks=[],outputs=[];let negativeCases=0;
function reject(name,fn){assert.throws(fn,undefined,name);negativeCases++;}
function preserve(a,b,index){
 const m=core.parse(a),x=nat.read(a,index,m),y=nat.read(b,index);
 same(a.subarray(0,core.HEADER_SIZE),b.subarray(0,core.HEADER_SIZE),'Global header');
 for(const s of m.slots)if(s.index!==index)same(a.subarray(s.base,s.end),b.subarray(s.base,s.end),'Other slot '+s.number);
 same(a.subarray(x.slot.base,x.slot.base+0x124),b.subarray(y.slot.base,y.slot.base+0x124),'Slot header and timestamp');
 same(a.subarray(x.slot.base+0x128,x.slot.base+0x10400),b.subarray(y.slot.base+0x128,y.slot.base+0x10400),'World and story');
 same(x.objectsAndGroups,y.objectsAndGroups,'Instances and opaque groups');
 same(x.maps[1].prefix,y.maps[1].prefix,'Selected weapon');
 for(const row of x.rows)assert.equal(nat.quantity(y,nat.idOf(row)),nat.view(row).getUint32(8,true),'Existing primary quantity');
 same(a.subarray(y.state.activeEnd,x.slot.end),b.subarray(y.state.activeEnd,y.slot.end),'Absolute reserve');
}
function output(name,bytes,slot,kind){const file=path.join(outDir,name+'.sav');fs.writeFileSync(file,bytes);outputs.push({name,file,slot,kind,sha256:sha(bytes)});}
// Os hashes são dos arquivos efetivamente testados e aprovados pelo usuário.
const near=plan.patch(source,[grant(7)]);
assert.equal(sha(near.bytes),'75e71f5b237d06f35b00a39ac7748b878b5dce7b0d645c65809324e1e2c02b3f');preserve(source,near.bytes,7);
const bundle=slots.extract(source,10).bytes,control=slots.patch(source,[{slot:7,type:'slot-import',id:'subsave',bundle}]).bytes;
nat.view(control).setBigUint64(core.HEADER_SIZE+7*core.SLOT_SIZE,1792986928n,true);
assert.equal(sha(control),'4c7e8822f380bad5de5011321460388802498267a0c9ad03eb16f2a70967ca3e');
const early=plan.patch(control,[grant(7)]);
assert.equal(sha(early.bytes),'59cc5e73c1b4c45430578c198eb93898c74a2683736b89b63147d4ddf94145f3');preserve(control,early.bytes,7);
output('early_control',control,7,'control');output('early_granted_approved',early.bytes,7,'grant');checks.push('BL_01 e BL_04 byte a byte iguais aos arquivos aprovados no jogo');
for(const index of [7,10]){
 const g=plan.patch(source,[grant(index)]);preserve(source,g.bytes,index);
 same(plan.patch(g.bytes,[grant(index)]).bytes,g.bytes,'Repeated grant');assert.equal(plan.patch(g.bytes,[grant(index)]).log.length,0);
 for(let n=1;n<=5;n++){
  const result=plan.patch(source,[level(index,n),grant(index)]),state=weapons.inspect(result.bytes,index,blade.id),tx=nat.read(result.bytes,index);
  assert(state.available&&state.earlyBladesMapsOnly);assert.equal(state.current,n);assert.equal(state.registeredMax,n);assert.equal(state.options.length,5);
  for(let k=0;k<blade.history.length;k++)assert.equal(nat.quantity(tx,blade.history[k]),k<n-1?1:null);
  preserve(source,result.bytes,index);same(plan.patch(result.bytes,[grant(index),level(index,n)]).bytes,result.bytes,'Repeated maximum');
  const down=weapons.patch(result.bytes,[level(index,1)]),dt=nat.read(down.bytes,index);assert.equal(weapons.inspect(down.bytes,index,blade.id).current,1);
  for(let k=0;k<n-1;k++)assert.equal(nat.quantity(dt,blade.history[k]),1);
  if(n===5){output(index===10?'initial_native_slot_max':'near_original_event_max',result.bytes,index,'max');}
 }
 checks.push('Níveis 1..5, downgrade, histórico e repetição no slot '+(index+1));
}
const earlyMax=plan.patch(control,[grant(7),level(7,5)]);output('early_grant_and_max',earlyMax.bytes,7,'max');preserve(control,earlyMax.bytes,7);
const maxBytes=earlyMax.bytes;
for(const name of ['game(DepoisDePegarAsBlades).sav','game(BL_04_INICIO_INVENTARIO(FuncionouPerfeitamente)).sav','game(BL_02_EQUIPADAS(Funcionou)MesmoAposAcutscene).sav']){
 const b=read(name),slot=core.parse(b).latestSlot,s=weapons.inspect(b,slot,blade.id);
 assert(s.available&&s.earlyBladesMapsOnly);same(unlock.patch(b,[grant(slot)]).bytes,b,'Native existing possession');
 const result=plan.patch(b,[level(slot,5)]);preserve(b,result.bytes,slot);assert.equal(weapons.inspect(result.bytes,slot,blade.id).current,5);
 checks.push('Retorno nativo e nível máximo: '+name);
}
// Rejeições de estruturas incompletas, conflitos e referências desconhecidas.
reject('Aquisição duplicada',()=>plan.patch(source,[grant(7),grant(7)]));
reject('Níveis duplicados',()=>plan.patch(control,[grant(7),level(7,4),level(7,5)]));
for(const n of [0,6,1.5,null])reject('Nível inválido '+n,()=>plan.patch(control,[grant(7),level(7,n)]));
reject('Slot inválido',()=>unlock.patch(source,[grant(20)]));
reject('Machado inicial mantém proteção',()=>weapons.patch(source,[{slot:10,type:weapons.TYPE,id:'axe-main-level',level:6}]));
const partial=nat.read(control,7);nat.addGlobal(partial,3,0);const partialBytes=nat.write(partial).bytes;
assert(!unlock.inspect(partialBytes,7).available);reject('Posse parcial',()=>unlock.patch(partialBytes,[grant(7)]));
function mutated(name,mutate){
 const tx=nat.read(maxBytes,7);mutate(tx);const bad=nat.write(tx).bytes;
 assert(!weapons.inspect(bad,7,blade.id).available,name);reject(name,()=>weapons.patch(bad,[level(7,3)]));
}
mutated('Mapas divergentes',tx=>nat.view(nat.mapEntry(tx,1,3)).setUint32(4,1,true));
mutated('Posse da arma zerada',tx=>nat.putQuantity(tx,recipe.weaponId,0));
mutated('Cabo padrão incoerente',tx=>nat.view(nat.mapEntry(tx,1,80)).setUint32(4,1,true));
mutated('Referência inicial ausente',tx=>{tx.refs=tx.refs.filter(row=>nat.idOf(row)!=='FA7DCFD7BC7C81CC');});
mutated('Histórico com lacuna',tx=>nat.putQuantity(tx,blade.history[0],0));
for(const offset of [0x8000,0x40000]){
 const bad=maxBytes.slice(),slot=core.parse(bad).slots[7];bad.set(nat.fromHex(blade.sceneMarker).subarray(8),slot.base+offset);
 assert(!weapons.inspect(bad,7,blade.id).available);reject('Referência secundária desconhecida '+offset,()=>weapons.patch(bad,[level(7,3)]));
}
// O caminho anterior com campo secundário continua igual ao 0.19.0.
const worldProbe=early.bytes.slice(),probeSlot=core.parse(worldProbe).slots[7],probeOffset=probeSlot.base+0x8000;
worldProbe.set(nat.fromHex(blade.sceneMarker),probeOffset);nat.view(worldProbe).setUint32(probeOffset+16,0,true);
same(weapons.patch(worldProbe,[level(7,5)]).bytes,oldWeapon.patch(worldProbe,[level(7,5)]).bytes,'Existing secondary-field path');
checks.push('Caminho com propriedade secundária igual ao 0.19.0 em sonda sintética identificada');
for(const n of [1,4,5])same(plan.patch(source,[{slot:7,type:weapons.TYPE,id:'axe-main-level',level:n}]).bytes,oldPlan.patch(source,[{slot:7,type:weapons.TYPE,id:'axe-main-level',level:n}]).bytes,'Native Axe regression');
// Comparação dos gravadores existentes usando os mesmos dados nativos.
const inventory=inv.inspect(source,7),kinds=['chest','wrist','waist','axe','blades','talisman','axe-runic-light','blades-runic-light'];
const requests=kinds.map(kind=>inventory.profiles.find(p=>p.kind===kind&&p.available&&!p.owned)).filter(Boolean).map(p=>({slot:7,type:'inventory-equipment',id:p.id,stage:p.stages.length-1,allowExperimental:true}));
requests.push({slot:7,id:'9E5240D27406E85A',quantity:1234567},{slot:7,id:'8A9A9B831CF67C9C',quantity:2345678});
const factory=inv.FACTORIES.find(p=>p.variant==='Normal'&&p.id.startsWith('ng-enchantment-'));
requests.push({slot:7,type:'enchantment-create',id:factory.id,count:1});
const regression=plan.patch(source,requests),previous=oldPlan.patch(source,requests);same(regression.bytes,previous.bytes,'Equipment, resource, runic and enchantment regression');
assert(regression.log.length>=10);checks.push('Equipamentos, rúnicos, recursos e encantamento: exportação idêntica ao 0.19.0');
const r=removal.inspect(source,7).equipment.find(p=>p.available&&p.owned);assert(r);
const remove={slot:7,type:removal.EQUIPMENT,id:r.id,confirmUnequipped:true};same(plan.patch(source,[remove]).bytes,oldPlan.patch(source,[remove]).bytes,'Removal regression');checks.push('Remoção existente idêntica ao 0.19.0');
for(const p of ciphers.PROFILES){const request={slot:10,type:ciphers.TYPE,id:p.id,total:4};same(plan.patch(source,[request]).bytes,oldPlan.patch(source,[request]).bytes,'Cipher binary regression');assert.equal(plan.patch(source,[request]).log[0].storyWarning,ciphers.STORY_WARNING);}
checks.push('Cifras: mesmos bytes, aviso incluído no relatório');
const mixed=plan.patch(source,[...requests,grant(7),level(7,5)]),mt=nat.read(mixed.bytes,7);assert.equal(nat.quantity(mt,'9E5240D27406E85A'),1234567);assert.equal(weapons.inspect(mixed.bytes,7,blade.id).current,5);assert.equal(mixed.log.length,regression.log.length+2);checks.push('Aquisição e máximo em lote com equipamentos, rúnicos, recursos e encantamento');
// Fila cheia: o gravador preserva seu limite nativo de 512 avisos.
const full=nat.read(control,7);full.finals=[];
for(let k=0;k<512;k++){const row=new Uint8Array(16);nat.view(row).setUint32(0,0x12300000+k,true);full.finals.push(row);}
const fullBytes=nat.write(full).bytes,filled=plan.patch(fullBytes,[grant(7),level(7,5)]);assert.equal(nat.read(filled.bytes,7).finals.length,512);assert.equal(weapons.inspect(filled.bytes,7,blade.id).current,5);checks.push('Limite de 512 avisos respeitado em sonda sintética');
const ngpFile=path.join(work,'legacy_fixtures/game(20261025-031453).sav');assert(fs.existsSync(ngpFile),'Fixture NG+ necessária');
const ngp=new Uint8Array(fs.readFileSync(ngpFile)),ngpSlot=core.parse(ngp).latestSlot,ngpRequests=weapons.PROFILES.map(p=>({slot:ngpSlot,type:weapons.TYPE,id:p.id,level:p.max}));
for(const p of weapons.PROFILES)assert(weapons.inspect(ngp,ngpSlot,p.id).partialHistoryMapped);
same(plan.patch(ngp,ngpRequests).bytes,oldPlan.patch(ngp,ngpRequests).bytes,'Existing NG+ regression');checks.push('NG+ com histórico parcial: exportação das duas armas idêntica ao 0.19.0');
assert.equal(sha(source),hash,'Input mutation');
const report={passed:true,version:core.VERSION,checks,negativeCases,approvedAcquisitionHashesMatched:true,allLevelsAndDowngradesPassed:true,earlyMaximumInGameTested:false,unrelatedExportsByteIdentical:true,outputs};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_LAMINAS_0_20_0.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:true,checks:checks.length,negativeCases,approvedAcquisitionHashesMatched:true,unrelatedExportsByteIdentical:true,outputs:outputs.length}));
