'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const core=require('./src/core'),wallet=require('./src/wallet'),policy=require('./src/resource-policy'),slots=require('./src/slots');
const stat=require('./src/enchantment-stats'),enchants=require('./src/enchantments'),plan=require('./src/plan'),resources=require('./src/resource-edit');
const [sourceFile,normalFile,ngFile,stableRoot,outDir]=process.argv.slice(2),read=p=>new Uint8Array(fs.readFileSync(p));
const same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b))),source=read(sourceFile),normal=read(normalFile),ng=read(ngFile),pristine=Buffer.from(source);
fs.mkdirSync(outDir,{recursive:true});const model=core.parse(source),index=12,slot=model.slots[index],state=resources.inspect(source,index,model);
assert.equal(core.FIELDS.length,48);assert.equal(policy.FIELDS.length,67);assert.equal(new Set(policy.FIELDS.map(x=>x.id)).size,67);
const requests=policy.FIELDS.map(field=>({slot:index,id:field.id,quantity:field.suggested}));
fs.writeFileSync(path.join(outDir,'wallet_requests.json'),JSON.stringify(requests,null,2));
const all=wallet.patch(source,requests),next=resources.inspect(all.bytes,index,all.model);fs.writeFileSync(path.join(outDir,'wallet_all.bin'),all.bytes);
assert.ok(all.validation.newRecords>32);assert.equal(all.model.slots[index].table.count,slot.table.count+all.validation.newRecords);
for(const req of requests)assert.equal(all.model.slots[index].rows.find(r=>r.id===req.id).quantity,req.quantity);
same(all.bytes.subarray(next.objectStart,next.activeEnd),source.subarray(state.objectStart,state.activeEnd));
same(all.bytes.subarray(next.activeEnd),source.subarray(next.activeEnd));same(all.bytes.subarray(0,slot.base),source.subarray(0,slot.base));
for(const row of slot.rows){const found=all.model.slots[index].rows.find(r=>r.id===row.id);assert.equal(found.auxiliary,row.auxiliary);}
const mainKit=policy.buildKit(all.model.slots[index],'main',10);assert.ok(mainKit.every(req=>req.quantity>=all.model.slots[index].rows.find(r=>r.id===req.id).quantity));
assert.equal(policy.buildKit(slot,'helmets',1).length,8);assert.ok(policy.buildKit(slot,'helmets',1).every(x=>x.id!==policy.IDS.queen));assert.equal(policy.buildKit(slot,'helmets-queen',1).length,9);
assert.equal(policy.buildKit(slot,'dwarven',99999).find(x=>x.id==='EC3F370D42DC5103').quantity,1);
for(const bad of [null,{slot:index,id:'EC3F370D42DC5103',quantity:2},{slot:index,id:'EEA7E31201646AAF',quantity:1},
 {slot:index,id:policy.IDS.hs,quantity:-1},{slot:index,id:policy.IDS.hs,quantity:1.5},{slot:index,id:policy.IDS.hs,quantity:NaN},
 {slot:14,id:policy.IDS.hs,quantity:1},{slot:index,id:policy.IDS.hs,quantity:1,type:'other'}])assert.throws(()=>wallet.patch(source,[bad]));
assert.throws(()=>wallet.patch(source,[requests[0],requests[0]]));
const absent='EC3F370D42DC5103';same(wallet.patch(source,[{slot:index,id:absent,quantity:0}]).bytes,source);same(wallet.patch(source,[]).bytes,source);
const stable=require(path.resolve(stableRoot,'src/plan'));
for(const [input,changes] of [[source,[{slot:index,id:policy.IDS.hs,quantity:123}]],
 [normal,[{slot:11,id:'CC1B3E5C878842B3',quantity:20}]],
 [normal,[{slot:11,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73},{slot:11,id:policy.IDS.hs,quantity:888}]]])same(plan.patch(input,changes).bytes,stable.patch(input,changes).bytes);
const ordered=slots.ordered(model).filter(x=>x.available);assert.equal(ordered[0].number,13);assert.ok(ordered.every((s,i)=>i===0||ordered[i-1].timestamp>=s.timestamp));assert.ok(ordered.every(s=>s.difficulty===null&&s.saveType===null&&s.runMode===null));
const bundle=slots.extract(source,index);fs.writeFileSync(path.join(outDir,'subsave.forja-slot'),bundle.bytes);const decoded=slots.readBundle(bundle.bytes);same(decoded.body,source.subarray(slot.base,slot.end));assert.equal(decoded.sourceIndex,index);
const importReq={slot:13,id:'subsave',type:'slot-import',bundle:bundle.bytes};
const imported=slots.patch(source,[importReq]);assert.equal(imported.model.supported,model.supported+1);const importedSlot=imported.model.slots[13];same(imported.bytes.subarray(importedSlot.base,importedSlot.end),decoded.body);fs.writeFileSync(path.join(outDir,'slots_imported.bin'),imported.bytes);
same(slots.patch(imported.bytes,[importReq]).bytes,imported.bytes);assert.equal(slots.patch(imported.bytes,[importReq]).log.length,0);
const deleted=slots.patch(source,[{slot:0,id:'subsave',type:'slot-delete'}]);assert.equal(deleted.model.supported,model.supported-1);assert.ok(deleted.model.slots[0].empty);fs.writeFileSync(path.join(outDir,'slots_deleted.bin'),deleted.bytes);
const restored=slots.patch(deleted.bytes,[{slot:0,id:'subsave',type:'slot-import',bundle:slots.extract(source,0).bytes}]);same(restored.bytes,source);
const mixedImport=plan.patch(source,[importReq,{slot:13,id:policy.IDS.hs,quantity:1234}]);assert.equal(mixedImport.baseModel.slots[13].available,true);assert.equal(mixedImport.model.slots[13].rows.find(r=>r.id===policy.IDS.hs).quantity,1234);
const checksumBad=bundle.bytes.slice();checksumBad[slots.BUNDLE_HEADER+200]^=1;assert.throws(()=>slots.readBundle(checksumBad));assert.throws(()=>slots.patch(source,[{...importReq,bundle:checksumBad}]));
assert.throws(()=>slots.readBundle(bundle.bytes.subarray(0,500)));assert.throws(()=>slots.inspectSource(new Uint8Array(128)));assert.throws(()=>slots.patch(source,[importReq,importReq]));
const buildBad=bundle.bytes.slice();new DataView(buildBad.buffer).setUint32(24,123,true);new DataView(buildBad.buffer).setUint32(slots.BUNDLE_HEADER+12,123,true);new DataView(buildBad.buffer).setUint32(32,slots.crc32(buildBad.subarray(slots.BUNDLE_HEADER)),true);assert.throws(()=>slots.patch(source,[{...importReq,bundle:buildBad}]));
const one=source.slice();for(const s of model.slots)if(s.index!==index)one.fill(0,s.base,s.end);assert.throws(()=>slots.patch(one,[{slot:index,id:'subsave',type:'slot-delete'}]));
const filter=stat.filtered(source,index,'48B6FD1AC0CB4E01',3,1000);assert.equal(filter.length,1);assert.equal(filter[0].targetUid,12);
const modified=stat.patch(source,filter);fs.writeFileSync(path.join(outDir,'stat_filtered.bin'),modified.bytes);assert.equal(modified.log.length,1);assert.equal(modified.log[0].length,4);
same(stat.patch(modified.bytes,[{...filter[0],value:3,expected:1000}]).bytes,source);
const ngFilter=stat.filtered(ng,18,'7A00D0F01CCEAB3A',8,1000);assert.equal(ngFilter.length,2);const ngChanged=stat.patch(ng,ngFilter);fs.writeFileSync(path.join(outDir,'stats_ng.bin'),ngChanged.bytes);
for(const req of [null,{...filter[0],targetUid:73,id:stat.idFor(73,filter[0].statId)},{...filter[0],value:-1},{...filter[0],value:Infinity},{...filter[0],value:1000001},{...filter[0],expected:999},{...filter[0],statId:'0000000000000000'}])assert.throws(()=>stat.patch(source,[req]));
assert.throws(()=>stat.patch(source,[filter[0],filter[0]]));assert.throws(()=>plan.patch(source,[filter[0],{slot:index,id:'enchantment-12',type:'enchantment-copy',targetUid:12,templateUid:73}]));
const combination=plan.patch(source,[...requests,...filter]);assert.equal(stat.entries(combination.bytes,index,combination.model).entries.find(x=>x.uid===12&&x.statId==='48B6FD1AC0CB4E01').value,1000);assert.equal(combination.validation.newRecords,all.validation.newRecords);
const offset=Buffer.alloc(source.length+16);offset.set(source,8);const saved=Buffer.from(offset);same(wallet.patch(offset.subarray(8,source.length+8),[{slot:index,id:policy.IDS.hs,quantity:123}]).bytes,wallet.patch(source,[{slot:index,id:policy.IDS.hs,quantity:123}]).bytes);same(offset,saved);same(source,pristine);
const report={version:'0.9.0',editableWalletProfiles:67,legacyProfilesUnchanged:48,newWalletProfiles:19,missingRecordsInCombinedTest:all.validation.newRecords,
 legacyExportsByteIdentical:true,allWalletRequestsReRead:true,batchesAbove32HandledInMemory:true,uniqueItemTotalsEnforced:true,unknownArmorIdsRejected:true,
 sortedByNativeTimestamp:true,unmappedMetadataNotInvented:true,completeSubsaveExtractImportDeleteAndRestoreChecked:true,mixedBuildsObservedInSameFileSupported:true,
 crcTamperingAndTruncationRejected:true,unsupportedBuildAndLastSaveDeletionRejected:true,importedSubsaveCanBeEdited:true,
 individualAndExactValueBulkEnchantmentWritesChecked:true,nonmatchingEnchantmentsPreserved:true,copyAndStatConflictBlocked:true,allOtherSlotsAndUnknownBytesPreserved:true,
 originalAndOffsetInputUnmodified:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_FUNCOES_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
