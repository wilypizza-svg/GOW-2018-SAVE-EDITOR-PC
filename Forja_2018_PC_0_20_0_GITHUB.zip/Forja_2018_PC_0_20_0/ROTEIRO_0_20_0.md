# Roteiro — Forja 2018 PC 0.20.0

## Adicionar as Lâminas e escolher o nível

1. Feche o jogo e guarde o original. Abra uma cópia do `game.sav` completo no editor.
2. Em **Gerenciar saves**, escolha o título e a data desejados. O número interno do slot não equivale à posição na lista do jogo.
3. Abra **Níveis**. No cartão **Lâminas do Caos**, clique em **Adicionar Lâminas ao inventário**. Se já estiverem possuídas, siga para a escolha do nível.
4. Escolha **Nível 5**, ou outro nível de 1 a 5, e clique em **Elevar para Nível 5** ou no botão correspondente.
5. Abra **Alterações**. Para uma arma ausente no original, devem aparecer duas linhas: aquisição das Lâminas com o cabo padrão e ajuste do nível 1 para o nível escolhido.
6. Use **Desfazer** para retirar um ajuste. Desfazer apenas o nível mantém a arma no nível 1. Desfazer a aquisição também retira o nível que depende dela, preservando os outros ajustes.
7. Baixe o `game.sav`, coloque a cópia no local usado pelo jogo após fechá-lo e carregue o mesmo título/data.
8. Confira a posse, o nível e o cabo padrão. Alterne as armas, ataque, abra e feche o inventário, salve manualmente e recarregue. Confira novamente a posse e o nível.

A aquisição antecipada já teve confirmação no jogo, inclusive durante a progressão inicial e após a cutscene original. O ajuste direto ao nível máximo desde o início é a parte nova que precisa dessa confirmação. Se enviar um retorno, use o arquivo salvo novamente pelo jogo e informe se o nível continuou correto após recarregar.

## Cifras de Muspelheim e Niflheim

**Evite adicionar as cifras antes da primeira viagem a Alfheim. Elas podem travar a cena em que Freya pede para mover a ponte de Týr. Espere concluir essa sequência antes de usar a função.**

O aviso aparece em **Campanha e inventário**, junto dos controles de cifras, e na revisão quando houver alterações desse tipo. O editor não detecta automaticamente se essa etapa da história foi concluída.

## Conferir uma edição combinada

Depois do teste das Lâminas, use outra cópia do original para combinar a aquisição e o nível com recursos ou um equipamento já conhecido. Confira cada linha em **Alterações**, carregue a cópia, abra e feche o inventário, salve e recarregue.

Recursos, peças possuídas, encantamentos e seleção de arma são preservados pela operação de aquisição. As regras específicas das outras funções continuam valendo. O botão **Baixar original** devolve o arquivo inicialmente aberto.
