'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const [inputDir,previousRoot,normalFile,outputDir]=process.argv.slice(2).map(p=>path.resolve(p));
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),select=require('./src/inventory-selection'),clone=require('./src/armor-template-clone'),records=require('./src/equipment-record-clone'),plan=require('./src/plan');
const oldPlan=require(previousRoot+'/src/plan'),oldInv=require(previousRoot+'/src/inventory');
const load=f=>new Uint8Array(fs.readFileSync(f)),base=load(inputDir+'/game(SaveBase).sav'),normal=load(normalFile),played=load(inputDir+'/game(6).sav'),played2=load(inputDir+'/game(UsandoOmetodoClonagemComCodOfWar).sav');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),m),index=14,initialHash=hash(base);
const request=(id,slot=index)=>({slot,id,type:'inventory-equipment',stage:inv.PROFILES.find(p=>p.id===id).stages.length-1,allowExperimental:true});
const pommel='20079575B16C9CD2',ymir='BAB314470E329FEF',betrayal='0290AA0A3136E656',tyr='0FD03F4ABE9A21AE';
const previous=oldPlan.patch(base,[...clone.BASE_IDS.map(id=>request(id)),request(pommel)]),a=nat.read(previous.bytes,index),b=nat.read(played,index),c=nat.read(played2,index);
const p=inv.PROFILES.find(p=>p.id===pommel);assert.equal(p.key,966);assert.equal(p.experimentalTemplate,undefined);
const newKeys=source=>source.maps[0].entries.filter(r=>!a.maps[0].entries.some(q=>nat.view(r).getUint32(0,true)===nat.view(q).getUint32(0,true))).map(r=>[nat.view(r).getUint32(0,true),nat.view(r).getUint32(4,true)]);
for(const tx of [b,c]){
 assert.deepEqual(newKeys(tx),[[966,2]]);assert.deepEqual(tx.refs,a.refs);assert.equal(tx.rows.length,a.rows.length);
 for(const id of [...clone.IDS,...p.ids])same(nat.unique(tx.rows,id,true),nat.unique(a.rows,id,true),'registro clonado mudou no jogo');
 const targetFinals=tx.finals.filter(r=>[...clone.IDS,...p.ids].includes(nat.idOf(r)));assert.deepEqual(targetFinals,a.finals.filter(r=>[...clone.IDS,...p.ids].includes(nat.idOf(r))));
 same(plan.patch(tx.bytes,[request(pommel)]).bytes,tx.bytes,'reaplicar pomo no save regravado deve ser inócuo');
}
// Os conjuntos são agrupados pela família interna, nunca apenas pelo nome.
assert.equal(select.SETS.length,47);assert.equal(select.SETS.filter(s=>s.variant==='normal').length,32);assert.equal(select.SETS.filter(s=>s.variant==='NG+').length,15);
for(const set of select.SETS){assert.deepEqual(set.parts.map(p=>p.kind),['chest','wrist','waist']);assert.ok(set.parts.every(p=>p.variant===set.variant));}
const brokNormal=select.SETS.find(s=>s.id==='KratosArmor_HuldraBrokSet_Tier06::normal'),brokPlus=select.SETS.find(s=>s.id==='KratosArmor_HuldraBrokSet_Tier06_NGP::NG+');assert.ok(brokNormal&&brokPlus);
assert.equal(brokNormal.parts[0].id,'D3E92FA332CC6A5C');assert.equal(brokNormal.parts[0].stages[0].label,'6');assert.equal(brokNormal.parts[0].variant,'normal');assert.equal(brokNormal.parts[0].name.includes('Maze'),false);
assert.equal(select.filterProfiles({variant:'NG+'}).some(p=>p.id==='D3E92FA332CC6A5C'),false);
for(const variant of ['normal','NG+'])assert.ok(select.filterProfiles({variant}).every(p=>p.variant===variant));
assert.equal(inv.PROFILES.filter(p=>p.kind==='blades').length,oldInv.PROFILES.filter(p=>p.kind==='blades').length,'não ampliar cabos das lâminas');
const normalIndex=core.parse(normal).latestSlot;assert.notEqual(normalIndex,index);
const baseState=inv.inspect(base,index),normalState=inv.inspect(normal,normalIndex),setRequests=(state,set,slot=index)=>select.buildSet(state,set.id,'template-max',true).map(r=>({...r,slot}));
const brokRequests=setRequests(baseState,brokPlus),normalRequests=setRequests(normalState,brokNormal,normalIndex);assert.equal(brokRequests.length,3);assert.equal(normalRequests.length,3);
const normalTalisman=[...normalState.profiles.filter(p=>p.id===betrayal),...normalState.profiles].find(p=>p.kind==='talisman'&&p.variant==='normal'&&p.available&&!p.owned&&p.ids.length>1);assert.ok(normalTalisman);
let scenarios=[{name:'07_Brok_NGmais_Retribuicao',source:base,requests:[...brokRequests,request(pommel)],sourceName:'game(SaveBase).sav'},
 {name:'08_Zeus_Ymir_NGmais',source:base,requests:[request(clone.BASE_IDS[0]),request(ymir)],sourceName:'game(SaveBase).sav'},
 {name:'09_Brok_normal_Talisma_normal',source:normal,index:normalIndex,requests:[...normalRequests,request(normalTalisman.id,normalIndex)],sourceName:path.basename(normalFile)}];
fs.mkdirSync(outputDir,{recursive:true});const cases=[];
for(const scenario of scenarios){
 const slotIndex=scenario.index??index,normalized=inv.normalizeRequests(scenario.requests),allowedIds=new Set(normalized.flatMap(r=>r.type===clone.TYPE?clone.IDS:inv.PROFILES.find(p=>p.id===r.id).ids)),allowedKeys=new Set(normalized.flatMap(r=>r.type===clone.TYPE?[682,683,684]:Number.isInteger(inv.PROFILES.find(p=>p.id===r.id).key)?[inv.PROFILES.find(p=>p.id===r.id).key]:[]));
 const result=plan.patch(scenario.source,scenario.requests),before=nat.read(scenario.source,slotIndex),after=nat.read(result.bytes,slotIndex);assert.ok(result.log.length>=2);
 for(const r of normalized){if(r.type===clone.TYPE)clone.validate(after);else for(const id of inv.PROFILES.find(p=>p.id===r.id).ids)assert.equal(nat.quantity(after,id),1);}
 assert.deepEqual(before.refs,after.refs,'nenhuma referência de outro item copiada');same(before.objectsAndGroups,after.objectsAndGroups,'instâncias de encantamentos ou mundo alterados');assert.deepEqual(before.maps.slice(1),after.maps.slice(1));
 for(const row of before.rows)if(!allowedIds.has(nat.idOf(row)))same(row,nat.unique(after.rows,nat.idOf(row),true),'outro estoque/equipamento foi alterado');
 for(const row of before.finals)if(!allowedIds.has(nat.idOf(row)))same(row,nat.unique(after.finals,nat.idOf(row),true));
 assert.deepEqual(before.maps[0].entries.filter(r=>!allowedKeys.has(nat.view(r).getUint32(0,true))),after.maps[0].entries.filter(r=>!allowedKeys.has(nat.view(r).getUint32(0,true))));
 for(const slot of core.parse(scenario.source).slots)if(slot.index!==slotIndex)same(scenario.source.subarray(slot.base,slot.end),result.bytes.subarray(slot.base,slot.end));
 same(scenario.source.subarray(0,before.slot.base+0x124),result.bytes.subarray(0,before.slot.base+0x124));same(scenario.source.subarray(before.slot.base+0x128,before.slot.base+0x10400),result.bytes.subarray(before.slot.base+0x128,before.slot.base+0x10400));same(scenario.source.subarray(after.state.activeEnd),result.bytes.subarray(after.state.activeEnd));
 same(plan.patch(result.bytes,scenario.requests).bytes,result.bytes,'repetir a operação deve preservar o arquivo');assert.equal(result.layout.length,1,'um rebuild por slot');
 const folder=path.join(outputDir,scenario.name);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(folder+'/game.sav',result.bytes);
 cases.push({name:scenario.name,slot:slotIndex+1,source:scenario.sourceName,sourceSha256:hash(scenario.source),sha256:hash(result.bytes),requests:normalized,items:result.log.map(r=>r.name),allowedIds:[...allowedIds],allowedKeys:[...allowedKeys],activeSize:after.state.activeSize,rows:after.rows.length,objects:after.state.objects.length,refs:after.refs.length,inGameTestedHere:false});
}
// Mesma clonagem de Zeus já confirmada; só o mapa do novo pomo muda.
const newCombined=plan.patch(base,[request(clone.BASE_IDS[0]),request(pommel)]),newState=nat.read(newCombined.bytes,index);assert.equal(newState.state.activeSize,a.state.activeSize+8);assert.deepEqual(newState.rows,a.rows);assert.deepEqual(newState.finals,a.finals);assert.deepEqual(newState.refs,a.refs);same(newState.objectsAndGroups,a.objectsAndGroups);
const expectedMap=a.maps[0].entries.map(r=>r.slice()),txCopy={...a,maps:[{...a.maps[0],entries:expectedMap},...a.maps.slice(1)]};nat.addGlobal(txCopy,966,2);assert.deepEqual(newState.maps,txCopy.maps);
same(plan.patch(base,[{slot:index,type:clone.TYPE,id:clone.ID,level:9,allowExperimental:true}]).bytes,oldPlan.patch(base,[{slot:index,type:clone.TYPE,id:clone.ID,level:9,allowExperimental:true}]).bytes);
let preservedMapped=0,preservedGuards=0;for(const mapped of oldInv.MAPPED_PROFILES){const r=request(mapped.id);let old,error;try{old=oldPlan.patch(base,[r]);}catch(e){error=e.message;}
 if(error){assert.throws(()=>plan.patch(base,[r]),e=>e.message===error);preservedGuards++;}else{same(plan.patch(base,[r]).bytes,old.bytes,'perfil mapeado anterior alterado');preservedMapped++;}}
// Lote total e por variante: nenhum item possuído é rebaixado e IDs são únicos.
const eligible=baseState.profiles.filter(p=>p.available).map(p=>p.id),bulk=select.buildMissing(baseState,eligible,'template-max',true).map(r=>({...r,slot:index}));
const batch=plan.patch(base,bulk),batchState=nat.read(batch.bytes,index);assert.equal(batch.layout.length,1);same(batchState.objectsAndGroups,nat.read(base,index).objectsAndGroups);assert.deepEqual(batchState.maps.slice(1),nat.read(base,index).maps.slice(1));same(plan.patch(batch.bytes,bulk).bytes,batch.bytes);
for(const r of inv.normalizeRequests(bulk)){if(r.type===clone.TYPE)clone.validate(batchState);else{const p=inv.PROFILES.find(p=>p.id===r.id);for(const id of p.ids.slice(0,r.stage+1))assert.equal(nat.quantity(batchState,id),p.mode==='quantity'?r.stage+1:1);}}
const fullState=inv.inspect(batch.bytes,index);for(const set of select.SETS)if(set.parts.every(p=>fullState.profiles.find(s=>s.id===p.id)?.available))assert.equal(select.buildSet(fullState,set.id,'template-max',true).length,0);
for(const v of ['normal','NG+'])assert.ok(select.filterProfiles({variant:v}).every(p=>p.variant===v));
assert.throws(()=>select.buildSet(baseState,brokPlus.id,'template-max',false),/experimental/);assert.throws(()=>select.buildSet(baseState,'bad','template-max',true));assert.throws(()=>select.buildMissing(baseState,[pommel,pommel],'template-max',true));assert.throws(()=>select.filterProfiles({variant:'NG'}));
const qty=[{slot:index,id:'9E5240D27406E85A',quantity:1000000}];same(plan.patch(base,qty).bytes,oldPlan.patch(base,qty).bytes);
const multiple=plan.patch(base,[request(pommel),{...request(ymir),slot:0}]);for(const slot of core.parse(base).slots)if(![0,index].includes(slot.index))same(base.subarray(slot.base,slot.end),multiple.bytes.subarray(slot.base,slot.end));assert.equal(hash(base),initialHash);
const manifest={version:core.VERSION,cases};fs.writeFileSync(outputDir+'/manifest.json',JSON.stringify(manifest,null,2)+'\n');
const report={version:core.VERSION,newAttachmentsParsed:true,returnedNativeRowsAndUpgradeFinalsPreserved:true,retributionKey966ObservedInBothFiles:true,reapplyingMappedPommelToGameResaveIsNoOp:true,
 armorSets:select.SETS.length,normalSets:32,ngpSets:15,allSetsHaveThreeMatchingParts:true,profiles:inv.PROFILES.length,mappedProfiles:inv.MAPPED_PROFILES.length,nativeTemplates:records.models.length,metadataVariantAndCategoryMismatchBlocked:true,
 previousMappedOutputsByteIdentical:preservedMapped,previousMappedGuardsUnchanged:preservedGuards,previousZeusCloneByteIdentical:true,newRetributionOnlyAddsObservedGlobalRow:true,quantityPathByteIdentical:true,
 bulkAvailableProfiles:eligible.length,bulkMissingRequests:bulk.length,batchRebuildOnce:true,noExpansionOfBladesHandles:true,resourcesWorldReferencesEnchantmentObjectsAnd19SlotsPreserved:true,repeatedAdditionIsNoOp:true,
 cases:cases.map(({requests,allowedIds,allowedKeys,...c})=>c),inGameTestedHere:false,allFamiliesGameStabilityProven:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ESCALONAMENTO_0_13_0.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
