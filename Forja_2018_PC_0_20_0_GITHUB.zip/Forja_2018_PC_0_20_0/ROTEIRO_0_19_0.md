# Forja 2018 PC 0.19.0 — roteiro de uso e teste

## Começar com uma cópia

1. Feche o jogo e guarde seu `game.sav` original em outra pasta.
2. Abra `Forja_2018_PC_0_19_0.html` no navegador.
3. Escolha o arquivo completo. Em **Gerenciar saves**, selecione o salvamento pelo **título e pela data**. O número interno do slot não corresponde à posição na lista do jogo.
4. As alterações ficam numa cópia em memória. Antes de baixar, confira **Alterações**; use **Desfazer** ou **Desfazer tudo** quando necessário.

## Teste 1 — encantamentos comuns do NG normal

1. Entre em **Encantamentos**.
2. Em **Catálogo**, escolha **NG normal**. Em **Tipo**, escolha **Comuns**.
3. Busque um atributo, por exemplo **recarga**, ou deixe a busca vazia.
4. Escolha um encantamento ausente. Leia o nível, os atributos do modelo e a indicação de novo modelo.
5. Clique em **Preparar encantamento** e confira uma linha na revisão.
6. Baixe a cópia, substitua o arquivo de jogo após fechar o jogo e carregue o mesmo salvamento pelo título/data.
7. Encontre o encantamento no inventário e equipe em uma armadura com encaixe disponível. Abra e feche o inventário, jogue um pouco, salve manualmente e recarregue. Confira se o item continua presente.

**Esperado:** uma instância nova, solta, com o nível/efeitos do modelo. Encantamentos que já existiam mantêm os próprios valores; a criação não normaliza seus atributos aleatórios.

## Teste 2 — inclusão em lote

1. Reabra uma cópia do original para comparar os resultados.
2. Em **Encantamentos**, selecione **NG normal → Comuns** e mantenha a busca vazia.
3. Confira a prévia: quantos estão ausentes e disponíveis, quantos já existem e quantos estão indisponíveis.
4. Clique em **Preparar ausentes do filtro**. Cada inclusão efetiva deve aparecer em uma linha de **Alterações**. Os já possuídos são preservados.
5. Faça o mesmo ciclo de carregar, equipar alguns, fechar o inventário, salvar e recarregar.
6. Depois, teste **NG normal → Únicos**. Por fim, teste comuns e únicos juntos. Essa sequência ajuda a localizar uma falha se ocorrer.

O catálogo tem **107 perfis**, dos quais **92 são do NG normal**. Os **90 modelos recém acrescentados** foram extraídos de saves nativos e verificados estruturalmente; a inclusão de cada um pelo editor ainda precisa da confirmação no jogo. Modelos sem nome confirmado são descritos pelos atributos. “Modelo 1/2” distingue perfis observados que têm a mesma descrição visível.

Uma unidade por perfil ausente é adicionada. O botão em lote não cria cópias extras de únicos nem substitui instâncias existentes. Um modelo incompatível ou uma posse incoerente permanece fora do lote; a prévia mostra o total indisponível e a seleção individual explica o motivo.

## Teste 3 — marcas perfeitas e materiais

1. Escolha **NG+ → Únicos** para ver as cinco marcas perfeitas.
2. Mesmo possuindo peças ou materiais para a fabricação, o botão de inclusão pode ser usado se a marca estiver ausente e seus registros forem coerentes.
3. A mensagem informa que é **PREFERÍVEL fazer a conversão pelo jogo**. É uma recomendação; não é um bloqueio.
4. Se escolher o editor, adicione uma marca ou as ausentes do filtro. A inclusão preserva equipamentos, materiais e Hacksilver. O editor não executa a troca da loja nem consome os ingredientes.
5. No jogo, confira separadamente a marca, as peças preservadas e seus efeitos. Equipe a marca, feche o inventário, salve e recarregue.

A **Marca Perfeita de Týr + junto com seu conjunto completo** já foi confirmada pelo José no jogo, inclusive equipada no peitoral. Essa evidência não garante todas as marcas e combinações possíveis.

## Teste 4 — armas no NG+

1. Abra o save original usado no ensaio de NG+ e selecione o salvamento correto.
2. Em **Níveis**, escolha Machado **6** e Lâminas **5**, preparando cada ajuste.
3. Confira as duas linhas na revisão. Exporte e repita o ciclo de carregar, verificar, salvar e recarregar.

A implementação produz os mesmos bytes do ensaio que funcionou. O retorno nativo confirmou os dois mapas e as melhorias. O caso aprovado tinha **Machado 2 → 6 e Lâminas 1 → 5**. O Machado NG+ originalmente no nível 1 ainda não foi validado; armas precisam estar liberadas. A regra do primeiro upgrade no NG normal continua protegida quando o registro secundário está ausente. Essa função não ativa o menu NG+.

## Conferir as funções anteriores

Em uma cópia separada, altere um recurso conhecido para um valor fácil de conferir, adicione uma peça de armadura, um pomo/cabo e um rúnico que não possua. Revise antes de exportar. As rotinas e os modelos já validados foram preservados.

Para remoção, desequipe a peça e retire encantamentos únicos pelo jogo antes de salvar. Os formatos comuns reconhecidos podem ser devolvidos ao inventário pela rotina da 0.18.0. A inclusão nova não amplia automaticamente os formatos de remoção.

## Se houver falha

Guarde o arquivo original, o editado e o **relatório de alterações**. Informe o item ou filtro usado e o momento exato: carregar o save, abrir a categoria, equipar, fechar o inventário ou recarregar após salvar. Não continue acumulando alterações sobre um arquivo que já falhou. Isso permite repetir exatamente o caso.
