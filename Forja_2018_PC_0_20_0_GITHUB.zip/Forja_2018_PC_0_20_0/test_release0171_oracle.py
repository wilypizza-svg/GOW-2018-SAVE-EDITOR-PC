"""Confere a correção e os testes externos com um leitor Python independente."""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys

root=Path(__file__).resolve().parent
ws=Path(sys.argv[1]).resolve()
reader=root/'test_clone_native_reader.py'
node=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[node],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']
tal=json.loads((ws/'analysis_0_17_1/testes/talismas_manifest.json').read_text())
normal=json.loads((ws/'analysis_0_17_1/normal_tests/manifest.json').read_text())
cases=[dict(name='Lote de talismãs válidos',source=tal['source'],slot=tal['slot'],output=tal['output'],sha256=tal['sha256'],items=[dict(p,stage=next(r['stage'] for r in tal['requests'] if r['id']==p['id'])) for p in tal['profiles']])]
cases += [dict(c,source=normal['source'],slot=normal['slot']) for c in normal['cases']]

def split(raw,n):
    assert len(raw)%n==0
    return [raw[i:i+n] for i in range(0,len(raw),n)]

def mapping(raw,index):
    prefix=8 if index==1 else 0;stride=8 if index==0 else 9
    count=struct.unpack_from('<I',raw,2+prefix)[0]
    return {struct.unpack_from('<I',raw,6+prefix+i*stride)[0]:raw[6+prefix+i*stride:6+prefix+(i+1)*stride] for i in range(count)}

checked=[]
for c in cases:
    before=Path(c['source']).read_bytes();after=Path(c['output']).read_bytes()
    assert hashlib.sha256(after).hexdigest()==c['sha256']
    if c.get('control'):
        assert before==after
        checked.append({'name':c['name'],'passed':True,'control':True});continue
    ns['SLOT_INDEX']=c['slot'];a,b=parse(before),parse(after)
    allowed={id for p in c['items'] for id in p['ids'][:p['stage']+1]}
    refs={id for p in c['items'] for id in p.get('referenceIds',[])}
    keys={p['key'] for p in c['items'] if isinstance(p.get('key'),int)}
    aa={r[:8].hex().upper():r for r in a['rows']};bb={r[:8].hex().upper():r for r in b['rows']}
    assert set(aa)<=set(bb) and set(bb)-set(aa)<=allowed
    for id,row in aa.items():
        if id not in allowed:assert bb[id]==row
    for id in allowed:assert struct.unpack_from('<I',bb[id],8)[0]>0
    assert a['objects']==b['objects']
    assert [r for r in split(a['refs'],8) if r.hex().upper() not in refs]==[r for r in split(b['refs'],8) if r.hex().upper() not in refs]
    for i in range(3):
        amap,bmap=mapping(a['frames'][i],i),mapping(b['frames'][i],i)
        for key,row in amap.items():
            if key not in keys:assert bmap[key]==row
        assert set(amap)<=set(bmap) and set(bmap)-set(amap)<=keys
        if i==1:assert a['frames'][i][2:10]==b['frames'][i][2:10]
    managed=allowed|refs
    old=[r for r in split(a['finals'][4:],16) if r[:8].hex().upper() not in managed]
    new=[r for r in split(b['finals'][4:],16) if r[:8].hex().upper() not in managed]
    assert new==(old[-len(new):] if new else []) and len(b['finals'][4:])//16<=512
    prefix=bytearray(before[:a['start']]);p=a['base']+0x124;prefix[p:p+4]=after[p:p+4]
    assert prefix==after[:b['start']]
    assert before[max(a['end'],b['end']):]==after[max(a['end'],b['end']):]
    for slot in range(20):
        if slot!=c['slot']:
            p=4160+slot*1677512;assert before[p:p+1677512]==after[p:p+1677512]
    for id in ['B1DFE124C69AF353','82D3E124C69AF353']:assert id not in bb
    checked.append({'name':c['name'],'passed':True,'requests':len(c['items'])})
for saved in json.loads((ws/'analysis_0_17_1/baseline.json').read_text()):
    assert hashlib.sha256(Path(saved['path']).read_bytes()).hexdigest()==saved['sha256']
report={'version':'0.17.1','independentLanguage':'Python','passed':True,'cases':checked,'unrequestedPersistentRecordsAndObjectsAndBindingsPreserved':True,'worldAndOther19SlotsPreserved':True,'bothExcludedIdsAbsentFromAllOutputs':True,'queueWithin512AndUnrelatedRemainderPreserved':True,'original0170Unchanged':True,'armorGameTestsPending':True}
(root/'VERIFICACAO_INDEPENDENTE_0_17_1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
