'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const core = require('./src/core'), resources = require('./src/resource-edit'), levels = require('./src/levels'), writer = require('./src/plan');
const [beforeFile, afterFile, normalFile, legacyFile, outputPath] = process.argv.slice(2);
assert.ok(beforeFile && afterFile && normalFile && legacyFile && outputPath);
const before = fs.readFileSync(beforeFile), actual = fs.readFileSync(afterFile), copy = Buffer.from(before), slot = 11;
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes');
const request = { slot, id: levels.ID, type: 'axe-level', level: 6 };
const old = levels.inspect(before, slot), native = levels.inspect(actual, slot);
assert.equal(old.level, 5); assert.equal(old.canUpgrade, true); assert.equal(native.level, 6);
const result = writer.patch(before, [request]), next = levels.inspect(result.bytes, slot, result.model);
assert.equal(next.level, 6); assert.equal(result.log.length, 1); assert.equal(result.layout[0].addedBytes, 24);
const canonical = rows => rows.map(row => [row.key, row.value]).sort((a, b) => a[0] - b[0]);
assert.deepEqual(canonical(next.globalMap), canonical(native.globalMap)); assert.deepEqual(canonical(next.storedMap), canonical(native.storedMap));
for (const i of [0, 3]) same(result.bytes.subarray(next.state.frames[i].start, next.state.frames[i].end), actual.subarray(native.state.frames[i].start, native.state.frames[i].end));
const refs = (bytes, state) => bytes.subarray(state.slot.table.end, state.state.objectStart);
same(refs(result.bytes, next), refs(actual, native));
const quantities = state => state.slot.rows.map(row => [row.id, row.quantity]).sort((a, b) => a[0].localeCompare(b[0]));
// A compra real consome uma chama; edição direta mantém os recursos.
const nativeStock = new Map(quantities(native)); nativeStock.set('EDB4476E71735CC3', 4);
assert.deepEqual(quantities(next), [...nativeStock].sort((a, b) => a[0].localeCompare(b[0])));
for (const row of old.slot.rows) {
  const unchanged = next.slot.rows.find(entry => entry.id === row.id);
  assert.equal(unchanged.quantity, row.quantity); assert.equal(unchanged.auxiliary, row.auxiliary);
}
same(before.subarray(0, old.slot.base), result.bytes.subarray(0, old.slot.base));
same(before.subarray(old.slot.end), result.bytes.subarray(old.slot.end));
same(before.subarray(next.state.activeEnd, old.slot.end), result.bytes.subarray(next.state.activeEnd, old.slot.end));
same(writer.patch(result.bytes, [request]).bytes, result.bytes); same(writer.patch(before, []).bytes, before);
const mixed = writer.patch(before, [request, { slot, id: 'CC1B3E5C878842B3', quantity: 222 }, { slot, id: 'EDB4476E71735CC3', quantity: 3 }]);
assert.equal(levels.inspect(mixed.bytes, slot).level, 6);
assert.equal(mixed.model.slots[slot].rows.find(row => row.id === 'CC1B3E5C878842B3').quantity, 222);
assert.equal(mixed.model.slots[slot].rows.find(row => row.id === 'EDB4476E71735CC3').quantity, 3);
assert.equal(mixed.log.length, 3);
const two = writer.patch(before, [request, { ...request, slot: 2 }]); assert.equal(two.log.length, 2);
assert.equal(levels.inspect(two.bytes, 2).level, 6); assert.equal(levels.inspect(two.bytes, slot).level, 6);
for (const bad of [null, { ...request, level: 7 }, { ...request, level: 5 }, { ...request, level: '6' }, { ...request, slot: 12 }, { ...request, id: 'bad' }]) assert.throws(() => writer.patch(before, [bad]));
assert.throws(() => writer.patch(before, [request, request]), /duas melhorias/);
assert.throws(() => levels.patch(before, {}), /Plano/);
const normal = fs.readFileSync(normalFile); assert.equal(levels.inspect(normal, 0).level, 4); assert.throws(() => writer.patch(normal, [{ ...request, slot: 0 }]), /somente/);
const broken = Buffer.from(before); broken.writeUInt32LE(3, old.propertyOffset); assert.equal(levels.inspect(broken, slot).available, false); assert.throws(() => writer.patch(broken, [request]), /persistido/);
const padded = Buffer.concat([Buffer.alloc(13), before, Buffer.alloc(17)]); same(writer.patch(padded.subarray(13, 13 + before.length), [request]).bytes, result.bytes);
const legacy = fs.readFileSync(legacyFile), resourceOnly = [{ slot: 0, id: 'CC1B3E5C878842B3', quantity: 10 }, { slot: 0, id: core.FIELDS[1].id, quantity: 12345 }];
same(writer.patch(legacy, resourceOnly).bytes, resources.patch(legacy, resourceOnly).bytes);
same(before, copy); same(fs.readFileSync(beforeFile), copy); fs.writeFileSync(outputPath, result.bytes);
const report = { version: core.VERSION, naturalPairTransition: '5 -> 6', changedPhysicalSlot: 12,
  threeLevelFieldsSynchronized: true, nativeGlobalMapAndFinalFrameMatchedExactly: true,
  nativeReferenceArrayAndCanonicalStoredMapMatched: true, allOldQuantitiesAndAuxiliariesPreserved: true,
  nativeTier6MarkersReproduced: true, directEditPreservesFrozenFlames: true, netGrowth24BytesVerified: true,
  isolatedSlotAndUnusedTailPreserved: true, resourcesAndLevelCanBeCombined: true, otherTransitionsBlocked: true,
  oldResourceOnlyExportsUnchanged: true, inputsUnchanged: true, inGameTestedHere: false };
fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_NIVEIS_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
