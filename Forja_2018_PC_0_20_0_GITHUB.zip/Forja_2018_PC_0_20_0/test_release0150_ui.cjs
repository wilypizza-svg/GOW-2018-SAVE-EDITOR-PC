/* Executa o HTML realmente gerado em DOM simulado. Não é teste visual. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,$,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),ciphers=require('./src/ciphers');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),load=p=>new Uint8Array(fs.readFileSync(path.join(ws,p))),ok=()=>assert.equal($('error').hidden,true,$('error').textContent);
const change=async(id,value)=>{$(id).value=value;await $(id).fire('change');},same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async()=>{
 const ngp=load('upload/game(10).sav'),gi=core.parse(ngp).latestSlot;
 api.loadBytes(ngp,'game.sav');api.selectSlot(gi);api.chooseView('levels');
 assert.equal($('level-original').textContent,'Nível 6');assert.equal($('blades-level-original').textContent,'Nível 5');
 assert.match($('level-range').textContent,/NG\+/);await change('level-target','5');assert.equal($('level-apply').disabled,false);
 await $('level-apply').click();ok();const downgraded=api.exportBytes();assert.equal(downgraded.log[0].synchronizedLevelFields,2);
 assert.equal($('level-edited').textContent,'Nível 5');assert.equal($('blades-level-edited').textContent,'Nível 5');
 await $('reset-changes').click();ok();assert.equal($('level-edited').textContent,'Nível 6');assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 const normal=load('upload/game(9).sav'),ni=core.parse(normal).latestSlot;
 api.loadBytes(normal,'game.sav');api.selectSlot(ni);api.chooseView('equipment');
 await change('inventory-kind','axe-runics-all');await change('inventory-variant','NG+');
 assert.equal($('inventory-item').children.filter(x=>x.tagName==='option').length,16);
 await change('inventory-item','1F03AB1C949A4EC1');assert.equal($('inventory-stage').value,'2');assert.equal($('inventory-apply').disabled,true);
 assert.equal($('inventory-stage').children[0].disabled,true);assert.equal($('inventory-stage').children[1].disabled,true);
 $('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');assert.equal($('inventory-apply').disabled,false);
 await $('inventory-apply').click();ok();assert.equal(nat.quantity(nat.read(api.exportBytes().bytes,ni),'1F03AB1C949A4EC1'),3);
 assert.equal($('inventory-apply').disabled,true);assert.match($('inventory-note').textContent,/já existe/);
 await change('inventory-kind','blades-runics-all');assert.equal($('inventory-item').children.filter(x=>x.tagName==='option').length,15);
 await change('inventory-item','26B0F5C05C9255C2');assert.equal($('inventory-apply').disabled,true);assert.match($('inventory-note').textContent,/nível 1/);
 // Os dois lotes incluem somente os ausentes, inclusive no filtro NG+.
 await change('inventory-kind','axe-runics-all');await change('inventory-bulk-mode','template-max');await $('inventory-bulk').click();ok();
 await change('inventory-kind','blades-runics-all');await $('inventory-bulk').click();ok();
 const expanded=api.exportBytes(),before=nat.read(normal,ni),after=nat.read(expanded.bytes,ni);
 for(const p of inv.PROFILES.filter(p=>p.kind.includes('runic')))assert.equal(nat.quantity(after,p.id),nat.quantity(before,p.id)??3);
 await $('export-top').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),expanded.bytes);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.15.0');
 await $('reset-changes').click();ok();await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),normal);
 // Cifras: controles separados para os dois reinos e nova inclusão no NG+.
 api.loadBytes(ngp,'game.sav');api.selectSlot(gi);api.chooseView('campaign');
 assert.equal($('niflheim-cipher-total').value,'0');assert.equal($('muspelheim-cipher-total').value,'3');
 $('niflheim-cipher-total').value='';await $('niflheim-cipher-apply').click();assert.equal($('error').hidden,false);assert.equal(api.getState().changes.length,0);
 $('niflheim-cipher-total').value='4';await $('niflheim-cipher-apply').click();ok();
 $('muspelheim-cipher-total').value='4';await $('muspelheim-cipher-apply').click();ok();
 const completed=api.exportBytes();assert.equal(completed.log.length,2);
 for(const p of ciphers.PROFILES){const s=ciphers.inspect(completed.bytes,gi,p.id);assert.equal(s.total,4);assert.equal(s.complete,true);}
 assert.equal($('niflheim-cipher-apply').disabled,true);assert.equal($('muspelheim-cipher-apply').disabled,true);
 assert.ok(nat.read(completed.bytes,gi).finals.length<=512);
 // Os cabos seguem disponíveis sem optar pelas novas inclusões experimentais.
 const control=load('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav');api.loadBytes(control,'game.sav');api.selectSlot(14);api.chooseView('equipment');
 await change('inventory-kind','blades');await change('inventory-variant','NG+');await change('inventory-bulk-mode','mapped-max');assert.equal($('inventory-bulk').disabled,false);
 await $('inventory-bulk').click();ok();same(api.exportBytes().bytes,load('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav'));
 const result={version:core.VERSION,executedBuiltHtmlInSimulatedDom:true,ngpLevelLabelsAndDraftPassed:true,sharedRunicFilters16And15:true,newRunicsRequireExperimentalOption:true,newRunicsFixedAt3AndOwnedPreserved:true,twoRunicBatchesAndExportPassed:true,downloadReportResetAndOriginalPassed:true,bothRealmCipherControlsPassed:true,cipherCompletionAndQueueLimitPassed:true,fiveHandleUiExportByteIdenticalToApprovedFile:true,actualBrowserVisualTest:false,newFeaturesRunInGameHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_15_0.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
