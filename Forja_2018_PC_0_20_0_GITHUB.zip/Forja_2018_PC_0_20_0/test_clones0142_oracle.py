"""Compara as variantes com os testes falhos usando um leitor Python independente."""
from pathlib import Path
import ast,json,struct,sys
root=Path(__file__).parent
out=Path(sys.argv[1]);uploads=Path(sys.argv[2])
reader=root/'test_clone_native_reader.py'
definition=next(node for node in ast.parse(reader.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=14)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse'];results=[]
for folder,failed,removed in [
 ('17_Cursed_Clonagem_Sem_Aquisicao','game(Crashou).sav',['B19A13C4B34FA37F','C9DCC879F5174FCF']),
 ('18_Bestla_Clonagem_Local_Sem_Aviso','game(CrashouAoInventariofechar).sav',['FC00000000000000'])]:
 old_bytes=(uploads/failed).read_bytes();new_bytes=(out/folder/'game.sav').read_bytes();old=parse(old_bytes);new=parse(new_bytes)
 for field in ['rows','refs','objects','frames']:assert old[field]==new[field],(folder,field)
 old_final=[old['finals'][p:p+16] for p in range(4,len(old['finals']),16)]
 new_final=[new['finals'][p:p+16] for p in range(4,len(new['finals']),16)]
 removed_bytes={bytes.fromhex(value) for value in removed}
 assert new_final==[row for row in old_final if row[:8] not in removed_bytes]
 assert len(old_final)-len(new_final)==len(removed)
 assert old['end']-new['end']==len(removed)*16
 old_header=bytearray(old_bytes[:old['start']]);old_header[old['base']+0x124:old['base']+0x128]=new_bytes[new['base']+0x124:new['base']+0x128]
 assert bytes(old_header)==new_bytes[:new['start']]
 for index in range(20):
  if index==14:continue
  a=4160+index*1677512;b=a+1677512;assert old_bytes[a:b]==new_bytes[a:b]
 results.append({'test':folder,'inventoryRowsReferencesObjectsAndMapsIdenticalToFailedFile':True,'onlyRemovedFinalIds':removed,'worldAndOtherSlotsUnchanged':True})
report={'version':'0.14.2','independentPythonReader':True,'cases':results,'inGameFixConfirmed':False}
(root/'VERIFICACAO_INDEPENDENTE_0_14_2.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
