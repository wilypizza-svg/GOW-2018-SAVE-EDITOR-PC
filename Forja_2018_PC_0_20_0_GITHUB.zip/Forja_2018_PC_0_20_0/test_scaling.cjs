'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const inv=require('./src/inventory'),plan=require('./src/plan'),nat=require('./src/native-records'),core=require('./src/core'),policy=require('./src/resource-policy');
const [fixturesFile,outPath,oldRoot]=process.argv.slice(2),fixtures=JSON.parse(fs.readFileSync(fixturesFile)),out=path.resolve(outPath);fs.mkdirSync(out,{recursive:true});
const read=s=>new Uint8Array(fs.readFileSync(s.path)),same=(a,b,msg)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),msg),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const source=fixtures.find(s=>s.file==='game(AntesDeComprarUmPeitoral).sav'),a=read(source),index=source.index,at=nat.read(a,index),state=inv.inspect(a,index);
assert.equal(inv.PROFILES.length,223);assert.equal(inv.MAPPED_PROFILES.length,20);
assert.equal(inv.PROFILES.filter(p=>p.kind==='chest'||p.kind==='wrist'||p.kind==='waist').length,141);
assert.equal(inv.PROFILES.filter(p=>p.kind==='axe').length,34);assert.equal(inv.PROFILES.filter(p=>p.kind==='talisman').length,43);
assert.equal(inv.PROFILES.filter(p=>p.experimentalTemplate&&p.kind==='blades').length,0);
const eligible=state.profiles.filter(p=>p.experimentalTemplate&&p.available&&!p.owned);assert.ok(eligible.length>150);
const requests=eligible.map(p=>({slot:index,id:p.id,type:'inventory-equipment',stage:0,allowExperimental:true}));
const batch=plan.patch(a,requests),bt=nat.read(batch.bytes,index);
assert.equal(batch.layout.length,1);assert.equal(batch.layout[0].operations,requests.length);
assert.equal(batch.log.length,requests.length);for(const r of requests)assert.equal(nat.quantity(bt,r.id),1);
same(at.objectsAndGroups,bt.objectsAndGroups,'all old objects and groups');assert.deepEqual(at.maps,bt.maps,'level maps are never guessed');assert.deepEqual(at.refs,bt.refs,'references never guessed');
for(const row of at.rows)same(row,nat.unique(bt.rows,nat.idOf(row),true),'old row');for(const row of at.finals)same(row,nat.unique(bt.finals,nat.idOf(row),true),'old final');
same(a.subarray(0,at.slot.base+0x124),batch.bytes.subarray(0,at.slot.base+0x124));same(a.subarray(at.slot.base+0x128,at.slot.base+0x10400),batch.bytes.subarray(at.slot.base+0x128,at.slot.base+0x10400));same(a.subarray(bt.state.activeEnd),batch.bytes.subarray(bt.state.activeEnd));
for(const p of eligible){for(const id of p.familyIds.slice(1))assert.equal(nat.quantity(bt,id),nat.quantity(at,id),'no unknown reinforcement flags');}
assert.throws(()=>plan.patch(a,[{...requests[0],allowExperimental:false}]),/experimental/);assert.throws(()=>plan.patch(a,[{...requests[0],stage:99}]),/níveis/);
same(plan.patch(a,[]).bytes,a);same(plan.patch(a,requests).bytes,batch.bytes,'deterministic batch');
const allUpgrades=eligible.map(p=>({slot:index,id:p.id,type:'inventory-equipment',stage:p.stages.length-1,allowExperimental:true})),upgraded=plan.patch(a,allUpgrades),ut=nat.read(upgraded.bytes,index);
assert.deepEqual(ut.maps,at.maps,'unmapped indices remain untouched even at last template stage');
assert.deepEqual(ut.refs,at.refs);
for(const p of eligible)for(const id of p.ids)assert.equal(nat.quantity(ut,id),1,'own IDs in every template step');
for(const name of ['Cuirass of Zeus','Cuirass of Ares']){const p=inv.PROFILES.find(p=>p.name===name);assert.deepEqual(p.stages.map(s=>s.label),['8','8+','9']);assert.equal(p.prototypeId,'3225AAC6C42CC83D');assert.ok(!p.ids.some(id=>inv.MAPPED_PROFILES[6].ids.includes(id)));}
for(const p of inv.PROFILES.filter(p=>p.prototypeLabels?.[0]==='7'&&p.ids.length===3))assert.deepEqual(p.stages.map(s=>s.label),['7','8','9']);
const donor=fixtures.find(s=>s.file==='game(DepoisDeComprarUmEncatamentoComum).sav'),db=read(donor),choices=inv.duplicateChoices(db,donor.index);assert.ok(choices.available);
const model=choices.choices.find(o=>o.sampleName==='Symbol of Menace');assert.ok(model);
const duplicate={slot:index,id:inv.duplicateId(donor.index,model.uid,model.raw),type:'enchantment-duplicate',sourceBuild:model.sourceBuild,sourceSlot:donor.index,templateUid:model.uid,templateBytes:model.raw,sourceName:model.name,sourceFilename:donor.file,count:3,allowExperimental:true};
const copies=plan.patch(a,[duplicate]),ct=nat.read(copies.bytes,index),log=copies.log[0];assert.equal(log.uids.length,3);
assert.equal(ct.state.objects.length,at.state.objects.length+3);assert.deepEqual(at.rows,ct.rows);assert.deepEqual(at.refs,ct.refs);assert.deepEqual(at.maps,ct.maps);
for(let k=0;k<at.state.objects.length;k++){const p=at.state.objects[k],q=ct.state.objects[k];same(a.subarray(p.start,p.end),copies.bytes.subarray(q.start,q.end));}
for(const uid of log.uids){assert.ok(!at.state.objects.some(o=>o.uid===uid));const o=ct.state.objects.find(o=>o.uid===uid),b=copies.bytes.subarray(o.start,o.end),v=nat.view(b);same(b.subarray(0,8),model.raw.subarray(0,8));same(b.subarray(16,48),model.raw.subarray(16,48));same(b.subarray(60),model.raw.subarray(60));assert.equal(core.hex(b.subarray(8,16)),'0000000000000000');assert.equal(v.getUint32(52,true),0xffffffff);assert.equal(v.getUint32(56,true),0xffffffff);}
assert.equal(new Set(ct.state.objects.map(o=>o.uid)).size,ct.state.objects.length);
same(db,read(donor),'external donor is read only');same(a.subarray(ct.state.activeEnd),copies.bytes.subarray(ct.state.activeEnd));
for(const bad of [{count:0},{count:11},{allowExperimental:false},{sourceBuild:4397815},{templateUid:999},{id:'wrong'}])assert.throws(()=>plan.patch(a,[{...duplicate,...bad}]));
const badBody=model.raw.slice();nat.view(badBody).setUint32(72,999999,true);assert.throws(()=>plan.patch(a,[{...duplicate,templateBytes:badBody,id:inv.duplicateId(donor.index,model.uid,badBody)}]));
const combinedRequests=[...requests,duplicate,...policy.buildKit(core.parse(a).slots[index],'main',99999)],combined=plan.patch(a,combinedRequests),combo=nat.read(combined.bytes,index);
assert.equal(combo.state.objects.length,at.state.objects.length+3);for(const r of requests)assert.equal(nat.quantity(combo,r.id),1);
const old=require(path.resolve(oldRoot,'src/plan'));
let mappedChecks=0;for(const p of inv.MAPPED_PROFILES){const r={slot:index,id:p.id,type:'inventory-equipment',stage:p.stages.length-1};same(plan.patch(a,[r]).bytes,old.patch(a,[r]).bytes,p.name+' existing mapped output preserved');mappedChecks++;}
const mapped=inv.MAPPED_PROFILES.map(p=>({slot:index,id:p.id,type:'inventory-equipment',stage:p.stages.length-1}));same(plan.patch(a,mapped).bytes,old.patch(a,mapped).bytes,'mapped batch preserves previous bytes');
const offset=Buffer.alloc(a.length+25,55);Buffer.from(a).copy(offset,13);same(plan.patch(offset.subarray(13,a.length+13),[duplicate]).bytes,copies.bytes);
const manifest=[];for(const [name,result,rr]of [['base-batch',batch,requests],['template-last-stage',upgraded,allUpgrades],['enchantment-duplicates',copies,[duplicate]],['combined',combined,combinedRequests]]){const file=path.join(out,name+'.sav');fs.writeFileSync(file,result.bytes);manifest.push({name,source:source.path,index,output:file,sourceSha256:hash(a),outputSha256:hash(result.bytes),requests:rr.map(r=>({...r,...(r.type==='inventory-equipment'?{expectedIds:inv.PROFILES.find(p=>p.id===r.id).ids.slice(0,r.stage+1)}:{}),...(r.templateBytes?{templateHex:core.hex(r.templateBytes),templateBytes:undefined}:{})}))});}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));
const report={version:core.VERSION,catalogOptions:223,armorPieces:141,axePommels:34,talismans:43,previousBladeHandle:1,runicProfiles:4,
 mappedProfiles:20,experimentalTemplateProfiles:203,baseItemsIncludedInTest:requests.length,allTemplateHistoriesBuiltWithOwnIds:true,separateLevel7AndLevel8Templates:true,oneRebuildPerTargetSlot:true,
 existingMappedOutputsByteIdentical:mappedChecks,mappedCombinedOutputByteIdentical:true,noUnknownLevelMapKeysWritten:true,
 oldObjectsGroupsReferencesAndReinforcementsPreserved:true,newEnchantmentsHaveUniqueIdentities:true,donorReadOnly:true,
 malformedModelsAndMissingOptInRejected:true,mixedResourceAndEquipmentBatchPassed:true,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_ESCALA_0_12_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
