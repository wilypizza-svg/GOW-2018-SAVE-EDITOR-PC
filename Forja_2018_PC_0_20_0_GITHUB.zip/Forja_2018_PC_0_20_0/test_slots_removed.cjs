/* Retirada dos escritores de encaixes e regressão das operações preservadas. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const core=require('./src/core'),plan=require('./src/plan'),inv=require('./src/inventory'),ench=require('./src/enchantments'),camp=require('./src/campaign'),nat=require('./src/native-records');
const [manifestPath,previousRoot]=process.argv.slice(2);
assert.ok(manifestPath&&previousRoot,'Informe o manifesto 0.14.0 e a pasta do código 0.14.0.');
const oldPlan=require(path.resolve(previousRoot,'src/plan.js'));
const manifest=JSON.parse(fs.readFileSync(manifestPath)),workspace=path.resolve(path.dirname(manifestPath),'../..');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
assert.equal(ench.patch,undefined);assert.equal(ench.compatible,undefined);assert.equal(camp.attachmentState,undefined);
assert.ok(!camp.TYPES.includes('attach-enchantment'));
assert.ok(!fs.existsSync(path.join(__dirname,'src/enchantment-stats.js')));
const removed=['attach-enchantment','enchantment-copy','enchantment-stat'];
for(const type of removed){
  const bytes=new Uint8Array([1,2,3]),original=bytes.slice();
  assert.throws(()=>plan.patch(bytes,[{type}]),/edição de encaixes foi removida/);
  assert.throws(()=>plan.patch(bytes,[{slot:0,id:'anything',quantity:1},{type}]),/edição de encaixes foi removida/);
  same(bytes,original);
}
const successful=['10_','12_','13_','14_'];
const regressions=[];
for(const test of manifest.cases.filter(c=>successful.some(prefix=>c.name.startsWith(prefix)))){
  const bytes=new Uint8Array(fs.readFileSync(path.resolve(workspace,test.source))),before=sha(bytes);
  const result=plan.patch(bytes,test.requests);
  assert.equal(sha(result.bytes),test.sha256,test.name);assert.equal(sha(bytes),before);
  regressions.push({name:test.name,sha256:test.sha256,byteIdenticalToPrevious:true});
}
const failedCase=manifest.cases.find(c=>c.name.startsWith('11_'));
const source=new Uint8Array(fs.readFileSync(path.resolve(workspace,failedCase.source))),index=core.parse(source).latestSlot;
const originalHash=sha(source);
const suspended=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+'&&p.experimentalTemplate);
assert.equal(suspended.length,4);
for(const profile of suspended){
  const state=inv.inspect(source,index).profiles.find(p=>p.id===profile.id);
  assert.equal(state.available,false);assert.match(state.reason,/Edição suspensa/);
  for(let stage=0;stage<profile.stages.length;stage++){
    const request={slot:index,id:profile.id,type:'inventory-equipment',stage,allowExperimental:true};
    assert.throws(()=>inv.patch(source,[request]),/Edição suspensa/);
    assert.throws(()=>plan.patch(source,[{slot:index,id:inv.MENACE,type:'enchantment-create',count:1},request]),/Edição suspensa/);
    assert.equal(sha(source),originalHash);
  }
}
function checkLooseAndPreserved(result){
  const before=nat.read(source,index),after=nat.read(result.bytes,index);
  for(const old of before.state.objects){
    const current=after.state.objects.find(o=>o.uid===old.uid);assert.ok(current,'Instância original ausente');
    same(source.subarray(old.start,old.end),result.bytes.subarray(current.start,current.end));
  }
  for(const uid of result.log.flatMap(log=>log.uids||[])){
    const row=after.state.objects.find(o=>o.uid===uid);assert.ok(row);
    const raw=result.bytes.subarray(row.start,row.end),view=nat.view(raw);
    assert.equal(core.hex(raw.subarray(8,16)),'0000000000000000');
    assert.equal(view.getUint32(52,true),0xFFFFFFFF);assert.equal(view.getUint32(56,true),0xFFFFFFFF);
  }
  same(source.subarray(0,core.HEADER_SIZE),result.bytes.subarray(0,core.HEADER_SIZE));
  for(const slot of core.parse(source).slots)if(slot.index!==index)same(source.subarray(slot.base,slot.end),result.bytes.subarray(slot.base,slot.end));
  assert.equal(sha(source),originalHash);
}
let creationCases=0;
for(const id of [inv.MENACE,'7DD0A7B4B01F5116'])for(const count of [1,2,10]){
  const requests=[{slot:index,id,type:'enchantment-create',count}],result=plan.patch(source,requests);
  same(result.bytes,oldPlan.patch(source,requests).bytes);checkLooseAndPreserved(result);creationCases++;
}
const choices=inv.duplicateChoices(source,index);assert.ok(choices.available&&choices.choices.length);
const equipped=choices.choices.find(c=>c.sourceArmor);assert.ok(equipped,'É necessário um modelo equipado para este teste.');
let duplicateCases=0;
for(const count of [1,2,10]){
  const requests=[{slot:index,id:inv.duplicateId(index,equipped.uid,equipped.raw),type:'enchantment-duplicate',count,allowExperimental:true,
    templateUid:equipped.uid,sourceSlot:index,templateBytes:equipped.raw,sourceBuild:equipped.sourceBuild}];
  const result=plan.patch(source,requests);same(result.bytes,oldPlan.patch(source,requests).bytes);checkLooseAndPreserved(result);duplicateCases++;
}
const summary={version:'0.14.1',removedWritersAbsent:true,removedRequestTypesRejectedBeforeParsing:true,
  successfulPreparedOutputsPreserved:regressions,looseCreationCases:creationCases,looseDuplicateCases:duplicateCases,
  retainedEnchantmentOutputsByteIdentical:true,equippedSourceAndExistingInstancesPreserved:true,headerAndOtherSlotsPreserved:true,
  suspendedUnmappedNgpHandles:suspended.map(p=>({id:p.id,name:p.name})),suspendedHandleStagesRejected:12,
  handleSerializationChanged:false,test11CrashFixed:false,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_REMOCAO_0_14_1.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
