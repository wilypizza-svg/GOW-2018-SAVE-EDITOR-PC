"""Verifica a melhoria sem importar os módulos ou relatórios JavaScript.
Uso: python3 test_armor_levels_oracle.py antes.sav editado.sav depois_nativo.sav
"""
from pathlib import Path
import json
import struct
import sys

original, edited, native = [Path(p).read_bytes() for p in sys.argv[1:4]]
base, table = 4160 + 11 * 1677512, 4160 + 11 * 1677512 + 66589
BASE_ID = 'EEA7E31201646AAF'
OLD_ID, NEW_ID = '4B9C550D079A0AE1', '5898550D079A0AE1'
OLD_REFS, NEW_REF = ['985E5DF0300D402F', 'E58958B05C01970E'], '212CB488175777C7'

def u32(data, pos):
    return struct.unpack_from('<I', data, pos)[0]

def parse(data):
    count, count8, count4 = struct.unpack_from('<III', data, table - 12)
    end = table + 16 * count
    rows = {data[p:p+8].hex().upper(): (u32(data, p+8), u32(data, p+12), p) for p in range(table, end, 16)}
    assert len(rows) == count
    refs = [data[p:p+8].hex().upper() for p in range(end, end+count8*8, 8)]
    stats_size = u32(data, table-24)
    stats_end = table-20+stats_size
    frames = []
    cursor = stats_end
    for _ in range(3):
        size = struct.unpack_from('<H', data, cursor)[0]
        frames.append((cursor, cursor+2+size))
        cursor += 2+size
    assert data[cursor:cursor+2] == bytes.fromhex('2EFA')
    length = struct.unpack_from('<H', data, cursor+2)[0]
    frames.append((cursor, cursor+4+length))
    assert frames[-1][1] == base+0x10400+u32(data, base+0x124)
    maps = []
    for idx, (a, z) in enumerate(frames[:3]):
        prefix, stride = (8, 9) if idx == 1 else (0, 8) if idx == 0 else (0, 9)
        start = a+2+prefix
        entries = u32(data, start)
        assert start+4+entries*stride == z
        values = {}
        for p in range(start+4, z, stride):
            key, value = struct.unpack_from('<II', data, p)
            assert key not in values
            values[key] = (value, data[p+8] if stride == 9 else None, p+4)
        maps.append(values)
    return dict(count=count, count8=count8, count4=count4, end=end, rows=rows, refs=refs,
                stats_size=stats_size, stats_end=stats_end, frames=frames, maps=maps)

before, out, game = map(parse, [original, edited, native])
assert before['maps'][0][607][0] == before['maps'][1][607][0] == 1
assert out['maps'][0][607][0] == out['maps'][1][607][0] == 2
ref_index = before['refs'].index(OLD_REFS[0])
assert before['refs'][ref_index:ref_index+2] == OLD_REFS
ref_start = before['end']+ref_index*8
record = bytearray(original[before['rows'][OLD_ID][2]:before['rows'][OLD_ID][2]+16])
record[:8] = bytes.fromhex(NEW_ID)
struct.pack_into('<II', record, 8, 1, before['count'])
final_start, old_end = before['frames'][3]
trackers = [original[p:p+16] for p in range(final_start+4, old_end, 16)]
old_flag = next(row for row in trackers if row[:8] == bytes.fromhex(OLD_ID))
old_recipe = next(row for row in trackers if row[:8] == bytes.fromhex(OLD_REFS[0]))
assert old_flag[8:].hex().upper() == '00000000F67F0000'
assert old_recipe[8:].hex().upper() == '01000000F27F0000'
new_trackers = bytes.fromhex(NEW_ID)+old_flag[8:]+bytes.fromhex(NEW_REF)+old_recipe[8:]
expected = bytearray(original)
payload = (record+original[before['end']:ref_start]+bytes.fromhex(NEW_REF)+original[ref_start+16:old_end]+new_trackers)
expected[before['end']:old_end+40] = payload
for pos, value in [(table-24,before['stats_size']+8),(table-12,before['count']+1),(table-8,before['count8']-1),(base+0x124,u32(original,base+0x124)+40)]:
    struct.pack_into('<I',expected,pos,value)
struct.pack_into('<H',expected,final_start+8+2,old_end-final_start-4+32)
for idx in [0,1]:
    struct.pack_into('<I',expected,before['maps'][idx][607][2]+8,2)
assert len(edited) == len(expected) == len(original) == 33554400
assert edited == expected, 'A saída contém diferenças fora da transformação prevista'
assert edited[:base] == original[:base]
assert edited[old_end+40:] == original[old_end+40:]
assert out['refs'] == game['refs']
assert edited[out['frames'][0][0]:out['frames'][0][1]] == native[game['frames'][0][0]:game['frames'][0][1]]
assert edited[out['frames'][3][0]:out['frames'][3][1]] == native[game['frames'][3][0]:game['frames'][3][1]]
for idx in [0,1]:
    assert {k:v[:2] for k,v in out['maps'][idx].items()} == {k:v[:2] for k,v in game['maps'][idx].items()}
assert edited[out['frames'][2][0]:out['frames'][2][1]] == original[before['frames'][2][0]:before['frames'][2][1]]
for id, (qty, aux, _) in before['rows'].items():
    assert out['rows'][id][:2] == (qty,aux)
assert out['rows'][NEW_ID][0] == game['rows'][NEW_ID][0] == 1
assert out['count4'] == before['count4']
assert edited[out['end']+out['count8']*8:out['stats_end']] == original[before['end']+before['count8']*8:before['stats_end']]
report=dict(version='0.9.0',independentPythonOracle=True,wholeFileExpectedByteExact=True,
            nativeLevelMapsReferencesAndFinalMarkersMatch=True,existingQuantitiesAndAuxiliaryValuesPreserved=True,
            attributeObjectsAndUnknownThirdFramePreserved=True,allOtherSlotsHeaderAndUnusedTailPreserved=True,
            nativeShopResourceCostsNotApplied=True,noJavaScriptParserImported=True,inGameTestedHere=False)
Path(__file__).with_name('VERIFICACAO_ARMADURA_INDEPENDENTE_0_9_0.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
