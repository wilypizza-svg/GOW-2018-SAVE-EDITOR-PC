/* Verifica catálogo, par controlado de PC e compatibilidade com a 0.1.0. */
'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const catalog = require('./src/catalog'), core = require('./src/core');
const [beforeFile, afterFile, stableRoot, oldBeforeFile, oldAfterFile] = process.argv.slice(2);
assert.ok(beforeFile && afterFile && stableRoot && oldBeforeFile && oldAfterFile);
const oldCore = require(path.resolve(stableRoot, 'src/core.js'));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes.');
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
assert.equal(catalog.items.length, 1682); assert.equal(new Set(catalog.items.map(item => item.id)).size, 1682);
assert.equal(core.FIELDS.length, 48); assert.equal(catalog.items.filter(item => item.hasCleanName).length, 465);
assert.ok(catalog.items.every(item => /^[0-9A-F]{16}$/.test(item.id)));
const unstable = catalog.lookup('FCC6B87B4C8E41DC'), oblivion = catalog.lookup('04BE0462249E0A4A');
assert.equal(unstable.internalName, 'UnstableOre'); assert.equal(unstable.originalName, 'Unstable Ore'); assert.equal(unstable.editable, true); assert.equal(unstable.controlledPcPair, true);
assert.equal(oblivion.originalName, 'Oblivion Stone'); assert.equal(oblivion.provisional, false);
assert.ok(catalog.matches(unstable.id, 'minério instável') && catalog.matches(unstable.id, 'Unstable Ore') && catalog.matches(unstable.id, unstable.id));
const protectedResources = catalog.items.filter(item => item.category === 'Itens especiais e progresso'); assert.equal(protectedResources.length, 15);
assert.ok(protectedResources.every(item => !core.lookup(item.id)));
assert.equal(catalog.lookup('26FA272A8BF271FA').name, 'Skap Slag'); assert.ok(core.lookup('26FA272A8BF271FA'));
const a = new Uint8Array(fs.readFileSync(beforeFile)), b = new Uint8Array(fs.readFileSync(afterFile));
const ma = core.parse(a), mb = core.parse(b), slot = 18;
const oldValue = ma.slots[slot].rows.find(row => row.id === unstable.id), newValue = mb.slots[slot].rows.find(row => row.id === unstable.id);
assert.equal(oldValue.quantity, 9999999); assert.equal(newValue.quantity, 9999998); assert.equal(oldValue.valueOffset, 30266405); assert.equal(newValue.valueOffset, oldValue.valueOffset);
const quantityChanges = [];
for (const beforeSlot of ma.slots) {
 const afterSlot=mb.slots[beforeSlot.index]; assert.equal(beforeSlot.rows.length, afterSlot.rows.length);
 for(let i=0;i<beforeSlot.rows.length;i++){
  const old=beforeSlot.rows[i],next=afterSlot.rows[i];assert.equal(old.id,next.id);assert.equal(old.auxiliary,next.auxiliary);
  if(old.quantity!==next.quantity)quantityChanges.push({slot:beforeSlot.number,id:old.id,before:old.quantity,after:next.quantity});
 }
}
assert.deepEqual(quantityChanges,[{slot:19,id:unstable.id,before:9999999,after:9999998}]);
const output=core.patch(a,[{slot,id:unstable.id,quantity:9999998}]);
const remaining=[]; for(let i=0;i<b.length;i++)if(output.bytes[i]!==b[i])remaining.push(i);
assert.deepEqual(remaining,[30199376,30199377,30199692,30295667]);
const normalized=output.bytes.slice();for(const offset of remaining)normalized[offset]=b[offset];same(normalized,b);
const reverse=core.patch(b,[{slot,id:unstable.id,quantity:9999999}]).bytes;for(const offset of remaining)reverse[offset]=a[offset];same(reverse,a);
let regressionExports=0;
for(const filename of [beforeFile,afterFile,oldBeforeFile,oldAfterFile]){
 const bytes=new Uint8Array(fs.readFileSync(filename)),beforeHash=sha(bytes),model=core.parse(bytes);
 assert.equal(model.supported,20);same(core.roundTrip(bytes),bytes);
 const plan=[{slot:0,id:'8A9A9B831CF67C9C',quantity:7654321},{slot:0,id:'9E5240D27406E85A',quantity:1234567},{slot:18,id:'04BE0462249E0A4A',quantity:4321}];
 same(core.patch(bytes,plan).bytes,oldCore.patch(bytes,plan).bytes);regressionExports++;
 const present=core.FIELDS.filter(field=>model.slots[18].rows.some(row=>row.id===field.id));assert.equal(present.length,41);
 const blocked=protectedResources.find(item=>model.slots[18].rows.some(row=>row.id===item.id));assert.ok(blocked);assert.throws(()=>core.patch(bytes,[{slot:18,id:blocked.id,quantity:2}]),/consulta/);
 const equipment=catalog.items.find(item=>!item.editable&&item.sourceType==='Armor'&&model.slots[18].rows.some(row=>row.id===item.id));
 if(equipment)assert.throws(()=>core.patch(bytes,[{slot:18,id:equipment.id,quantity:2}]),/consulta/);
 assert.equal(sha(bytes),beforeHash);assert.equal(sha(fs.readFileSync(filename)),beforeHash);
 if(global.gc)global.gc();
}
// Os sete perfis ausentes não são criados; simula-se um registro existente
// para conferir somente a posição dos quatro bytes e a política do catálogo.
const missing=core.FIELDS.filter(field=>!ma.slots[0].rows.some(row=>row.id===field.id));assert.equal(missing.length,7);
const replace=ma.slots[0].rows.find(row=>!core.lookup(row.id));assert.ok(replace);
for(const field of missing){
 assert.throws(()=>core.patch(a,[{slot:0,id:field.id,quantity:5}]),/não existe/);
 const fixture=a.slice();fixture.set(Uint8Array.from(field.id.match(/../g),value=>parseInt(value,16)),replace.offset);
 const before=core.parse(fixture).slots[0].rows.find(row=>row.id===field.id),edited=core.patch(fixture,[{slot:0,id:field.id,quantity:5}]);
 same(fixture.subarray(0,before.valueOffset),edited.bytes.subarray(0,before.valueOffset));same(fixture.subarray(before.valueOffset+4),edited.bytes.subarray(before.valueOffset+4));
 assert.equal(edited.model.slots[0].rows.find(row=>row.id===field.id).quantity,5);
}
function section(source,start,end){return source.slice(source.indexOf(start),source.indexOf(end,source.indexOf(start)));}
const oldSource=fs.readFileSync(path.resolve(stableRoot,'src/core.js'),'utf8'),newSource=fs.readFileSync(path.join(__dirname,'src/core.js'),'utf8');
assert.equal(section(oldSource,'  function text(','  function parse('),section(newSource,'  function text(','  function parse('));
assert.equal(section(oldSource,'  function roundTrip(','  function patch('),section(newSource,'  function roundTrip(','  function patch('));
assert.equal(section(oldSource,'  function patch(','  return Object.freeze'),section(newSource,'  function patch(','  return Object.freeze'));
const report={version:'0.9.0',catalogIds:1682,cleanNamesFromCsv:465,editableProfiles:48,presentEditableResourcesPerSlot:41,
 protectedResourceProfiles:15,quantityChangeMatchesUserReport:quantityChanges[0],controlledPairDifferentBytes:5,
 otherDifferentBytesOutsideQuantity:4,regressionExportsIdenticalTo010:regressionExports,
 slotReaderAndQuantityWriterUnchanged:true,containerRecognitionCorrected:true,roundTripFilesChecked:4,allMissingProfilesRejected:true,
 syntheticExistingRowsForMissingProfilesChecked:missing.length,originalsOverwritten:false,inGameTestedHere:false};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_CATALOGO_0_9_0.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
