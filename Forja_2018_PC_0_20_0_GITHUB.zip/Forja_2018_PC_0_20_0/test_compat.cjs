'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const core = require('./src/core'), resources = require('./src/resource-edit'), attrs = require('./src/attributes');
const [fixture, previousRoot, outputPath] = process.argv.slice(2);
assert.ok(fixture && previousRoot && outputPath);
const previous = require(path.resolve(previousRoot, 'src/core'));
const bytes = fs.readFileSync(fixture), original = Buffer.from(bytes), model = core.parse(bytes);
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes');
assert.throws(() => previous.parse(bytes), /cabeçalho/); // reproduz a imagem enviada
assert.equal(model.supported, 12); assert.equal(model.latestSlot, 1);
assert.equal(model.slots.filter(slot => slot.empty).length, 8);
same(core.roundTrip(bytes), bytes); same(resources.patch(bytes).bytes, bytes);
let scalarFields = 0, slotExports = 0;
const mixed = [];
for (const slot of model.slots) {
  if (!slot.available) { assert.equal(slot.empty, true); assert.throws(() => core.patch(bytes, [{ slot: slot.index, id: core.FIELDS[1].id, quantity: 1 }]), /vazio/); continue; }
  assert.ok(slot.rows.length >= 304 && slot.rows.length <= 316);
  assert.ok(!slot.rows.some(row => ['5343978C802835DB', 'DBC20322187668AD'].includes(row.id)));
  const state = resources.inspect(bytes, slot.index, model); assert.equal(state.available, true, state.reason);
  assert.equal(state.statsEnd - state.objectEnd, 220);
  assert.deepEqual(state.groups.map(group => [group.count, group.count8, group.count4]), [[0, 0, 0], [0, 0, 0], [10, 0, 0]]);
  const present = core.FIELDS.filter(item => slot.rows.some(row => row.id === item.id)); assert.equal(present.length, 15);
  const scalarPlan = present.map((item, i) => ({ slot: slot.index, id: item.id, quantity: 1234 + slot.index * 20 + i }));
  const scalar = core.patch(bytes, scalarPlan);
  same(resources.patch(bytes, scalarPlan).bytes, scalar.bytes);
  same(bytes.subarray(0, slot.base), scalar.bytes.subarray(0, slot.base));
  same(bytes.subarray(slot.end), scalar.bytes.subarray(slot.end));
  let cursor = slot.base;
  for (const entry of scalar.log.slice().sort((a, b) => a.offset - b.offset)) {
    same(bytes.subarray(cursor, entry.offset), scalar.bytes.subarray(cursor, entry.offset)); cursor = entry.offset + 4;
  }
  same(bytes.subarray(cursor, slot.end), scalar.bytes.subarray(cursor, slot.end));
  scalarFields += scalarPlan.length; slotExports++;
  attrs.DEWS.forEach((stat, i) => mixed.push({ slot: slot.index, id: stat.id, quantity: 500 + slot.index * 10 + i }));
  mixed.push({ slot: slot.index, id: 'FCC6B87B4C8E41DC', quantity: 1000 + slot.index },
    { slot: slot.index, id: core.FIELDS[1].id, quantity: 2000000 + slot.index });
  if (global.gc) global.gc();
}
const result = resources.patch(bytes, mixed);
assert.equal(result.log.length, 96); assert.equal(result.validation.newRecords, 72);
same(result.bytes.subarray(0, core.HEADER_SIZE), bytes.subarray(0, core.HEADER_SIZE));
same(result.bytes.subarray(model.slots[12].base), bytes.subarray(model.slots[12].base));
for (const slot of model.slots.filter(slot => slot.available)) {
  const next = result.model.slots[slot.index], before = resources.inspect(bytes, slot.index, model), after = resources.inspect(result.bytes, slot.index, result.model);
  assert.equal(after.available, true, after.reason); assert.equal(next.rows.length, slot.rows.length + 6);
  for (const request of mixed.filter(request => request.slot === slot.index)) assert.equal(next.rows.find(row => row.id === request.id).quantity, request.quantity);
  same(bytes.subarray(slot.table.end, before.activeEnd), result.bytes.subarray(next.table.end, after.activeEnd));
  same(bytes.subarray(after.activeEnd, slot.end), result.bytes.subarray(after.activeEnd, slot.end));
  for (const row of slot.rows) assert.equal(next.rows.find(item => item.id === row.id).auxiliary, row.auxiliary);
}
// Mais de 32 ausentes continua bloqueado por capacidade, não por modo de jogo.
const missing = resources.inspect(bytes, 0, model).choices; assert.equal(missing.length, 33);
assert.throws(() => resources.patch(bytes, missing.map(item => ({ slot: 0, id: item.id, quantity: 1 }))), /máximo 32/);
const maximum = resources.patch(bytes, missing.slice(0, 32).map(item => ({ slot: 0, id: item.id, quantity: 1 })));
assert.equal(maximum.validation.newRecords, 32);
// A validação estrutural permanece ativa depois de retirar o valor fixo errado.
for (const [offset, value] of [[8, 3], [12, 0], [16, 209], [20, 1], [24, 1]]) {
  const broken = Buffer.from(bytes); broken.writeUInt32LE(value, offset); assert.throws(() => core.parse(broken), /cabeçalho/);
}
for (const marker of resources.inspect(bytes, 0, model).groups) {
  const broken = Buffer.from(bytes); broken[marker.start] ^= 1; assert.equal(resources.inspect(broken, 0).available, false);
  assert.throws(() => resources.patch(broken, [{ slot: 0, id: attrs.DEWS[0].id, quantity: 1 }]), /tabela final/);
}
const brokenCount = Buffer.from(bytes), group = resources.inspect(bytes, 0, model).groups[2];
brokenCount.writeUInt32LE(4096, group.start + 8); assert.equal(resources.inspect(brokenCount, 0).available, false);
const variable = Buffer.from(bytes); variable.writeUInt32LE(0x11223344, 0); variable.writeUInt32LE(0x55667788, 4);
assert.equal(core.parse(variable).supported, 12);
same(core.patch(variable, [{ slot: 0, id: core.FIELDS[1].id, quantity: 321 }]).bytes.subarray(0, core.HEADER_SIZE), variable.subarray(0, core.HEADER_SIZE));
same(bytes, original); same(fs.readFileSync(fixture), original); fs.writeFileSync(outputPath, result.bytes);
const report = { version: core.VERSION, previousHeaderErrorReproduced: true, occupiedSlots: 12, emptySlots: 8,
  slotExports, existingScalarFieldsChecked: scalarFields, mixedChangesChecked: 96, newRecordsChecked: 72,
  finalTablesParsedByCounts: true, normalSaveTailLength: 220, structuralValidationStillActive: true,
  allOldRecordsAndSecondaryTablesPreserved: true, emptySlotsAndGlobalHeaderPreserved: true,
  sourceSaveUnchanged: true, inGameTestedHere: false };
fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_COMPATIBILIDADE_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
