'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, context, document, query, downloads, $ } = require('./test_dom_harness.cjs');
const [fixture] = process.argv.slice(2); assert.ok(fixture);
const bytes = new Uint8Array(fs.readFileSync(fixture)), core = require('./src/core'), catalog = require('./src/catalog'), model = core.parse(bytes);
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)), 'Bytes divergentes.');
const noError = () => assert.equal($('error').hidden, true, $('error').textContent);
const markup = fs.readFileSync(path.join(__dirname, 'src/index.template.html'), 'utf8').split('<script')[0];
const ancestry = new Map(), stack = [], voids = new Set(['meta', 'input', 'br', 'img', 'link', 'hr']);
for (const token of markup.matchAll(/<\/?([a-z][\w-]*)([^>]*?)>/gi)) {
 const tag=token[1].toLowerCase();
 if(token[0].startsWith('</')){const index=stack.map(item=>item.tag).lastIndexOf(tag);if(index>=0)stack.splice(index);continue;}
 const attrs={};for(const match of token[2].matchAll(/([\w-]+)(?:="([^"]*)")?/g))attrs[match[1]]=match[2]||'';
 if(attrs.id)ancestry.set(attrs.id,[...stack.map(item=>item.attrs),attrs]);
 if(!voids.has(tag)&&!token[0].endsWith('/>'))stack.push({tag,attrs});
}
function visible(id){
 assert.ok(ancestry.has(id),id);
 return ancestry.get(id).every(attrs=>{const el=attrs.id?$(attrs.id):attrs['data-page']?query('[data-page]').find(el=>el.dataset.page===attrs['data-page']):null;return el?!el.hidden:!Object.hasOwn(attrs,'hidden');});
}
async function quantity(id,value){$('quantity-category').value='all';$('quantity-search').value='';await $('quantity-search').fire('input');assert.ok($('quantity-item').children.some(option=>option.attrs.value===id));$('quantity-item').value=id;await $('quantity-item').fire('change');$('quantity-value').value=String(value);await $('quantity-value').fire('input');await $('quantity-apply').click();}
(async()=>{
 assert.equal(visible('open-main'),true);assert.equal(visible('quantity-apply'),false);
 api.chooseView('catalog');assert.equal(visible('catalog-search'),true);assert.equal($('catalog-count').textContent,'1683 de 1683 IDs');
 $('catalog-search').value='Unstable Ore';await $('catalog-search').fire('input');assert.equal($('catalog-count').textContent,'1 de 1683 IDs');assert.ok($('catalog-body').innerHTML.includes('Minério instável'));
 $('catalog-search').value='';await $('catalog-search').fire('input');await $('catalog-next').click();assert.ok($('catalog-page').textContent.startsWith('2 de'));api.chooseView('slots');
 let picker=0;$('file-input').addEventListener('click',()=>picker++);await $('open-main').click();assert.equal(picker,1);
 api.loadBytes(bytes,'game(depoisDaAlteração).sav');noError();assert.equal(api.getState().selected,null);assert.equal(api.getState().page,'slots');
 assert.equal(query('[data-select-slot]').length,20);assert.equal(visible('slots-body'),true);assert.equal(visible('quantity-apply'),false);
 assert.equal($('export-top').disabled,true);
 await query('[data-select-slot]').find(el=>el.dataset.selectSlot==='0').click();noError();assert.equal(api.getState().selected,0);assert.equal(visible('quantity-apply'),true);assert.equal(visible('selected-summary'),true);
 $('quantity-search').value='Unstable Ore';await $('quantity-search').fire('input');assert.equal($('quantity-count').textContent,'1 de 67 recursos do catálogo');assert.equal($('quantity-item').value,'FCC6B87B4C8E41DC');
 $('quantity-search').value='minério instável';await $('quantity-search').fire('input');assert.equal($('quantity-item').value,'FCC6B87B4C8E41DC');
 $('quantity-search').value='';$('quantity-category').value='Recursos';await $('quantity-category').fire('change');assert.ok($('quantity-item').children.every(option=>catalog.lookup(option.attrs.value)?.category==='Recursos'));
 $('quantity-search').value='Recurso inexistente xyz';await $('quantity-search').fire('input');assert.equal($('quantity-apply').disabled,true);
 await quantity('FCC6B87B4C8E41DC',4321);noError();same(api.exportBytes().bytes,core.patch(bytes,[{slot:0,id:'FCC6B87B4C8E41DC',quantity:4321}]).bytes);
 assert.equal($('quantity-note').textContent.includes('ID confirmado pela amostra de PC'),true);
 await quantity(core.FIELDS[1].id,1234567);noError();let plan=[{slot:0,id:'FCC6B87B4C8E41DC',quantity:4321},{slot:0,id:core.FIELDS[1].id,quantity:1234567}];same(api.exportBytes().bytes,core.patch(bytes,plan).bytes);
 const validDraft=api.exportBytes().bytes;await quantity(core.FIELDS[1].id,-1);assert.equal($('error').hidden,false);same(api.exportBytes().bytes,validDraft);
 await $('change-slot').click();assert.equal(visible('slots-body'),true);
 await query('[data-select-slot]').find(el=>el.dataset.selectSlot==='18').click();noError();await quantity(core.FIELDS[0].id,7654321);noError();plan.push({slot:18,id:core.FIELDS[0].id,quantity:7654321});same(api.exportBytes().bytes,core.patch(bytes,plan).bytes);
 const row=model.slots[18].rows.find(row=>catalog.lookup(row.id)&&!core.lookup(row.id));assert.ok(row);
 api.chooseView('records');$('record-search').value=row.id;await $('record-search').fire('input');assert.ok($('records-body').innerHTML.includes(catalog.lookup(row.id).name));assert.ok($('records-body').innerHTML.includes('Consulta'));
 api.chooseView('records');$('record-search').value=core.FIELDS[0].id;await $('record-search').fire('input');assert.equal($('record-count').textContent,'1 de '+model.slots[18].rows.length+' registros');assert.ok($('records-body').innerHTML.includes('7654321')||$('records-body').innerHTML.includes('7.654.321'));
 $('record-search').value='';await $('record-search').fire('input');assert.equal($('records-prev').disabled,true);await $('records-next').click();assert.ok($('records-page').textContent.startsWith('2 de'));
 api.chooseView('changes');assert.equal(visible('changes-body'),true);assert.equal(api.getState().log.length,3);await $('export-top').click();assert.equal(downloads.at(-1).name,'game.sav');same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),bytes);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.9.0');assert.equal(report.validation.unstableOreIdConfirmedByPcPair,true);assert.equal(report.changes.length,3);assert.ok(report.changes.some(change=>change.slot===19));
 await query('[data-undo]').find(el=>el.dataset.undo==='0:'+'FCC6B87B4C8E41DC').click();noError();plan=plan.filter(entry=>entry.id!=='FCC6B87B4C8E41DC');same(api.exportBytes().bytes,core.patch(bytes,plan).bytes);
 await $('reset-changes').click();noError();assert.equal(api.getState().log.length,0);assert.equal($('export-top').disabled,true);assert.throws(()=>api.exportBytes(),/Nenhuma alteração/);
 await quantity(core.FIELDS[0].id,model.slots[18].rows[0].quantity);noError();assert.equal(api.getState().log.length,0);
 // Uma nova abertura limpa o rascunho e exige nova escolha de slot.
 api.loadBytes(bytes,'game.sav');assert.equal(api.getState().selected,null);assert.equal(visible('quantity-apply'),false);assert.equal(api.getState().log.length,0);
 const broken=bytes.slice();broken[model.slots[0].table.start]^=1;api.loadBytes(broken,'perfil_incompleto.sav');assert.equal(query('[data-select-slot]').find(el=>el.dataset.selectSlot==='0').disabled,true);assert.throws(()=>api.selectSlot(0),/reconhecido/);
 assert.throws(()=>api.loadBytes(new Uint8Array(5)),/tamanho/);same(bytes,fs.readFileSync(fixture));
 const result={version:'0.9.0',htmlExecutedInVM:true,staticAncestryChecked:true,explicitSlotSelectionRequired:true,
  all20SlotsListed:true,multiSlotQuantitiesVerified:true,controlledPcIdDisplayed:true,invalidInputKeepsDraft:true,
  editedAndOriginalDownloadsVerified:true,outputFilenameGameSav:true,reportAndUndoVerified:true,
  searchAndPaginationVerified:true,newFileResetsSelection:true,unsupportedSlotDisabled:true,
 catalogAvailableWithoutSave:true,catalogAndRecordNamesVerified:true,resourceSearchAndCategoryVerified:true,unknownAndEquipmentRowsReadOnly:true,
  visualBrowserTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_9_0.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
