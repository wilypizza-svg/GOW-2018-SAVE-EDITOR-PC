# Forja 2018 PC v0.20.0 — Lâminas do Caos desde o início

## Novidades

- Aquisição antecipada das Lâminas do Caos com o cabo padrão, disponível em **Níveis**.
- Seleção dos níveis de 1 a 5 para as Lâminas nos estados iniciais reconhecidos.
- Aquisição e nível em linhas separadas na revisão, com desfazer dos ajustes dependentes.
- Aviso para evitar cifras de Muspelheim/Niflheim antes da primeira viagem a Alfheim, devido ao travamento relatado na cena da ponte de Týr.

As funções anteriores de recursos, equipamentos, rúnicos, encantamentos e remoção foram preservadas. As comparações de regressão mantiveram os mesmos resultados da 0.19.0 nos casos examinados.

## Download

Para usar o editor, baixe **Forja_2018_PC_0_20_0_SO_EDITOR.zip** em **Assets**, extraia e abra o HTML incluído. O pacote funciona offline.

## Cobertura desta versão

A aquisição antecipada já foi confirmada no jogo e a integração reproduz os arquivos aprovados. **O ajuste direto ao nível 5 no início da campanha passou nos testes locais e ainda aguarda confirmação no jogo.**

Evite adicionar cifras antes da primeira viagem a Alfheim. Guarde o original e teste a cópia exportada, incluindo salvar e recarregar no jogo.
