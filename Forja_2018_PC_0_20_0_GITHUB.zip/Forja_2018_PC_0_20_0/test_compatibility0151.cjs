/* Regressão do bloqueio por build e preservação dos formatos já reconhecidos.
   node test_compatibility0151.cjs CAMINHO_DO_WORKSPACE */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),core=require('./src/core'),nat=require('./src/native-records'),compat=require('./src/compatibility'),inv=require('./src/inventory'),weapons=require('./src/weapon-levels'),campaign=require('./src/campaign'),ciphers=require('./src/ciphers'),armor=require('./src/armor-template-clone'),policy=require('./src/resource-policy'),plan=require('./src/plan');
const oldRoot=path.join(ws,'Forja_2018_PC_0_15_0'),oldPlan=require(oldRoot+'/src/plan'),read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert.ok(nat.equal(a,b),m);
const filename='upload/game(20261024-134912).sav',source=read(filename),hash=sha(source),model=core.parse(source),slot=model.latestSlot,tx=nat.read(source,slot,model);
assert.equal(model.build,4389704);assert.equal(tx.slot.build,4389704);assert.deepEqual(compat.BUILDS,[4389704,4757534]);
const states=weapons.PROFILES.map(p=>weapons.inspect(source,slot,p.id,model));assert.equal(states[0].current,3);assert.equal(states[0].available,true);assert.equal(states[1].available,false);assert.match(states[1].reason,/registros das Lâminas/);
const inventory=inv.inspect(source,slot,model);assert.equal(inventory.available,true);assert.equal(inventory.profiles.filter(p=>p.available).length,268);
const cases=[],out=path.join(ws,'analysis_0_15_1/testes');fs.mkdirSync(out,{recursive:true});
function protectedParts(input,output,index,worldOffsets=[]){
 const a=nat.read(input,index),b=nat.read(output,index),prefix=input.slice(a.slot.base,a.slot.base+0x10400);
 nat.view(prefix).setUint32(0x124,nat.view(output).getUint32(a.slot.base+0x124,true),true);
 for(const at of worldOffsets)prefix.set(output.subarray(at,at+4),at-a.slot.base);
 same(prefix,output.subarray(a.slot.base,a.slot.base+0x10400),'Mundo/cabeçalho alterado fora dos campos permitidos.');
 same(a.objectsAndGroups,b.objectsAndGroups,'Instâncias alteradas.');
 same(input.subarray(0,core.HEADER_SIZE),output.subarray(0,core.HEADER_SIZE),'Cabeçalho global alterado.');
 for(const s of a.model.slots){assert.equal(core.parse(output).slots[s.index].build,s.build);if(s.index!==index)same(input.subarray(s.base,s.end),output.subarray(s.base,s.end),'Outro slot alterado.');}
 same(input.subarray(Math.max(a.state.activeEnd,b.state.activeEnd)),output.subarray(Math.max(a.state.activeEnd,b.state.activeEnd)));
 assert.ok(b.finals.length<=512);return b;
}
function compareReference(name,bytes,index,requests){
 // Oráculo de teste em memória: a 0.15.0 só admite 4757534. O campo é
 // ajustado apenas na sonda privada, depois restaurado para comparar bytes.
 // A saída real vem sempre do arquivo original, sem converter seu build.
 const p=core.parse(bytes),probe=bytes.slice();nat.view(probe).setUint32(p.slots[index].base+12,4757534,true);
 const reference=oldPlan.patch(probe,requests).bytes;nat.view(reference).setUint32(p.slots[index].base+12,p.slots[index].build,true);
 const result=plan.patch(bytes,requests);same(result.bytes,reference,name+': bytes diferentes da rotina anterior.');
 const world=[];
 if(requests.some(r=>r.type===weapons.TYPE))for(const r of requests.filter(r=>r.type===weapons.TYPE)){
  const profile=weapons.PROFILES.find(x=>x.id===r.id),needle=Buffer.from(profile.sceneMarker,'hex'),relative=Buffer.from(bytes.subarray(p.slots[index].base+0x400,p.slots[index].base+0x10400)).indexOf(needle);
  if(relative>=0)world.push(p.slots[index].base+0x400+relative+needle.length);
 }
 protectedParts(bytes,result.bytes,index,world);same(plan.patch(result.bytes,requests).bytes,result.bytes,'Operação repetida não é inócua.');
 cases.push({name,slot:index+1,requests,sha256:sha(result.bytes),previousAlgorithmByteIdenticalAfterRestoringProbeBuild:true});return result;
}
for(const level of [1,2,4,5,6]){
 const r={type:weapons.TYPE,id:'axe-main-level',slot,level},result=compareReference('Machado_'+level,source,slot,[r]);assert.equal(weapons.inspect(result.bytes,slot,r.id).current,level);
 if(level<=3){const restored=plan.patch(result.bytes,[{...r,level:3}]);same(restored.bytes,source);}
}
const selected=[];
for(const kind of ['chest','wrist','waist','axe','blades','talisman']){
 const p=inventory.profiles.find(p=>p.kind===kind&&p.variant==='normal'&&p.available&&!p.owned&&!p.autoFullSet);assert.ok(p,kind);
 const request={type:'inventory-equipment',id:p.id,slot,stage:p.stages.length-1,allowExperimental:true};selected.push(request);compareReference(kind+'_'+p.id,source,slot,[request]);
}
const traveler={type:'inventory-equipment',id:'615B1370AEBED3EA',slot,stage:2};const travelerResult=compareReference('Peitoral_Viajante',source,slot,[traveler]);
assert.equal(nat.quantity(nat.read(travelerResult.bytes,slot),traveler.id),1);
const zeus={type:armor.TYPE,id:armor.ID,slot,level:9,allowExperimental:true},zeusResult=compareReference('Zeus_Clonagem',source,slot,[zeus]);
assert.equal(zeusResult.log[0].actualConstructionVerifiedInGame,false);assert.equal(zeusResult.log[0].sourceBuild,4389704);
const runic=inventory.profiles.find(p=>p.mode==='runic-quantity-template'&&p.available&&!p.owned);assert.ok(runic);
compareReference('Runico_'+runic.id,source,slot,[{type:'inventory-equipment',id:runic.id,slot,stage:2,allowExperimental:true}]);
const cipherRequests=ciphers.PROFILES.map(p=>({type:ciphers.TYPE,id:p.id,slot,total:4}));compareReference('Cifras',source,slot,cipherRequests);
compareReference('Vida_Furia',source,slot,[{type:'idunn-apples',id:'idunn-apples',slot,total:9},{type:'blood-mead-horns',id:'blood-mead-horns',slot,total:9}]);
const resources=policy.FIELDS.slice(0,44).map(p=>({slot,id:p.id,quantity:p.unique?1:1000}));
const combined=[...resources,traveler,{type:weapons.TYPE,id:'axe-main-level',slot,level:6}],combinedResult=compareReference('44_Recursos_Equipamento_e_Machado',source,slot,combined);
fs.writeFileSync(path.join(out,'Combinado_PC4389704.sav'),combinedResult.bytes);
// Testemunha antiga já fornecida: Machado 5 e Lâminas 3 em 4389704.
const witness=read('upload/game(09_Brok_normal_Talisma_normal).sav'),wi=11;assert.equal(core.parse(witness).slots[wi].build,4389704);
assert.equal(weapons.inspect(witness,wi,'axe-main-level').current,5);assert.equal(weapons.inspect(witness,wi,'blades-main-level').current,3);
compareReference('Laminas_5_4389704',witness,wi,[{type:weapons.TYPE,id:'blades-main-level',slot:wi,level:5}]);
for(const kind of ['maps','history','world','unknown-build','structure']){
 let broken=source.slice();const t=nat.read(broken,slot),profile=weapons.PROFILES[0];
 if(kind==='maps'){nat.view(nat.mapEntry(t,1,profile.key)).setUint32(4,1,true);broken=nat.write(t).bytes;}
 if(kind==='history'){nat.putQuantity(t,profile.history[0],0);broken=nat.write(t).bytes;}
 if(kind==='world'){const marker=Buffer.from(profile.sceneMarker,'hex'),at=Buffer.from(broken).indexOf(marker,t.slot.base+0x400)+16;nat.view(broken).setUint32(at,5,true);}
 if(kind==='unknown-build')nat.view(broken).setUint32(t.slot.base+12,1234567,true);
 if(kind==='structure')broken[t.state.frames[1].start+2]^=1;
 assert.equal(weapons.inspect(broken,slot,'axe-main-level').available,false,kind);
 assert.throws(()=>plan.patch(broken,[{type:weapons.TYPE,id:'axe-main-level',slot,level:6}]));
 if(['unknown-build','structure'].includes(kind))assert.throws(()=>plan.patch(broken,[traveler]));
}
assert.match(weapons.inspect(source,10,'axe-main-level').reason,/primeiro upgrade/);
// Os arquivos anteriormente aprovados precisam manter a mesma exportação.
const legacy=JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_14_0/testes/manifest.json'))).cases,regressions=[];
for(const c of legacy.filter(c=>['10_','12_','13_','14_'].some(p=>c.name.startsWith(p)))){assert.equal(sha(plan.patch(read(c.source),c.requests).bytes),c.sha256);regressions.push(c.name);}
const control=read('analysis_0_14_2/testes/CONTROLE_17_Original_Sem_Alteracoes/game.sav'),five=inv.PROFILES.filter(p=>p.kind==='blades'&&p.variant==='NG+').map(p=>({type:'inventory-equipment',id:p.id,slot:14,stage:2}));same(plan.patch(control,five).bytes,read('analysis_cabos/diagnostico_cinco_cabos/Cursed_F_Cinco_Cabos_NGmais_Nivel9.sav'));
for(const rel of ['src/native-records.js','src/resource-edit.js','src/wallet.js','src/equipment-record-clone.js','src/enchantments.js','src/enchantment-instance-clone.js','src/level-targets.js','src/armor-levels.js','src/armor-ancients.js','src/plan.js'])same(fs.readFileSync(path.join(__dirname,rel)),fs.readFileSync(path.join(oldRoot,rel)),rel);
for(const file of fs.readdirSync(path.join(__dirname,'data')))same(fs.readFileSync(path.join(__dirname,'data',file)),fs.readFileSync(path.join(oldRoot,'data',file)));
for(const file of JSON.parse(fs.readFileSync(path.join(ws,'analysis_0_15_1/baseline_manifest.json'))))assert.equal(sha(fs.readFileSync(file.path)),file.sha256);
assert.equal(sha(source),hash);
const report={version:core.VERSION,sourceBuild:4389704,sourceHash:hash,supportedBuilds:compat.BUILDS,axe3Recognized:true,bladesWithoutUnlockStillBlocked:true,all268EquipmentProfilesRecognized:true,comparisons:cases.length,cases,sourceGlobalAndSlotBuildsNeverConverted:true,oldSaveOutputsMatchExistingAlgorithm:true,worldObjectsOtherSlotsPreserved:true,corruptMapsHistoryWorldAndStructureBlocked:true,unknownBuildStillBlocked:true,firstAxeUpgradeStillRequired:true,previousApprovedExportsByteIdentical:regressions,fiveHandlesStillByteIdenticalToGameApprovedFile:true,commonSerializerAndDataUnchanged:true,old0150Preserved:true,oldBuildGameValidationPending:true};
fs.writeFileSync(path.join(__dirname,'VERIFICACAO_COMPATIBILIDADE_0_15_1.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,cases:undefined},null,2));
