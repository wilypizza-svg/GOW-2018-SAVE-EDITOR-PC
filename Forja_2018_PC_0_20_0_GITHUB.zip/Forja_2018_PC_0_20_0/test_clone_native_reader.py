"""Leitor binário independente dos testes; não usa o gravador JavaScript."""
import struct
HEADER, SLOT, START, SIZE = 4160, 1677512, 0x10400, 33554400
SLOT_INDEX = 14

def parse(b):
    assert len(b) == SIZE
    base = HEADER + SLOT_INDEX * SLOT
    start = base + START
    u32 = lambda p: struct.unpack_from('<I', b, p)[0]
    assert b[start:start+2] == b'\x01\x00'
    assert b[start+3:start+5] == b'\xfa\xff'
    assert b[start+9:start+17] == bytes.fromhex('5F2243C695480000')
    count, nrefs, nobjects = struct.unpack_from('<III', b, start+17)
    row_start = start+29
    row_end = row_start+16*count
    rows = [b[p:p+16] for p in range(row_start, row_end, 16)]
    assert len({row[:8] for row in rows}) == count
    cursor = row_end+8*nrefs
    object_start = cursor
    stats_end = start+9+u32(start+5)

    def skip_objects(n):
        nonlocal cursor
        ids = set()
        for _ in range(n):
            assert b[cursor:cursor+8] == bytes.fromhex('3B056E1555DABD5D')
            uid = u32(cursor+48)
            assert uid not in ids
            ids.add(uid)
            cursor += 72
            for _ in range(2):
                nlist = u32(cursor)
                assert nlist <= 64
                cursor += 4+4*nlist
            nstats = u32(cursor)
            assert nstats <= 64
            cursor += 4+12*nstats
            assert cursor <= stats_end

    skip_objects(nobjects)
    for marker in ('EA2555A4149BE338', '4B30662F58A15983', 'B0BDD5E2372DB672'):
        assert b[cursor:cursor+8] == bytes.fromhex(marker)
        count16, count8, count4 = struct.unpack_from('<III', b, cursor+8)
        cursor += 20+16*count16+8*count8
        skip_objects(count4)
    assert cursor == stats_end
    objects = b[object_start:stats_end]
    frames = []
    for frame in range(3):
        length = struct.unpack_from('<H', b, cursor)[0]
        raw = b[cursor:cursor+2+length]
        prefix, stride = (8 if frame == 1 else 0), (8 if frame == 0 else 9)
        n = struct.unpack_from('<I', raw, 2+prefix)[0]
        assert length == prefix+4+stride*n
        keys = [struct.unpack_from('<I', raw, 2+prefix+4+stride*i)[0] for i in range(n)]
        assert len(set(keys)) == n
        frames.append(raw)
        cursor += 2+length
    assert b[cursor:cursor+2] == bytes.fromhex('2EFA')
    final_len = struct.unpack_from('<H', b, cursor+2)[0]
    assert final_len % 16 == 0
    finals = b[cursor:cursor+4+final_len]
    end = cursor+4+final_len
    assert end == start+u32(base+0x124)
    assert end+4096 <= base+0x30400
    return dict(base=base, start=start, row_start=row_start, row_end=row_end,
                rows=rows, refs=b[row_end:object_start], objects=objects,
                frames=frames, finals=finals, end=end)
