"""Releitura independente; não importa o gravador JavaScript.
Uso: python3 test_scaling_clone_oracle.py ENTRADAS SAVE_NORMAL SAIDAS
"""
from pathlib import Path
import ast, hashlib, json, struct, sys
inputs, normal, outputs=map(Path,sys.argv[1:4]);root=Path(__file__).parent
reader=root/'test_clone_native_reader.py';definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=14)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns);parse=ns['parse']
manifest=json.loads((outputs/'manifest.json').read_text());profiles={p['id']:p for p in json.loads((root/'data/inventory-profiles.json').read_text())['profiles']}
zeus=json.loads((root/'data/armor-set-template.json').read_text());results=[]
for case in manifest['cases']:
 ns['SLOT_INDEX']=case['slot']-1
 source=(inputs/case['source']) if case['source']=='game(SaveBase).sav' else normal
 original=source.read_bytes();edited=(outputs/case['name']/'game.sav').read_bytes();a,b=parse(original),parse(edited)
 assert hashlib.sha256(original).hexdigest()==case['sourceSha256']
 assert hashlib.sha256(edited).hexdigest()==case['sha256']
 assert len(original)==len(edited)==33554400
 assert a['refs']==b['refs'] and a['objects']==b['objects'] and a['frames'][1:]==b['frames'][1:]
 assert original[:a['base']+0x124]==edited[:a['base']+0x124]
 assert original[a['base']+0x128:a['start']]==edited[a['base']+0x128:a['start']]
 assert original[b['end']:]==edited[b['end']:]
 for i in range(20):
  if i!=case['slot']-1:
   off=4160+i*1677512;assert original[off:off+1677512]==edited[off:off+1677512]
 old={r[:8]:r for r in a['rows']};new={r[:8]:r for r in b['rows']};ids={bytes.fromhex(s) for s in case['allowedIds']}
 for identity,row in old.items():
  if identity not in ids:assert new[identity]==row
 for identity in ids:assert struct.unpack_from('<I',new[identity],8)[0]==1
 def gm(frame):
  n=struct.unpack_from('<I',frame,2)[0];return dict(struct.unpack_from('<II',frame,6+8*i) for i in range(n))
 old_g,new_g=gm(a['frames'][0]),gm(b['frames'][0]);allowed=set(case['allowedKeys'])
 assert {k:v for k,v in old_g.items() if k not in allowed}=={k:v for k,v in new_g.items() if k not in allowed}
 expected={}
 for request in case['requests']:
  if request['type']=='armor-set-template':expected.update({682:2,683:2,684:2})
  elif request['id'] in profiles:expected[profiles[request['id']]['key']]=request['stage']
 assert allowed==set(expected)
 for key,value in expected.items():assert new_g[key]==value
 def finals(state):return [state['finals'][p:p+16] for p in range(4,len(state['finals']),16)]
 new_final=finals(b)
 for row in finals(a):
  if row[:8] not in ids:assert row in new_final
 if any(r['type']=='armor-set-template' for r in case['requests']):
  zids={bytes.fromhex(s) for p in zeus['parts'] for s in p['targetIds']};assert {r for r in new_final if r[:8] in zids}=={bytes.fromhex(r) for r in zeus['targetFinalRows']}
 for request in case['requests']:
  if request['id'] not in profiles and request['type']=='inventory-equipment':assert not any(r[:8]==bytes.fromhex(request['id']) for r in new_final)
 results.append({'case':case['name'],'slot':case['slot'],'sha256':case['sha256'],'onlyRequestedIdsAndObservedMapsChanged':True,'resourcesObjectsWorldAnd19SlotsPreserved':True})
report={'version':'0.13.0','independentLanguage':'Python','passed':True,'cases':results,'inGameTestedHere':False}
(root/'VERIFICACAO_INDEPENDENTE_0_13_0.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'cases':len(results),'inGameTestedHere':False}))
