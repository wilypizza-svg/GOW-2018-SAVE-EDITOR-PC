/* Pares reais e propriedades de preservação; fixtures são fornecidas fora do código. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const core=require('./src/core'),nat=require('./src/native-records'),inv=require('./src/inventory'),plan=require('./src/plan'),camp=require('./src/campaign'),ench=require('./src/enchantments');
const fixtures=JSON.parse(fs.readFileSync(process.argv[2])),out=path.resolve(process.argv[3]);fs.mkdirSync(out,{recursive:true});
const read=s=>new Uint8Array(fs.readFileSync(s.path)),eq=(a,b,message)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)),message),hex=core.hex;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const values=rows=>rows.map(r=>({id:nat.idOf(r),quantity:nat.view(r).getUint32(8,true)}));
const find=prefix=>fixtures.find(s=>s.path&&s.file.startsWith('game('+prefix));
const req=(p,slot,stage)=>({slot,id:p.id,type:'inventory-equipment',stage});
function unchanged(a,b,index,{rows=[],refs=[],finals=[],maps=[],objects=0}={}){
 const x=nat.read(a,index),y=nat.read(b,index),rs=new Set(rows),refset=new Set(refs),fs=new Set(finals),ms=new Set(maps);
 eq(a.subarray(0,x.slot.base+0x124),b.subarray(0,x.slot.base+0x124),'header, earlier slots and world');
 eq(a.subarray(x.slot.base+0x128,x.slot.base+0x10400),b.subarray(x.slot.base+0x128,x.slot.base+0x10400),'world after active size');
 eq(a.subarray(y.state.activeEnd),b.subarray(y.state.activeEnd),'absolute tail and later slots');
 for(const row of x.rows)if(!rs.has(nat.idOf(row)))eq(row,nat.unique(y.rows,nat.idOf(row),true),'unrelated primary row');
 assert.deepEqual(x.refs.filter(r=>!refset.has(nat.idOf(r))),y.refs.filter(r=>!refset.has(nat.idOf(r))),'unrelated references');
 assert.deepEqual(x.finals.filter(r=>!fs.has(nat.idOf(r))),y.finals.filter(r=>!fs.has(nat.idOf(r))),'unrelated final records');
 for(let k=0;k<3;k++)assert.deepEqual(x.maps[k].entries.filter(r=>k===2||!ms.has(nat.view(r).getUint32(0,true))),y.maps[k].entries.filter(r=>k===2||!ms.has(nat.view(r).getUint32(0,true))),'unrelated map');
 assert.equal(y.state.objects.length,x.state.objects.length+objects);
 for(let k=0;k<x.state.objects.length;k++){const u=x.state.objects[k],v=y.state.objects[k];assert.equal(v.uid,u.uid);eq(a.subarray(u.start,u.end),b.subarray(v.start,v.end),'old object');}
 x.state.groups.forEach((g,k)=>eq(a.subarray(g.start,g.end),b.subarray(y.state.groups[k].start,y.state.groups[k].end),'opaque group'));
 return y;
}
const manifest=[];function save(name,s,output,requests){const file=path.join(out,name+'.sav');fs.writeFileSync(file,output);manifest.push({name,source:s.path,index:s.index,output:file,requests,sourceSha256:hash(read(s)),outputSha256:hash(output)});}
let transitions=0,acquisitions=0;
for(const p of inv.MAPPED_PROFILES){
 const all=new Set([...p.ids,...p.referenceIds]);
 for(let stage=0;stage<p.stages.length;stage++){
  const witness=fixtures.find(s=>s.file===p.stages[stage].witness);assert.ok(witness,p.id+' witness');
  const source=stage===0?fixtures.find(s=>s.path&&!s.maps[0].some(r=>r.key===p.key)&&!s.rows.some(r=>p.ids.includes(r.id)&&r.quantity>0)):fixtures.find(s=>s.path&&s.file===p.stages[stage-1].witness);
  // The vitality 8+ complement is retained as an independent semantic oracle.
  if(!source)continue;
  const a=read(source),r=req(p,source.index,stage),result=plan.patch(a,[r]),t=unchanged(a,result.bytes,source.index,{rows:p.ids,refs:p.referenceIds,finals:[...all],maps:[p.key]});
  assert.equal(nat.view(nat.mapEntry(t,0,p.key)).getUint32(4,true),stage);
  if(p.mode==='quantity')assert.equal(nat.quantity(t,p.id),stage+1);else for(let k=0;k<=stage;k++)assert.equal(nat.quantity(t,p.ids[k]),1);
  const expectedRefs=witness.refs.filter(id=>p.referenceIds.includes(id));assert.deepEqual(t.refs.map(nat.idOf).filter(id=>p.referenceIds.includes(id)),expectedRefs,p.name+' native reference order');
  const expectedFinals=witness.final.filter(f=>all.has(f.id)).map(f=>f.id+f.metadata).sort();
  assert.deepEqual(t.finals.filter(f=>all.has(nat.idOf(f))).map(hex).sort(),expectedFinals,p.name+' native final fields');
  for(const row of witness.rows.filter(row=>p.ids.includes(row.id)))assert.equal(nat.quantity(t,row.id),row.quantity,p.name+' native quantity');
  eq(plan.patch(result.bytes,[r]).bytes,result.bytes,'idempotent level');
  const down=plan.patch(result.bytes,[req(p,source.index,0)]);
  assert.equal(inv.inspect(down.bytes,source.index).profiles.find(x=>x.id===p.id).stage,0);
  if(p.mode==='history'){
   const dt=nat.read(down.bytes,source.index);assert.deepEqual(t.rows,dt.rows);assert.deepEqual(t.refs,dt.refs);assert.deepEqual(t.finals,dt.finals);
   assert.ok(inv.inspect(down.bytes,source.index).profiles.find(x=>x.id===p.id).highest>=stage);
  }
  stage===0?acquisitions++:transitions++;
  if(p.id==='3225AAC6C42CC83D'&&stage===2||p.id==='933A6B47A628A38C'&&stage===2||p.id==='615B1370AEBED3EA'&&stage===0||p.id==='18CC5ACF13806F4C'&&stage===2)save(p.id+'-'+stage,source,result.bytes,[r]);
 }
}
const normal=find('AntesDaCompraDeUmEncantamentoComum'),a=read(normal),native=fixtures.find(s=>s.file==='game(DepoisDeComprarUmEncatamentoComum).sav'),create={slot:normal.index,id:inv.MENACE,type:'enchantment-create',count:1};
const common=plan.patch(a,[create]),old=nat.read(a,normal.index),ct=nat.read(common.bytes,normal.index),uid=common.log[0].uids[0],newObject=ct.state.objects.find(o=>o.uid===uid);
assert.equal(uid,native.objects.find(o=>!normal.objects.some(p=>p.uid===o.uid)).uid);
const raw=common.bytes.subarray(newObject.start,newObject.end),oracle=native.objects.find(o=>o.uid===uid);assert.equal(hex(raw),oracle.hex,'normal factory equals actual native object');
unchanged(a,common.bytes,normal.index,{rows:[inv.MENACE],finals:[inv.MENACE,hex(Uint8Array.of(uid,0,0,0,0,0,0,0))],objects:1});
save('menace',normal,common.bytes,[create]);
const nativeBefore=fixtures.find(s=>s.file==='game(AntesDeConseguirUmEncantamentoUnico(Kvasir)).sav'),ka=read(nativeBefore);
const kr={slot:nativeBefore.index,id:inv.KVASIR,type:'enchantment-create',count:1};
for(const keep of [false,true]){
 const result=plan.patch(ka,[{...kr,keepTalisman:keep}]),t=nat.read(result.bytes,nativeBefore.index),log=result.log[0],id=new Uint8Array(8);nat.view(id).setUint32(0,log.uids[0],true);
 unchanged(ka,result.bytes,nativeBefore.index,{rows:[inv.KVASIR,'9E5240D27406E85A',...(keep?[]:inv.SACRIFICE)],refs:keep?[]:['9469F5C56C4DF108'],finals:[inv.KVASIR,hex(id),...(keep?[]:[...inv.SACRIFICE,'9469F5C56C4DF108'])],maps:keep?[]:[959],objects:1});
 for(const item of inv.SACRIFICE)assert.equal(nat.quantity(t,item),keep?1:0);
 assert.equal(!!nat.mapEntry(t,0,959),keep);assert.equal(!!nat.unique(t.refs,'9469F5C56C4DF108'),keep);
 assert.equal(nat.quantity(t,'9E5240D27406E85A'),nat.quantity(nat.read(ka,nativeBefore.index),'9E5240D27406E85A')-40000);
 assert.equal(log.warning,keep?'Talvez corrompa seu save':null);
 const object=t.state.objects.find(o=>o.uid===log.uids[0]),v=nat.view(result.bytes);assert.equal(v.getUint32(object.start+52,true),0xFFFFFFFF);assert.equal(v.getUint32(object.start+56,true),0xFFFFFFFF);
 assert.equal(ench.inspect(result.bytes,nativeBefore.index).templates.find(o=>o.uid===log.uids[0]).sampleName,'Perfect Mark of Kvasir +');
 assert.throws(()=>plan.patch(result.bytes,[kr]),/já foi/);
 save('kvasir-'+keep,nativeBefore,result.bytes,[{...kr,keepTalisman:keep}]);
}
const rage=find('AntesDoUpgradeDeFuria'),ra=read(rage),horn={slot:rage.index,id:'blood-mead-horns',type:'blood-mead-horns',total:6},hr=plan.patch(ra,[horn]);
assert.equal(camp.totals(hr.model.slots[rage.index],camp.HORNS).total,6);save('horns',rage,hr.bytes,[horn]);
for(let total=0;total<=9;total++)assert.equal(camp.totals(plan.patch(ra,[{...horn,total}]).model.slots[rage.index],camp.HORNS).total,total);
const stone=find('AntesDeComprarApedra'),sa=read(stone),sr={slot:stone.index,id:'berserker-stone',type:'berserker-stone'},st=plan.patch(sa,[sr]);assert.equal(camp.berserkerState(st.bytes,stone.index).owned,true);
unchanged(sa,st.bytes,stone.index,{rows:['3832900B4A8A614B','024373073A80CFB5'],refs:['9CACC83BC2F1FDD4'],finals:['3832900B4A8A614B','9CACC83BC2F1FDD4']});save('berserker',stone,st.bytes,[sr]);
const first=find('AntesDeComprarUmPeitoral'),ba=read(first),requests=inv.MAPPED_PROFILES.map(p=>req(p,first.index,p.stages.length-1));
requests.push({slot:first.index,id:inv.MENACE,type:'enchantment-create',count:3},{slot:first.index,id:'FCC6B87B4C8E41DC',quantity:321});
const batch=plan.patch(ba,requests);for(const p of inv.MAPPED_PROFILES)assert.equal(inv.inspect(batch.bytes,first.index).profiles.find(x=>x.id===p.id).stage,p.stages.length-1);
assert.equal(batch.model.slots[first.index].rows.find(r=>r.id==='FCC6B87B4C8E41DC').quantity,321);eq(plan.patch(ba,requests).bytes,batch.bytes,'deterministic export');eq(plan.patch(ba,[]).bytes,ba,'undo restores original');save('all-mapped-and-resources',first,batch.bytes,requests);
const offset=Buffer.alloc(ba.length+27,85);Buffer.from(ba).copy(offset,11);eq(plan.patch(offset.subarray(11,11+ba.length),requests).bytes,batch.bytes,'offset Buffer input');
for(const bad of [-1,100,1.5,NaN,'2'])assert.throws(()=>plan.patch(ba,[{...requests[0],stage:bad}]));
assert.throws(()=>plan.patch(ba,[{slot:first.index,id:'B74F7BCF35641B8F',type:'inventory-equipment',stage:2}]),/receita PC/);
assert.throws(()=>plan.patch(ba,[requests[0],requests[0]]),/dois pedidos/);
assert.throws(()=>plan.patch(a,[{...create,count:11}]));assert.throws(()=>plan.patch(ka,[{...kr,keepTalisman:'true'}]));
const broken=ba.slice(),bt=nat.read(broken,first.index),entry=nat.mapEntry(bt,0,1);assert.ok(entry); // corrupt an established map key by duplication
const f=bt.state.frames[0],n=nat.view(broken);n.setUint32(f.start+6+8,n.getUint32(f.start+6,true),true);assert.throws(()=>plan.patch(broken,[requests[0]]));
const summary={version:core.VERSION,profiles:inv.MAPPED_PROFILES.length,acquisitions,nativeProgressions:transitions,normalFactoryByteExact:true,
 kvasirSacrificeDefaultAndExperimentalCoexistenceVerified:true,oldObjectsGroupsOtherSlotsAndTailPreserved:true,
 downgradesPreserveHistory:true,allMappedCombinedWithResourceInsertion:true,offsetInputsAndInvalidRequestsChecked:true,inGameTestedHere:false};
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INVENTARIO_0_11_0.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
