'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{api,$,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),plan=require('./src/plan'),rem=require('./src/inventory-removal');
const ws=path.resolve(process.argv[2]||'..'),manifest=JSON.parse(fs.readFileSync(ws+'/testes_forja_remocao_20261025/delivery_manifest.json'));
const set=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
(async()=>{
 const control=manifest.files.find(f=>f.key==='00_CONTROLE_NGMAIS'),bytes=new Uint8Array(fs.readFileSync(control.file)),slot=core.parse(bytes).latestSlot;
 api.loadBytes(bytes,'game.sav');api.selectSlot(slot);api.chooseView('equipment');await set('inventory-kind','wrist');await set('removal-equipment-item','19CD39EBB39080CB');assert($('removal-equipment-apply').disabled);
 $('removal-unequipped').checked=true;await $('removal-unequipped').fire('change');assert(!$('removal-equipment-apply').disabled);await $('removal-equipment-apply').click();assert($('error').hidden,$('error').textContent);
 let exported=api.exportBytes();assert.deepEqual(exported.bytes,plan.patch(bytes,[{slot,type:rem.EQUIPMENT,id:'19CD39EBB39080CB',confirmUnequipped:true}]).bytes);api.chooseView('changes');assert.equal($('change-count').textContent,'1 alteração');assert($('changes-body').innerHTML.includes('Removido'));
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.18.0');assert.equal(report.changes[0].type,rem.EQUIPMENT);await $('reset-changes').click();assert.throws(()=>api.exportBytes());
 api.chooseView('enchantments');await set('removal-enchantment-item',226);assert(!$('removal-enchantment-apply').disabled);await $('removal-enchantment-apply').click();assert($('error').hidden,$('error').textContent);exported=api.exportBytes();assert.deepEqual(exported.bytes,plan.patch(bytes,[{slot,type:rem.ENCHANTMENT,id:'enchantment-226',uid:226}]).bytes);
 await $('export-top').click();assert.deepEqual(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),exported.bytes);await $('reset-changes').click();api.chooseView('equipment');await set('inventory-kind','chest');await set('removal-equipment-item','503DAAC6C42CC83D');assert.match($('removal-equipment-note').textContent,/3 encantamentos/);
 $('removal-unequipped').checked=true;await $('removal-unequipped').fire('change');await $('removal-equipment-apply').click();assert($('error').hidden,$('error').textContent);assert.equal(api.exportBytes().log[0].releasedUids.length,3);
 fs.writeFileSync('VERIFICACAO_INTERFACE_0_18_0.json',JSON.stringify({version:core.VERSION,passed:true,builtHtmlExecuted:true,selectionAndUnequippedConfirmationPassed:true,equipmentAndEnchantmentActionsMatchWriter:true,reviewAndResetAndReportAndExportPassed:true,releaseThreeEnchantmentsVisible:true},null,2));console.log('UI verification passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
