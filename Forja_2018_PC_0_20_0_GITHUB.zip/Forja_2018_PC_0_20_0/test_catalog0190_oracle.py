"""Conferência independente dos três lotes reais, sem ler ou executar JS."""
from pathlib import Path
import ast
import struct
import json
import hashlib

WS=Path(__file__).resolve().parent.parent
PROJECT=Path(__file__).resolve().parent
source=ast.parse((PROJECT/'test_clone_native_reader.py').read_text())
fn=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='parse')
env={'struct':struct,'HEADER':4160,'SLOT':1677512,'START':0x10400,'SIZE':33554400}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<independent-python>','exec'),env)

def roots(b,s):
    at=s['row_end']+len(s['refs']);records=[]
    for _ in range(struct.unpack_from('<I',b,s['start']+25)[0]):
        begin=at;uid=struct.unpack_from('<I',b,at+48)[0];at+=72
        for _ in range(2):
            n=struct.unpack_from('<I',b,at)[0];at+=4+4*n
        n=struct.unpack_from('<I',b,at)[0];at+=4+12*n
        records.append((uid,b[begin:at]))
    return records,b[at:s['start']+9+struct.unpack_from('<I',b,s['start']+5)[0]]

profiles=json.loads((PROJECT/'data/enchantment-acquisition.json').read_text())['profiles']
patterns=[]
for model in profiles:
    raw=bytearray.fromhex(model['raw']);raw[8:16]=b'\0'*8
    raw[48:52]=b'\0'*4;raw[52:60]=b'\xff'*8
    patterns.append((model['id'],bytes(raw)))

pairs=[
    ('entrega_encantamentos_02/ENC_02_CONTROLE_Normal.sav','analysis_0_19_0/testes/CATALOGO_1.sav'),
    ('upload/game(MarcaPerfeitaDoTYR+SETCOMPLETODOTYR).sav','analysis_0_19_0/testes/CATALOGO_2.sav'),
    ('upload/game(NGP_01_ARMAS_MAXIMAS(Funcionou)).sav','analysis_0_19_0/testes/CATALOGO_3.sav'),
]
results=[]
for before,after in pairs:
    b=(WS/before).read_bytes();n=(WS/after).read_bytes()
    slot=max(range(20),key=lambda i:struct.unpack_from('<Q',b,4160+i*1677512)[0])
    env['SLOT_INDEX']=slot;a=env['parse'](b);z=env['parse'](n)
    ar,ag=roots(b,a);zr,zg=roots(n,z);zm=dict(zr)
    assert ag==zg
    for uid,raw in ar:assert zm[uid]==raw
    added=[(uid,raw) for uid,raw in zr if uid not in dict(ar)]
    for uid,raw in added:
        norm=bytearray(raw);norm[48:52]=b'\0'*4
        models=[id for id,pattern in patterns if pattern==bytes(norm)]
        assert len(models)==1,(uid,models)
    assert a['frames']==z['frames'] and a['refs']==z['refs']
    base=a['base']
    assert b[:base+0x124]==n[:base+0x124]
    assert b[base+0x128:a['start']]==n[base+0x128:a['start']]
    assert b[base+1677512:]==n[base+1677512:]
    assert len(z['finals'][4:])//16<=512
    results.append({'file':after,'slot':slot+1,'addedRoots':len(added),
        'allNewRootsExactlyMatchFullNativeCatalogModel':True,
        'existingRootsGroupsReferencesMapsWorldOtherSlotsPreserved':True,
        'sha256':hashlib.sha256(n).hexdigest()})
    print(after,'OK',len(added),'novas instâncias')

report={'passed':True,'version':'0.19.0','independentPythonGrammar':True,
    'cases':results,'noJavaScriptReaderOrWriterUsed':True,
    'gameTestOfNewCatalogPending':True}
(PROJECT/'VERIFICACAO_INDEPENDENTE_0_19_0.json').write_text(json.dumps(report,indent=2)+'\n')
