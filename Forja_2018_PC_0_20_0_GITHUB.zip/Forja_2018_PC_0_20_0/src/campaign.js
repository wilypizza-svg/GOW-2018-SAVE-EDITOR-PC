/* Campos ligados às amostras PC de outubro/2026. Perfis explícitos;
   não generaliza aquisição de uma peça para todo o catálogo. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./resource-edit.js'),require('./native-records.js'),require('./compatibility.js'));
  else root.Forja2018Campaign=factory(root.Forja2018,root.Forja2018Resources,root.Forja2018NativeRecords,root.Forja2018Compatibility);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,resources,native,compat){
  'use strict';
  const fail=m=>{throw new Error(m);};
  const APPLES=Object.freeze({piece:'8EC8B40DE6B3AC68',menu:'2085C71C79E4ED7E',card:'B42DDFD1FBD3ED7E',upgrades:'D6833365C3296802'});
  const HORNS=Object.freeze({piece:'E54B545124A5891E',menu:'89DADD432CFF222C',card:'1B7F1BA84084222C',upgrades:'1AEEE86352596537'});
  const STONES=Object.freeze(['DA0A900B4A8A614B','CB0E900B4A8A614B','3832900B4A8A614B']);
  const STONE_FLAG='024373073A80CFB5',STONE_REF='101A353D83F1212E',USED_REF='CE0BFA08B3CE47F9';
  const CHESTS=Object.freeze([{id:'41C19E30CAE5761D',key:613,name:'Metal-Plated Shoulder Guard'},
    {id:'EEA7E31201646AAF',key:607,name:'Defender’s Cuirass'}]);
  const GAUNTLETS=Object.freeze({id:'C3BB0F4EA2814358',key:650,name:'Gauntlets of the Ancients',ref:'1A471745F887768B',anchor:'4305393E4800FED9'});
  const TYPES=Object.freeze(['difficulty','idunn-apples','blood-mead-horns','superior-stone','berserker-stone','equip-chest','acquire-ancients-wrist']);
  function totals(slot,ids){
    try{
      const values={},missing=[];
      for(const [key,id]of Object.entries(ids)){
        const rows=slot.rows.filter(r=>r.id===id);
        if(rows.length>1)fail('Um dos contadores de coleta está repetido.');
        if(!rows.length){
          compat.requireSlot(slot,'Contadores de vida e fúria');
          values[key]=0;missing.push(key);
        }else values[key]=rows[0].quantity;
      }
      const total=values.card;
      if(!Number.isInteger(total)||total>9||values.menu!==total||values.upgrades!==Math.floor(total/3)||
        values.piece!==total%3&&!(total===9&&values.piece===3))fail('Os contadores de coleta divergem; edição bloqueada neste slot.');
      return {available:true,total,...values,missing,inferredZeroCounters:missing.length};
    }catch(e){return {available:false,total:null,reason:e.message};}
  }
  function difficulty(input,index,parsed){
    const bytes=native.bytesOf(input),model=parsed||core.parse(bytes),slot=model.slots[index];
    if(!slot?.available)return {available:false,reason:'Escolha um slot.'};
    const a=native.view(bytes).getUint32(slot.base+0x110,true),b=bytes[slot.base+0x10402];
    const known=({1:'Give Me a Balanced Experience',2:'Give Me a Challenge'})[a];
    return {available:a===b&&!!known,code:a,label:a!==b?'Campos divergentes':known||'Dificuldade não identificada',
      reason:a!==b?'Os dois campos de dificuldade divergem.':known?'':'A amostra nominal deste código ainda não foi fornecida.'};
  }
  function equipmentState(input,index,parsed){
    try{
      const tx=native.read(input,index,parsed),active=CHESTS.filter(p=>native.mapEntry(tx,1,p.key));
      if(active.length!==1)fail('O peitoral ativo não corresponde aos dois perfis de troca mapeados.');
      const entry=native.mapEntry(tx,1,active[0].key),dv=native.view(entry),level=dv.getUint32(4,true);
      if(entry[8]!==1||!native.mapEntry(tx,0,active[0].key)||native.view(native.mapEntry(tx,0,active[0].key)).getUint32(4,true)!==level||native.quantity(tx,active[0].id)!==1)fail('Os registros do peitoral ativo divergem.');
      const choices=CHESTS.filter(p=>native.quantity(tx,p.id)===1&&native.mapEntry(tx,0,p.key)&&native.view(native.mapEntry(tx,0,p.key)).getUint32(4,true)<=2);
      return {available:true,current:active[0],choices};
    }catch(e){return {available:false,choices:[],reason:e.message};}
  }
  function stoneState(input,index,parsed){
    try{
      const tx=native.read(input,index,parsed),counts=STONES.map(id=>native.quantity(tx,id)||0),flag=native.quantity(tx,STONE_FLAG);
      if(![0,1].includes(flag)||counts.some(n=>![0,1].includes(n))||counts.reduce((a,b)=>a+b,0)>1||
        flag!==(counts.some(Boolean)?0:1))fail('O estado da pedra e da flag não é consistente.');
      if(native.quantity(tx,'928D43976BD3AC87')!==1)fail('A introdução da ressurreição ainda não está registrada.');
      if(counts[0]||counts[2])fail('Já há uma pedra simples ou berserker. A troca entre tipos ainda não foi mapeada.');
      return {available:true,owned:counts[1]===1};
    }catch(e){return {available:false,owned:false,reason:e.message};}
  }
  function acquisitionState(input,index,parsed){
    try{
      const tx=native.read(input,index,parsed),count=native.quantity(tx,GAUNTLETS.id);
      if(count===1)return {available:true,owned:true};
      if(count!==null||native.mapEntry(tx,0,GAUNTLETS.key)||native.unique(tx.refs,GAUNTLETS.ref)||native.unique(tx.finals,GAUNTLETS.id)||native.unique(tx.finals,GAUNTLETS.ref))fail('Há registros parciais da braçadeira; inclusão bloqueada.');
      native.unique(tx.refs,GAUNTLETS.anchor,true);
      return {available:true,owned:false};
    }catch(e){return {available:false,owned:false,reason:e.message};}
  }
  function berserkerState(input,index,parsed){
    try{
      const tx=native.read(input,index,parsed),counts=STONES.map(id=>native.quantity(tx,id)||0),flag=native.quantity(tx,STONE_FLAG);
      compat.requireNative(tx,'Pedra berserker');
      if(counts[2]===1&&counts[0]===0&&counts[1]===0&&flag===0)return {available:true,owned:true};
      if(counts.some(Boolean)||flag!==1)fail('Já há outra pedra ou os contadores divergem. Use a pedra no jogo antes de adicionar outra.');
      if(native.quantity(tx,'928D43976BD3AC87')!==1)fail('A introdução da ressurreição ainda não foi registrada.');
      const purchase=native.unique(tx.finals,'9CACC83BC2F1FDD4'),stock=native.unique(tx.rows,STONES[2]);
      let restock=false;
      if(purchase||native.unique(tx.refs,'9CACC83BC2F1FDD4')||native.unique(tx.finals,STONES[2])){
        if(!stock||counts[2]!==0||native.unique(tx.refs,'9CACC83BC2F1FDD4')||native.unique(tx.finals,STONES[2])||
          !purchase||core.hex(purchase.subarray(8))!=='01000000F27F0000')fail('O estado de consumo da pedra berserker não corresponde à reposição mapeada.');
        restock=true;
      }
      native.unique(tx.refs,'56A01A0AAF5B1BD4',true);
      return {available:true,owned:false,restock};
    }catch(e){return {available:false,owned:false,reason:e.message};}
  }
  function inspect(input,index,parsed){
    const bytes=native.bytesOf(input),model=parsed||core.parse(bytes),slot=model.slots[index];
    if(!slot?.available)return {available:false,reason:'Escolha um slot reconhecido.'};
    try{compat.requireNative(native.read(bytes,index,model),'Campanha e inventário');}
    catch(e){return {available:false,reason:e.message};}
    return {available:true,difficulty:difficulty(bytes,index,model),apples:totals(slot,APPLES),horns:totals(slot,HORNS),
      equipment:equipmentState(bytes,index,model),stone:stoneState(bytes,index,model),berserker:berserkerState(bytes,index,model),acquisition:acquisitionState(bytes,index,model)};
  }
  function scalar(input,index,fields){
    const bytes=native.bytesOf(input),output=bytes.slice(),dv=native.view(output),allowed=new Set();
    for(const f of fields){
      if(!Number.isInteger(f.offset)||![1,4].includes(f.width)||f.offset<0||f.offset+f.width>bytes.length)fail('Campo inválido.');
      if(f.width===1)dv.setUint8(f.offset,f.value);else dv.setUint32(f.offset,f.value,true);
      for(let p=f.offset;p<f.offset+f.width;p++)allowed.add(p);
    }
    for(let p=0;p<bytes.length;p++)if(bytes[p]!==output[p]&&!allowed.has(p))fail('Um campo externo foi alterado.');
    const model=core.parse(output);if(!resources.inspect(output,index,model).available)fail('A releitura do slot não confere.');
    return {bytes:output,model};
  }
  function patch(input,requests=[]){
    const original=native.bytesOf(input),originalModel=core.parse(original),seen=new Set();
    if(!Array.isArray(requests))fail('Plano de campanha inválido.');
    for(const r of requests){
      if(!r||!TYPES.includes(r.type)||r.id!==r.type||!Number.isInteger(r.slot)||!originalModel.slots[r.slot]?.available)fail('Pedido de campanha inválido.');
      const key=r.slot+':'+r.type;if(seen.has(key))fail('Há dois pedidos para o mesmo campo.');seen.add(key);
    }
    let bytes=original;const log=[],layout=[];
    for(const r of requests){
      const model=core.parse(bytes),slot=model.slots[r.slot];let before,after,name,output;
      compat.requireNative(native.read(bytes,r.slot,model),'Campanha e inventário');
      if(r.type==='difficulty'){
        const state=difficulty(bytes,r.slot,model);
        if(!state.available||![1,2].includes(r.code))fail(state.reason||'Escolha Balanced Experience ou Challenge.');
        if(state.code===r.code)continue;
        before=state.label;after=r.code===1?'Give Me a Balanced Experience':'Give Me a Challenge';name='Dificuldade';
        output=scalar(bytes,r.slot,[{offset:slot.base+0x110,width:4,value:r.code},{offset:slot.base+0x10402,width:1,value:r.code}]);
        if(difficulty(output.bytes,r.slot,output.model).code!==r.code)fail('Os campos de dificuldade não conferem.');
      }else if(r.type==='idunn-apples'||r.type==='blood-mead-horns'){
        const ids=r.type==='idunn-apples'?APPLES:HORNS,state=totals(slot,ids);
        if(!state.available||!Number.isInteger(r.total)||r.total<0||r.total>9)fail(state.reason||'Informe de 0 a 9 maçãs.');
        if(r.total===state.total)continue;
        const values={piece:r.total%3,menu:r.total,card:r.total,upgrades:Math.floor(r.total/3)};
        if(state.missing.length){
          const tx=native.read(bytes,r.slot,model);
          for(const [key,id]of Object.entries(ids))native.putQuantity(tx,id,values[key],true);
          output=native.write(tx);
        }else output=scalar(bytes,r.slot,Object.entries(ids).map(([key,id])=>({offset:slot.rows.find(x=>x.id===id).valueOffset,width:4,value:values[key]})));
        if(totals(output.model.slots[r.slot],ids).total!==r.total)fail('Os quatro contadores não conferem.');
        before=String(state.total);after=String(r.total);name=(r.type==='idunn-apples'?'Maçãs de Iðunn':'Chifres de hidromel sangrento')+' · quatro contadores';
      }else if(r.type==='equip-chest'){
        const state=equipmentState(bytes,r.slot,model),target=state.choices.find(x=>x.id===r.targetId);
        if(!state.available||!target)fail(state.reason||'O peitoral escolhido não está possuído e mapeado.');
        if(target.id===state.current.id)continue;
        const tx=native.read(bytes,r.slot,model),entry=native.mapEntry(tx,1,state.current.key),frame=tx.state.frames[1],offset=frame.start+2+8+4+tx.maps[1].entries.indexOf(entry)*9;
        const level=native.view(native.mapEntry(tx,0,target.key)).getUint32(4,true);
        output=scalar(bytes,r.slot,[{offset,width:4,value:target.key},{offset:offset+4,width:4,value:level}]);
        if(equipmentState(output.bytes,r.slot,output.model).current?.id!==target.id)fail('O peitoral ativo não confere.');
        before=state.current.name;after=target.name;name='Peitoral equipado';
      }else if(r.type==='berserker-stone'){
        const state=berserkerState(bytes,r.slot,model);if(!state.available)fail(state.reason);if(state.owned)continue;
        const tx=native.read(bytes,r.slot,model);
        native.putQuantity(tx,STONES[2],1,true);native.putQuantity(tx,STONE_FLAG,0);
        native.insertRefAfter(tx,'9CACC83BC2F1FDD4','56A01A0AAF5B1BD4');
        if(!state.restock){native.ensureFinal(tx,STONES[2],'00000000F67F0000');native.ensureFinal(tx,'9CACC83BC2F1FDD4','01000000F27F0000');}
        output=native.write(tx);
        if(!berserkerState(output.bytes,r.slot,output.model).owned)fail('A pedra berserker não foi registrada.');
        before='Sem pedra';after='Pedra berserker · 1';name='Pedra de ressurreição';
      }else if(r.type==='superior-stone'){
        const state=stoneState(bytes,r.slot,model);if(!state.available)fail(state.reason);if(state.owned)continue;
        const tx=native.read(bytes,r.slot,model),used=native.unique(tx.refs,USED_REF);
        if(used){
          if(native.unique(tx.refs,STONE_REF))fail('Há referências de pedra conflitantes.');
          const marker=native.unique(tx.finals,USED_REF,true);
          if(core.hex(marker.subarray(8))!=='0100000000000000')fail('O marcador de consumo não foi reconhecido.');
          tx.refs[tx.refs.indexOf(used)]=native.fromHex(STONE_REF);tx.finals.splice(tx.finals.indexOf(marker),1);
        }else native.insertRefAfter(tx,STONE_REF,'47A41A0AAF5B1BD4');
        native.putQuantity(tx,STONES[1],1,true);native.putQuantity(tx,STONE_FLAG,0);
        native.ensureFinal(tx,STONES[1],'00000000F77F0000');native.ensureFinal(tx,STONE_REF,'01000000F37F0000');
        output=native.write(tx);
        if(!stoneState(output.bytes,r.slot,output.model).owned)fail('A pedra superior não foi registrada.');
        before='Sem pedra';after='Pedra superior · 1';name='Pedra de ressurreição';
      }else{
        const state=acquisitionState(bytes,r.slot,model);if(!state.available)fail(state.reason);if(state.owned)continue;
        const tx=native.read(bytes,r.slot,model);
        native.putQuantity(tx,GAUNTLETS.id,1,true);native.insertRefAfter(tx,GAUNTLETS.ref,GAUNTLETS.anchor);native.addGlobal(tx,GAUNTLETS.key,0);
        native.ensureFinal(tx,GAUNTLETS.id,'00000000F77F0000');native.ensureFinal(tx,GAUNTLETS.ref,'01000000F37F0000');
        native.ensureFinal(tx,'5395046D84ED7B28','0300000000000000');output=native.write(tx);
        if(!acquisitionState(output.bytes,r.slot,output.model).owned)fail('A aquisição da braçadeira não confere.');
        before='Ausente';after='Adicionada · peça base';name=GAUNTLETS.name;
      }
      bytes=output.bytes;
      if(output.layout)layout.push({...output.layout,operation:r.type});
      log.push({type:r.type,id:r.id,slot:r.slot+1,slotIndex:r.slot,name,before:null,after:1,beforeLabel:before,afterLabel:after,experimental:true});
    }
    if(!native.equal(original.subarray(0,core.HEADER_SIZE),bytes.subarray(0,core.HEADER_SIZE)))fail('O cabeçalho global foi alterado.');
    const affected=new Set(requests.map(r=>r.slot));for(const s of originalModel.slots)if(!affected.has(s.index)&&!native.equal(original.subarray(s.base,s.end),bytes.subarray(s.base,s.end)))fail('Um slot não selecionado foi alterado.');
    return {bytes,model:core.parse(bytes),log,layout,validation:{campaignChanges:log.length,campaignInGameTested:false,
      currentRageEdited:false,currentHealthEdited:false,ngpMenuUnlockEdited:false,unmappedEquipmentAcquisitionEnabled:false}};
  }
  return Object.freeze({APPLES,HORNS,STONES,CHESTS,GAUNTLETS,TYPES,totals,difficulty,inspect,equipmentState,stoneState,berserkerState,acquisitionState,patch});
});
