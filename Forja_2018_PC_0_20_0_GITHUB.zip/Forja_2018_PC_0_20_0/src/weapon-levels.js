/* Sincroniza os mapas e a propriedade do mundo quando presente. Lâminas
   adquiridas e coerentes podem receber as etapas mapeadas sem criar uma
   propriedade de mundo ausente. O reconhecimento anterior do NG+ é mantido. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('../data/weapon-profiles.json'),require('./compatibility.js'),require('./blades-unlock.js'));
 else root.Forja2018WeaponLevels=factory(root.Forja2018,root.Forja2018NativeRecords,JSON.parse(document.getElementById('weapon-data').textContent),root.Forja2018Compatibility,root.Forja2018BladesUnlock);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,data,compat,bladesUnlock){
 'use strict';
 const TYPE='weapon-level',PROFILES=Object.freeze(data.profiles),byId=new Map(PROFILES.map(p=>[p.id,p]));
 const fail=m=>{throw new Error(m);},value=r=>r?native.view(r).getUint32(4,true):null;
 function ngpReferenceState(tx,p,marker,highest){
  const property=marker.subarray(8),occurrences=[];
  for(let at=tx.slot.base,stop=tx.slot.end-property.length;at<=stop;at++)if(tx.bytes[at]===property[0]&&native.equal(tx.bytes.subarray(at,at+property.length),property))occurrences.push(at);
  if(!occurrences.length)return {available:highest===p.max,partial:false};
  const rule=data.ngpPartialHistory?.profiles[p.id];if(!rule||highest<rule.minimumRegistered||occurrences.length!==rule.referenceWindows.length)return {available:false,partial:false};
  const unmatched=new Set(rule.referenceWindows);
  for(const at of occurrences){
   if(at<tx.slot.base+0x400||at+32>tx.slot.base+0x10400)return {available:false,partial:false};
   const context=core.hex(tx.bytes.subarray(at-16,at+32));if(!unmatched.delete(context))return {available:false,partial:false};
  }
  return {available:unmatched.size===0,partial:unmatched.size===0};
 }
 function earlyBladesState(tx,p,marker,highest){
  if(p.id!=='blades-main-level'||!bladesUnlock.mapsOnlyReady(tx))return false;
  if(['5343978C802835DB','DBC20322187668AD'].some(id=>{const q=native.quantity(tx,id);return q!==null&&q!==0;}))return false;
  const property=marker.subarray(8);
  for(let at=tx.slot.base,stop=tx.slot.end-property.length;at<=stop;at++)if(tx.bytes[at]===property[0]&&native.equal(tx.bytes.subarray(at,at+property.length),property))return false;
  const recipes=highest===1?[p.recipeReferenceIds[0]]:p.steps.find(step=>step.level===highest)?.recipeRefs;
  return !!recipes&&recipes.every(id=>native.unique(tx.refs,id));
 }
 function read(input,index,id,parsed){
  const p=byId.get(id);if(!p)fail('Arma principal fora do catálogo.');
  const tx=native.read(input,index,parsed);
  compat.requireNative(tx,'Progressão das armas principais');
  const global=native.mapEntry(tx,0,p.key),stored=native.mapEntry(tx,1,p.key),raw=value(global);
  if(p.id==='blades-main-level'&&!global&&!stored&&p.history.every(id=>{const q=native.quantity(tx,id);return q===null||q===0;}))fail('Este slot ainda não possui as Lâminas do Caos. Use Adicionar Lâminas ao inventário para liberar a escolha de nível.');
  if(!global||!stored||stored[8]!==1||value(stored)!==raw||raw<0||raw>=p.max)fail('Os mapas da arma estão ausentes ou divergem. A arma precisa estar liberada no jogo.');
  let highest=1,gap=false;
  for(let k=0;k<p.history.length;k++){
   const q=native.quantity(tx,p.history[k]);
   if(q===1){if(gap)fail('O histórico da arma possui uma melhoria sem as anteriores.');highest=k+2;}
   else if(q===null||q===0)gap=true;else fail('A flag de melhoria da arma é inválida.');
  }
  const current=raw+1;if(current>highest)fail('O nível da arma ultrapassa o histórico registrado.');
  const marker=native.fromHex(p.sceneMarker),fields=[];
  for(let at=tx.slot.base+0x400,stop=tx.slot.base+0x10400-marker.length-4;at<=stop;at++){
   if(tx.bytes[at]===marker[0]&&native.equal(tx.bytes.subarray(at,at+marker.length),marker))fields.push(at+marker.length);
  }
  let sceneOffset=fields[0]??null,sceneMode='world-and-maps',partialHistoryMapped=false;
  if(fields.length===0&&native.quantity(tx,'5343978C802835DB')===1&&native.quantity(tx,'DBC20322187668AD')===1){
   // Cada ocorrência isolada precisa pertencer a um contexto observado no
   // teste e no retorno nativo. Uma referência extra ou deslocada é rejeitada.
   const ngp=ngpReferenceState(tx,p,marker,highest);if(ngp.available){sceneMode='ngp-maps-only';partialHistoryMapped=ngp.partial;}
  }
  if(fields.length===0&&sceneMode==='world-and-maps'&&earlyBladesState(tx,p,marker,highest))sceneMode='blades-maps-only';
  if(fields.length!==1&&!['ngp-maps-only','blades-maps-only'].includes(sceneMode)){
   const message=p.id==='axe-main-level'&&current===1&&!fields.length?'Faça o primeiro upgrade do Machado no jogo. O registro secundário ainda não existe neste save; as etapas seguintes podem ser ajustadas pelo editor.':'A propriedade secundária da arma está ausente ou repetida.';
   const error=new Error(message);
   if(!fields.length)error.recognizedLevel={current,registeredMax:highest};
   throw error;
  }
  if(sceneOffset!==null&&native.view(tx.bytes).getUint32(sceneOffset,true)!==raw)fail('A propriedade secundária e os mapas da arma divergem.');
  return {tx,profile:p,current,registeredMax:highest,sceneOffset,sceneMode,partialHistoryMapped};
 }
 function inspect(input,index,id,parsed){
  try{
   const s=read(input,index,id,parsed),p=s.profile;
   return {available:true,profile:p,current:s.current,registeredMax:s.registeredMax,currentLabel:'Nível '+s.current,
    registeredLabel:'Nível '+s.registeredMax,sceneMode:s.sceneMode,ngpMapsOnly:s.sceneMode==='ngp-maps-only',earlyBladesMapsOnly:s.sceneMode==='blades-maps-only',partialHistoryMapped:s.partialHistoryMapped,options:Array.from({length:p.max},(_,k)=>({value:k+1,label:'Nível '+(k+1),available:s.sceneMode!=='ngp-maps-only'||s.partialHistoryMapped||k+1<=s.registeredMax,
      mode:k+1<=s.registeredMax?'registered':'mapped-upgrade'})),reason:''};
  }catch(e){return {available:false,recognized:!!e.recognizedLevel,profile:byId.get(id)||null,current:e.recognizedLevel?.current??null,registeredMax:e.recognizedLevel?.registeredMax??null,currentLabel:e.recognizedLevel?'Nível '+e.recognizedLevel.current:null,options:[],reason:e.message};}
 }
 function patch(input,requests=[]){
  const original=native.bytesOf(input),originalModel=core.parse(original),seen=new Set();
  if(!Array.isArray(requests))fail('Plano de armas principais inválido.');
  for(const r of requests){
   const p=r&&byId.get(r.id);
   if(!p||r.type!==TYPE||!Number.isInteger(r.slot)||!originalModel.slots[r.slot]?.available||!Number.isInteger(r.level)||r.level<p.min||r.level>p.max)fail('Escolha uma arma liberada, um slot e um nível válido.');
   const key=r.slot+':'+r.id;if(seen.has(key))fail('Há dois níveis para a mesma arma.');seen.add(key);
  }
  let bytes=original;const log=[],layout=[];
  for(const r of requests){
   const s=read(bytes,r.slot,r.id),tx=s.tx,p=s.profile;if(r.level===s.current)continue;
   const newlyRegistered=r.level>s.registeredMax;
   if(newlyRegistered){
    for(let level=s.registeredMax+1;level<=r.level;level++){
     const step=p.steps.find(x=>x.level===level);if(!step)fail('Uma transição da arma ainda não foi mapeada.');
     let row=native.unique(tx.rows,step.id);
     if(!row){row=native.fromHex(step.row);native.view(row).setUint32(12,tx.rows.length,true);tx.rows.push(row);}
     else native.view(row).setUint32(8,1,true);
     if(!native.unique(tx.finals,step.id))native.ensureFinal(tx,step.id,step.metadata);
     for(const ref of step.refs){
      if(!native.unique(tx.refs,ref.id))tx.refs.push(native.fromHex(ref.id));
      if(ref.metadata&&!native.unique(tx.finals,ref.id))native.ensureFinal(tx,ref.id,ref.metadata);
     }
    }
    const last=p.steps.find(x=>x.level===r.level),managed=new Set(p.recipeReferenceIds);
    tx.refs=tx.refs.filter(row=>!managed.has(native.idOf(row))||last.recipeRefs.includes(native.idOf(row)));
    for(const id of last.recipeRefs)if(!native.unique(tx.refs,id))tx.refs.push(native.fromHex(id));
   }
   native.view(native.mapEntry(tx,0,p.key)).setUint32(4,r.level-1,true);
   native.view(native.mapEntry(tx,1,p.key)).setUint32(4,r.level-1,true);
   const next=native.write(tx);if(s.sceneOffset!==null)native.view(next.bytes).setUint32(s.sceneOffset,r.level-1,true);
   const verified=read(next.bytes,r.slot,r.id);
   if(verified.current!==r.level||verified.registeredMax!==Math.max(s.registeredMax,r.level))fail('A releitura da progressão da arma não confere.');
   bytes=next.bytes;layout.push({...next.layout,operation:TYPE});
   log.push({type:TYPE,id:p.id,slot:r.slot+1,slotIndex:r.slot,name:p.name+' · nível',before:s.current,after:r.level,
    beforeLabel:'Nível '+s.current,afterLabel:'Nível '+r.level,registeredMaxBefore:s.registeredMax,registeredMaxAfter:verified.registeredMax,
    historyPreserved:true,materialsPreserved:true,synchronizedLevelFields:s.sceneOffset===null?2:3,sceneMode:s.sceneMode,worldPropertyCreated:false,experimental:true});
  }
  const affected=new Set(requests.map(r=>r.slot));
  if(!native.equal(original.subarray(0,core.HEADER_SIZE),bytes.subarray(0,core.HEADER_SIZE)))fail('O cabeçalho geral foi alterado.');
  for(const s of originalModel.slots)if(!affected.has(s.index)&&!native.equal(original.subarray(s.base,s.end),bytes.subarray(s.base,s.end)))fail('Um slot não escolhido foi alterado.');
  return {bytes,model:core.parse(bytes),log,layout,validation:{weaponChanges:log.length,weaponHistoryPreserved:true,currentHealthEdited:false,currentRageEdited:false,inGameTestedHere:false}};
 }
 return Object.freeze({TYPE,PROFILES,inspect,patch});
});
