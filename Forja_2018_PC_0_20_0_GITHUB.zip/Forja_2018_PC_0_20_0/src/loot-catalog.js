/* Metadados da tabela fornecida. Não muda a lista de gravação de recursos.
   PERM_Hash é convertido para ordem literal; INV_Hash e Index ficam separados. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./catalog.js'), require('../data/loot-table.json'));
  else root.Forja2018Loot = factory(root.Forja2018Catalog, JSON.parse(document.getElementById('loot-data').textContent));
})(typeof globalThis !== 'undefined' ? globalThis : this, function (base, data) {
  'use strict';
  const metadata = new Map(data.items.map(item => [item.id, Object.freeze({ ...item, sourceRows: Object.freeze([...item.sourceRows]) })]));
  const normalize = base.normalize;
  const items = base.items.map(item => {
    const loot = metadata.get(item.id);
    if (!loot || loot.internalName !== item.internalName.trim()) return item;
    const enriched = !item.hasCleanName && !!loot.gameName;
    return Object.freeze({ ...item, ...(enriched ? { name: loot.gameName, originalName: loot.gameName, hasCleanName: true, nameSource: 'loot-table' } : {}), loot });
  });
  const ids = new Set(items.map(item => item.id));
  for (const loot of data.items) if (!ids.has(loot.id)) {
    items.push(Object.freeze({ id: loot.id, name: loot.gameName || loot.internalName, originalName: loot.gameName || loot.internalName,
      internalName: loot.internalName, category: 'Receitas · consulta', sourceType: loot.subCategory || '',
      hasCleanName: !!loot.gameName, editable: false, provisional: false, controlledPcPair: false, nameSource: 'loot-table', loot: metadata.get(loot.id) }));
    ids.add(loot.id);
  }
  items.sort((a, b) => a.id.localeCompare(b.id));
  const byId = new Map(items.map(item => [item.id, item]));
  const search = new Map(items.map(item => [item.id, normalize([item.name, item.originalName, item.internalName, item.id, item.category,
    base.lookup(item.id)?.name, item.loot?.inventoryHash, item.loot?.set, item.loot?.rarity].join(' '))]));
  const catalog = Object.freeze({ ...base, items: Object.freeze(items), lookup: id => byId.get(String(id).toUpperCase()) || null,
    matches: (id, query) => !query || (search.get(id) || normalize(id)).includes(normalize(query)),
    categories: Object.freeze([...new Set(items.map(item => item.category))].sort((a, b) => a.localeCompare(b, 'pt-BR'))) });
  function summary(id) {
    const loot = metadata.get(String(id).toUpperCase());
    if (!loot) return '';
    return [loot.rarity, loot.level !== undefined ? 'Nível na tabela: ' + loot.level : '', loot.sockets !== undefined ? 'Encaixes na tabela: ' + loot.sockets : ''].filter(Boolean).join(' · ');
  }
  return Object.freeze({ catalog, lookup: id => metadata.get(String(id).toUpperCase()) || null, summary,
    sourceFile: data.sourceFile, sourceSha256: data.sourceSha256, metadataCount: metadata.size });
});
