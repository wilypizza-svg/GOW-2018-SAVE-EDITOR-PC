(function () {
  'use strict';
  const core = window.Forja2018, catalog = window.Forja2018Loot.catalog, resources = window.Forja2018Wallet, policy = window.Forja2018ResourcePolicy, slotCore = window.Forja2018Slots, campaign = window.Forja2018Campaign, attributes = window.Forja2018Attributes, levelCore = window.Forja2018Levels, armorCore = window.Forja2018ArmorLevels, targetCore = window.Forja2018LevelTargets, equipment = window.Forja2018Equipment, writer = window.Forja2018Plan, $ = id => document.getElementById(id);
  const inventory = window.Forja2018Inventory, selection = window.Forja2018InventorySelection;
  const removal = window.Forja2018Removal;
  const weaponCore = window.Forja2018WeaponLevels, ciphers = window.Forja2018Ciphers, bladesUnlock = window.Forja2018BladesUnlock;
  const levelApi = id => weaponCore.PROFILES.some(p=>p.id===id) ? weaponCore : targetCore;
  const INVENTORY_KINDS = {chest:'Peitorais',wrist:'Braçadeiras',waist:'Cinturas',axe:'Pomos do machado',blades:'Cabos das lâminas',talisman:'Talismãs','axe-runics-all':'Todos os rúnicos · machado','blades-runics-all':'Todos os rúnicos · lâminas','axe-runic-light':'Rúnicos leves · machado','axe-runic-heavy':'Rúnicos pesados · machado','blades-runic-light':'Rúnicos leves · lâminas','blades-runic-heavy':'Rúnicos pesados · lâminas','axe-runic':'Rúnicos · machado · tipo a confirmar','blades-runic':'Rúnicos · lâminas · tipo a confirmar'};
  const fmt = value => new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 }).format(value);
  const escape = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  const date = seconds => new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'medium' }).format(new Date(seconds * 1000));
  const normalize = text => String(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  let original = null, model = null, result = null, selected = null, changes = [], page = 'slots', recordPage = 0, catalogPage = 0, equipmentPage = 0;
  let armorProfileId = armorCore.PROFILE.id;
  let sourceBytes = null, sourceFilename = 'game.sav', importSource = null, enchantmentDonor = null;
  function notify(message) {
    $('toast').textContent = message; $('toast').hidden = false;
    setTimeout(() => { $('toast').hidden = true; }, 4200);
  }
  function error(message = '') {
    $('error').textContent = message; $('error').hidden = !message;
    $('export-top').disabled = !!message || !result?.log.length;
  }
  function chooseView(name) {
    page = name;
    document.querySelectorAll('[data-view]').forEach(button => button.classList.toggle('active', button.dataset.view === name));
    document.querySelectorAll('[data-page]').forEach(section => { section.hidden = section.dataset.page !== name; });
    const withoutFile = ['help', 'catalog', 'equipment'].includes(name);
    $('welcome').hidden = !!model || withoutFile; $('editor').hidden = !model && !withoutFile;
    document.querySelector('.file-summary').hidden = !model;
    document.querySelector('.notice').hidden = !model;
    document.querySelector('.status-bar').hidden = !model;
    $('selected-summary').hidden = selected === null || !model || name === 'slots';
  }
  function quantity(slot, id, edited = true) {
    return (edited ? result.model : model).slots[slot].rows.find(row => row.id === id)?.quantity;
  }
  function renderSlots() {
    const working = result.model;
    $('slot-count').textContent = working.supported + ' de ' + core.SLOT_COUNT + ' slots reconhecidos · mais recentes primeiro';
    $('slots-body').innerHTML = slotCore.ordered(working).map(slot => {
      const pending = changes.some(change => change.slot === slot.index), latest = slot.index === working.latestSlot;
      return `<tr class="${pending ? 'slot-pending' : latest ? 'slot-latest' : slot.empty ? 'slot-empty' : ''}"><td><strong>${slot.number}</strong>${latest ? '<small>Mais recente</small>' : ''}${pending ? '<small>Alteração pendente</small>' : ''}${selected === slot.index ? '<small>Selecionado</small>' : ''}</td><td>${escape(slot.title || (slot.empty ? 'Vazio' : 'Não reconhecido'))}<small>${slot.available ? 'Itens NG+: ' + (slot.ngpItemsPresent ? 'presentes' : 'não encontrados') + ' · ' + escape(campaign.difficulty(result.bytes, slot.index, working).label) : escape(slot.reason)}</small></td><td>${slot.available ? escape(date(slot.timestamp)) : '—'}</td><td>${slot.available ? fmt(quantity(slot.index, core.FIELDS[1].id)) : '—'}</td><td>${slot.available && quantity(slot.index, 'FCC6B87B4C8E41DC') !== undefined ? fmt(quantity(slot.index, 'FCC6B87B4C8E41DC')) : '—'}</td><td><div class="slot-actions"><button class="button ghost" data-select-slot="${slot.index}" ${slot.available ? '' : 'disabled'}>Editar</button><button class="text-button" data-extract-slot="${slot.index}" ${slot.available ? '' : 'disabled'}>Extrair</button><button class="text-button" data-delete-slot="${slot.index}" ${slot.available ? '' : 'disabled'}>Excluir da cópia</button></div></td></tr>`;
    }).join('');
    document.querySelectorAll('[data-select-slot]').forEach(button => button.addEventListener('click', () => { try { selectSlot(Number(button.dataset.selectSlot)); } catch (e) { error(e.message); } }));
    document.querySelectorAll('[data-extract-slot]').forEach(button => button.addEventListener('click', () => {
      try { const extracted = slotCore.extract(result.bytes, Number(button.dataset.extractSlot)); download(extracted.bytes, extracted.filename); } catch (e) { error(e.message); }
    }));
    document.querySelectorAll('[data-delete-slot]').forEach(button => button.addEventListener('click', () => {
      try { const index = Number(button.dataset.deleteSlot); commit([...changes.filter(change => change.slot !== index), { slot: index, id: 'subsave', type: 'slot-delete' }], selected === index ? null : selected); notify('Exclusão preparada na cópia. Você pode desfazer na revisão.'); } catch (e) { error(e.message); }
    }));
    const previous = $('slot-import-destination').value;
    $('slot-import-destination').innerHTML = working.slots.filter(slot => slot.available || slot.empty).map(slot => `<option value="${slot.index}">Slot ${slot.number} · ${escape(slot.title || 'Vazio')}</option>`).join('');
    $('slot-import-destination').value = working.slots.some(slot => String(slot.index) === previous && (slot.available || slot.empty)) ? previous : String(working.slots.find(slot => slot.empty)?.index ?? selected ?? 0);
    renderImportPreview();
  }
  function renderImportPreview() {
    $('slot-import-apply').disabled = !importSource || !model;
    const source = importSource?.slots.find(slot => String(slot.index) === $('slot-source-choice').value);
    $('slot-source-preview').textContent = source ? 'Origem: slot ' + source.number + ' · ' + source.title + ' · ' + date(source.timestamp) : 'Escolha um game.sav de origem ou um arquivo .forja-slot extraído.';
  }
  function renderKits() {
    $('kits-controls').hidden = selected === null; $('kits-unavailable').hidden = selected !== null;
    if (selected === null) return;
    const previous = $('kit-choice').value;
    $('kit-choice').innerHTML = policy.KITS.map(kit => `<option value="${kit.id}">${escape(kit.name)}</option>`).join('');
    if (policy.KITS.some(kit => kit.id === previous)) $('kit-choice').value = previous;
    else $('kit-quantity').value = String(policy.KITS[0].suggested);
    renderKitPreview();
  }
  function renderKitPreview() {
    if (selected === null) { $('kit-apply').disabled = true; return; }
    try {
      const kit = policy.KITS.find(kit => kit.id === $('kit-choice').value), text = $('kit-quantity').value.trim(), value = Number(text);
      if (!text) throw new Error('Informe uma quantidade.');
      const requests = policy.buildKit(result.model.slots[selected], kit?.id, value);
      $('kit-preview').textContent = requests.length + ' itens. Itens únicos ficam com total 1. Os outros estoques são elevados até pelo menos o valor escolhido, sem reduzir quantidades maiores.';
      $('kit-apply').disabled = false;
    } catch (e) { $('kit-preview').textContent = e.message; $('kit-apply').disabled = true; }
  }
  function applyQuantities(requests) {
    let candidate = changes;
    for (const request of requests) {
      candidate = candidate.filter(change => change.slot !== request.slot || change.id !== request.id);
      const row = model.slots[request.slot].rows.find(row => row.id === request.id);
      if ((row?.quantity || 0) !== request.quantity) candidate.push(request);
    }
    commit(candidate);
  }
  function renderCampaign() {
    $('cipher-story-warning').textContent = ciphers.STORY_WARNING;
    const state = selected === null ? null : campaign.inspect(result.bytes, selected, result.model);
    $('campaign-controls').hidden = !state?.available;
    $('campaign-unavailable').hidden = !!state?.available;
    if (!state?.available) return;
    $('difficulty-current').textContent = state.difficulty.label;
    $('difficulty-choice').disabled = !state.difficulty.available;
    $('difficulty-apply').disabled = !state.difficulty.available;
    $('difficulty-choice').value = state.difficulty.available ? String(state.difficulty.code) : '1';
    $('difficulty-note').textContent = state.difficulty.available ? 'Balance ↔ Challenge: os dois campos do save são sincronizados.' : state.difficulty.reason;
    $('apples-total').value = state.apples.available ? String(state.apples.total) : '';
    $('apples-total').disabled = !state.apples.available; $('apples-apply').disabled = !state.apples.available;
    $('apples-note').textContent = state.apples.available ? state.apples.total + ' maçãs · ' + state.apples.upgrades + ' melhorias · ' + state.apples.piece + ' fragmentos.' + (state.apples.inferredZeroCounters ? ' Contadores iniciais ausentes equivalem a zero; serão criados ao aplicar um novo total.' : '') : state.apples.reason;
    $('horns-total').value = state.horns.available ? String(state.horns.total) : '';
    $('horns-total').disabled = !state.horns.available; $('horns-apply').disabled = !state.horns.available;
    $('horns-note').textContent = state.horns.available ? state.horns.total + ' chifres · ' + state.horns.upgrades + ' melhorias. Altera a capacidade de fúria.' + (state.horns.inferredZeroCounters ? ' Os contadores iniciais serão criados ao aplicar um novo total.' : '') : state.horns.reason;
    $('stone-apply').disabled = !state.stone.available || state.stone.owned;
    $('stone-note').textContent = state.stone.available ? state.stone.owned ? 'Pedra superior já registrada.' : 'Adicionar 1 pedra superior sem gastar Hacksilver.' : state.stone.reason;
    $('berserker-apply').disabled = !state.berserker.available || state.berserker.owned;
    $('berserker-note').textContent = state.berserker.available ? state.berserker.owned ? 'Pedra berserker já registrada.' : state.berserker.restock ? 'Repõe uma pedra berserker após o consumo mapeado, preservando os marcadores de compra.' : 'Adicionar uma pedra berserker, sem gastar Hacksilver.' : state.berserker.reason;
    $('acquire-wrist-apply').disabled = !state.acquisition.available || state.acquisition.owned;
    $('acquire-wrist-note').textContent = state.acquisition.available ? state.acquisition.owned ? 'Braçadeira dos Ancestrais já registrada.' : 'Adiciona a peça base sem consumir equipamento ou materiais.' : state.acquisition.reason;
    $('equip-chest-choice').innerHTML = state.equipment.choices.map(p => `<option value="${p.id}">${escape(p.name)}</option>`).join('');
    if (state.equipment.available) $('equip-chest-choice').value = state.equipment.current.id;
    $('equip-chest-choice').disabled = !state.equipment.available; $('equip-chest-apply').disabled = !state.equipment.available;
    $('equip-chest-note').textContent = state.equipment.available ? 'Equipado: ' + state.equipment.current.name + '. Troca entre os dois peitorais mapeados e já possuídos.' : state.equipment.reason;
    for(const p of ciphers.PROFILES){
      const prefix=p.id.replace('-cipher',''),s=ciphers.inspect(result.bytes,selected,p.id,result.model),before=ciphers.inspect(original,selected,p.id,model);
      $(prefix+'-cipher-total').value=s.available?String(s.total):'';
      $(prefix+'-cipher-total').min=String(before.total??0);
      $(prefix+'-cipher-total').disabled=!s.available;
      $(prefix+'-cipher-apply').disabled=!s.available||s.complete;
      $(prefix+'-cipher-note').textContent=!s.available?s.reason:s.complete?'4/4 partes e cifra completa já registradas.':s.total+'/4 partes. Ao escolher 4, registra também a cifra completa. Confira a leitura e o acesso ao reino no jogo; esta inclusão está em teste.';
    }
  }
  function applyCampaign(type, values = {}) {
    if (selected === null) throw new Error('Escolha um slot.');
    const candidate = changes.filter(c => !(c.slot === selected && c.id === type));
    candidate.push({slot: selected, id: type, type, ...values}); commit(candidate);
    notify('Ajuste preparado. Confira a revisão e teste a cópia no jogo.');
  }
  function renderSelection() {
    $('selected-summary').hidden = selected === null || page === 'slots';
    if (selected === null) return;
    const slot = model.slots[selected];
    $('selected-name').textContent = 'Slot ' + slot.number + ' · ' + slot.title;
    $('selected-details').textContent = date(slot.timestamp) + ' · ' + fmt(slot.rows.length) + ' registros de quantidade';
  }
  function renderQuantities() {
    const available = selected !== null && model.slots[selected].available;
    $('quantities-unavailable').hidden = available; $('quantities-controls').hidden = !available;
    if (!available) return;
    const present = resources.FIELDS;
    renderFilter('quantity-category', present.map(field => field.category));
    const fields = present.filter(field => catalog.matches(field.id, $('quantity-search').value) && ($('quantity-category').value === 'all' || field.category === $('quantity-category').value));
    const previous = $('quantity-item').value;
    $('quantity-item').innerHTML = fields.map(field => `<option value="${field.id}">${escape(field.name)}${field.originalName !== field.name ? ' · ' + escape(field.originalName) : ''}${model.slots[selected].rows.some(row => row.id === field.id) ? '' : ' · Novo no save'}</option>`).join('');
    if (fields.some(field => field.id === previous)) $('quantity-item').value = previous;
    $('quantity-count').textContent = fields.length + ' de ' + present.length + ' recursos do catálogo';
    $('summary-cards').innerHTML = core.FIELDS.slice(0, 2).map(field => `<article class="stat-card"><h3>${escape(field.name)}</h3><span class="small-label">No original</span><div class="original-value">${fmt(quantity(selected, field.id, false))}</div><div class="card-footer"><span>Na edição</span><strong>${fmt(quantity(selected, field.id))}</strong></div></article>`).join('');
    renderQuantityPreview(true);
  }
  function renderQuantityPreview(reset = false) {
    if (selected === null) { $('quantity-apply').disabled = true; return; }
    const field = resources.lookup($('quantity-item').value), slot = model.slots[selected];
    const rows = field ? slot.rows.filter(row => row.id === field.id) : [];
    if (field) $('quantity-value').max = String(field.max);
    if (reset && field) $('quantity-value').value = String(quantity(selected, field.id) || 0);
    const text = $('quantity-value').value.trim(), desired = Number(text);
    const addition = rows.length === 0 ? resources.inspect(original, selected, model) : null;
    const valid = !!field && rows.length <= 1 && !!text && Number.isSafeInteger(desired) && desired >= 0 && desired <= field.max &&
      (rows.length === 1 || desired === 0 || addition.available && addition.capacity > 0);
    $('quantity-apply').disabled = !valid;
    $('quantity-apply').textContent = rows.length === 0 && desired > 0 ? 'Incluir recurso e aplicar total' : 'Aplicar quantidade';
    $('quantity-note').textContent = !field ? 'Nenhum recurso corresponde aos filtros.' : rows.length > 1 ? 'O registro está duplicado neste slot.'
      : rows.length === 0 ? 'Recurso ausente: será criado sem consumir outro estoque. Inclusão em teste; valide a cópia no jogo.' +
          (!addition.available ? ' ' + addition.reason : '')
      : 'Slot ' + slot.number + ' · ' + field.originalName + ' · original: ' + fmt(rows[0].quantity) + (field.controlledPcPair ? ' · ID confirmado pela amostra de PC.' : '')
        + (!valid ? ' Informe um total inteiro permitido para este item.' : '');
    if (field) $('quantity-note').textContent += field.unique ? ' Item único: total 0 ou 1. Isso não conclui missões nem derrota chefes.' : ' Os limites efetivos do jogo não são detectados automaticamente.';
  }
  function setQuantity(id, value) {
    if (selected === null || !resources.lookup(id)) throw new Error('Escolha um recurso e um slot.');
    const before = model.slots[selected].rows.find(row => row.id === id);
    const candidate = changes.filter(entry => entry.slot !== selected || entry.id !== id);
    if ((before?.quantity || 0) !== value) candidate.push({ slot: selected, id, quantity: value });
    commit(candidate);
  }
  function renderAttributes() {
    const available = selected !== null;
    $('attributes-controls').hidden = !available; $('attributes-unavailable').hidden = available;
    $('targets-controls').hidden = !available; $('targets-unavailable').hidden = available;
    if (!available) return;
    const before = attributes.states(model.slots[selected]), after = attributes.states(result.model.slots[selected]);
    $('attribute-cards').innerHTML = after.map((stat, i) => `<article class="stat-card"><h3>${stat.name}</h3><span class="small-label">Bônus no original</span><div class="original-value">${fmt(before[i].bonus)}</div><div class="card-footer"><span>Bônus na edição</span><strong>${fmt(stat.bonus)}</strong></div><p class="mini-note">${fmt(stat.quantity)} orvalhos · ${before[i].present ? 'Registro existente' : 'Inclusão em teste'}</p><label class="field">Bônus desejado<input id="dew-${stat.key}" type="number" min="0" max="4294967294" step="2" value="${stat.bonus}"><small>Cada unidade soma 2 pontos. Informe um bônus par.</small></label><button class="button primary" data-dew-apply="${stat.key}">Aplicar bônus</button></article>`).join('');
    document.querySelectorAll('[data-dew-apply]').forEach(button => button.addEventListener('click', () => {
      try {
        const stat = attributes.DEWS.find(stat => stat.key === button.dataset.dewApply), text = $('dew-' + stat.key).value.trim(), bonus = Number(text);
        if (!text || !Number.isSafeInteger(bonus) || bonus < 0 || bonus % 2) throw new Error('Informe um bônus inteiro, par e maior ou igual a zero.');
        setQuantity(stat.id, bonus / 2); notify('Bônus preparado para o slot ' + (selected + 1) + '.');
      } catch (e) { error(e.message); }
    }));
    renderTarget();
  }
  function renderLevels() {
    const available = selected !== null;
    $('levels-controls').hidden = !available; $('levels-unavailable').hidden = available;
    if (!available) return;
    const acquisition = bladesUnlock.inspect(result.bytes, selected, result.model);
    $('blades-unlock-apply').disabled = !acquisition.available || acquisition.owned;
    $('blades-unlock-apply').textContent = acquisition.owned ? 'Lâminas já possuídas' : 'Adicionar Lâminas ao inventário';
    $('blades-unlock-note').textContent = !acquisition.available ? acquisition.reason : acquisition.owned ? 'As Lâminas já estão no inventário. Escolha o nível desejado abaixo.' : 'Adicione as Lâminas com o cabo padrão, mesmo no início da campanha. Depois escolha um nível de 1 a 5.';
    renderLevelPicker(levelCore.ID, 'level');
    renderLevelPicker('blades-main-level', 'blades-level');
    const profiles = targetCore.PROFILES.filter(profile => profile.kind === 'armor');
    const states = profiles.map(profile => ({ profile, state: targetCore.inspect(original, selected, profile.id, model) }));
    if (!states.some(entry => entry.profile.id === armorProfileId && entry.state.available)) armorProfileId = states.find(entry => entry.state.available)?.profile.id || armorProfileId;
    $('armor-level-profile').innerHTML = states.map(({ profile, state }) => `<option value="${profile.id}">${escape(profile.name)}${state.available ? '' : ' · não reconhecido neste slot'}</option>`).join('');
    $('armor-level-profile').value = armorProfileId;
    renderArmorLevelPicker();
  }
  function renderArmorLevelPicker() {
    const profile = targetCore.PROFILES.find(profile => profile.id === armorProfileId && profile.kind === 'armor');
    $('armor-level-name').textContent = profile ? profile.name + ' · peitoral' : 'Armadura não reconhecida';
    renderLevelPicker(armorProfileId, 'armor-level');
  }
  function levelStateBefore(id) {
    const state = levelApi(id).inspect(original, selected, id, model);
    if (id !== 'blades-main-level' || state.available || !changes.some(c=>c.slot===selected&&c.type===bladesUnlock.TYPE)) return state;
    const base = writer.patch(sourceBytes, changes.filter(c=>!(c.slot===selected&&c.type===weaponCore.TYPE&&c.id===id)));
    return {...weaponCore.inspect(base.bytes, selected, id, base.model), pendingAcquisition:true};
  }
  function renderLevelPicker(id, prefix) {
    const before = levelStateBefore(id), after = levelApi(id).inspect(result.bytes, selected, id, result.model);
    $(prefix + '-original').textContent = before.pendingAcquisition ? 'Não possuídas' : before.available||before.recognized ? before.currentLabel : 'Não reconhecido neste slot';
    $(prefix + '-edited').textContent = after.available||after.recognized ? after.currentLabel : 'Não reconhecido neste slot';
    $(prefix + '-target').innerHTML = before.options.map(option => `<option value="${option.value}" ${option.available ? '' : 'disabled'}>${escape(option.label)}${option.available ? '' : ' · indisponível neste save'}</option>`).join('');
    $(prefix + '-target').disabled = !before.available;
    $(prefix + '-target').value = after.available ? String(after.current) : '';
    $(prefix + '-range').textContent = before.earlyBladesMapsOnly ? 'Níveis de 1 a 5 disponíveis desde o início, sem primeiro upgrade obrigatório pelo jogo.' : before.available ? 'Maior etapa registrada no original: ' + before.registeredLabel + (before.ngpMapsOnly ? (before.partialHistoryMapped?'. NG+ com formato testado: permite registrar as melhorias mapeadas e preserva o mundo.':'. NG+ reconhecido; o ajuste preserva o histórico das etapas registradas.') : '. Você pode escolher uma etapa registrada ou uma nova melhoria que esteja mapeada.') : '';
    renderLevelChoice(id, prefix, before, after);
  }
  function renderLevelChoice(id, prefix, before, after) {
    if (selected === null) { $(prefix + '-apply').disabled = true; return; }
    before ||= levelStateBefore(id);
    after ||= levelApi(id).inspect(result.bytes, selected, id, result.model);
    const text = $(prefix + '-target').value, target = text === '' ? null : Number(text), option = before.options.find(option => option.value === target);
    const valid = before.available && after.available && Number.isInteger(target) && option?.available;
    $(prefix + '-apply').disabled = !valid || target === after.current;
    $(prefix + '-apply').textContent = !valid || target === after.current ? 'Aplicar nível escolhido' : (target < after.current ? 'Reduzir para ' : 'Elevar para ') + option.label;
    const missingArmor=!before.available&&before.profile?.kind==='armor'&&before.profile.baseId&&!model.slots[selected].rows.some(row=>row.id===before.profile.baseId&&row.quantity>0);
    $(prefix + '-note').textContent = missingArmor ? 'Este controle é específico de '+before.profile.name+'. Esse peitoral não consta no inventário deste slot.' : !before.available ? before.reason : !after.available ? after.reason : !valid ? option?.reason || 'Escolha uma opção disponível neste save.'
      : target === after.current ? (before.ngpMapsOnly?'NG+ reconhecido. O ajuste usa os dois mapas existentes. Escolha um nível diferente para preparar uma alteração.':'Escolha um nível diferente para preparar uma alteração.')
      : before.earlyBladesMapsOnly ? 'Permite chegar ao nível 5 desde o início. Mantém a progressão da história e os recursos; confira a cópia no jogo.'
      : before.ngpMapsOnly ? before.partialHistoryMapped?'Registra as etapas mapeadas e sincroniza os dois mapas existentes do NG+. O mundo e os recursos ficam preservados.':'Sincroniza os níveis reconhecidos do NG+ e preserva o histórico completo.'
      : option.mode === 'registered' ? 'Altera o nível ativo e mantém o histórico das melhorias. Não devolve nem consome recursos. O novo ajuste precisa ser testado no jogo.'
      : 'Registra a nova etapa pela transição mapeada e mantém os recursos e encantamentos. Revise a cópia e teste no jogo.';
  }
  function setLevelTarget(id, prefix) {
    if (selected === null) throw new Error('Escolha um slot.');
    const state = levelStateBefore(id), text = $(prefix + '-target').value, target = text === '' ? null : Number(text);
    const option = state.options.find(option => option.value === target);
    if (!state.available || !Number.isInteger(target) || !option?.available) throw new Error(state.reason || option?.reason || 'Escolha um nível disponível neste save.');
    const candidate = changes.filter(entry => entry.slot !== selected || entry.id !== id);
    if (target !== state.current) candidate.push(levelApi(id)===weaponCore ? {slot:selected,id,type:weaponCore.TYPE,level:target} : { slot: selected, id, type: 'level-target', target });
    commit(candidate); notify('Nível ativo preparado. Confira a revisão e teste a cópia no jogo.');
  }
  function inventoryState() { return selected === null ? null : inventory.inspect(result.bytes, selected, result.model); }
  function inventoryList() {
    return selection.filterProfiles({kind:$('inventory-kind').value||'all',variant:$('inventory-variant').value||'all',
      support:$('inventory-support').value||'all',query:$('inventory-search').value});
  }

  function renderInventory() {
    const state = inventoryState(), previous = $('inventory-item').value,list=inventoryList();
    $('inventory-item').innerHTML = list.map(p => `<option value="${p.id}">${escape(p.name)} · ${escape(INVENTORY_KINDS[p.kind])} · ${p.sharedCampaign?'Normal e NG+':p.variant} · ${p.mode==='runic-quantity-template'?'inclusão no nível 3':inventory.maximumOnly(p)?'inclusão no nível 9':p.experimentalTemplate?'etapas de progressão':'níveis mapeados'}</option>`).join('');
    $('inventory-catalog-count').textContent=list.length+' opções no filtro · '+inventory.MAPPED_PROFILES.length+' com níveis mapeados · 31 ataques rúnicos (16 machado / 15 lâminas; 27 inclusões no nível 3) · 4 cabos NG+ com inclusão no nível 9.';
    if (list.some(p => p.id === previous)) $('inventory-item').value = previous;
    renderInventoryChoice(state);
    renderRemoval();
  }
  function renderInventoryChoice(state = inventoryState(), reset = false) {
    const id = $('inventory-item').value, p = inventory.PROFILES.find(p => p.id === id), current = state?.profiles.find(p => p.id === id);
    const previous = $('inventory-stage').value, same = $('inventory-stage').dataset.profile === id && !reset,runic=p?.mode==='runic-quantity-template';
    $('inventory-stage').innerHTML = p ? p.stages.map((s,k) => `<option value="${k}"${(p.autoFullSet||inventory.maximumOnly(p)||runic)&&k!==2||p.experimentalTemplate&&current?.owned&&k<current.highest?' disabled':''}>${p.experimentalTemplate&&!inventory.maximumOnly(p)&&!runic?'Etapa · ':'Nível '}${escape(s.label)}${runic&&k===2?' · inclusão no nível 3':inventory.maximumOnly(p)&&k===2?' · inclusão validada':!p.experimentalTemplate&&k === p.stages.length - 1 ? ' · máximo mapeado' : ''}</option>`).join('') : '';
    if (p) $('inventory-stage').value = p.autoFullSet||inventory.maximumOnly(p)||runic ? '2' : same && p.stages[Number(previous)] ? previous : String(current?.owned&&Number.isInteger(current.stage) ? current.stage : p.stages.length - 1);
    $('inventory-stage').dataset.profile = id;
    $('inventory-note').textContent = selected === null ? 'Escolha um slot.' : !p ? 'Nenhuma peça corresponde à pesquisa.' : !current?.available ? current?.reason || state?.reason || 'Slot não reconhecido.' : inventory.maximumOnly(p) ? current.owned ? current.highest===2?'Este cabo já está registrado com todas as melhorias.':'Este cabo já existe. Faça suas melhorias pelo jogo; esta opção adiciona cabos ausentes no nível 9.' : 'Inclui este cabo ausente no nível 9. Os cinco cabos NG+ foram testados juntos, equipados e regravados no jogo.' : p.id==='B19A13C4B34FA37F'&&!current.owned ? 'Cursed Flame +: inclusão nos níveis 8 e 9 validada no jogo. Escolha o nível desejado; os demais equipamentos e recursos são preservados.' : p.autoFullSet ? 'Zeus é incluído como conjunto completo no nível 9. As três peças aparecem juntas na revisão.' : p.experimentalTemplate ? 'Inclui a peça e suas melhorias por etapas de progressão. Os equipamentos existentes são preservados.' : current.owned ? 'No save: nível ' + p.stages[current.stage].label + '. Um nível menor preserva o histórico de melhorias. Equipamento pronto para equipar no jogo.' : 'Ausente: será incluído no nível escolhido, preservando os outros equipamentos e recursos.';
    if(runic&&current?.available)$('inventory-note').textContent=current.owned?'No save: nível '+(current.stage+1)+'. Este rúnico já existe e será preservado. Faça suas melhorias pelo jogo.':'Inclui este ataque ausente no nível 3 e preserva os ataques existentes.';
    if(current?.available&&current.crossBuild)$('inventory-note').textContent+=' Formato estrutural reconhecido; confira a inclusão nesta amostra no jogo.';
    $('inventory-apply').disabled = !current?.available||(inventory.maximumOnly(p)||runic)&&current.owned||inventory.requiresExperimental(p)&&!$('inventory-experimental').checked;
    renderInventoryBulk(state);
    renderArmorClone(state);
    renderArmorSet(state);
  }
  function renderArmorSet(state=inventoryState()) {
    const variant=$('inventory-variant').value||'all',previous=$('inventory-set').value;
    const sets=selection.SETS.filter(s=>variant==='all'||s.variant===variant);
    $('inventory-set').innerHTML=sets.map(s=>`<option value="${s.id}">${escape(s.name)} · ${s.variant}</option>`).join('');
    if(sets.some(s=>s.id===previous))$('inventory-set').value=previous;
    renderArmorSetChoice(state);
  }
  function renderArmorSetChoice(state=inventoryState()) {
    const set=selection.SETS.find(s=>s.id===$('inventory-set').value);
    $('inventory-set-apply').disabled=true;
    if(selected===null||!state?.available||!set){$('inventory-set-note').textContent='Escolha um slot e um conjunto.';return;}
    try{
      const mode=$('inventory-set-mode').value||'template-max',requests=selection.buildSet(state,set.id,mode,true);
      const names=set.parts.map(p=>p.name).join(' · ');
      const experimental=requests.some(r=>r.type!=='inventory-equipment'||inventory.PROFILES.find(p=>p.id===r.id)?.experimentalTemplate);
      $('inventory-set-note').textContent=names+' — '+(set.zeus?'Zeus usa o conjunto completo no 9, pelo molde já confirmado.':requests.length+' peça(s) ausente(s). As já possuídas permanecem como estão. '+(mode==='base'?'Inclui na base.':'Inclui até a última etapa de cada peça.'));
      $('inventory-set-apply').disabled=!requests.length||experimental&&!$('inventory-experimental').checked;
    }catch(e){$('inventory-set-note').textContent=e.message;}
  }
  function renderArmorClone(state=inventoryState()) {
    const clone=state?.armorClone;
    $('armor-clone-note').textContent=selected===null?'Escolha um slot.':!clone?.available?clone?.reason||state?.reason||'Slot não reconhecido.':clone.fullyRegistered?'Zeus já corresponde ao molde no nível 9.':'Inclui ou normaliza Zeus completo usando o molde nativo. As peças doadoras e os demais equipamentos são preservados. Talvez corrompa seu save.';
    $('armor-clone-apply').disabled=!clone?.available||clone.fullyRegistered||!$('inventory-experimental').checked;
  }
  function renderInventoryBulk(state=inventoryState()) {
    const eligible=inventoryList().filter(p=>state?.profiles.some(s=>s.id===p.id&&s.available&&!s.owned)),experimental=eligible.filter(inventory.requiresExperimental).length;
    $('inventory-bulk-note').textContent=selected===null?'Escolha um slot.':eligible.length+' peças ausentes disponíveis neste filtro'+'.'+(eligible.some(inventory.maximumOnly)?' Os quatro cabos NG+ por molde serão incluídos no nível 9.':'');
    $('inventory-bulk').disabled=!eligible.length||experimental>0&&!$('inventory-experimental').checked;
  }
  function withImprovementMaterials(candidate) {
    if(!$('inventory-materials').checked)return candidate;
    const slot=result.model.slots[selected],quantities=[...policy.buildKit(slot,'main',99999),...policy.buildKit(slot,'xp-hs',2000000000)];
    const ids=new Set(quantities.map(r=>r.id));return [...candidate.filter(r=>r.slot!==selected||!ids.has(r.id)),...quantities];
  }
  function removalState(){return selected===null?null:removal.inspect(result.bytes,selected,result.model);}
  function renderRemoval(){
    const state=removalState(),allowed=new Set(inventoryList().map(p=>p.id)),old=$('removal-equipment-item').value;
    const list=(state?.equipment||[]).filter(p=>p.owned&&allowed.has(p.id));
    $('removal-equipment-item').innerHTML=list.map(p=>`<option value="${p.id}">${escape(p.name)} · ${escape(INVENTORY_KINDS[p.kind])} · ${escape(p.variant)}</option>`).join('');
    if(list.some(p=>p.id===old))$('removal-equipment-item').value=old;
    else $('removal-unequipped').checked=false;
    renderRemovalEquipmentChoice(state);
    const previous=$('removal-enchantment-item').value,common=(state?.enchantments||[]).filter(e=>e.common);
    $('removal-enchantment-item').innerHTML=common.map(e=>`<option value="${e.uid}">Registro ${e.uid} · ${escape(e.name)}${e.available?' · solto':' · em encaixe'}</option>`).join('');
    if(common.some(e=>String(e.uid)===previous))$('removal-enchantment-item').value=previous;
    renderRemovalEnchantmentChoice(state);
  }
  function renderRemovalEquipmentChoice(state=removalState()){
    const p=state?.equipment.find(p=>p.id===$('removal-equipment-item').value&&p.owned),confirm=!!p?.needsUnequippedConfirmation;
    $('removal-unequipped-row').hidden=!confirm;
    $('removal-equipment-note').textContent=selected===null?'Escolha um slot.':!state?.available?state?.reason||'Slot não reconhecido.':!p?'Não há equipamentos possuídos neste filtro.':p.reason+(confirm?' Confirme que a peça já está desequipada no jogo.':'');
    $('removal-equipment-apply').disabled=!p?.available||confirm&&!$('removal-unequipped').checked;
  }
  function renderRemovalEnchantmentChoice(state=removalState()){
    const text=$('removal-enchantment-item').value,e=text===''?null:state?.enchantments.find(e=>e.uid===Number(text));
    $('removal-enchantment-note').textContent=selected===null?'Escolha um slot.':!state?.available?state?.reason||'Slot não reconhecido.':!e?'Não há instâncias comuns dos formatos reconhecidos neste slot.':e.available?'Retira somente esta instância solta. As outras cópias, os efeitos restantes e os recursos ficam preservados.':e.reason;
    $('removal-enchantment-apply').disabled=!e?.available;
  }
  function creationList(){
    const variant=$('enchantment-variant').value||'all',kind=$('enchantment-kind').value||'all',query=normalize($('enchantment-search').value);
    return inventory.FACTORIES.filter(p=>(variant==='all'||p.variant===variant)&&(kind==='all'||p.classification===kind)&&(!query||normalize(p.name+' '+(p.nativeVisibleStats||[]).map(s=>s.name+' '+s.value).join(' ')).includes(query))).sort((a,b)=>a.variant.localeCompare(b.variant)||a.name.localeCompare(b.name,'pt-BR'));
  }
  function renderCreation() {
    const state = inventoryState(), previous = $('enchantment-create-item').value,list=creationList();
    $('enchantment-create-item').innerHTML = list.map(p => `<option value="${p.id}">${escape(p.name)} · ${p.variant==='Normal'?'NG normal':'NG+'}${p.gameValidated===false?' · novo modelo':''}</option>`).join('');
    if (list.some(p => p.id === previous)) $('enchantment-create-item').value = previous;
    else if(list.some(p=>p.id===inventory.BESTLA))$('enchantment-create-item').value=inventory.BESTLA;
    $('enchantment-catalog-count').textContent=list.length+' opções neste filtro · '+inventory.FACTORIES.length+' no catálogo ('+inventory.FACTORIES.filter(p=>p.variant==='Normal').length+' NG normal / '+inventory.FACTORIES.filter(p=>p.variant==='NG+').length+' NG+).';
    renderCreationChoice(state);renderCreationBulk(state);
  }
  function creationBulk(state=inventoryState()){
    const list=creationList(),states=new Map((state?.enchantments||[]).map(p=>[p.id,p]));
    return {requests:list.filter(p=>states.get(p.id)?.available&&!states.get(p.id).owned).map(p=>({slot:selected,type:'enchantment-create',id:p.id,count:1})),owned:list.filter(p=>states.get(p.id)?.owned).length,blocked:list.filter(p=>!states.get(p.id)?.available).length};
  }
  function renderCreationBulk(state=inventoryState()){
    const batch=creationBulk(state);$('enchantment-bulk-apply').disabled=selected===null||!batch.requests.length;
    $('enchantment-bulk-note').textContent=selected===null?'Escolha um salvamento.':batch.requests.length+' modelos ausentes disponíveis para inclusão · '+batch.owned+' já presentes · '+batch.blocked+' indisponíveis neste slot. O lote usa o filtro acima e preserva os encantamentos e materiais existentes.';
  }
  function renderCreationChoice(state = inventoryState()) {
    const id = $('enchantment-create-item').value, current = state?.enchantments.find(p => p.id === id), kvasir = id === inventory.KVASIR;
    const profile = inventory.FACTORIES.find(p=>p.id===id), validated = profile?.validatedAcquisition===true;
    $('kvasir-options').hidden = !kvasir || validated;
    $('enchantment-local-options').hidden = true;
    $('enchantment-create-count').disabled = kvasir || validated;
    if (kvasir || validated) $('enchantment-create-count').value = '1';
    $('enchantment-create-note').textContent = selected === null ? 'Escolha um slot.' : !profile?'Nenhum encantamento corresponde ao filtro.':!current?.available ? current?.reason || state?.reason || 'Inclusão não reconhecida neste slot.'
      : validated ? current.owned ? 'Este encantamento já consta no inventário. A instância e seus encaixes serão preservados.'
        : (current.unique?'Único':'Comum')+' · uma unidade ausente, solta no inventário. '+(profile.gameValidated===false?'Modelo completo observado em save do jogo; a inclusão deste novo modelo pelo editor aguarda seu teste.':'Inclusão e persistência confirmadas nos testes do jogo.')+' Equipe pelo jogo.'+(profile?.nameAssociation?.individualConfirmationPending?' Confira o nome no jogo: a associação foi feita pelo catálogo e pelas amostras.':'')+(current.crossBuild?' Formato reconhecido em outra versão do arquivo.':'')
      : kvasir ? 'Amuleto pronto para conversão. Revise a opção experimental antes de aplicar.'
      : 'Comum · adiciona '+current.name+' solto ao inventário. Equipe pelo jogo.';
    if(current?.conversionNotice)$('enchantment-create-note').textContent+=' '+current.conversionNotice;
    if(profile?.nativeVisibleStats?.length)$('enchantment-create-note').textContent+=' Atributos do modelo: '+profile.nativeVisibleStats.map(s=>s.name+' '+s.value).join(' · ')+'. Os valores de uma instância já existente são preservados.';
    $('enchantment-create-apply').disabled = !current?.available || validated && current.owned;
  }
  function duplicateSource() {
    return $('duplicate-origin').value==='donor'?enchantmentDonor:original&&model?{bytes:original,model,filename:sourceFilename}:null;
  }
  function duplicateModels() {
    const source=duplicateSource(),text=$('duplicate-slot').value;
    if(!source||text==='')return {available:false,choices:[],reason:'Escolha um arquivo e um salvamento de origem.'};
    return inventory.duplicateChoices(source.bytes,Number(text),source.model);
  }
  function renderDuplicate() {
    const previous=$('duplicate-origin').value;
    $('duplicate-origin').innerHTML='<option value="current">Arquivo aberto</option>'+(enchantmentDonor?`<option value="donor">${escape(enchantmentDonor.filename)}</option>`:'');
    if(previous==='donor'&&enchantmentDonor)$('duplicate-origin').value='donor';
    renderDuplicateSlots();
  }
  function renderDuplicateSlots() {
    const source=duplicateSource(),previous=$('duplicate-slot').value,slots=source?slotCore.ordered(source.model).filter(s=>s.available&&s.build===4757534):[];
    $('duplicate-slot').innerHTML=slots.map(s=>`<option value="${s.index}">Slot ${s.number} · ${escape(date(s.timestamp))} · ${escape(s.title)}</option>`).join('');
    if(slots.some(s=>String(s.index)===previous))$('duplicate-slot').value=previous;
    renderDuplicateModels();
  }
  function renderDuplicateModels() {
    const state=duplicateModels(),previous=$('duplicate-item').value;
    $('duplicate-item').innerHTML=state.choices.map(o=>`<option value="${o.uid}">Registro ${o.uid} · ${escape(o.name)} · ${o.unique?'único reconhecido':o.classification==='common'?'comum reconhecido':'classificação não confirmada'}${o.sourceArmor?' · em '+escape(o.sourceArmor):''}</option>`).join('');
    if(state.choices.some(o=>String(o.uid)===previous))$('duplicate-item').value=previous;
    renderDuplicateChoice(state);
  }
  function renderDuplicateChoice(state=duplicateModels()) {
    const text=$('duplicate-item').value,choice=text===''?null:state.choices.find(o=>o.uid===Number(text));
    $('duplicate-note').textContent=selected===null?'Escolha o salvamento de destino.':!choice?state.reason||'Não há modelos de encantamento reconhecidos nessa origem.':'Destino: slot '+(selected+1)+' · '+state.choices.length+' modelos disponíveis. Copiar: '+choice.name+'. A origem permanece intacta.';
    if(choice?.unique)$('duplicate-note').textContent='Encantamento único reconhecido: use a inclusão pelo catálogo quando ausente ou faça a conversão pelo jogo.';
    $('duplicate-apply').disabled=selected===null||!choice||choice.unique||!$('duplicate-experimental').checked||result.model.slots[selected].build!==4757534;
  }
  function renderEquipment() {
    renderInventory();
    const query = $('equipment-search').value, kind = $('equipment-kind').value || 'all';
    const families = equipment.families.filter(family => !family.stages.some(stage=>window.Forja2018InventoryCatalog.EXCLUDED_IDS.includes(stage.id)) && (kind === 'all' || family.kind === kind) &&
      family.stages.some(stage => catalog.matches(stage.id, query)));
    const pages = Math.max(1, Math.ceil(families.length / 30)); equipmentPage = Math.min(equipmentPage, pages - 1);
    const rows = selected === null ? null : result.model.slots[selected].rows;
    $('equipment-count').textContent = families.length + ' famílias · ' + equipment.upgrades.length + ' IDs de melhoria na lista fornecida';
    $('equipment-body').innerHTML = families.slice(equipmentPage * 30, (equipmentPage + 1) * 30).map(family => `<tr><td><strong>${escape(catalog.lookup(family.stages.find(stage => !stage.isUpgrade)?.id)?.name || family.name)}</strong><small>${escape(family.kindName)}</small></td><td>${family.stages.map(stage => {
      const matches = rows?.filter(row => row.id === stage.id);
      return `<details><summary>${escape(stage.stage)} · ${escape(catalog.lookup(stage.id)?.name || stage.name)}</summary><p class="mini-note mono">${stage.id}</p><p class="mini-note">${escape(stage.internalName)}</p><p class="mini-note">${!rows ? 'Selecione um slot para consultar os registros.' : !matches.length ? 'ID ausente na tabela consultada.' : 'ID encontrado · quantidade ' + matches.map(row => fmt(row.quantity)).join(', ')}</p></details>`;
    }).join('')}</td></tr>`).join('') || '<tr><td colspan="2">Nenhum equipamento corresponde à pesquisa.</td></tr>';
    $('equipment-page').textContent = (equipmentPage + 1) + ' de ' + pages;
    $('equipment-prev').disabled = equipmentPage === 0; $('equipment-next').disabled = equipmentPage + 1 >= pages;
  }
  function renderEnchantments() {
    renderCreation();
    renderDuplicate();
    $('enchantments-unavailable').hidden = selected !== null;
  }
  function getTarget() {
    if (selected === null) throw new Error('Escolha um slot.');
    const current = $('target-current').value.trim(), desired = $('target-desired').value.trim();
    if (!current || !desired) throw new Error('Informe o total atual no jogo e a meta desejada.');
    return attributes.planTarget(model.slots[selected], { key: $('target-stat').value, currentTotal: Number(current), desiredTotal: Number(desired), rounding: $('target-rounding').value });
  }
  function renderTarget() {
    try {
      const plan = getTarget();
      $('target-note').textContent = 'Contribuição sem orvalhos: ' + fmt(plan.equipmentTotal) + ' · Orvalhos necessários: ' + fmt(plan.quantity) +
        ' · Total projetado: ' + fmt(plan.projectedTotal) + (plan.exact ? '.' : '. A meta está entre ' + fmt(plan.lowerTotal) + ' e ' + fmt(plan.upperTotal) + '; foi usado o arredondamento escolhido.') +
        (!plan.stat.present && plan.quantity > 0 ? ' O registro será incluído: confirme o resultado no jogo.' : '');
      $('target-apply').disabled = false;
    } catch (e) { $('target-note').textContent = e.message; $('target-apply').disabled = true; }
  }

  function renderRecords() {
    if (!model || selected === null) {
      $('records-body').innerHTML = ''; $('record-count').textContent = 'Escolha um slot.';
      $('records-page').textContent = ''; $('records-prev').disabled = true; $('records-next').disabled = true; return;
    }
    const query = $('record-search').value, rows = result.model.slots[selected].rows.filter(row => catalog.matches(row.id, query));
    const pages = Math.max(1, Math.ceil(rows.length / 100)); recordPage = Math.min(recordPage, pages - 1);
    $('record-count').textContent = rows.length + ' de ' + result.model.slots[selected].rows.length + ' registros';
    $('records-body').innerHTML = rows.slice(recordPage * 100, (recordPage + 1) * 100).map(row => {
      const item = catalog.lookup(row.id), field = resources.lookup(row.id), after = quantity(selected, row.id);
      return `<tr><td><strong>${escape(item?.name || 'Registro sem identificação')}</strong>${item && item.originalName !== item.name ? '<small class="item-original">' + escape(item.originalName) + '</small>' : ''}<small>${escape(item?.category || 'Não classificado')}</small><small class="item-id mono">${row.id}</small></td><td>${model.slots[selected].rows.some(item => item.id === row.id) ? fmt(model.slots[selected].rows.find(item => item.id === row.id).quantity) : 'Ausente'}</td><td>${fmt(after)}</td><td>${field ? model.slots[selected].duplicateIds.includes(row.id) ? 'Duplicado · consulta' : 'Quantidade editável' : 'Consulta'}</td></tr>`;
    }).join('') || '<tr><td colspan="4">Nenhum registro corresponde à pesquisa.</td></tr>';
    $('records-page').textContent = (recordPage + 1) + ' de ' + pages;
    $('records-prev').disabled = recordPage === 0; $('records-next').disabled = recordPage + 1 >= pages;
  }
  function renderChanges() {
    const count = result?.log.length || 0;
    $('nav-count').textContent = count; $('nav-count').hidden = !count;
    $('change-count').textContent = count + (count === 1 ? ' alteração' : ' alterações');
    $('status-text').textContent = count ? count + ' ajustes prontos para revisão.' : selected === null ? 'Escolha um slot para começar.' : 'Slot ' + (selected + 1) + ' selecionado.';
    $('empty-changes').hidden = count > 0; $('reset-changes').disabled = !count; $('report-download').disabled = !count;
    $('cipher-review-warning').textContent = ciphers.STORY_WARNING;
    $('cipher-review-warning').hidden = !(result?.log || []).some(entry=>entry.type===ciphers.TYPE || entry.after>entry.before&&ciphers.PROFILES.some(p=>[p.piece,p.complete].includes(entry.id)));
    $('changes-body').innerHTML = (result?.log || []).map(entry => `<tr><td>${entry.slot}</td><td>${escape(entry.name)}${entry.provisional ? ' *' : ''}</td><td>${entry.beforeLabel ? escape(entry.beforeLabel) : entry.before === null ? 'Ausente' : fmt(entry.before)}</td><td>${entry.afterLabel ? escape(entry.afterLabel) : fmt(entry.after)}</td><td><button class="text-button" data-undo="${entry.slotIndex}:${entry.id}">Desfazer</button></td></tr>`).join('');
    document.querySelectorAll('[data-undo]').forEach(button => button.addEventListener('click', () => {
      try {
        const [slot, id] = button.dataset.undo.split(':'), index = Number(slot), removed = changes.find(c => c.slot === index && c.id === id);
        let candidate = changes.filter(entry => id === 'subsave' ? entry.slot !== index : entry.slot + ':' + entry.id !== button.dataset.undo);
        if (removed?.type === bladesUnlock.TYPE) candidate = candidate.filter(entry=>!(entry.slot===index&&entry.type===weaponCore.TYPE&&entry.id==='blades-main-level'));
        commit(candidate);
        if (removed?.type === 'enchantment-create') $('kvasir-keep').checked = false;
      } catch (e) { error(e.message); }
    }));
    $('export-top').disabled = !count;
  }
  function renderFilter(id, categories) {
    const select = $(id), previous = select.value || 'all', values = [...new Set(categories)].sort((a, b) => a.localeCompare(b, 'pt-BR'));
    select.innerHTML = '<option value="all">Todas as categorias</option>' + values.map(value => `<option value="${escape(value)}">${escape(value)}</option>`).join('');
    select.value = values.includes(previous) ? previous : 'all';
  }
  function renderCatalog() {
    const category = $('catalog-category').value || 'all', query = $('catalog-search').value;
    const availableItems = catalog.items.filter(item=>!window.Forja2018InventoryCatalog.EXCLUDED_IDS.includes(item.id));
    const items = availableItems.filter(item => catalog.matches(item.id, query) && (category === 'all' || item.category === category));
    const pages = Math.max(1, Math.ceil(items.length / 100)); catalogPage = Math.min(catalogPage, pages - 1);
    const rows = selected === null ? null : new Set(result.model.slots[selected].rows.map(row => row.id));
    $('catalog-count').textContent = items.length + ' de ' + availableItems.length + ' IDs';
    $('catalog-body').innerHTML = items.slice(catalogPage * 100, (catalogPage + 1) * 100).map(item => `<tr><td><strong>${escape(item.name)}</strong>${item.originalName !== item.name ? '<small class="item-original">' + escape(item.originalName) + '</small>' : ''}<small class="item-id mono">${item.id}</small><small>${escape(item.internalName)}</small></td><td>${escape(item.category)}<small>${escape(window.Forja2018Loot.summary(item.id))}</small></td><td>${rows ? rows.has(item.id) ? 'ID encontrado' : 'Não encontrado' : 'Selecione um slot'}</td></tr>`).join('') || '<tr><td colspan="3">Nenhum item corresponde aos filtros.</td></tr>';
    $('catalog-page').textContent = (catalogPage + 1) + ' de ' + pages;
    $('catalog-prev').disabled = catalogPage === 0; $('catalog-next').disabled = catalogPage + 1 >= pages;
  }
  function render() { renderSlots(); renderSelection(); renderQuantities(); renderKits(); renderCampaign(); renderAttributes(); renderLevels(); renderEquipment(); renderEnchantments(); renderRecords(); renderCatalog(); renderChanges(); chooseView(page); }
  function selectSlot(index) {
    $('removal-unequipped').checked=false;
    $('enchantment-local-experimental').checked = false;
    if (!model || !Number.isInteger(index) || !model.slots[index]?.available) throw new Error('Selecione um slot reconhecido.');
    $('kvasir-keep').checked = false;
    $('inventory-experimental').checked=true;$('inventory-materials').checked=false;$('duplicate-experimental').checked=false;
    selected = index; $('target-current').value = ''; $('target-desired').value = ''; recordPage = 0; $('record-search').value = ''; $('quantity-category').value = 'all'; $('quantity-search').value = ''; page = 'quantities'; render(); error('');
  }
  function commit(candidate, nextSelection = selected) {
    candidate=inventory.normalizeRequests(candidate);
    const next = writer.patch(sourceBytes, candidate);
    changes = candidate; result = next; original = next.baseBytes; model = next.baseModel; model.filename = sourceFilename;
    selected = nextSelection !== null && model.slots[nextSelection]?.available ? nextSelection : null;
    $('file-details').textContent = fmt(next.model.size) + ' bytes · ' + next.model.supported + ' slots reconhecidos';
    render(); error('');
  }
  function loadBytes(bytes, filename = 'game.sav') {
    const next = core.parse(bytes, filename);
    sourceBytes = new Uint8Array(bytes).slice(); sourceFilename = filename; importSource = null; original = sourceBytes; model = next; selected = null; changes = []; recordPage = 0; page = 'slots';
    $('kvasir-keep').checked = false; $('enchantment-local-experimental').checked = false; $('enchantment-create-count').value = '1';
    enchantmentDonor=null;$('duplicate-origin').value='current';$('duplicate-file').value='';$('duplicate-experimental').checked=false;$('inventory-experimental').checked=true;$('inventory-materials').checked=false;
    result = { bytes: original, model: next, log: [], layout: [], validation: {} };
    $('slot-source-choice').innerHTML = ''; $('slot-import-file').value = '';
    $('filename').textContent = filename; $('file-details').textContent = fmt(next.size) + ' bytes · ' + next.supported + ' slots reconhecidos';
    $('toolbar-subtitle').textContent = filename + ' · God of War 2018 · PC';
    $('record-search').value = ''; $('quantity-category').value = 'all'; $('quantity-search').value = ''; render(); error(''); notify('Arquivo lido. Escolha o salvamento que deseja editar.'); return next;
  }
  async function loadFile(file) {
    if (!file) return;
    try { loadBytes(new Uint8Array(await file.arrayBuffer()), file.name); } catch (e) { error(e.message); }
    finally { $('file-input').value = ''; }
  }
  function download(data, name, type = 'application/octet-stream') {
    const url = URL.createObjectURL(new Blob([data], { type })), link = document.createElement('a');
    link.href = url; link.download = name.replace(/[\\/\x00-\x1f]/g, '_'); document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function exportBytes() {
    if (!model) throw new Error('Abra um arquivo primeiro.');
    const next = writer.patch(sourceBytes, changes);
    if (!next.log.length) throw new Error('Nenhuma alteração para exportar.');
    return next;
  }
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => chooseView(button.dataset.view)));
  for (const id of ['open-main', 'open-top']) $(id).addEventListener('click', () => $('file-input').click());
  $('file-input').addEventListener('change', event => loadFile(event.target.files[0]));
  for (const name of ['dragenter', 'dragover']) $('drop-area').addEventListener(name, event => { event.preventDefault(); $('drop-area').classList.add('drag-over'); });
  for (const name of ['dragleave', 'drop']) $('drop-area').addEventListener(name, event => { event.preventDefault(); $('drop-area').classList.remove('drag-over'); });
  $('drop-area').addEventListener('drop', event => loadFile(event.dataTransfer.files[0]));
  $('change-slot').addEventListener('click', () => chooseView('slots'));
  $('quantity-item').addEventListener('change', () => renderQuantityPreview(true));
  $('quantity-search').addEventListener('input', () => model && renderQuantities());
  $('quantity-category').addEventListener('change', () => model && renderQuantities());
  $('quantity-value').addEventListener('input', () => renderQuantityPreview(false));
  $('quantity-apply').addEventListener('click', () => {
    try {
      if (selected === null) throw new Error('Escolha um slot.');
      const id = $('quantity-item').value, text = $('quantity-value').value.trim();
      if (!text) throw new Error('Informe a quantidade desejada.');
      const quantity = Number(text);
      setQuantity(id, quantity); notify('Quantidade preparada para o slot ' + (selected + 1) + '.');
    } catch (e) { error(e.message); }
  });
  $('level-apply').addEventListener('click', () => {
    try { setLevelTarget(levelCore.ID, 'level'); } catch (e) { error(e.message); }
  });
  for(const p of ciphers.PROFILES){
    const prefix=p.id.replace('-cipher','');
    $(prefix+'-cipher-apply').addEventListener('click',()=>{
      try{
        if(selected===null)throw new Error('Escolha um slot.');
        const text=$(prefix+'-cipher-total').value.trim();if(!text)throw new Error('Informe um total entre 0 e 4.');
        const total=Number(text),before=ciphers.inspect(original,selected,p.id,model),candidate=changes.filter(c=>c.slot!==selected||c.id!==p.id);
        if(!before.available)throw new Error(before.reason);
        if(total!==before.total)candidate.push({slot:selected,id:p.id,type:ciphers.TYPE,total});
        commit(candidate);notify('Cifras preparadas. Atenção: evite usá-las antes da primeira viagem a Alfheim.');
      }catch(e){error(e.message);}
    });
  }
  $('armor-level-apply').addEventListener('click', () => {
    try { setLevelTarget(armorProfileId, 'armor-level'); } catch (e) { error(e.message); }
  });
  $('level-target').addEventListener('change', () => renderLevelChoice(levelCore.ID, 'level'));
  $('blades-unlock-apply').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um slot.');
      const state=bladesUnlock.inspect(result.bytes,selected,result.model);
      if(!state.available)throw new Error(state.reason);
      if(state.owned)return;
      commit([...changes.filter(c=>c.slot!==selected||c.id!==bladesUnlock.ID),{slot:selected,type:bladesUnlock.TYPE,id:bladesUnlock.ID}]);
      notify('Lâminas adicionadas à edição. Escolha o nível desejado e revise as alterações.');
    }catch(e){error(e.message);}
  });
  $('blades-level-apply').addEventListener('click',()=>{try{setLevelTarget('blades-main-level','blades-level');}catch(e){error(e.message);}});
  $('blades-level-target').addEventListener('change',()=>renderLevelChoice('blades-main-level','blades-level'));
  $('armor-level-target').addEventListener('change', () => renderLevelChoice(armorProfileId, 'armor-level'));
  $('armor-level-profile').addEventListener('change', () => {
    if (selected === null) return;
    armorProfileId = $('armor-level-profile').value;
    renderArmorLevelPicker();
  });
  for (const id of ['equipment-search', 'equipment-kind']) $(id).addEventListener(id === 'equipment-search' ? 'input' : 'change', () => { equipmentPage = 0; renderEquipment(); });
  $('equipment-prev').addEventListener('click', () => { equipmentPage = Math.max(0, equipmentPage - 1); renderEquipment(); });
  $('equipment-next').addEventListener('click', () => { equipmentPage++; renderEquipment(); });
  $('inventory-kind').addEventListener('change', renderInventory);
  $('inventory-variant').addEventListener('change', renderInventory);
  $('inventory-set').addEventListener('change',()=>renderArmorSetChoice());
  $('inventory-set-mode').addEventListener('change',()=>renderArmorSetChoice());
  $('inventory-set-apply').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um slot.');
      const requests=selection.buildSet(inventoryState(),$('inventory-set').value,$('inventory-set-mode').value||'template-max',$('inventory-experimental').checked).map(r=>({...r,slot:selected}));
      if(!requests.length)throw new Error('As peças do conjunto já estão registradas.');
      const ids=new Set(requests.map(r=>r.id));
      commit(withImprovementMaterials([...changes.filter(r=>r.slot!==selected||!ids.has(r.id)),...requests]));
      notify('Conjunto preparado. Confira cada peça na revisão e teste a cópia no jogo.');
    }catch(e){error(e.message);}
  });
  $('inventory-search').addEventListener('input', renderInventory);
  $('removal-equipment-item').addEventListener('change',()=>{$('removal-unequipped').checked=false;renderRemovalEquipmentChoice();});
  $('removal-unequipped').addEventListener('change',()=>renderRemovalEquipmentChoice());
  $('removal-enchantment-item').addEventListener('change',()=>renderRemovalEnchantmentChoice());
  $('removal-equipment-apply').addEventListener('click',()=>{
    try{if(selected===null)throw new Error('Escolha um slot.');const id=$('removal-equipment-item').value;
      commit([...changes.filter(r=>r.slot!==selected||r.id!==id),{slot:selected,id,type:removal.EQUIPMENT,confirmUnequipped:$('removal-unequipped').checked}]);
      notify('Remoção preparada. Confira o item e os encantamentos devolvidos na revisão.');
    }catch(e){error(e.message);}
  });
  $('removal-enchantment-apply').addEventListener('click',()=>{
    try{if(selected===null)throw new Error('Escolha um slot.');const uid=Number($('removal-enchantment-item').value),id='enchantment-'+uid;
      commit([...changes.filter(r=>r.slot!==selected||r.id!==id),{slot:selected,id,uid,type:removal.ENCHANTMENT}]);
      notify('Retirada da instância preparada. Confira a revisão antes de exportar.');
    }catch(e){error(e.message);}
  });
  $('inventory-support').addEventListener('change',renderInventory);
  $('inventory-experimental').addEventListener('change',()=>renderInventoryChoice());
  $('inventory-item').addEventListener('change', () => renderInventoryChoice(inventoryState(), true));
  $('armor-clone-apply').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um slot.');
      const clone=window.Forja2018ArmorClone;
      const candidate=changes.filter(e=>e.slot!==selected||e.type!==clone.TYPE&&!(e.type==='inventory-equipment'&&clone.BASE_IDS.includes(e.id)));
      candidate.push({slot:selected,id:clone.ID,type:clone.TYPE,level:9,allowExperimental:$('inventory-experimental').checked});
      commit(withImprovementMaterials(candidate));
      notify('Conjunto Zeus preparado pelo molde nativo. Confira a cópia no jogo.');
    }catch(e){error(e.message);}
  });
  $('inventory-apply').addEventListener('click', () => {
    try {
      if (selected === null) throw new Error('Escolha um slot.');
      const id = $('inventory-item').value, stage = Number($('inventory-stage').value);
      commit(withImprovementMaterials([...changes.filter(e => e.slot !== selected || e.id !== id), {slot:selected,id,type:'inventory-equipment',stage,allowExperimental:$('inventory-experimental').checked}]));
      notify(inventory.PROFILES.find(p=>p.id===id)?.autoFullSet?'Zeus completo preparado automaticamente pelo molde do teste 05.':'Equipamento preparado por molde nativo. Confira a cópia no jogo.');
    } catch(e) { error(e.message); }
  });
  $('inventory-bulk').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um slot.');
      const state=inventoryState(),eligible=inventoryList().filter(p=>state.profiles.some(s=>s.id===p.id&&s.available&&!s.owned));
      if(!eligible.length)throw new Error('Não há peças ausentes disponíveis neste filtro.');
      if(eligible.some(inventory.requiresExperimental)&&!$('inventory-experimental').checked)throw new Error('Ative a inclusão experimental antes de preparar este lote. Talvez corrompa seu save.');
      const ids=new Set(eligible.map(p=>p.id)),mode=$('inventory-bulk-mode').value;
      const additions=selection.buildMissing(state,eligible.map(p=>p.id),mode,$('inventory-experimental').checked).map(r=>({...r,slot:selected}));
      commit(withImprovementMaterials([...changes.filter(r=>r.slot!==selected||!ids.has(r.id)),...additions]));
      notify(eligible.length+' inclusões preparadas. Revise a cópia antes de testar no jogo.');
    }catch(e){error(e.message);}
  });
  $('duplicate-origin').addEventListener('change',()=>renderDuplicateSlots());
  $('duplicate-slot').addEventListener('change',()=>renderDuplicateModels());
  $('duplicate-item').addEventListener('change',()=>renderDuplicateChoice());
  $('duplicate-experimental').addEventListener('change',()=>renderDuplicateChoice());
  $('duplicate-open').addEventListener('click',()=>$('duplicate-file').click());
  $('duplicate-file').addEventListener('change',async event=>{
    const file=event.target.files[0];if(!file)return;
    try{
      const bytes=new Uint8Array(await file.arrayBuffer()),model=core.parse(bytes,file.name);
      if(!model.slots.some(s=>s.available&&s.build===4757534))throw new Error('A origem não contém slots PC da versão 4757534.');
      enchantmentDonor={bytes,model,filename:file.name};$('duplicate-origin').innerHTML='<option value="current">Arquivo aberto</option><option value="donor">Outro arquivo</option>';$('duplicate-origin').value='donor';
      $('duplicate-experimental').checked=false;renderDuplicate();error('');notify('Origem dos modelos lida. Escolha o encantamento que quer copiar.');
    }catch(e){error(e.message);}finally{$('duplicate-file').value='';}
  });
  $('duplicate-apply').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um salvamento de destino.');
      const source=duplicateSource(),state=duplicateModels(),text=$('duplicate-item').value,choice=text===''?null:state.choices.find(o=>o.uid===Number(text));
      if(!choice||!$('duplicate-count').value.trim())throw new Error('Escolha um modelo válido e uma quantidade.');
      if(!$('duplicate-experimental').checked)throw new Error('Ative a duplicação experimental. Talvez corrompa seu save.');
      const id=inventory.duplicateId(choice.sourceSlot,choice.uid,choice.raw),candidate=changes.filter(r=>r.slot!==selected||r.id!==id);
      candidate.push({slot:selected,id,type:'enchantment-duplicate',count:Number($('duplicate-count').value),allowExperimental:true,
        templateUid:choice.uid,templateBytes:choice.raw.slice(),sourceBuild:choice.sourceBuild,sourceSlot:choice.sourceSlot,sourceName:choice.name,sourceFilename:source.filename});
      commit(candidate);notify('Cópias experimentais preparadas. O modelo original permanece intacto.');
    }catch(e){error(e.message);}
  });
  $('enchantment-create-item').addEventListener('change', () => { $('kvasir-keep').checked = false; $('enchantment-local-experimental').checked = false; renderCreationChoice(); });
  for(const id of ['enchantment-variant','enchantment-kind','enchantment-search'])$(id).addEventListener(id==='enchantment-search'?'input':'change',()=>renderCreation());
  $('enchantment-bulk-apply').addEventListener('click',()=>{
    try{
      if(selected===null)throw new Error('Escolha um slot.');
      const batch=creationBulk();if(!batch.requests.length)throw new Error('Não há encantamentos ausentes disponíveis neste filtro.');
      const ids=new Set(batch.requests.map(r=>r.id)),candidate=changes.filter(r=>r.slot!==selected||!ids.has(r.id));
      commit([...candidate,...batch.requests]);notify(batch.requests.length+' encantamentos preparados. Confira cada inclusão em Alterações.');
    }catch(e){error(e.message);}
  });
  $('enchantment-local-experimental').addEventListener('change',()=>renderCreationChoice());
  $('enchantment-create-apply').addEventListener('click', () => {
    try {
      if (selected === null) throw new Error('Escolha um slot.');
      const id = $('enchantment-create-item').value, kvasir = id === inventory.KVASIR && !inventory.FACTORIES.find(p=>p.id===id)?.validatedAcquisition;
      if (!$('enchantment-create-count').value.trim()) throw new Error('Informe a quantidade de encantamentos.');
      const candidate = changes.filter(e => e.slot !== selected || e.id !== id);
      candidate.push({slot:selected,id,type:'enchantment-create',count:kvasir?1:Number($('enchantment-create-count').value),keepTalisman:kvasir && $('kvasir-keep').checked,allowExperimental:$('enchantment-local-experimental').checked});
      commit(candidate); notify(kvasir && $('kvasir-keep').checked ? 'Teste experimental preparado: Talvez corrompa seu save.' : 'Encantamento preparado no inventário. Teste a cópia no jogo.');
    } catch(e) { error(e.message); }
  });
  $('record-search').addEventListener('input', () => { recordPage = 0; renderRecords(); });
  $('records-prev').addEventListener('click', () => { recordPage = Math.max(0, recordPage - 1); renderRecords(); });
  $('records-next').addEventListener('click', () => { recordPage++; renderRecords(); });
  for (const id of ['catalog-search', 'catalog-category']) $(id).addEventListener(id === 'catalog-search' ? 'input' : 'change', () => { catalogPage = 0; renderCatalog(); });
  $('catalog-download').addEventListener('click', () => download(window.Forja2018IdList.text($('catalog-search').value, $('catalog-category').value || 'all'), 'IDS_GOW2018.txt', 'text/plain;charset=utf-8'));
  $('catalog-prev').addEventListener('click', () => { catalogPage = Math.max(0, catalogPage - 1); renderCatalog(); });
  $('catalog-next').addEventListener('click', () => { catalogPage++; renderCatalog(); });
  $('reset-changes').addEventListener('click', () => { if (model) { $('kvasir-keep').checked = false; $('enchantment-local-experimental').checked = false; $('inventory-experimental').checked=true; $('duplicate-experimental').checked=false; commit([]); } });
  $('original-download').addEventListener('click', () => { if (model) download(sourceBytes, sourceFilename + '.original.bak'); });
  $('show-changes').addEventListener('click', () => chooseView('changes'));
  $('export-top').addEventListener('click', () => {
    try { download(exportBytes().bytes, 'game.sav'); notify('Cópia game.sav enviada para os downloads.'); } catch (e) { error(e.message); }
  });
  $('report-download').addEventListener('click', () => {
    if (!result?.log.length) return;
    download(JSON.stringify({ editor: 'Forja 2018 PC', version: core.VERSION, sourceFilename,
      outputFilename: 'game.sav', createdAt: new Date().toISOString(), changes: result.log,
      layout: result.layout, validation: { ...result.validation, preservesBytesOutsideQuantityFields: result.log.every(entry => entry.type === undefined), inGameTestedHere: false, existingQuantityEditingConfirmedByUser: true, catalogSource: 'CSV fornecido pelo usuário', unstableOreIdConfirmedByPcPair: true } }, null, 2), 'Forja_2018_alteracoes.json', 'application/json');
  });
  for (const id of ['target-stat', 'target-current', 'target-desired', 'target-rounding']) $(id).addEventListener(id === 'target-current' || id === 'target-desired' ? 'input' : 'change', renderTarget);
  $('target-apply').addEventListener('click', () => { try { const plan = getTarget(); setQuantity(plan.stat.id, plan.quantity); notify('Meta preparada. Confira a projeção e as alterações.'); } catch (e) { error(e.message); } });
  $('slot-import-open').addEventListener('click', () => $('slot-import-file').click());
  $('slot-import-file').addEventListener('change', async event => {
    const file = event.target.files[0]; if (!file) return;
    try {
      const next = slotCore.inspectSource(new Uint8Array(await file.arrayBuffer()));
      importSource = next;
      $('slot-source-choice').innerHTML = next.slots.map(slot => `<option value="${slot.index}">Slot ${slot.number} · ${escape(date(slot.timestamp))} · ${escape(slot.title)}</option>`).join('');
      renderImportPreview(); error('');
    } catch (e) { importSource = null; $('slot-source-choice').innerHTML = ''; renderImportPreview(); error(e.message); }
    finally { $('slot-import-file').value = ''; }
  });
  $('slot-source-choice').addEventListener('change', renderImportPreview);
  $('slot-import-destination').addEventListener('change', renderImportPreview);
  $('slot-import-apply').addEventListener('click', () => {
    try {
      if (!model || !importSource) throw new Error('Abra o arquivo de destino e escolha uma origem.');
      const target = Number($('slot-import-destination').value), source = Number($('slot-source-choice').value);
      if (!Number.isInteger(target) || !importSource.slots.some(slot => slot.index === source)) throw new Error('Escolha uma origem e um destino válidos.');
      const bundle = importSource.kind === 'bundle' ? importSource.bytes : slotCore.extract(importSource.bytes, source).bytes;
      commit([...changes.filter(change => change.slot !== target), { slot: target, id: 'subsave', type: 'slot-import', bundle }], target);
      chooseView('slots'); notify('Subsave importado na cópia. Confira a revisão antes de baixar.');
    } catch (e) { error(e.message); }
  });
  $('kit-choice').addEventListener('change', () => { const kit = policy.KITS.find(kit => kit.id === $('kit-choice').value); if (kit) $('kit-quantity').value = String(kit.suggested); renderKitPreview(); });
  $('kit-quantity').addEventListener('input', renderKitPreview);
  $('kit-apply').addEventListener('click', () => { try { if (selected === null) throw new Error('Escolha um slot.'); applyQuantities(policy.buildKit(result.model.slots[selected], $('kit-choice').value, Number($('kit-quantity').value))); notify('Pacote preparado para revisão.'); } catch (e) { error(e.message); } });
  $('dews-bulk-apply').addEventListener('click', () => {
    try {
      const text = $('dews-bulk-bonus').value.trim(), bonus = Number(text);
      if (selected === null || !text || !Number.isSafeInteger(bonus) || bonus < 0 || bonus % 2 || bonus / 2 > core.MAX_QUANTITY) throw new Error('Escolha um slot e um bônus inteiro par válido.');
      applyQuantities(attributes.DEWS.map(stat => ({ slot: selected, id: stat.id, quantity: bonus / 2 }))); notify('Os seis bônus de orvalhos foram preparados.');
    } catch (e) { error(e.message); }
  });
  $('difficulty-apply').addEventListener('click', () => { try { applyCampaign('difficulty', {code: Number($('difficulty-choice').value)}); } catch(e) { error(e.message); } });
  $('apples-apply').addEventListener('click', () => { try { if (!$('apples-total').value.trim()) throw new Error('Informe de 0 a 9 maçãs.'); applyCampaign('idunn-apples', {total: Number($('apples-total').value)}); } catch(e) { error(e.message); } });
  $('horns-apply').addEventListener('click', () => { try { if (!$('horns-total').value.trim()) throw new Error('Informe de 0 a 9 chifres.'); applyCampaign('blood-mead-horns', {total:Number($('horns-total').value)}); } catch(e) { error(e.message); } });
  $('stone-apply').addEventListener('click', () => { try { applyCampaign('superior-stone'); } catch(e) { error(e.message); } });
  $('berserker-apply').addEventListener('click', () => { try { applyCampaign('berserker-stone'); } catch(e) { error(e.message); } });
  $('acquire-wrist-apply').addEventListener('click', () => { try { applyCampaign('acquire-ancients-wrist'); } catch(e) { error(e.message); } });
  $('equip-chest-apply').addEventListener('click', () => { try { applyCampaign('equip-chest', {targetId: $('equip-chest-choice').value}); } catch(e) { error(e.message); } });
  $('equipment-kind').innerHTML = '<option value="all">Todos os equipamentos</option>' + Object.entries(equipment.LABELS).map(([key, label]) => `<option value="${key}">${escape(label)}</option>`).join('');
  $('inventory-kind').innerHTML = '<option value="all">Todos os tipos disponíveis</option>' + Object.entries(INVENTORY_KINDS).map(([key,label]) => `<option value="${key}">${escape(label)}</option>`).join('');
  renderFilter('catalog-category', catalog.categories); renderCatalog(); renderEquipment(); renderEnchantments(); chooseView('slots'); renderRecords();
  window.Forja2018Editor = Object.freeze({ loadBytes, selectSlot, exportBytes, chooseView,
    getState: () => ({ selected, page, changes: structuredClone(changes), log: structuredClone(result?.log || []), layout: structuredClone(result?.layout || []) }) });
})();
