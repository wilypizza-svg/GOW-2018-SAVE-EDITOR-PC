/* Nomes e categorias fornecidos pelo usuário; recursos editáveis explícitos. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('../data/catalog.json'));
  else root.Forja2018Catalog = factory(JSON.parse(document.getElementById('catalog-data').textContent));
})(typeof globalThis !== 'undefined' ? globalThis : this, function (data) {
  'use strict';
  const items = Object.freeze(data.items.map(item => Object.freeze({ ...item })));
  const byId = new Map(items.map(item => [item.id, item]));
  const lookup = id => byId.get(String(id).toUpperCase()) || null;
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const searchText = new Map(items.map(item => [item.id, normalize([item.name, item.originalName, item.internalName, item.id, item.category].join(' '))]));
  const matches = (id, query) => !query || (searchText.get(id) || normalize(id)).includes(normalize(query));
  const firstIds = ['8A9A9B831CF67C9C', '9E5240D27406E85A'];
  const editableItems = Object.freeze([
    ...firstIds.map(id => lookup(id)),
    ...items.filter(item => item.editable && !firstIds.includes(item.id)).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'))
  ]);
  return Object.freeze({ VERSION: '0.2.0', items, editableItems, lookup, normalize, matches,
    categories: Object.freeze([...new Set(items.map(item => item.category))].sort((a, b) => a.localeCompare(b, 'pt-BR'))) });
});
