/* Seleção do nível ativo de perfis reconhecidos.
   Etapas já registradas usam apenas os campos de nível sincronizados.
   O histórico de melhorias, as referências e os marcadores são preservados.
   Para registrar uma etapa nova, reutiliza os gravadores mapeados da 0.6.0.
   Os novos downgrades/retornos ainda precisam de validação no jogo. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'), require('./levels.js'), require('./armor-levels.js'), require('./armor-ancients.js'));
  else root.Forja2018LevelTargets = factory(root.Forja2018, root.Forja2018Resources, root.Forja2018Levels, root.Forja2018ArmorLevels, root.Forja2018Ancients);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources, axe, armor, ancients) {
  'use strict';
  const ARMOR = armor.PROFILE;
  const PROFILES = Object.freeze([
    Object.freeze({ id: axe.ID, name: 'Machado Leviatã', kind: 'axe', min: 1, max: 6, bias: 1, key: 1,
      sceneMarker: 'F6B0E3435B7E14EBC47FE9879611F7CA', baseId: null,
      history: Object.freeze(['21C41B327975AF5E', '3EC01B327975AF5E', '4FDC1B327975AF5E', '5CD81B327975AF5E', '6DD41B327975AF5E']),
      nativeFrom: 5, nativeTo: 6 }),
    Object.freeze({ id: ARMOR.id, name: ARMOR.name, kind: 'armor', min: 0, max: 2, bias: 0, key: ARMOR.mapKey,
      sceneMarker: null, baseId: ARMOR.baseId, history: Object.freeze([ARMOR.previousId, ARMOR.nextId]), nativeFrom: 1, nativeTo: 2 }),
    Object.freeze({ id: ancients.PROFILE.id, name: ancients.PROFILE.name, kind: 'armor', min: 0, max: 2, bias: 0, key: ancients.PROFILE.mapKey,
      sceneMarker: null, baseId: ancients.PROFILE.baseId, baseTracker: false, history: ancients.PROFILE.history, nativeWriter: 'ancients' })
  ]);
  const byId = new Map(PROFILES.map(profile => [profile.id, profile]));
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const viewOf = bytes => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
  const fromHex = value => Uint8Array.from(value.match(/../g), part => parseInt(part, 16));
  const label = (profile, value) => profile.kind === 'axe' ? 'Nível ' + value : value === 0 ? 'Base · sem reforço' : 'Melhoria ' + value;
  function read(input, slotIndex, id, parsed) {
    const profile = byId.get(id);
    if (!profile) fail('O vínculo de nível desta peça ainda não foi mapeado.');
    const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
    if (!slot?.available) fail('Escolha um slot reconhecido.');
    const state = resources.inspect(bytes, slotIndex, model), view = viewOf(bytes);
    if (!state.available) fail(state.reason);
    const u32 = p => view.getUint32(p, true), signature = (p, value) => core.hex(bytes.subarray(p, p + value.length / 2)) === value;
    function map(frame, prefix, stride) {
      const payload = frame.start + 2, count = u32(payload + prefix), entries = new Map();
      if (count > 4096 || prefix + 4 + count * stride !== frame.length) fail('Um mapa de níveis não corresponde ao formato reconhecido.');
      for (let i = 0; i < count; i++) {
        const offset = payload + prefix + 4 + i * stride, key = u32(offset);
        if (entries.has(key) || stride === 9 && bytes[offset + 8] > 1) fail('Há chaves ou marcadores inválidos no mapa de níveis.');
        entries.set(key, { value: u32(offset + 4), offset: offset + 4, flag: stride === 9 ? bytes[offset + 8] : null });
      }
      return entries;
    }
    const global = map(state.frames[0], 0, 8).get(profile.key), storedFrame = state.frames[1];
    if (!['C65F861310000000', 'ED8AAF0950420000'].some(marker => signature(storedFrame.start + 2, marker))) fail('O mapa persistido de níveis não foi reconhecido.');
    const stored = map(storedFrame, 8, 9).get(profile.key);
    if (!global || !stored || stored.flag !== 1 || global.value !== stored.value || global.value + profile.bias < profile.min || global.value + profile.bias > profile.max)
      fail('Os registros ativos desta peça estão ausentes ou não concordam.');
    const current = global.value + profile.bias, fields = [global.offset, stored.offset];
    if (profile.sceneMarker) {
      const needle = fromHex(profile.sceneMarker), positions = [], stop = slot.base + 0x10400 - needle.length - 4;
      for (let p = slot.base + 0x400; p <= stop; p++) if (bytes[p] === needle[0] && equal(bytes.subarray(p, p + needle.length), needle)) positions.push(p + needle.length);
      if (positions.length !== 1 || u32(positions[0]) !== global.value) fail('O terceiro registro do machado está ausente, repetido ou divergente.');
      fields.push(positions[0]);
    }
    function registered(id, requireTracker = true) {
      const rows = slot.rows.filter(row => row.id === id);
      if (rows.length > 1 || rows.some(row => ![0, 1].includes(row.quantity))) fail('Há marcadores de melhoria ambíguos.');
      if (!rows.length || rows[0].quantity === 0) return false;
      if (!requireTracker) return true;
      let trackers = 0;
      const final = state.frames[3];
      for (let offset = final.start + 4; offset < final.end; offset += 16) if (signature(offset, id)) trackers++;
      if (trackers !== 1) fail('O histórico da melhoria não tem um marcador final único.');
      return true;
    }
    if (profile.baseId && !registered(profile.baseId, profile.baseTracker !== false)) fail('A peça base não possui um histórico reconhecido.');
    let registeredMax = profile.min, gap = false;
    for (let i = 0; i < profile.history.length; i++) {
      const exists = registered(profile.history[i]);
      if (exists && gap) fail('O histórico contém uma melhoria sem as etapas anteriores.');
      if (exists) registeredMax = profile.min + i + 1;
      else gap = true;
    }
    if (current > registeredMax) fail('O nível ativo ultrapassa as melhorias registradas neste save.');
    if (new Set(fields).size !== fields.length) fail('Os campos de nível se sobrepõem.');
    return { available: true, slotIndex, slot, state, profile, current, registeredMax, fields };
  }
  function scalar(input, current, target) {
    const bytes = bytesOf(input), output = bytes.slice(), view = viewOf(output), raw = target - current.profile.bias;
    const fields = [...current.fields].sort((a, b) => a - b);
    for (const offset of fields) view.setUint32(offset, raw, true);
    let cursor = 0;
    for (const offset of fields) {
      if (offset < cursor || !equal(bytes.subarray(cursor, offset), output.subarray(cursor, offset))) fail('Dados fora dos campos de nível foram alterados.');
      cursor = offset + 4;
    }
    if (!equal(bytes.subarray(cursor), output.subarray(cursor))) fail('Um trecho externo ao nível não foi preservado.');
    const verified = read(output, current.slotIndex, current.profile.id);
    if (verified.current !== target || verified.registeredMax !== current.registeredMax) fail('O nível escolhido ou seu histórico não confere após a releitura.');
    return output;
  }
  function nativeInspect(bytes, current) {
    const profile = current.profile;
    const from = profile.nativeWriter === 'ancients' ? current.registeredMax : profile.nativeFrom;
    let probe = bytes;
    if (current.current !== from) {
      // Sonda apenas para oferecer opções. Não é uma saída exportável.
      // A aplicação real continua usando scalar() com verificação integral.
      probe = bytes.slice(); const view = viewOf(probe);
      current.fields.forEach(offset => view.setUint32(offset, from - profile.bias, true));
    }
    if (profile.nativeWriter === 'ancients') {
      const state = ancients.inspect(probe, current.slotIndex);
      return { available: state.available && state.canUpgrade, targets: state.options, reason: state.reason || '' };
    }
    const state = profile.kind === 'axe' ? axe.inspect(probe, current.slotIndex) : armor.inspect(probe, current.slotIndex, profile.id);
    return { available: !!state.available && !!state.canUpgrade, targets: [profile.nativeTo], reason: state.reason || '' };
  }
  function inspect(input, slotIndex, id, parsed) {
    try {
      const bytes = bytesOf(input), current = read(bytes, slotIndex, id, parsed), profile = current.profile;
      let next = { available: false, reason: '' };
      if (profile.nativeWriter === 'ancients' || current.registeredMax === profile.nativeFrom) next = nativeInspect(bytes, current);
      const options = [];
      for (let value = profile.min; value <= profile.max; value++) {
        const recorded = value <= current.registeredMax, mapped = next.available && next.targets.includes(value);
        options.push({ value, label: label(profile, value), available: recorded || mapped,
          mode: recorded ? 'registered' : mapped ? 'mapped-upgrade' : 'unmapped',
          reason: recorded || mapped ? '' : next.reason || 'Esta melhoria ainda não está registrada nem tem uma transição mapeada neste save.' });
      }
      return { ...current, options, reason: '', registeredLabel: label(profile, current.registeredMax), currentLabel: label(profile, current.current) };
    } catch (error) { return { available: false, profile: byId.get(id) || null, current: null, registeredMax: null, fields: [], options: [], reason: error.message }; }
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original), seen = new Set();
    if (!Array.isArray(requests)) fail('Plano de níveis inválido.');
    for (const request of requests) {
      if (!request || request.type !== 'level-target' || !byId.has(request.id) || !Number.isInteger(request.slot) || !model.slots[request.slot]?.available || !Number.isInteger(request.target))
        fail('Escolha uma peça reconhecida e um nível inteiro disponível.');
      const key = request.slot + ':' + request.id;
      if (seen.has(key)) fail('Há dois níveis de destino para a mesma peça no mesmo slot.');
      seen.add(key);
      const state = inspect(original, request.slot, request.id, model), option = state.options.find(option => option.value === request.target);
      if (!state.available || !option?.available) fail(state.reason || option?.reason || 'O nível escolhido está fora das opções reconhecidas para este save.');
    }
    let output = original.slice();
    const log = [], layout = [];
    for (const request of requests) {
      const current = read(output, request.slot, request.id), profile = current.profile;
      if (request.target === current.current) continue;
      const mode = request.target <= current.registeredMax ? 'registered' : 'mapped-upgrade';
      if (mode === 'registered') output = scalar(output, current, request.target);
      else {
        const native = nativeInspect(output, current);
        if (!native.available || !native.targets.includes(request.target)) fail(native.reason || 'A nova etapa não possui um caminho mapeado.');
        const from = profile.nativeWriter === 'ancients' ? current.registeredMax : profile.nativeFrom;
        if (current.current !== from) output = scalar(output, current, from);
        const result = profile.nativeWriter === 'ancients' ? ancients.patch(output, [{ slot: request.slot, id: profile.id, type: 'armor-ancients-level', stage: request.target }])
          : profile.kind === 'axe' ? axe.patch(output, [{ slot: request.slot, id: profile.id, type: 'axe-level', level: profile.nativeTo }])
            : armor.patch(output, [{ slot: request.slot, id: profile.id, type: 'armor-level', stage: profile.nativeTo }]);
        output = result.bytes;
        layout.push(...result.layout.map(entry => ({ ...entry, requestedBy: 'level-target' })));
      }
      const verified = read(output, request.slot, request.id);
      if (verified.current !== request.target || verified.registeredMax !== (mode === 'registered' ? current.registeredMax : request.target)) fail('A releitura do nível de destino não confere.');
      log.push({ type: 'level-target', id: profile.id, slot: request.slot + 1, slotIndex: request.slot,
        name: profile.name + ' · nível ativo', before: current.current, after: request.target,
        beforeLabel: label(profile, current.current), afterLabel: label(profile, request.target), mode,
        registeredMaxBefore: current.registeredMax, registeredMaxAfter: verified.registeredMax,
        synchronizedLevelFields: verified.fields, historyPreserved: true, experimental: true });
    }
    const affected = new Set(requests.map(request => request.slot));
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um slot não selecionado foi alterado.');
    return { bytes: output, model: core.parse(output), log, layout, validation: { levelTargetsInGameTested: false,
      levelTargetChanges: log.length, levelHistoryPreserved: true, levelDowngradesPreservePurchaseHistory: true,
      newlyRegisteredLevelTransitions: log.filter(entry => entry.mode === 'mapped-upgrade').length } };
  }
  return Object.freeze({ VERSION: '0.8.0', PROFILES, inspect, patch, label });
});
