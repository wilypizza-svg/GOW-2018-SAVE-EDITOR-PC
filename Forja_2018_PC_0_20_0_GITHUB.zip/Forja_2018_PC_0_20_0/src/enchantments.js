/* Leitor de instâncias de encantamento para identificar modelos e efeitos.
   A escrita em encaixes foi retirada. As novas instâncias são entregues
   soltas pelo módulo inventory.js e equipadas pelo próprio jogo. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'), require('./equipment.js'),require('../data/enchantment-acquisition.json'));
  else root.Forja2018Enchantments = factory(root.Forja2018, root.Forja2018Resources, root.Forja2018Equipment,JSON.parse(document.getElementById('enchantment-acquisition-data').textContent));
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources, equipment, acquisitionData) {
  'use strict';
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const STATS = Object.freeze({ '7A00D0F01CCEAB3A': 'Força', '48B6FD1AC0CB4E01': 'Rúnico', '0B72D37F6DC3F0F0': 'Defesa',
    'CBC51FB77C16F8F3': 'Vitalidade', '93E62C7A854C0000': 'Sorte', '57B8D16AF17D1E01': 'Recarga' });
  const RECIPE_NAMES = [{"name": "Symbol of Shadows", "kind": "loja", "bits": "0000004010000800004000400000000000000000000000000000000000000000", "first": 43696, "second": []}, {"name": "Heart of the Valkyrie", "kind": "único", "bits": "00800040C0000040001004400000000000000000000001000000000000011000", "first": 19414, "second": [816]}, {"name":"Symbol of Menace","kind":"loja","bits":"0000004010000800004000400000000000000000000000000000000000000000","first":43691,"second":[]}, {"name":"Perfect Mark of Kvasir +","kind":"único NG+","bits":"0000004000000000001020400000000000000000000000000400004000001018","first":44721,"second":[1016]}];
  RECIPE_NAMES.push({name:"Bestla's Frozen Shard+",kind:'loja NG+',bits:'0000004000000800000010400000000000000000000000000400004000002010',first:44811,second:[780]});
  // Classificação explícita dos perfis observados. O nome interno "Unique"
  // e a presença de um perk não determinam a regra de aquisição.
  RECIPE_NAMES.push({name:'Marca Perfeita do Viajante +',kind:'único NG+',bits:'0000004000000000001020400000000000000000000000000400004000001018',first:44717,second:[831]},{name:'Marca Perfeita dos Anciões +',kind:'único NG+',bits:'0000004000000000001020400000000000000000000000000400004000001018',first:44712,second:[1025]});
  RECIPE_NAMES.push(...[{"name":"Marca Perfeita de Týr +","kind":"único NG+","bits":"0000004000000000001020400000000000000000000000000400004000001018","first":44726,"second":[814]},{"name":"Marca Perfeita da Proteção +","kind":"único NG+","bits":"0000004000000000001020400000000000000000000000000400004000001018","first":44725,"second":[1017]},{"name":"Aurvandil's Fiery Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400008000002010","first":44817,"second":[772]},{"name":"Borr's Frozen Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400004000002010","first":44812,"second":[779]},{"name":"Hyrokkin's Fiery Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400008000002010","first":44814,"second":[773]},{"name":"Dagr's Fiery Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400008000002010","first":44815,"second":[776]},{"name":"Jarnsaxa's Fiery Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400008000002010","first":44816,"second":[774]},{"name":"Logi's Fiery Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400008000002010","first":44818,"second":[775]},{"name":"Hroodr's Frozen Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400004000002010","first":44809,"second":[781]},{"name":"Buri's Frozen Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400004000002010","first":44813,"second":[778]},{"name":"Hymir's Frozen Shard+","kind":"loja NG+","bits":"0000004000000800000010400000000000000000000000000400004000002010","first":44810,"second":[777]}]);
  const RULES=Object.freeze({43696:"common",19414:"unique",43691:"common",44721:"unique",44811:"common",44717:"unique",44712:"unique",44726:"unique",44725:"unique",44817:"common",44812:"common",44814:"common",44815:"common",44816:"common",44818:"common",44809:"common",44813:"common",44810:"common"});
  for(const p of acquisitionData.profiles.filter(p=>p.nativeModel))RECIPE_NAMES.push({name:p.name,kind:p.classification==='unique'?'único':'comum',classification:p.classification,bits:p.signature.bits,firstList:p.signature.lists[0],second:p.signature.lists[1]});
  function matchRecipe(bits,lists){
    return RECIPE_NAMES.find(recipe=>{const first=recipe.firstList||[recipe.first];return bits===recipe.bits&&lists[0].length===first.length&&lists[0].every((value,index)=>value===first[index])&&lists[1].length===recipe.second.length&&lists[1].every((value,index)=>value===recipe.second[index]);})||null;
  }
  const classificationOf=recipe=>recipe?(recipe.classification||RULES[recipe.first]):'unknown';
  function classifyRaw(input){
    const raw=bytesOf(input),view=new DataView(raw.buffer,raw.byteOffset,raw.byteLength);
    if(raw.length<84||core.hex(raw.subarray(0,8))!=='3B056E1555DABD5D')fail('Bloco de encantamento inválido.');
    let cursor=72;const lists=[];
    for(let k=0;k<2;k++){
      if(cursor+4>raw.length)fail('Lista de efeitos incompleta.');
      const count=view.getUint32(cursor,true);cursor+=4;
      if(count>64||cursor+count*4>raw.length)fail('Lista de efeitos inválida.');
      const values=[];for(let i=0;i<count;i++,cursor+=4)values.push(view.getUint32(cursor,true));lists.push(values);
    }
    if(cursor+4>raw.length)fail('Bloco de atributos incompleto.');
    const count=view.getUint32(cursor,true);if(count>64||cursor+4+count*12!==raw.length)fail('Tamanho do bloco de atributos inválido.');
    const recipe=matchRecipe(core.hex(raw.subarray(16,48)),lists),classification=classificationOf(recipe);
    return {classification,unique:classification==='unique',conversion:recipe?.first===44721,name:recipe?.name||null,recognized:!!recipe};
  }
  const recordId = uid => 'enchantment-' + uid;
  function inspect(input, slotIndex, parsed) {
    try {
      const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
      if (!slot?.available) fail('Escolha um slot reconhecido.');
      const state = resources.inspect(bytes, slotIndex, model);
      if (!state.available) fail(state.reason);
      const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), u32 = p => view.getUint32(p, true);
      const objects = [];
      for (const object of state.objects) {
        const { start, end, uid } = object, bindingId = core.hex(bytes.subarray(start + 8, start + 16));
        let cursor = start + 72;
        const lists = [];
        for (let k = 0; k < 2; k++) {
          const count = u32(cursor); cursor += 4; const values = [];
          for (let i = 0; i < count; i++, cursor += 4) values.push(u32(cursor));
          lists.push(values);
        }
        const count = u32(cursor); cursor += 4;
        const stats = [], ids = new Set(); let valid = u32(start + 60) === 1;
        for (let i = 0; i < count; i++, cursor += 12) {
          const id = core.hex(bytes.subarray(cursor, cursor + 8)), value = view.getFloat32(cursor + 8, true);
          if (ids.has(id) || !Number.isFinite(value) || value < 0 || value > 1000000) valid = false;
          ids.add(id); stats.push({ id, name: STATS[id] || null, value });
        }
        if (cursor !== end) fail('O registro de encantamento não termina no limite esperado.');
        const visibleStats = stats.filter(stat => stat.name), kind = equipment.armorKind(bindingId);
        const binding = equipment.lookup(bindingId), link = u32(start + 52), socket = u32(start + 56);
        // Dois nomes ligados por equipar/desquipar nas amostras. O UID não é
        // usado como identificador global; perfil e listas precisam coincidir.
        const named = matchRecipe(core.hex(bytes.subarray(start + 16, start + 48)),lists);
        const usable = valid && visibleStats.length > 0;
        objects.push({ uid, id: recordId(uid), start, end, length: end - start, bindingId, link, socket,
          kind, armorName: kind ? binding.stage.name : null, lists, stats, visibleStats, usable, sampleName: named?.name || null, sampleKind: named?.kind || null,
          classification:classificationOf(named),unique:classificationOf(named)==='unique',
          target: usable && !!kind && (link !== 0xFFFFFFFF || !!named) && socket < 3 });
      }
      const targets = objects.filter(object => object.target), seen = new Set();
      for (const target of targets) {
        const key = target.bindingId + ':' + target.socket;
        if (seen.has(key)) fail('Há mais de um registro para o mesmo encaixe de armadura.');
        seen.add(key);
      }
      return { available: true, slotIndex, state, objects, targets, templates: objects.filter(object => object.usable),
        reason: targets.length ? '' : 'Não há um encantamento associado a um encaixe de armadura reconhecido neste slot.' };
    } catch (error) { return { available: false, targets: [], templates: [], objects: [], reason: error.message }; }
  }
  function summary(object) {
    const format = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 });
    return (object.sampleName ? object.sampleName + ' · ' : '') + object.visibleStats.map(stat => stat.name + ' ' + format.format(stat.value)).join(' · ') || 'Sem atributos identificados';
  }
  return Object.freeze({ VERSION: '0.14.2', STATS, classifyRaw, inspect, summary });
});
