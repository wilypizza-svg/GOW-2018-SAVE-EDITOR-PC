/* Receitas PC mapeadas e moldes experimentais. Os IDs da família preenchem
   cada etapa. Índices PC desconhecidos não são copiados nem deduzidos do CSV.
   A montagem dos IDs por molde não prova o nível real no jogo. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('../data/inventory-profiles.json'),require('./inventory-catalog.js'),require('./enchantments.js'),require('./equipment.js'),require('./armor-template-clone.js'),require('./equipment-record-clone.js'),require('./enchantment-instance-clone.js'),require('./runics.js'),require('./compatibility.js'),require('./enchantment-acquisition.js'));
  else root.Forja2018Inventory=factory(root.Forja2018,root.Forja2018NativeRecords,JSON.parse(document.getElementById('inventory-data').textContent),root.Forja2018InventoryCatalog,root.Forja2018Enchantments,root.Forja2018Equipment,root.Forja2018ArmorClone,root.Forja2018EquipmentClone,root.Forja2018EnchantmentClone,root.Forja2018Runics,root.Forja2018Compatibility,root.Forja2018EnchantmentAcquisition);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,data,catalog,enchants,equipmentCatalog,armorClone,recordClone,instanceClone,runics,compat,acquisition){
  'use strict';
  const fail=m=>{throw new Error(m);},MAPPED_PROFILES=Object.freeze(data.profiles.map(p=>p.mode==='quantity'?Object.freeze({...p,sharedCampaign:true}):p)),PROFILES=Object.freeze([...MAPPED_PROFILES,...catalog.profiles,...runics.profiles]),FACTORIES=Object.freeze([...data.enchantments.map(p=>acquisition.lookup(p.id)||p),...acquisition.PROFILES.filter(p=>!data.enchantments.some(q=>q.id===p.id))]);
  const TYPES=Object.freeze(['inventory-equipment','enchantment-create','enchantment-duplicate',armorClone.TYPE]);
  const KVASIR='3CACEA8D28B756B4',MENACE='43AF176CDD226DD8',KVASIR_KEY=959;
  const BESTLA='7DD0A7B4B01F5116',CURSED='B19A13C4B34FA37F';
  const BLADE_FINAL_LIMIT=native.MAX_FINALS;
  const MAX_ONLY_BLADES=new Set(['ACA76C51F8DD4AEB','AA1C44285192C8C0','23D287FFCB336671','A8850E68CC1A3CB4']);
  const maximumOnly=p=>!!p&&p.kind==='blades'&&p.variant==='NG+'&&p.experimentalTemplate===true&&MAX_ONLY_BLADES.has(p.id);
  const requiresExperimental=p=>!!p?.experimentalTemplate&&!maximumOnly(p);
  // Origem informada pelo usuário. Não deduz referências de compra a partir
  // da origem: os vínculos de cada etapa vêm das amostras correspondentes.
  const ACQUISITION_ORIGINS=Object.freeze({B19A13C4B34FA37F:'chest',ACA76C51F8DD4AEB:'chest',AA1C44285192C8C0:'chest','23D287FFCB336671':'shop',A8850E68CC1A3CB4:'chest'});
  const SACRIFICE=Object.freeze(['44C4565F57AD8B0C','B7AB0C2C27078684','A65DA1787B482B84','874E711224448484']);
  const KVASIR_REF='9469F5C56C4DF108';
  const readValue=r=>r?native.view(r).getUint32(4,true):null;
  function profileState(tx,p){
    try{
      compat.requireNative(tx,'Equipamentos e melhorias');
      if(runics.isTemplate(p))return runics.state(tx,p);
      if(p.experimentalTemplate){
        if(p.kind==='blades'&&p.variant==='NG+'&&!maximumOnly(p))fail('Este cabo NG+ ainda não tem inclusão validada.');
        const qty=native.quantity(tx,p.id);
        if(qty!==null&&qty!==0&&qty!==1)fail('A quantidade da peça não é única.');
        let highest=qty===1?0:-1,gap=false;
        for(let k=1;k<p.ids.length;k++){const q=native.quantity(tx,p.ids[k]);
          if(q===1){if(qty!==1||gap)fail('Há melhorias sem uma base e um histórico completo.');highest=k;}
          else if(q===null||q===0)gap=true;else fail('Uma flag de melhoria é inválida.');
        }
        if(p.id===SACRIFICE[0]&&(native.quantity(tx,KVASIR)||0)>0)fail('A Marca de Kvasir já existe. A coexistência com o talismã permanece restrita à opção experimental da conversão.');
        return {available:true,owned:qty===1,stage:highest<0?null:highest,highest,experimentalTemplate:true,actualLevelKnown:false,maximumOnly:maximumOnly(p),maximumInGameTested:maximumOnly(p)&&tx.slot.build===p.build};
      }
      const qty=native.quantity(tx,p.id),global=native.mapEntry(tx,0,p.key),stored=native.mapEntry(tx,1,p.key);
      if(qty===null||qty===0){
        // A venda nativa pode manter o mapa e zerar toda a família.
        // Aceitar somente esse estado coerente, sem peça equipada ou encaixes.
        const retainedStage=readValue(global),ids=new Set(p.ids);
        const bound=tx.state.objects.concat(...tx.state.groups.map(g=>g.objects)).some(o=>ids.has(core.hex(tx.bytes.subarray(o.start+8,o.start+16))));
        if(qty===0&&p.mode!=='quantity'&&global&&!stored&&retainedStage>=0&&retainedStage<p.stages.length&&
          p.ids.slice(1).every(id=>{const q=native.quantity(tx,id);return q===null||q===0;})&&
          p.ids.slice(1,retainedStage+1).every(id=>native.quantity(tx,id)===0)&&!bound)
          return {available:true,owned:false,stage:null,highest:-1,nativeSoldState:true,retainedStage};
        if(global||stored||p.ids.slice(1).some(id=>(native.quantity(tx,id)||0)>0))fail('Há registros parciais da peça; aquisição bloqueada.');
        return {available:true,owned:false,stage:null,highest:-1};
      }
      const stage=readValue(global);
      if(!global||stage<0||stage>=p.stages.length||stored&&(stored[8]!==1||readValue(stored)!==stage))fail('Os mapas de progressão da peça divergem.');
      if(p.mode==='quantity'){
        if(qty!==stage+1)fail('O nível rúnico e o contador do ataque divergem.');
        return {available:true,owned:true,stage,highest:stage};
      }
      if(qty!==1)fail('A quantidade da peça base não é única.');
      let highest=0,gap=false;
      for(let k=1;k<p.ids.length;k++){
        const q=native.quantity(tx,p.ids[k]);
        if(q===1){if(gap)fail('O histórico de melhorias está incompleto.');highest=k;}
        else if(q===null||q===0)gap=true;else fail('Uma flag de melhoria não é válida.');
      }
      if(highest<stage)fail('Falta parte do histórico do nível selecionado.');
      return {available:true,owned:true,stage,highest};
    }catch(e){return {available:false,owned:false,stage:null,reason:e.message};}
  }
  function inspect(input,index,parsed){
    try{
      const tx=native.read(input,index,parsed);
      return {available:true,armorClone:armorClone.inspectTx(tx),profiles:PROFILES.map(p=>({...p,...profileState(tx,p),sourceBuild:tx.slot.build,crossBuild:tx.slot.build!==p.build,acquisitionOrigin:ACQUISITION_ORIGINS[p.id]||null})),
        enchantments:FACTORIES.map(p=>({...p,...factoryState(tx,p)}))};
    }catch(e){return {available:false,profiles:[],enchantments:[],reason:e.message};}
  }
  function factoryState(tx,p){
    if(acquisition.handles(p.id))return acquisition.inspectTx(tx,p.id);
    try{
      if(tx.slot.build!==data.build)fail('A criação de encantamentos foi mapeada para a versão PC 4757534.');
      const qty=native.quantity(tx,p.id)||0;
      if(p.id===KVASIR){
        if(qty>0)fail('A Marca Perfeita de Kvasir já foi registrada neste slot.');
        const recipe=native.fromHex(p.raw),listEnd=88;
        if(tx.state.objects.some(o=>native.equal(tx.bytes.subarray(o.start+16,o.start+48),recipe.subarray(16,48))&&native.equal(tx.bytes.subarray(o.start+64,o.start+listEnd),recipe.subarray(64,listEnd))))fail('Já há uma instância da Marca de Kvasir; os registros de posse divergem.');
        if(SACRIFICE.some(id=>native.quantity(tx,id)!==1)||readValue(native.mapEntry(tx,0,KVASIR_KEY))!==3)fail('A conversão exige o Amuleto de Kvasir + com todas as três melhorias.');
        if(native.mapEntry(tx,1,KVASIR_KEY))fail('Desequipe o Amuleto de Kvasir + no jogo antes de convertê-lo.');
        if((native.quantity(tx,'9E5240D27406E85A')||0)<40000)fail('São necessários 40.000 Hacksilver para a conversão.');
      }
      const rule=enchants.classifyRaw(native.fromHex(p.raw));
      const local=p.id===BESTLA?instanceClone.localModel(tx,p):null;
      return {available:true,quantity:qty,classification:rule.classification,unique:rule.unique,conversion:rule.conversion,
        experimentalClone:p.id===BESTLA,localTemplateUid:local?.object.uid??null};
    }catch(e){return {available:false,quantity:native.quantity(tx,p.id)||0,reason:e.message};}
  }
  function removeFinals(tx,ids){tx.finals=tx.finals.filter(r=>!ids.has(native.idOf(r)));}
  function insertRef(tx,ref){
    if(native.unique(tx.refs,ref.id))return;
    for(const id of ref.after){const found=native.unique(tx.refs,id);if(found){tx.refs.splice(tx.refs.indexOf(found)+1,0,native.fromHex(ref.id));return;}}
    for(const id of ref.before){const found=native.unique(tx.refs,id);if(found){tx.refs.splice(tx.refs.indexOf(found),0,native.fromHex(ref.id));return;}}
    // A lista é uma coleção contada de identificadores, sem offsets externos.
    tx.refs.push(native.fromHex(ref.id));
  }
  function equipment(tx,r,p){
    const s=profileState(tx,p);
    if(!s.available)fail(s.reason);
    if(!Number.isInteger(r.stage)||r.stage<0||r.stage>=p.stages.length)fail('Escolha um dos níveis mapeados para esta peça.');
    if(runics.isTemplate(p))return runics.apply(tx,r,p);
    if(maximumOnly(p)){
      if(r.stage!==p.stages.length-1)fail('Este cabo NG+ foi validado para inclusão no nível 9.');
      if(s.owned){
        if(s.highest===p.stages.length-1)return null;
        fail('Este cabo já existe. Faça as melhorias no jogo; a alteração de um nível já registrado ainda exige seu índice PC próprio.');
      }
    }
    if(p.experimentalTemplate){
      if(requiresExperimental(p)&&r.allowExperimental!==true)fail('Ative a inclusão e os upgrades por molde experimental. Talvez corrompa seu save.');
      if(s.owned&&r.stage<s.highest)fail('A redução de nível exige o índice PC da peça. O molde preserva as melhorias existentes.');
      const advancing=!s.owned||r.stage>s.highest;
      const clone=recordClone.copyHistory(tx,p,r.stage);
      const finals=recordClone.normalizeFinals(tx,p,r.stage,advancing);
      if(!advancing&&!clone.addedPrimaryRows&&!finals.removedBaseNotices&&!finals.addedUpgradeNotices)return null;
      return {before:s.owned?s.highest:null,after:r.stage,beforeLabel:s.owned?'Histórico até etapa '+s.highest:'Ausente',
        afterLabel:maximumOnly(p)?tx.slot.build===p.build?'Nível 9 · inclusão validada no jogo':'Nível 9 · compatibilidade de versão em teste':'Clonagem até '+p.stages[r.stage].label+' · confirmar no jogo',name:p.name,
        acquired:!s.owned,experimentalTemplate:true,prototypeId:p.prototypeId,stageIds:p.ids.slice(0,r.stage+1),
        ...clone,...finals,levelMapWritten:false,actualLevelVerified:maximumOnly(p)&&tx.slot.build===p.build,warning:maximumOnly(p)&&tx.slot.build===p.build?null:'Talvez corrompa seu save'};
    }
    if(s.owned&&s.stage===r.stage)return null;
    const target=p.stages[r.stage],retained=s.owned&&p.mode==='history'&&s.highest>=r.stage;
    if(p.mode==='quantity')native.putQuantity(tx,p.id,r.stage+1,true);
    else recordClone.copyHistory(tx,p,r.stage);
    const global=native.mapEntry(tx,0,p.key),stored=native.mapEntry(tx,1,p.key);
    if(global)native.view(global).setUint32(4,r.stage,true);else native.addGlobal(tx,p.key,r.stage);
    if(stored)native.view(stored).setUint32(4,r.stage,true);
    if(!retained){
      const refs=new Set(p.referenceIds),wanted=new Set(target.refs.map(x=>x.id));
      tx.refs=tx.refs.filter(row=>!refs.has(native.idOf(row))||wanted.has(native.idOf(row)));
      // Não recria notificações antigas. Só o novo passo acrescenta flags finais.
      const managed=new Set([...p.ids,...p.referenceIds]);
      removeFinals(tx,managed);
      for(const ref of target.refs)insertRef(tx,ref);
      for(const f of target.finals)native.ensureFinal(tx,f.id,f.metadata);
    }
    return {before:s.stage,after:r.stage,beforeLabel:s.owned?'Nível '+p.stages[s.stage].label:'Ausente',
      afterLabel:'Nível '+target.label+(retained?' · histórico preservado':''),name:p.name,
      acquired:!s.owned,retainedHistory:retained};
  }
  function nextUid(tx){
    // Reserva acima de todas as identidades conhecidas, inclusive grupos finais.
    const used=tx.state.objects.concat(...tx.state.groups.map(g=>g.objects)).map(o=>o.uid);
    for(const r of tx.finals)if(native.view(r).getUint32(8,true)===2){const v=native.view(r);if(v.getUint32(4,true)===0)used.push(v.getUint32(0,true));}
    for(const r of tx.newObjects||[])used.push(native.view(r).getUint32(48,true));
    const uid=Math.max(0,...used)+1;
    if(!Number.isSafeInteger(uid)||uid>=0xFFFFFFFF)fail('Não foi possível reservar uma identidade livre.');
    return uid;
  }
  function duplicateChoices(input,index,parsed){
    try{
      const bytes=native.bytesOf(input),model=parsed||core.parse(bytes),slot=model.slots[index];
      if(!slot?.available||slot.build!==data.build)fail('Escolha um slot da versão PC 4757534 como origem.');
      const state=enchants.inspect(bytes,index,model);if(!state.available)fail(state.reason);
      return {available:true,choices:state.templates.filter(o=>o.lists[0].length>0&&(o.bindingId==='0000000000000000'||!!o.kind)).map(o=>({
        uid:o.uid,name:enchants.summary(o),sampleName:o.sampleName,raw:bytes.slice(o.start,o.end),sourceBuild:slot.build,
        sourceSlot:index,sourceArmor:o.armorName||null,sourceSocket:o.socket,classification:o.classification,unique:o.unique
      }))};
    }catch(e){return {available:false,choices:[],reason:e.message};}
  }
  function validateTemplate(r){
    if(r.allowExperimental!==true)fail('Ative a duplicação experimental de encantamentos. Talvez corrompa seu save.');
    if(r.sourceBuild!==data.build)fail('O modelo precisa vir da versão PC 4757534.');
    const b=native.bytesOf(r.templateBytes),v=native.view(b),u32=p=>v.getUint32(p,true);
    if(b.length<100||b.length>2048||core.hex(b.subarray(0,8))!=='3B056E1555DABD5D'||u32(60)!==1||u32(48)!==r.templateUid)fail('Modelo de encantamento inválido.');
    if(enchants.classifyRaw(b).unique)fail('Encantamento único reconhecido: a duplicação genérica foi bloqueada. Kvasir usa somente sua conversão específica.');
    let p=72,n=u32(p);if(n<1||n>64)fail('A origem não tem uma receita de efeitos reconhecida.');p+=4+n*4;
    if(p+4>b.length)fail('Modelo incompleto.');n=u32(p);if(n>64)fail('Lista de origem inválida.');p+=4+n*4;
    if(p+4>b.length)fail('Modelo incompleto.');n=u32(p);p+=4;
    if(n<1||n>64||p+n*12!==b.length)fail('Os atributos do modelo não conferem.');
    let visible=0;const ids=new Set();
    for(let k=0;k<n;k++,p+=12){const id=core.hex(b.subarray(p,p+8)),value=v.getFloat32(p+8,true);
      if(ids.has(id)||!Number.isFinite(value)||value<0||value>1000000)fail('A origem contém atributos inválidos.');
      ids.add(id);if(enchants.STATS[id])visible++;
    }
    if(!visible)fail('A origem não tem atributos de encantamento identificados.');
    return b;
  }
  function duplicateId(sourceSlot,uid,input){
    let hash=0x811C9DC5;for(const byte of native.bytesOf(input))hash=Math.imul(hash^byte,0x01000193)>>>0;
    return 'enchantment-duplicate-'+sourceSlot+'-'+uid+'-'+hash.toString(16).padStart(8,'0');
  }
  function duplicate(tx,r){
    if(tx.slot.build!==data.build)fail('A duplicação foi preparada para a versão PC 4757534.');
    const raw=validateTemplate(r),count=r.count;
    if(!Number.isInteger(count)||count<1||count>10)fail('Escolha de 1 a 10 cópias por pedido.');
    const uids=[];tx.newObjects=tx.newObjects||[];
    for(let k=0;k<count;k++){
      const b=raw.slice(),uid=nextUid(tx),v=native.view(b);
      b.fill(0,8,16);v.setUint32(48,uid,true);v.setUint32(52,0xFFFFFFFF,true);v.setUint32(56,0xFFFFFFFF,true);
      tx.newObjects.push(b);uids.push(uid);
      const id=new Uint8Array(8);native.view(id).setUint32(0,uid,true);
      native.ensureFinal(tx,core.hex(id),'02000000F37F0000');
    }
    return {before:0,after:count,beforeLabel:'Nenhuma cópia nova',afterLabel:count+' cópia(s) solta(s) · experimental',
      name:'Duplicar encantamento · '+(r.sourceName||'registro '+r.templateUid),uids,templateUid:r.templateUid,
      sourceFilename:r.sourceFilename||null,sourceSlot:r.sourceSlot,warning:'Talvez corrompa seu save',
      existingRecipeCountersPreserved:true,looseBindingExperimental:true};
  }
  function create(tx,r,p){
    if(acquisition.handles(r.id))return acquisition.apply(tx,r);
    if(r.keepTalisman!==undefined&&typeof r.keepTalisman!=='boolean')fail('Opção experimental inválida.');
    const s=factoryState(tx,p);if(!s.available)fail(s.reason);
    const count=r.count===undefined?1:r.count;
    if(!Number.isInteger(count)||count<1||count>10||p.id===KVASIR&&count!==1)fail('Inclua entre 1 e 10 símbolos, ou uma única Marca de Kvasir.');
    if(p.id!==KVASIR&&r.keepTalisman)fail('A opção de manter o talismã só se aplica à Marca de Kvasir.');
    if(p.id===BESTLA&&(r.allowExperimental!==true||count!==1))fail('Bestla exige clonagem local experimental e uma unidade por teste. Esse limite é do teste, não uma classificação como único.');
    if(p.id===KVASIR){
      if(!r.keepTalisman){
        for(const id of SACRIFICE)native.putQuantity(tx,id,0);
        tx.maps[0].entries=tx.maps[0].entries.filter(row=>native.view(row).getUint32(0,true)!==KVASIR_KEY);
        tx.refs=tx.refs.filter(row=>native.idOf(row)!==KVASIR_REF);
        removeFinals(tx,new Set([...SACRIFICE,KVASIR_REF]));
      }
      native.putQuantity(tx,'9E5240D27406E85A',native.quantity(tx,'9E5240D27406E85A')-40000);
    }
    const uids=[],templateUids=[];tx.newObjects=tx.newObjects||[];
    for(let k=0;k<count;k++){
      const uid=nextUid(tx),built=p.id===BESTLA?instanceClone.build(tx,p,uid):null,raw=built?built.raw:native.fromHex(p.raw),v=native.view(raw);
      if(built)templateUids.push(built.templateUid);
      raw.fill(0,8,16);v.setUint32(48,uid,true);
      // Um vínculo numérico da amostra não é portável. A nova instância fica
      // solta, como a compra comum observada: não aponta para outro objeto.
      v.setUint32(52,0xFFFFFFFF,true);v.setUint32(56,0xFFFFFFFF,true);
      tx.newObjects.push(raw);uids.push(uid);
      const id=new Uint8Array(8);native.view(id).setUint32(0,uid,true);
      if(p.id!==BESTLA)native.ensureFinal(tx,core.hex(id),p.uidMetadata);
    }
    native.putQuantity(tx,p.id,s.quantity+count,true);
    if(!native.unique(tx.finals,p.id))native.ensureFinal(tx,p.id,p.recipeMetadata);
    return {before:s.quantity,after:s.quantity+count,beforeLabel:s.quantity?'Registrados: '+s.quantity:'Ausente',
      afterLabel:p.name+' · '+count+' nova(s) instância(s)'+(r.keepTalisman?' · Talvez corrompa seu save':'')+
        (p.id===KVASIR?(r.keepTalisman?' · talismã preservado':' · talismã e melhorias consumidos')+' · 40.000 Hacksilver':''),name:p.name,uids,
      keepTalisman:!!r.keepTalisman,warning:r.keepTalisman||p.id===BESTLA?'Talvez corrompa seu save':null,looseBindingExperimental:true,
      classification:s.classification,unique:s.unique,localTemplate:p.id===BESTLA,templateUids,instanceAcquisitionNoticeAdded:p.id!==BESTLA};
  }
  function normalizeRequests(requests){
    if(!Array.isArray(requests))fail('Plano de inventário inválido.');
    const zeus=requests.filter(r=>r?.type==='inventory-equipment'&&armorClone.BASE_IDS.includes(r.id));
    for(const r of zeus)if(r.stage!==2||r.allowExperimental!==true)fail('O molde de Zeus inclui o conjunto completo no nível 9. Ative a inclusão experimental.');
    const slots=new Set(zeus.map(r=>r.slot)),done=new Set(),seen=new Set();
    for(const r of requests){if(!r)continue;const key=r.slot+':'+r.id;if(seen.has(key))fail('Há dois pedidos para o mesmo item.');seen.add(key);}
    const out=[];
    for(const r of requests){
      if(r?.type===armorClone.TYPE&&slots.has(r.slot))armorClone.checkRequest(r);
      if(r&&(r.type==='inventory-equipment'&&armorClone.BASE_IDS.includes(r.id)||r.type===armorClone.TYPE&&slots.has(r.slot))){
        if(!done.has(r.slot)){out.push({slot:r.slot,id:armorClone.ID,type:armorClone.TYPE,level:9,allowExperimental:true});done.add(r.slot);}
      }else out.push(r);
    }
    return out;
  }
  function patch(input,requests=[]){
    requests=normalizeRequests(requests);
    const original=native.bytesOf(input),originalModel=core.parse(original),seen=new Set();
    if(!Array.isArray(requests))fail('Plano de inventário inválido.');
    for(const r of requests){
      if(!r||!TYPES.includes(r.type)||!Number.isInteger(r.slot)||!originalModel.slots[r.slot]?.available)fail('Escolha um slot reconhecido.');
      const items=r.type==='inventory-equipment'?PROFILES:FACTORIES;
      if(r.type===armorClone.TYPE){
        armorClone.checkRequest(r);
        if(requests.some(other=>other.slot===r.slot&&other.type==='inventory-equipment'&&armorClone.BASE_IDS.includes(other.id)))fail('Use o conjunto clonado ou os ajustes individuais de Zeus nesta exportação.');
      }else if(r.type==='enchantment-duplicate'){
        if(!Number.isInteger(r.templateUid)||r.templateUid<0||!Number.isInteger(r.sourceSlot)||r.sourceSlot<0||r.sourceSlot>=core.SLOT_COUNT||r.id!==duplicateId(r.sourceSlot,r.templateUid,r.templateBytes))fail('Pedido de duplicação inválido.');
        validateTemplate(r);
      }else if(!items.some(p=>p.id===r.id))fail('Este item não tem receita PC de aquisição mapeada.');
      const key=r.slot+':'+r.id;if(seen.has(key))fail('Há dois pedidos para o mesmo item.');seen.add(key);
    }
    let bytes=original;const log=[],layout=[],groups=new Map();
    for(const r of requests){if(!groups.has(r.slot))groups.set(r.slot,[]);groups.get(r.slot).push(r);}
    // Mantém o limite do gravador nativo (32 novas instâncias por escrita).
    // Um lote maior é composto internamente em etapas, sem expor arquivos
    // intermediários e sem alterar a ordem dos pedidos ou a revisão final.
    const transactions=[];
    for(const [index,group]of groups){
      let chunk=[],weight=0;
      for(const r of group){const objects=['enchantment-create','enchantment-duplicate'].includes(r.type)?Number.isInteger(r.count)&&r.count>0&&r.count<=10?r.count:1:0;
        if(weight+objects>32&&chunk.length){transactions.push([index,chunk]);chunk=[];weight=0;}
        chunk.push(r);weight+=objects;
      }
      if(chunk.length)transactions.push([index,chunk]);
    }
    for(const [index,group]of transactions){
      const tx=native.read(bytes,index),pending=[];
      for(const r of group){
        const p=(r.type==='inventory-equipment'?PROFILES:FACTORIES).find(p=>p.id===r.id);
        const change=r.type===armorClone.TYPE?armorClone.apply(tx,r):r.type==='inventory-equipment'?equipment(tx,r,p):r.type==='enchantment-duplicate'?duplicate(tx,r):create(tx,r,p);
        if(change)pending.push({r,p,change});
      }
      if(!pending.length)continue;
      // O gravador comum aplica a fila nativa; a releitura confere o limite.
      const bladeChanges=pending.some(({r,p})=>r.type==='inventory-equipment'&&p.kind==='blades');
      const finalQueueBefore=tx.finals.length;
      // Um slot é recomposto uma única vez, mesmo em uma inclusão em lote.
      const result=native.write(tx);bytes=result.bytes;const next=native.read(bytes,index,result.model);
      if(bladeChanges&&next.finals.length>BLADE_FINAL_LIMIT)fail('A fila final de cabos ultrapassou o limite reconhecido.');
      for(const {r,p,change}of pending){
        if(r.type===armorClone.TYPE){armorClone.validate(next);}
        else if(r.type==='inventory-equipment'){
          const state=profileState(next,p);
          if(runics.isTemplate(p)){if(!state.available||!state.owned||state.stage!==2)fail('A inclusão do ataque rúnico não confere.');}
          else if(p.experimentalTemplate){if(native.quantity(next,p.id)!==1||p.ids.slice(0,r.stage+1).some(id=>native.quantity(next,id)!==1))fail('A inclusão dos registros do molde não confere.');}
          else if(!state.available||!state.owned||state.stage!==r.stage)fail('A releitura do equipamento não confere.');
        }else if(r.type==='enchantment-create'&&((!acquisition.handles(r.id)&&native.quantity(next,p.id)!==change.after)||change.uids.some(uid=>!next.state.objects.some(o=>o.uid===uid))))fail('As novas instâncias de encantamento não conferem.');
        if(r.type==='enchantment-create'&&acquisition.handles(r.id))acquisition.validateTx(next,r.id);
        log.push({type:r.type,id:r.id,slot:r.slot+1,slotIndex:r.slot,...change,sourceBuild:tx.slot.build,referenceBuild:p?.build??data.build,crossBuild:tx.slot.build!==(p?.build??data.build),experimental:change.validatedAcquisition?p.gameValidated===false||tx.slot.build!==p.build:r.type==='inventory-equipment'&&tx.slot.build===p.build&&p.kind==='blades'&&(p.id===CURSED||maximumOnly(p))?false:true});
      }
      layout.push({...result.layout,operation:pending.length===1?pending[0].r.type:'inventory-batch',operations:pending.length,...(bladeChanges?{finalQueueLimit:BLADE_FINAL_LIMIT,oldestFinalRowsDiscarded:Math.max(0,finalQueueBefore-BLADE_FINAL_LIMIT)}:{})});
    }
    log.sort((a,b)=>requests.findIndex(r=>r.slot===a.slotIndex&&r.id===a.id)-requests.findIndex(r=>r.slot===b.slotIndex&&r.id===b.id));
    if(!native.equal(original.subarray(0,core.HEADER_SIZE),bytes.subarray(0,core.HEADER_SIZE)))fail('O cabeçalho geral foi alterado.');
    const affected=new Set(requests.map(r=>r.slot));
    for(const s of originalModel.slots)if(!affected.has(s.index)&&!native.equal(original.subarray(s.base,s.end),bytes.subarray(s.base,s.end)))fail('Um slot não escolhido foi alterado.');
    return {bytes,model:core.parse(bytes),log,layout,validation:{inventoryInGameTested:false,inventoryChanges:log.length,
      inventoryUnmappedKeysGuessed:false,inventoryExistingObjectsPreserved:true,experimentalKvasirCoexistence:log.some(x=>x.keepTalisman),
      nativeEquipmentCloneChanges:log.filter(x=>x.nativeRecordClone).length,
      experimentalTemplateChanges:log.filter(x=>x.experimentalTemplate).length,experimentalEnchantmentDuplicates:log.filter(x=>x.type==='enchantment-duplicate').length,
      fullArmorTemplateChanges:log.filter(x=>x.fullArmorTemplate).length}};
  }
  return Object.freeze({PROFILES,MAPPED_PROFILES,FACTORIES,TYPES,KVASIR,MENACE,BESTLA,SACRIFICE,ACQUISITION_ORIGINS,BLADE_FINAL_LIMIT,maximumOnly,requiresExperimental,inspect,profileState,factoryState,duplicateChoices,duplicateId,normalizeRequests,patch});
});
