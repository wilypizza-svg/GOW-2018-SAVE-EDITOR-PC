/* Aquisição antecipada validada no jogo. Acrescenta apenas posse, referências,
   níveis iniciais e avisos; conserva seleção de arma, instâncias e mundo. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('./compatibility.js'),require('../data/blades-acquisition.json'));
 else root.Forja2018BladesUnlock=factory(root.Forja2018,root.Forja2018NativeRecords,root.Forja2018Compatibility,JSON.parse(document.getElementById('blades-acquisition-data').textContent));
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,compat,data){
 'use strict';
 const TYPE='blades-unlock',ID=TYPE,NAME='Lâminas do Caos · aquisição',fail=m=>{throw new Error(m);};
 const value=row=>row?native.view(row).getUint32(4,true):null;
 const quantityIds=data.primaryRows.map(row=>row.slice(0,16));
 function coherentMap(tx,key,max){
  const global=native.mapEntry(tx,0,key),stored=native.mapEntry(tx,1,key),raw=value(global);
  return !!global&&!!stored&&stored[8]===1&&raw===value(stored)&&raw>=0&&raw<max;
 }
 function state(tx){
  compat.requireNative(tx,'Aquisição das Lâminas');
  const main=native.quantity(tx,data.weaponId);
  if(main===1){
   if(!coherentMap(tx,3,5))fail('Os registros de nível das Lâminas divergem.');
   return {available:true,owned:true,current:value(native.mapEntry(tx,0,3))+1,reason:''};
  }
  const partial=quantityIds.some(id=>native.quantity(tx,id)!==null)||
   data.references.some(id=>native.unique(tx.refs,id))||
   data.mapKeys.some(key=>[0,1].some(frame=>native.mapEntry(tx,frame,key)))||
   data.history.some(id=>{const q=native.quantity(tx,id);return q!==null&&q!==0;});
  if(partial)fail('Há registros parciais das Lâminas neste slot. A inclusão requer um estado inicial coerente.');
  if(!coherentMap(tx,1,6))fail('Os registros do Machado deste slot não estão coerentes para incluir as Lâminas.');
  return {available:true,owned:false,current:null,reason:''};
 }
 function inspect(input,index,parsed){
  try{return state(native.read(input,index,parsed));}
  catch(e){return {available:false,owned:false,current:null,reason:e.message};}
 }
 // Requisitos adicionais para ajustar níveis sem propriedade secundária.
 // A busca dessa propriedade é feita pelo leitor de níveis, em todo o slot.
 function mapsOnlyReady(tx){
  try{
   if(!state(tx).owned||!coherentMap(tx,80,1))return false;
   if(!quantityIds.every(id=>native.quantity(tx,id)===1))return false;
   return data.references.filter(id=>id!==data.baseRecipe).every(id=>native.unique(tx.refs,id));
  }catch(e){return false;}
 }
 function patch(input,requests=[]){
  const original=native.bytesOf(input),model=core.parse(original),seen=new Set();
  if(!Array.isArray(requests))fail('Plano de aquisição das Lâminas inválido.');
  for(const r of requests){
   if(!r||r.type!==TYPE||r.id!==ID||!Number.isInteger(r.slot)||!model.slots[r.slot]?.available)fail('Escolha um slot reconhecido para incluir as Lâminas.');
   if(seen.has(r.slot))fail('Há duas inclusões das Lâminas no mesmo slot.');seen.add(r.slot);
  }
  let bytes=original;const log=[],layout=[];
  for(const r of requests){
   const tx=native.read(bytes,r.slot),before=state(tx);if(before.owned)continue;
   for(const raw of data.primaryRows){
    const row=native.fromHex(raw);native.view(row).setUint32(12,tx.rows.length,true);tx.rows.push(row);
   }
   for(let i=0;i<data.referenceOrder.length;i++){
    const id=data.referenceOrder[i];if(!data.references.includes(id))continue;
    const anchor=data.referenceOrder.slice(0,i).reverse().find(id=>native.unique(tx.refs,id));
    if(!anchor)fail('A referência necessária para incluir as Lâminas não foi reconhecida.');
    native.insertRefAfter(tx,id,anchor);
   }
   for(const key of data.mapKeys)native.addGlobal(tx,key,0);
   for(const key of data.mapKeys){
    const entries=tx.maps[1].entries;
    const anchor=key===3?1:entries.map(row=>native.view(row).getUint32(0,true)).find(key=>data.axeHandleKeys.includes(key))??3;
    const at=entries.findIndex(row=>native.view(row).getUint32(0,true)===anchor);
    if(at<0)fail('O ponto de inclusão no mapa de equipamento não foi reconhecido.');
    const row=new Uint8Array(9);native.view(row).setUint32(0,key,true);row[8]=1;entries.splice(at+1,0,row);
   }
   // A amostra nativa contém dois avisos diferentes com o mesmo ID de habilidade.
   tx.finals.push(...data.finalRows.map(native.fromHex));
   const next=native.write(tx),check=native.read(next.bytes,r.slot,next.model);
   if(!state(check).owned||!mapsOnlyReady(check))fail('A releitura da aquisição das Lâminas não confere.');
   bytes=next.bytes;layout.push({...next.layout,operation:TYPE});
   log.push({type:TYPE,id:ID,name:NAME,slot:r.slot+1,slotIndex:r.slot,before:null,after:1,
    beforeLabel:'Não possuídas',afterLabel:'Adicionadas · nível 1 · cabo padrão',
    weaponSelectionPreserved:true,worldPreserved:true,questEventsCopied:false,
    acquisitionReportedWorkingByUser:true,earlyCampaignReportedWorkingByUser:true});
  }
  if(!native.equal(original.subarray(0,core.HEADER_SIZE),bytes.subarray(0,core.HEADER_SIZE)))fail('O cabeçalho geral foi alterado.');
  for(const slot of model.slots)if(!seen.has(slot.index)&&!native.equal(original.subarray(slot.base,slot.end),bytes.subarray(slot.base,slot.end)))fail('Um slot não escolhido foi alterado.');
  return {bytes,model:core.parse(bytes),log,layout,validation:{bladesAcquisitions:log.length,bladesAcquisitionWorldPreserved:true,bladesAcquisitionGameValidated:true}};
 }
 return Object.freeze({TYPE,ID,inspect,mapsOnlyReady,patch});
});
