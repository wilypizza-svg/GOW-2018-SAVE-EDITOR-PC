(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./wallet.js'), require('./levels.js'), require('./armor-levels.js'), require('./level-targets.js'), require('./slots.js'), require('./campaign.js'), require('./inventory.js'), require('./weapon-levels.js'), require('./ciphers.js'), require('./inventory-removal.js'), require('./blades-unlock.js'));
  else root.Forja2018Plan = factory(root.Forja2018Wallet, root.Forja2018Levels, root.Forja2018ArmorLevels, root.Forja2018LevelTargets, root.Forja2018Slots, root.Forja2018Campaign, root.Forja2018Inventory, root.Forja2018WeaponLevels, root.Forja2018Ciphers, root.Forja2018Removal, root.Forja2018BladesUnlock);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (resources, levels, armorLevels, levelTargets, slots, campaign, inventory, weaponLevels, ciphers, removal, bladesUnlock) {
  'use strict';
  function patch(input, requests = []) {
    if (!Array.isArray(requests)) throw new Error('O plano de alterações deve ser uma lista.');
    if (requests.some(change => change && ['attach-enchantment','enchantment-copy','enchantment-stat'].includes(change.type))) throw new Error('A edição de encaixes foi removida. Adicione o encantamento ao inventário e equipe-o pelo jogo.');
    requests = inventory.normalizeRequests(requests);
    if (requests.some(change => !change || ![undefined, 'axe-level', 'armor-level', 'level-target', weaponLevels.TYPE, bladesUnlock.TYPE, ciphers.TYPE, 'slot-import', 'slot-delete', ...campaign.TYPES, ...inventory.TYPES, ...removal.TYPES].includes(change.type))) throw new Error('Tipo de alteração desconhecido.');
    for (const change of requests.filter(c => ['inventory-equipment','armor-set-template'].includes(c.type))) {
      if (requests.some(c => c.slot === change.slot && ['armor-level','level-target','equip-chest'].includes(c.type))) throw new Error('Prepare a edição de inventário separadamente dos controles antigos de nível e equipamento.');
    }
    for (const equip of requests.filter(change => change.type === 'equip-chest')) if (requests.some(change => change.slot === equip.slot && ['armor-level', 'level-target'].includes(change.type))) throw new Error('Prepare a troca de peitoral separadamente das alterações de nível.');
    const levelKeys = new Set();
    for (const request of requests.filter(change => ['axe-level', 'armor-level', 'level-target', weaponLevels.TYPE].includes(change.type))) {
      const key = request.slot + ':' + request.id;
      if (levelKeys.has(key)) throw new Error('Há duas alterações de nível para a mesma peça no mesmo slot.');
      levelKeys.add(key);
    }
    const slotRequests = requests.filter(change => ['slot-import', 'slot-delete'].includes(change.type));
    const structural = slotRequests.length ? slots.patch(input, slotRequests) : null;
    const baseBytes = structural?.bytes || input;
    const resourceResult = resources.patch(baseBytes, requests.filter(change => change.type === undefined));
    const baseModel = structural?.model || resourceResult.originalModel;
    const levelRequests = requests.filter(change => change.type === 'axe-level');
    let result = structural ? { ...resourceResult, log: [...structural.log, ...resourceResult.log], layout: [...structural.layout, ...resourceResult.layout], validation: { ...structural.validation, ...resourceResult.validation } } : resourceResult;
    const campaignRequests = requests.filter(change => campaign.TYPES.includes(change.type));
    if (campaignRequests.length) {
      const next = campaign.patch(result.bytes, campaignRequests);
      result = { ...next, log: [...result.log, ...next.log], layout: [...result.layout, ...next.layout], validation: { ...result.validation, ...next.validation } };
    }
    const cipherRequests = requests.filter(change => change.type === ciphers.TYPE);
    const bladesRequests = requests.filter(change => change.type === bladesUnlock.TYPE);
    if (bladesRequests.length) {
      const next = bladesUnlock.patch(result.bytes, bladesRequests);
      result = {...next,log:[...result.log,...next.log],layout:[...result.layout,...next.layout],validation:{...result.validation,...next.validation}};
    }
    if (cipherRequests.length) {
      const next = ciphers.patch(result.bytes, cipherRequests);
      result = {...next, log:[...result.log,...next.log],layout:[...result.layout,...next.layout],validation:{...result.validation,...next.validation}};
    }
    const inventoryRequests = requests.filter(change => inventory.TYPES.includes(change.type));
    if (inventoryRequests.length) {
      const next = inventory.patch(result.bytes, inventoryRequests);
      result = { ...next, log: [...result.log, ...next.log], layout: [...result.layout, ...next.layout], validation: { ...result.validation, ...next.validation } };
    }
    if (levelRequests.length) {
      const levelResult = levels.patch(result.bytes, levelRequests);
      result = { ...levelResult, log: [...result.log, ...levelResult.log], layout: [...result.layout, ...levelResult.layout],
        validation: { ...result.validation, axeLevelInGameTested: false, axeLevelTransitions: levelResult.log.length } };
    }
    const armorRequests = requests.filter(change => change.type === 'armor-level');
    if (armorRequests.length) {
      const armorResult = armorLevels.patch(result.bytes, armorRequests);
      result = { ...armorResult, log: [...result.log, ...armorResult.log], layout: [...result.layout, ...armorResult.layout],
        validation: { ...result.validation, ...armorResult.validation } };
    }
    const targetRequests = requests.filter(change => change.type === 'level-target');
    if (targetRequests.length) {
      const targetResult = levelTargets.patch(result.bytes, targetRequests);
      result = { ...targetResult, log: [...result.log, ...targetResult.log], layout: [...result.layout, ...targetResult.layout],
        validation: { ...result.validation, ...targetResult.validation } };
    }
    const weaponRequests = requests.filter(change => change.type === weaponLevels.TYPE);
    if (weaponRequests.length) {
      const next = weaponLevels.patch(result.bytes, weaponRequests);
      result = {...next, log:[...result.log,...next.log],layout:[...result.layout,...next.layout],validation:{...result.validation,...next.validation}};
    }
    const removalRequests = requests.filter(change => removal.TYPES.includes(change.type));
    if (removalRequests.length) {
      for (const r of removalRequests) if (requests.some(c=>c.slot===r.slot&&c.id===r.id&&c.type!==r.type)) throw new Error('Escolha uma ação por item: adicionar, ajustar ou remover.');
      const next = removal.patch(result.bytes, removalRequests);
      result = {...next, log:[...result.log,...next.log],layout:[...result.layout,...next.layout],validation:{...result.validation,...next.validation}};
    }
    return { ...result, baseBytes, baseModel };
  }
  return Object.freeze({ patch });
});
