/* Cifras: partes 0..4, marca de conclusão 0/1. Estados observados nos slots
   nativos e aquisição de Niflheim no par antes/depois. Não copia eventos de
   abertura de baú, missões ou mundo; não remove cifras já coletadas. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('./compatibility.js'));
 else root.Forja2018Ciphers=factory(root.Forja2018,root.Forja2018NativeRecords,root.Forja2018Compatibility);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,compat){
 'use strict';
 const TYPE='realm-cipher',fail=m=>{throw new Error(m);};
 const STORY_WARNING='Evite adicionar cifras de Muspelheim ou Niflheim antes da primeira viagem a Alfheim. Isso pode travar a cena em que Freya pede para mover a ponte de Týr. Conclua essa sequência antes de usar as cifras pelo editor.';
 const PROFILES=Object.freeze([
  Object.freeze({id:'niflheim-cipher',name:'Cifras de Niflheim',piece:'BF717A0CBE634AD9',complete:'04F506B8591A794C'}),
  Object.freeze({id:'muspelheim-cipher',name:'Cifras de Muspelheim',piece:'48ECF23EF868FBE4',complete:'3926F91F998D0F89'})
 ]),byId=new Map(PROFILES.map(p=>[p.id,p]));
 function inspect(input,index,id,parsed){
  try{
   const p=byId.get(id);if(!p)fail('Cifra fora do catálogo.');
   const tx=native.read(input,index,parsed);compat.requireNative(tx,'Cifras dos reinos');
   const total=native.quantity(tx,p.piece)??0,complete=native.quantity(tx,p.complete)??0;
   if(total>4||![0,1].includes(complete)||complete!==(total===4?1:0))fail('As partes e a marca de cifra completa divergem.');
   return {available:true,total,complete:complete===1,profile:p,reason:''};
  }catch(e){return {available:false,total:null,complete:false,profile:byId.get(id)||null,reason:e.message};}
 }
 function patch(input,requests=[]){
  const original=native.bytesOf(input),model=core.parse(original),seen=new Set();
  if(!Array.isArray(requests))fail('Plano de cifras inválido.');
  for(const r of requests){
   if(!r||r.type!==TYPE||!byId.has(r.id)||!Number.isInteger(r.slot)||!model.slots[r.slot]?.available||!Number.isInteger(r.total)||r.total<0||r.total>4)fail('Escolha uma cifra, um slot e um total entre 0 e 4.');
   const key=r.slot+':'+r.id;if(seen.has(key))fail('Há dois totais para a mesma cifra.');seen.add(key);
  }
  let bytes=original;const log=[],layout=[];
  for(const r of requests){
   const s=inspect(bytes,r.slot,r.id);if(!s.available)fail(s.reason);
   if(r.total<s.total)fail('A remoção de cifras já coletadas está bloqueada para preservar o acesso aos reinos.');
   if(r.total===s.total)continue;
   const tx=native.read(bytes,r.slot),p=s.profile;
   native.putQuantity(tx,p.piece,r.total,true);
   if(!native.unique(tx.finals,p.piece))native.ensureFinal(tx,p.piece,'00000000F77F0000');
   if(r.total===4){
    native.putQuantity(tx,p.complete,1,true);
    if(!native.unique(tx.finals,p.complete))native.ensureFinal(tx,p.complete,'00000000F77F0000');
   }
   const next=native.write(tx),check=inspect(next.bytes,r.slot,r.id,next.model);
   if(!check.available||check.total!==r.total)fail('A releitura das cifras não confere.');
   bytes=next.bytes;layout.push({...next.layout,operation:TYPE});
   log.push({type:TYPE,id:r.id,slot:r.slot+1,slotIndex:r.slot,name:p.name,before:s.total,after:r.total,
    beforeLabel:s.total+'/4 partes',afterLabel:r.total+'/4 partes'+(check.complete?' · cifra completa':''),experimental:true,
    worldPreserved:true,chestEventsCopied:false,inGameTestedHere:false,storyWarning:STORY_WARNING});
  }
  if(!native.equal(original.subarray(0,core.HEADER_SIZE),bytes.subarray(0,core.HEADER_SIZE)))fail('O cabeçalho geral foi alterado.');
  const affected=new Set(requests.map(r=>r.slot));
  for(const s of model.slots)if(!affected.has(s.index)&&!native.equal(original.subarray(s.base,s.end),bytes.subarray(s.base,s.end)))fail('Um slot não escolhido foi alterado.');
  return {bytes,model:core.parse(bytes),log,layout,validation:{cipherChanges:log.length,cipherInGameTested:false}};
 }
 return Object.freeze({TYPE,PROFILES,STORY_WARNING,inspect,patch});
});
