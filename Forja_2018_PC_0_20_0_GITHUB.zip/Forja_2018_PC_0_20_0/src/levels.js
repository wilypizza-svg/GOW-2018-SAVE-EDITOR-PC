/* Melhoria de machado 5 -> 6, baseada no par de saves de PC fornecido.
   O nível aparece em três mapas. O par também acrescenta o Tier06 em duas
   tabelas e retira uma referência de 8 bytes. Não altera o estoque de chamas.
   Outras transições aguardam amostras; a edição precisa de teste no jogo. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'));
  else root.Forja2018Levels = factory(root.Forja2018, root.Forja2018Resources);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources) {
  'use strict';
  const ID = 'axe-main-level', TIER5 = '5CD81B327975AF5E', TIER6 = '6DD41B327975AF5E';
  const EARLIER = ['21C41B327975AF5E', '3EC01B327975AF5E', '4FDC1B327975AF5E', TIER5];
  const OLD_REFERENCE = '123C61DD7BE614A1', PROPERTY = 'F6B0E3435B7E14EBC47FE9879611F7CA';
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const viewOf = bytes => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const fromHex = value => Uint8Array.from(value.match(/../g), value => parseInt(value, 16));
  const equal = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);
  function inspect(input, slotIndex, parsed) {
    try {
      const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
      if (!slot?.available) fail('Escolha um slot reconhecido.');
      const state = resources.inspect(bytes, slotIndex, model), view = viewOf(bytes);
      if (!state.available) fail(state.reason);
      const u32 = p => view.getUint32(p, true), signature = (p, id) => core.hex(bytes.subarray(p, p + id.length / 2)) === id;
      function map(frame, prefix, stride) {
        const start = frame.start + 2, count = u32(start + prefix);
        if (count > 4096 || prefix + 4 + count * stride !== frame.length) fail('Um mapa de níveis não corresponde ao formato confirmado.');
        const entries = [], seen = new Set();
        for (let i = 0; i < count; i++) {
          const offset = start + prefix + 4 + i * stride, key = u32(offset);
          if (seen.has(key) || stride === 9 && bytes[offset + 8] > 1) fail('Há chaves ou marcadores inválidos no mapa de níveis.');
          seen.add(key); entries.push({ key, value: u32(offset + 4), valueOffset: offset + 4 });
        }
        return entries;
      }
      const globalMap = map(state.frames[0], 0, 8), storedFrame = state.frames[1];
      const marker = core.hex(bytes.subarray(storedFrame.start + 2, storedFrame.start + 10));
      if (!['C65F861310000000', 'ED8AAF0950420000'].includes(marker)) fail('O mapa persistido de níveis ainda não foi reconhecido.');
      const storedMap = map(storedFrame, 8, 9), global = globalMap.find(entry => entry.key === 1), stored = storedMap.find(entry => entry.key === 1);
      if (!global || !stored || global.value !== stored.value || global.value > 5) fail('Os registros de nível do machado não concordam.');
      const level = global.value + 1, result = { available: true, canUpgrade: false, level, slotIndex, slot,
        state, global, stored, globalMap, storedMap, reason: level === 6 ? 'O machado já está no nível 6.' : 'Esta etapa confirma somente a melhoria do nível 5 para o 6.' };
      if (level !== 5) return result;
      if (EARLIER.some(id => slot.rows.filter(row => row.id === id && row.quantity === 1).length !== 1) || slot.rows.some(row => row.id === TIER6))
        fail('Os marcadores de melhoria não correspondem ao machado de nível 5 confirmado.');
      const references = [];
      for (let i = 0; i < slot.table.count8; i++) {
        const offset = slot.table.end + i * 8;
        if (signature(offset, OLD_REFERENCE)) references.push(offset);
      }
      if (references.length !== 1) fail('A referência da última melhoria está ausente ou repetida.');
      const properties = [], needle = fromHex(PROPERTY), stop = slot.base + 0x10400 - needle.length - 4;
      for (let p = slot.base + 0x400; p <= stop; p++) if (bytes[p] === needle[0] && equal(bytes.subarray(p, p + needle.length), needle)) properties.push(p + needle.length);
      if (properties.length !== 1 || u32(properties[0]) !== global.value) fail('O nível persistido da cena não corresponde ao machado.');
      const final = state.frames[3], templates = [];
      for (let p = final.start + 4; p < final.end; p += 16) {
        if (signature(p, TIER6)) fail('Já há um marcador final da melhoria de nível 6.');
        if (signature(p, TIER5)) templates.push(p);
      }
      if (templates.length !== 1 || !signature(templates[0] + 8, '00000000F67F0000')) fail('O registro final usado como modelo não corresponde à amostra.');
      if (state.activeEnd + 24 + 4096 > slot.base + 0x30400 || final.length + 16 > 65535 || slot.table.count >= 4096)
        fail('O limite estrutural para esta melhoria foi atingido.');
      return { ...result, canUpgrade: true, reason: '', propertyOffset: properties[0], referenceOffset: references[0], trackerTemplate: templates[0] };
    } catch (e) { return { available: false, canUpgrade: false, level: null, reason: e.message }; }
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original);
    if (!Array.isArray(requests)) fail('Plano de níveis inválido.');
    const selected = [], seen = new Set();
    for (const change of requests) {
      if (!change || change.type !== 'axe-level' || change.id !== ID || !Number.isInteger(change.slot) || !model.slots[change.slot]?.available || change.level !== 6)
        fail('Esta versão permite a melhoria confirmada do machado de 5 para 6.');
      if (seen.has(change.slot)) fail('Há duas melhorias para o mesmo slot.');
      seen.add(change.slot);
      const state = inspect(original, change.slot, model);
      if (state.available && state.level === 6) continue;
      if (!state.available || !state.canUpgrade) fail(state.reason);
      selected.push(state);
    }
    const output = original.slice(), view = viewOf(output), log = [], layout = [];
    for (const current of selected) {
      const { slot, state } = current, primary = slot.rows.find(row => row.id === TIER5), final = state.frames[3];
      const newFlag = original.slice(primary.offset, primary.offset + 16), flagView = viewOf(newFlag);
      newFlag.set(fromHex(TIER6)); flagView.setUint32(8, 1, true); flagView.setUint32(12, slot.rows.length, true);
      const tracker = original.slice(current.trackerTemplate, current.trackerTemplate + 16); tracker.set(fromHex(TIER6));
      const edits = [{ start: slot.table.end, remove: 0, bytes: newFlag }, { start: current.referenceOffset, remove: 8, bytes: new Uint8Array() },
        { start: state.activeEnd, remove: 0, bytes: tracker }];
      let read = slot.table.end, write = read;
      const segments = [{ start: slot.base, end: read, dest: slot.base }];
      for (const edit of edits) {
        if (edit.start < read || edit.start > state.activeEnd) fail('As operações de melhoria se sobrepõem.');
        output.set(original.subarray(read, edit.start), write); segments.push({ start: read, end: edit.start, dest: write });
        write += edit.start - read; output.set(edit.bytes, write); write += edit.bytes.length; read = edit.start + edit.remove;
      }
      const endAfter = state.activeEnd + 24;
      if (write !== endAfter) fail('O tamanho da melhoria não confere.');
      segments.push({ start: endAfter, end: slot.end, dest: endAfter });
      const fields = [
        { offset: state.statsHeader, width: 4, value: state.statsSize + 8 },
        { offset: slot.table.start - 12, width: 4, value: slot.table.count + 1 },
        { offset: slot.table.start - 8, width: 4, value: slot.table.count8 - 1 },
        { offset: slot.base + 0x124, width: 4, value: state.activeSize + 24 },
        { offset: final.start + 8 + 2, width: 2, value: final.length + 16 },
        { offset: current.global.valueOffset + 8, width: 4, value: 5 },
        { offset: current.stored.valueOffset + 8, width: 4, value: 5 },
        { offset: current.propertyOffset, width: 4, value: 5 }
      ];
      for (const field of fields) view[field.width === 2 ? 'setUint16' : 'setUint32'](field.offset, field.value, true);
      // Compara cada trecho copiado, descontando apenas os campos explicitamente alterados.
      for (const segment of segments) {
        const end = segment.dest + segment.end - segment.start; let cursor = segment.dest;
        for (const field of fields.filter(field => field.offset >= segment.dest && field.offset < end).sort((a, b) => a.offset - b.offset)) {
          const source = segment.start + cursor - segment.dest;
          if (!equal(original.subarray(source, source + field.offset - cursor), output.subarray(cursor, field.offset))) fail('Dados não relacionados à melhoria foram alterados.');
          cursor = field.offset + field.width;
        }
        const source = segment.start + cursor - segment.dest;
        if (!equal(original.subarray(source, segment.end), output.subarray(cursor, end))) fail('Um trecho original do slot não foi preservado.');
      }
      const verified = core.parse(output), after = inspect(output, slot.index, verified);
      if (!after.available || after.level !== 6 || after.state.activeEnd !== endAfter || verified.slots[slot.index].table.count8 !== slot.table.count8 - 1 ||
        !verified.slots[slot.index].rows.some(row => row.id === TIER6 && row.quantity === 1)) fail('A releitura do nível não confere.');
      for (const row of slot.rows) {
        const next = verified.slots[slot.index].rows.find(item => item.id === row.id);
        if (!next || next.quantity !== row.quantity || next.auxiliary !== row.auxiliary) fail('Um item ou recurso original foi alterado.');
      }
      log.push({ type: 'axe-level', id: ID, slot: slot.number, slotIndex: slot.index, name: 'Nível do Machado Leviatã', before: 5, after: 6,
        offset: current.global.valueOffset + 8, length: 4, experimental: true, synchronizedLevelFields: fields.slice(-3).map(field => field.offset) });
      layout.push({ slot: slot.number, operation: 'axe-level-5-to-6', addedPrimaryRecords: 1, removedReferences: 1,
        addedFinalRecords: 1, addedBytes: 24, activeEndBefore: state.activeEnd, activeEndAfter: endAfter, resourcesPreserved: true, inGameTestedHere: false });
    }
    const affected = new Set(selected.map(state => state.slot.index));
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um slot não selecionado foi alterado.');
    return { bytes: output, model: core.parse(output), log, layout };
  }
  return Object.freeze({ VERSION: '0.4.0', ID, TIER5, TIER6, inspect, patch });
});
