/* Catálogo de famílias. Um ID de melhoria não determina, sozinho,
   os vínculos e níveis de uma instância de equipamento no save. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./catalog.js'));
  else root.Forja2018Equipment = factory(root.Forja2018Catalog);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (catalog) {
  'use strict';
  const LABELS = Object.freeze({ chest: 'Peitorais', wrist: 'Braçadeiras', waist: 'Cinturas',
    axe: 'Cabos do machado', blades: 'Cabos das lâminas', talisman: 'Talismãs',
    'main-axe': 'Melhorias do machado', 'main-blades': 'Melhorias das lâminas',
    bow: 'Melhorias do arco', quiver: 'Melhorias da aljava', other: 'Outras melhorias' });
  const directKind = item => {
    const n = item.internalName;
    if (/^KratosArmorChest_/.test(n)) return 'chest';
    if (/^KratosArmorWrist_/.test(n)) return 'wrist';
    if (/^KratosArmorLegs_/.test(n)) return 'waist';
    if (/^WeaponComponent_Axe_/.test(n)) return 'axe';
    if (/^WeaponComponent_Blades_/.test(n)) return 'blades';
    if (/^KratosArmorTrinket_/.test(n) || item.sourceType === 'Talisman') return 'talisman';
    if (item.sourceType === 'Axe Pommel') return /blades/i.test(n) ? 'blades' : 'axe';
    const m = /^Reinforcement(Axe|Blades|Bow|Quiver)_Tier\d+/.exec(n);
    return m ? ({ Axe: 'main-axe', Blades: 'main-blades', Bow: 'bow', Quiver: 'quiver' })[m[1]] : null;
  };
  const keyOf = item => /^Reinforcement(?:Axe|Blades|Bow|Quiver)_Tier\d+/.test(item.internalName)
    ? item.internalName.replace(/_Tier\d+/, '') : item.internalName.replace(/_Reinforce\d+/, '');
  const groups = new Map();
  for (const item of catalog.items) {
    const key = keyOf(item);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }
  const families = [];
  for (const [key, members] of groups) {
    const kind = members.map(directKind).find(Boolean) || (members.some(item => /_Reinforce\d+/.test(item.internalName)) ? 'other' : null);
    if (!kind) continue;
    const stages = members.map(item => {
      const reinforcement = /_Reinforce(\d+)/.exec(item.internalName), tier = /_Tier(\d+)/.exec(item.internalName);
      const main = /^Reinforcement/.test(item.internalName);
      const order = main && tier ? Number(tier[1]) : reinforcement ? Number(reinforcement[1]) : 0;
      return Object.freeze({ ...item, order, stage: main && tier ? 'Nível ' + order : order ? 'Melhoria ' + order : 'Base',
        isUpgrade: !!reinforcement || main && !!tier });
    }).sort((a, b) => a.order - b.order || a.id.localeCompare(b.id));
    const base = stages.find(item => !item.isUpgrade) || stages[0];
    families.push(Object.freeze({ key, kind, kindName: LABELS[kind], name: base.name, stages: Object.freeze(stages) }));
  }
  families.sort((a, b) => a.kindName.localeCompare(b.kindName, 'pt-BR') || a.name.localeCompare(b.name, 'pt-BR'));
  const byId = new Map();
  for (const family of families) for (const stage of family.stages) byId.set(stage.id, { family, stage });
  const upgrades = Object.freeze(catalog.items.filter(item => /_Reinforce\d+|^Reinforcement(?:Axe|Blades|Bow|Quiver)_Tier\d+/.test(item.internalName)));
  return Object.freeze({ VERSION: '0.5.0', LABELS, families: Object.freeze(families), upgrades,
    lookup: id => byId.get(String(id).toUpperCase()) || null,
    armorKind: id => { const kind = byId.get(String(id).toUpperCase())?.family.kind; return ['chest', 'wrist', 'waist'].includes(kind) ? kind : null; } });
});
