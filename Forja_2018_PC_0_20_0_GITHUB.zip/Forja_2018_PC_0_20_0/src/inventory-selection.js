/* Seleções de conjuntos e filtros só montam pedidos para a rotina de clonagem
   existente. Não gravam bytes, não alteram níveis de peças já possuídas nem
   combinam variantes normal/NG+ por semelhança do nome visível. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./inventory.js'),require('./equipment.js'),require('./armor-template-clone.js'));
 else root.Forja2018InventorySelection=factory(root.Forja2018Inventory,root.Forja2018Equipment,root.Forja2018ArmorClone);
})(typeof globalThis!=='undefined'?globalThis:this,function(inventory,equipment,armorClone){
 'use strict';
 const fail=m=>{throw new Error(m);},kinds=['chest','wrist','waist'],groups=new Map(),byId=new Map(inventory.PROFILES.map(p=>[p.id,p]));
 for(const p of inventory.PROFILES.filter(p=>kinds.includes(p.kind))){
  const f=equipment.lookup(p.id)?.family;if(!f)fail('Família de armadura ausente.');
  const key=f.key.replace(/^KratosArmor(?:Chest|Wrist|Legs)_/,'KratosArmor_')+'::'+p.variant;
  if(!groups.has(key))groups.set(key,[]);groups.get(key).push(p);
 }
 const SETS=Object.freeze([...groups].filter(([key,parts])=>parts.length===3&&kinds.every(kind=>parts.filter(p=>p.kind===kind).length===1)).map(([id,parts])=>{
  parts.sort((a,b)=>kinds.indexOf(a.kind)-kinds.indexOf(b.kind));
  return Object.freeze({id,name:parts[0].name,variant:parts[0].variant,parts:Object.freeze(parts),
   zeus:parts.every(p=>armorClone.BASE_IDS.includes(p.id))});
 }).sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')||a.variant.localeCompare(b.variant)));
 function filterProfiles({kind='all',variant='all',support='all',query=''}={}){
  if(!['all','normal','NG+'].includes(variant))fail('Variante de equipamento inválida.');
  const normalized=String(query).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  return inventory.PROFILES.filter(p=>(kind==='all'||kind===p.kind||kind==='axe-runics-all'&&p.kind.startsWith('axe-runic')||kind==='blades-runics-all'&&p.kind.startsWith('blades-runic'))&&(variant==='all'||variant===p.variant||p.sharedCampaign)&&
   (support==='all'||support==='mapped'&&!p.experimentalTemplate||support==='base'&&p.experimentalTemplate)&&
   (p.name+' '+p.id).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(normalized));
 }
 function buildMissing(state,ids,mode='template-max',allowExperimental=false){
  if(!state?.available||!Array.isArray(ids)||new Set(ids).size!==ids.length)fail('Seleção de inventário inválida.');
  if(!['base','mapped-max','template-max'].includes(mode))fail('Escolha uma etapa de inclusão válida.');
  const requests=[];
  for(const id of ids){
   const p=byId.get(id),s=state.profiles.find(p=>p.id===id);if(!p||!s)fail('Equipamento fora do catálogo.');
   if(!s.available)fail(p.name+': '+(s.reason||'Registros incompatíveis.'));
   if(s.owned)continue;
   const stage=p.autoFullSet||inventory.maximumOnly(p)||p.mode==='runic-quantity-template'||mode==='template-max'||mode==='mapped-max'&&!p.experimentalTemplate?p.stages.length-1:0;
   if(inventory.requiresExperimental(p)&&allowExperimental!==true)fail('Ative a inclusão experimental para as peças por molde. Talvez corrompa seu save.');
   requests.push({type:'inventory-equipment',id:p.id,stage,allowExperimental:allowExperimental===true});
  }
  return requests;
 }
 function buildSet(state,id,mode='template-max',allowExperimental=false){
  const set=SETS.find(s=>s.id===id);if(!set||!state?.available)fail('Escolha um conjunto e um slot reconhecido.');
  if(set.zeus){
   if(!state.armorClone?.available)fail(state.armorClone?.reason||'O molde de Zeus não está disponível.');
   if(state.armorClone.fullyRegistered)return [];
   if(allowExperimental!==true)fail('Ative a inclusão experimental para Zeus. Talvez corrompa seu save.');
   return [{id:armorClone.ID,type:armorClone.TYPE,level:9,allowExperimental:true}];
  }
  return buildMissing(state,set.parts.map(p=>p.id),mode,allowExperimental);
 }
 return Object.freeze({SETS,filterProfiles,buildMissing,buildSet});
});
