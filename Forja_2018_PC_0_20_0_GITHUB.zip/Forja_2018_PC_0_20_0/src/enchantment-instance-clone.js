/* Constrói uma instância comum a partir de um molde do subsave de destino.
   Os efeitos vêm do perfil completo observado. Não troca só o ID da receita
   e não reaproveita a identidade ou o encaixe do modelo. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('./enchantments.js'));
  else root.Forja2018EnchantmentClone=factory(root.Forja2018,root.Forja2018NativeRecords,root.Forja2018Enchantments);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,enchantments){
  'use strict';
  const fail=message=>{throw new Error(message);};
  function localModel(tx,recipe){
    const target=native.fromHex(recipe.raw),rule=enchantments.classifyRaw(target);
    if(rule.classification!=='common')fail('A clonagem comum exige uma receita comum reconhecida.');
    const state=enchantments.inspect(tx.bytes,tx.slot.index,tx.model);
    if(!state.available)fail(state.reason);
    const options=state.templates.filter(object=>{
      const raw=tx.bytes.subarray(object.start,object.end);
      return !enchantments.classifyRaw(raw).unique&&native.equal(raw.subarray(64,72),target.subarray(64,72));
    });
    options.sort((a,b)=>Number(a.bindingId!=='0000000000000000')-Number(b.bindingId!=='0000000000000000')||a.uid-b.uid);
    if(!options.length)fail('Não há um bloco de encantamento compatível neste salvamento para a clonagem local.');
    return {object:options[0],target};
  }
  function build(tx,recipe,uid){
    const {object,target}=localModel(tx,recipe),raw=new Uint8Array(target.length),view=native.view(raw);
    raw.set(tx.bytes.subarray(object.start,object.start+72));
    raw.set(target.subarray(16,48),16);
    raw.set(target.subarray(72),72);
    raw.fill(0,8,16);
    view.setUint32(48,uid,true);view.setUint32(52,0xFFFFFFFF,true);view.setUint32(56,0xFFFFFFFF,true);view.setUint32(60,1,true);
    return {raw,templateUid:object.uid,classification:'common',localTemplate:true,effectsFromMappedRecipe:true};
  }
  return Object.freeze({localModel,build});
});
