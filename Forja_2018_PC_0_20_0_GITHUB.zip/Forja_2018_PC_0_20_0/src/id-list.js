/* Consulta em lote. Presença de ID e mapeamento de nível são conceitos distintos. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./loot-catalog.js').catalog, require('./equipment.js'), require('./level-targets.js'), require('./resource-policy.js'));
  else root.Forja2018IdList = factory(root.Forja2018Loot.catalog, root.Forja2018Equipment, root.Forja2018LevelTargets, root.Forja2018ResourcePolicy);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (catalog, equipment, targets, policy) {
  'use strict';
  function text(query = '', category = 'all') {
    const items = catalog.items.filter(item => catalog.matches(item.id, query) && (category === 'all' || item.category === category));
    const lines = ['FORJA 2018 PC — CATÁLOGO DE IDS', items.length + ' de ' + catalog.items.length + ' IDs da lista fornecida.',
      'IDs com 16 dígitos hexadecimais, na ordem literal dos 8 bytes no arquivo.',
      'Um ID no catálogo não prova posse, nível ativo nem suporte à edição.',
      'Melhoria N identifica ReinforceN; não é necessariamente o nível absoluto da peça no jogo.',
      'O mapeamento normal não se aplica automaticamente à variante NGP/NG+.', ''];
    for (const item of items) {
      const found = equipment.lookup(item.id), profile = targets.PROFILES.find(profile => profile.baseId === item.id || profile.history.includes(item.id));
      lines.push(item.id + ' | ' + item.name, '  Categoria: ' + item.category, '  Nome interno: ' + item.internalName);
      if (item.loot) lines.push('  Fonte: God of War Loot Table.xlsx, linhas ' + item.loot.sourceRows.join(', '), '  PERM_Hash da fonte: ' + item.loot.permHash + (item.loot.inventoryHash ? ' | INV_Hash (outro identificador): ' + item.loot.inventoryHash : ''), '  Index da fonte: ' + item.loot.sourceIndex + ' (não é chave de nível do save).');
      if (found) lines.push('  Família: ' + found.family.key + ' | Etapa: ' + found.stage.stage);
      lines.push(profile ? '  Campo de nível mapeado nesta família: chave ' + profile.key + '; edição depende dos registros do slot.'
        : policy.lookup(item.id) ? '  Quantidade editável no módulo de recursos.' + (policy.lookup(item.id).unique ? ' Total único: 0 ou 1 nesta política.' : '') : '  Consulta; vínculo de edição não mapeado.', '');
    }
    return lines.join('\n') + '\n';
  }
  return Object.freeze({ text });
});
