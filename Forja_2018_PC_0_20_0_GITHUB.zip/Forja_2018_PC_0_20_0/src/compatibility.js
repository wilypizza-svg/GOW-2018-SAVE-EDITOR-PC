/* Reconhecimento da gramática do save, independente do número de build.
   Contagens e offsets internos podem variar; assinaturas, tipos, limites e
   vínculos continuam validados. Não converte cabeçalhos nem libera ações
   cujos registros específicos não estejam presentes e coerentes. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'));
 else root.Forja2018Compatibility=factory(root.Forja2018);
})(typeof globalThis!=='undefined'?globalThis:this,function(core){
 'use strict';
 const PROFILE='gow2018-pc-rpg-v1',PERSISTED=Object.freeze(['C65F861310000000','ED8AAF0950420000','19682628084AEA38']);
 const fail=(feature,message)=>{throw new Error(feature+': '+message);};
 function requireSlot(slot,feature='Esta função'){
  if(!slot?.available)throw new Error('Escolha um slot reconhecido.');
  const table=slot.table;
  if(!Number.isInteger(slot.index)||slot.index<0||slot.index>=core.SLOT_COUNT||slot.base!==core.HEADER_SIZE+slot.index*core.SLOT_SIZE||slot.end!==slot.base+core.SLOT_SIZE||
   !table||table.start!==slot.base+core.TABLE_OFFSET||!Number.isInteger(table.count)||table.count<1||table.count>4096||table.end!==table.start+16*table.count||
   !Array.isArray(slot.rows)||slot.rows.length!==table.count||slot.rows[0].offset!==table.start||slot.rows.at(-1).offset!==table.end-16)
   fail(feature,'a tabela de registros não corresponde ao formato PC reconhecido.');
  return PROFILE;
 }
 function requireNative(tx,feature='Esta função'){
  requireSlot(tx?.slot,feature);
  const {bytes,slot,state}=tx,start=slot.base+0x10400,limit=slot.base+0x30400;
  if(!(bytes instanceof Uint8Array)||bytes.length!==core.FILE_SIZE||!state?.available||state.base!==slot.base||!Array.isArray(state.frames)||state.frames.length!==4)
   fail(feature,'a seção ativa não corresponde ao formato reconhecido.');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u32=at=>view.getUint32(at,true),hex=(at,n)=>core.hex(bytes.subarray(at,at+n));
  if(hex(start,2)!=='0100'||hex(start+3,2)!=='FAFF'||hex(start+9,8)!=='5F2243C695480000'||bytes[start+2]>3||u32(slot.base+0x110)!==bytes[start+2]||
   state.statsHeader!==start+5||state.statsEnd!==start+9+u32(start+5)||state.objectStart!==slot.table.end+slot.table.count8*8||
   state.objectEnd<state.objectStart||state.objectEnd>state.statsEnd||state.activeEnd!==start+u32(slot.base+0x124)||state.activeEnd>limit)
   fail(feature,'assinaturas, limites ou contadores da seção ativa divergem.');
  let cursor=state.statsEnd;
  for(let frame=0;frame<3;frame++){
   const f=state.frames[frame],prefix=frame===1?8:0,stride=frame===0?8:9;
   if(f.start!==cursor||f.end!==f.start+2+f.length||f.end>limit||f.length<prefix+4||view.getUint16(f.start,true)!==f.length)
    fail(feature,'os limites de um mapa interno não conferem.');
   if(frame===1&&!PERSISTED.includes(hex(f.start+2,8)))fail(feature,'o tipo do mapa persistido ainda não foi reconhecido.');
   const count=u32(f.start+2+prefix);
   if(count>4096||f.length!==prefix+4+count*stride)fail(feature,'o formato de um mapa interno não confere.');
   cursor=f.end;
  }
  const last=state.frames[3];
  if(last.start!==cursor||hex(last.start,2)!=='2EFA'||last.length%16||last.length>512*16||last.end!==last.start+4+last.length||last.end!==state.activeEnd)
   fail(feature,'a fila de registros auxiliares está fora do formato reconhecido.');
  return PROFILE;
 }
 function inspect(tx){
  try{return {available:true,profile:requireNative(tx),slotBuild:tx.slot.build,containerBuild:tx.model.build,reason:''};}
  catch(e){return {available:false,profile:null,reason:e.message};}
 }
 return Object.freeze({PROFILE,requireSlot,requireNative,inspect});
});
