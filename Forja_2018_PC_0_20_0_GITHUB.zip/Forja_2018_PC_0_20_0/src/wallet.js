/* Reutiliza o gravador anterior para seus 48 campos. Novos IDs só entram
   pela política explícita; nunca trata equipamentos como recursos. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'), require('./resource-policy.js'));
  else root.Forja2018Wallet = factory(root.Forja2018, root.Forja2018Resources, root.Forja2018ResourcePolicy);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, legacy, policy) {
  'use strict';
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength) : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const equal = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original), seen = new Set();
    if (!Array.isArray(requests)) fail('Plano de recursos inválido.');
    for (const request of requests) {
      const field = request && policy.lookup(request.id);
      if (!field || request.type !== undefined || !Number.isInteger(request.slot) || !model.slots[request.slot]?.available) fail('Escolha um recurso permitido e um slot reconhecido.');
      if (!Number.isSafeInteger(request.quantity) || request.quantity < 0 || request.quantity > field.max) fail('Informe um total entre 0 e ' + field.max + ' para ' + field.name + '.');
      if (model.slots[request.slot].duplicateIds.includes(field.id)) fail('O recurso selecionado está duplicado.');
      const key = request.slot + ':' + request.id;
      if (seen.has(key)) fail('Há duas alterações para o mesmo recurso no mesmo slot.'); seen.add(key);
    }
    let output = original.slice(); const log = [], layout = [];
    let newRecords = 0;
    // Lotes de até 32 inclusões usam a mesma rotina da versão anterior.
    // As operações continuam atômicas: apenas a saída completa é devolvida.
    const old = requests.filter(request => core.lookup(request.id));
    for (let start = 0; start < old.length; start += legacy.MAX_ADDITIONS) {
      const next = legacy.patch(output, old.slice(start, start + legacy.MAX_ADDITIONS)); output = next.bytes;
      log.push(...next.log); layout.push(...(next.layout || [])); newRecords += next.validation?.newRecords || 0;
    }
    const grouped = new Map();
    for (const request of requests.filter(request => !core.lookup(request.id))) {
      if (!grouped.has(request.slot)) grouped.set(request.slot, []); grouped.get(request.slot).push(request);
    }
    for (const [index, changes] of grouped) {
      const before = output, current = core.parse(before), slot = current.slots[index], state = legacy.inspect(before, index, current), view = new DataView(before.buffer, before.byteOffset, before.byteLength);
      if (!state.available) fail(state.reason);
      const additions = changes.filter(change => change.quantity > 0 && !slot.rows.some(row => row.id === change.id));
      const delta = additions.length * 16, newEnd = state.activeEnd + delta;
      if (slot.table.count + additions.length > 4096 || newEnd + 4096 > slot.base + 0x30400) fail('Não há espaço estrutural para este lote de recursos.');
      output = before.slice(); const out = new DataView(output.buffer);
      for (const change of changes) {
        const row = slot.rows.find(row => row.id === change.id), field = policy.lookup(change.id);
        if (row && row.quantity !== change.quantity) {
          out.setUint32(row.valueOffset, change.quantity, true);
          log.push({ slot: slot.number, slotIndex: index, id: field.id, name: field.name, before: row.quantity, after: change.quantity,
            offset: row.valueOffset, length: 4, type: 'wallet-quantity', experimental: true });
        }
      }
      const template = slot.rows.find(row => core.lookup(row.id)?.category === 'Recursos') || slot.rows[0];
      if (additions.length) {
        output.set(before.subarray(slot.table.end, state.activeEnd), slot.table.end + delta);
        for (let i = 0; i < additions.length; i++) {
          const change = additions[i], field = policy.lookup(change.id), p = slot.table.end + i * 16;
          output.set(before.subarray(template.offset, template.offset + 16), p);
          output.set(Uint8Array.from(field.id.match(/../g), value => parseInt(value, 16)), p);
          out.setUint32(p + 8, change.quantity, true); out.setUint32(p + 12, slot.table.count + i, true);
          log.push({ type: 'resource-add', slot: slot.number, slotIndex: index, id: field.id, name: field.name, before: null, after: change.quantity,
            offset: p, length: 16, experimental: true, templateId: template.id });
        }
        out.setUint32(state.statsHeader, state.statsSize + delta, true); out.setUint32(slot.table.start - 12, slot.table.count + additions.length, true);
        out.setUint32(slot.base + 0x124, state.activeSize + delta, true);
      }
      const verified = core.parse(output), nextSlot = verified.slots[index], next = legacy.inspect(output, index, verified);
      if (!next.available || next.activeEnd !== newEnd || nextSlot.table.count !== slot.table.count + additions.length || nextSlot.table.count8 !== slot.table.count8 || nextSlot.table.count4 !== slot.table.count4) fail('A releitura dos recursos ampliados não confere.');
      const masks = changes.map(change => slot.rows.find(row => row.id === change.id)).filter(Boolean).map(row => [row.valueOffset, row.valueOffset + 4]);
      if (delta) masks.push([state.statsHeader, state.statsHeader + 4], [slot.table.start - 12, slot.table.start - 8], [slot.base + 0x124, slot.base + 0x128]);
      let p = slot.base;
      for (const [start, end] of masks.sort((a, b) => a[0] - b[0])) {
        if (!equal(before.subarray(p, start), output.subarray(p, start))) fail('Dados externos aos recursos foram alterados.'); p = end;
      }
      if (!equal(before.subarray(p, slot.table.end), output.subarray(p, slot.table.end)) ||
        !equal(before.subarray(slot.table.end, state.activeEnd), output.subarray(slot.table.end + delta, newEnd)) ||
        !equal(before.subarray(newEnd, slot.end), output.subarray(newEnd, slot.end))) fail('Uma seção original não foi preservada.');
      for (const row of slot.rows) {
        const after = nextSlot.rows.find(x => x.id === row.id), change = changes.find(x => x.id === row.id);
        if (!after || after.quantity !== (change ? change.quantity : row.quantity) || after.auxiliary !== row.auxiliary) fail('Um estoque anterior não foi preservado.');
      }
      for (const change of changes) {
        const matches = nextSlot.rows.filter(row => row.id === change.id);
        if (matches.length !== (change.quantity > 0 || slot.rows.some(row => row.id === change.id) ? 1 : 0) || matches[0] && matches[0].quantity !== change.quantity) fail('O total do recurso não confere.');
      }
      if (delta) layout.push({ slot: slot.number, operation: 'wallet-add', addedRecords: additions.length, addedBytes: delta,
        activeEndBefore: state.activeEnd, activeEndAfter: newEnd, originalRecordsPreserved: true, unusedTailPreserved: true, inGameTestedHere: false });
      newRecords += additions.length;
    }
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    const affected = new Set(requests.map(request => request.slot));
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um slot não selecionado foi alterado.');
    return { bytes: output, model: core.parse(output), originalModel: model, log, layout, validation: { existingQuantityWriterUnchanged: true, newRecords,
      expandedResourcesInGameTested: false, inclusionInGameTested: false, questProgressFlagsUntouched: true, gameCapsAutomaticallyDetected: false } };
  }
  return Object.freeze({ VERSION: '0.9.0', patch, inspect: legacy.inspect, FIELDS: policy.FIELDS, lookup: policy.lookup });
});
