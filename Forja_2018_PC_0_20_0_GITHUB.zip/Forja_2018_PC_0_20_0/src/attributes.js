/* Orvalhos e cálculo de metas. O total equipado é informado pelo usuário;
   não é inferido de uma tabela de posse nem de estatísticas em memória. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'));
  else root.Forja2018Attributes = factory(root.Forja2018);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core) {
  'use strict';
  const DEWS = Object.freeze([
    { key: 'strength', name: 'Força', id: 'CC1B3E5C878842B3' },
    { key: 'runic', name: 'Rúnico', id: '623486F325B97A3A' },
    { key: 'defense', name: 'Defesa', id: '418F903C792C6B9C' },
    { key: 'vitality', name: 'Vitalidade', id: '6D92A12B3DC4A427' },
    { key: 'luck', name: 'Sorte', id: 'F3CBC3D285BFB35D' },
    { key: 'cooldown', name: 'Recarga', id: '6A13DB1C163C952D' }
  ].map(stat => Object.freeze(stat)));
  const fail = message => { throw new Error(message); };
  function states(slot) {
    return DEWS.map(stat => {
      const rows = slot.rows.filter(row => row.id === stat.id), quantity = rows[0]?.quantity || 0;
      return { ...stat, present: rows.length === 1, duplicate: rows.length > 1, quantity, bonus: quantity * 2 };
    });
  }
  function planTarget(slot, { key, currentTotal, desiredTotal, rounding = 'nearest' }) {
    const stat = states(slot).find(stat => stat.key === key);
    if (!stat || stat.duplicate) fail('Escolha um atributo sem registros duplicados.');
    if (![currentTotal, desiredTotal].every(value => Number.isSafeInteger(value) && value >= 0 && value <= 1000000000))
      fail('Informe totais inteiros entre 0 e 1.000.000.000.');
    if (!['nearest', 'above', 'below'].includes(rounding)) fail('Escolha como arredondar a meta.');
    const equipmentTotal = currentTotal - stat.bonus;
    if (equipmentTotal < 0) fail('O total observado no jogo é menor que o bônus de orvalhos do arquivo original.');
    const idealQuantity = (desiredTotal - equipmentTotal) / 2;
    if (idealQuantity < 0) fail('Essa meta fica abaixo da contribuição do equipamento. Reduza o equipamento no jogo.');
    const quantity = ({ nearest: Math.round, above: Math.ceil, below: Math.floor })[rounding](idealQuantity);
    if (quantity > core.MAX_QUANTITY) fail('A quantidade calculada excede o limite do editor.');
    return { stat, quantity, equipmentTotal, idealQuantity, projectedTotal: equipmentTotal + quantity * 2,
      exact: Number.isInteger(idealQuantity), lowerTotal: equipmentTotal + Math.floor(idealQuantity) * 2,
      upperTotal: equipmentTotal + Math.ceil(idealQuantity) * 2, request: { slot: slot.index, id: stat.id, quantity } };
  }
  return Object.freeze({ DEWS, states, planTarget });
});
