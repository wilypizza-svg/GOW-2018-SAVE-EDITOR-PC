/* Forja 2018 PC. Leitura de slots e edição limitada a quantidades existentes.
   Catálogo conferido com os arquivos de PC e a alteração de Unstable Ore.
   As rotinas de leitura e gravação de quantidades são as mesmas da 0.1.0. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./catalog.js'));
  else root.Forja2018 = factory(root.Forja2018Catalog);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (catalog) {
  'use strict';
  const VERSION = '0.20.0', HEADER_SIZE = 0x1040, SLOT_SIZE = 0x1998C8, SLOT_COUNT = 20;
  const TABLE_OFFSET = 0x1041D, FILE_SIZE = HEADER_SIZE + SLOT_SIZE * SLOT_COUNT;
  const MAX_QUANTITY = 2147483647;
  const FIELDS = catalog.editableItems;
  const byId = new Map(FIELDS.map(field => [field.id, field]));
  const fail = message => { throw new Error(message); };
  const asBytes = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um arquivo game.sav de PC.');
  const hex = input => Array.from(input, value => value.toString(16).padStart(2, '0')).join('').toUpperCase();
  const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
  const lookup = id => byId.get(id) || null;
  function text(bytes, start, end) {
    const raw = bytes.subarray(start, end), zero = raw.indexOf(0);
    return new TextDecoder('utf-8', { fatal: true }).decode(zero < 0 ? raw : raw.subarray(0, zero));
  }
  function readSlot(bytes, index) {
    const base = HEADER_SIZE + index * SLOT_SIZE, end = base + SLOT_SIZE;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const slot = { index, number: index + 1, base, end, available: false, empty: false,
      title: '', timestamp: 0, build: null, rows: [], reason: '' };
    if (bytes.subarray(base, base + 256).every(value => value === 0)) {
      slot.empty = true; slot.reason = 'Slot vazio ou sem cabeçalho reconhecido.'; return slot;
    }
    try {
      const low = view.getUint32(base, true), high = view.getUint32(base + 4, true);
      slot.timestamp = high * 4294967296 + low;
      if (!Number.isSafeInteger(slot.timestamp) || slot.timestamp < 946684800 || slot.timestamp > 7258118400)
        fail('A data deste slot não corresponde ao perfil reconhecido.');
      if (view.getUint32(base + 8, true) !== 10) fail('O cabeçalho deste slot ainda não é reconhecido.');
      slot.build = view.getUint32(base + 12, true);
      slot.title = text(bytes, base + 16, base + 256).trim();
      if (!slot.title || /[\x00-\x1F]/.test(slot.title)) fail('A descrição deste slot não foi reconhecida.');
      const table = base + TABLE_OFFSET;
      if (hex(bytes.subarray(table - 20, table - 16)) !== '5F2243C6' || hex(bytes.subarray(table, table + 8)) !== FIELDS[0].id)
        fail('A tabela de quantidades deste slot ainda não foi reconhecida.');
      const count = view.getUint32(table - 12, true);
      if (!count || count > 4096 || table + count * 16 > end) fail('A contagem da tabela deste slot não confere.');
      const count8 = view.getUint32(table - 8, true), count4 = view.getUint32(table - 4, true);
      if (count8 > 20000 || count4 > 20000 || table + count * 16 + count8 * 8 + count4 * 4 > end)
        fail('As referências da tabela ultrapassam o espaço do slot.');
      for (let rowIndex = 0; rowIndex < count; rowIndex++) {
        const offset = table + rowIndex * 16, id = hex(bytes.subarray(offset, offset + 8));
        if (/^(?:0{16}|F{16})$/.test(id)) fail('Um registro da tabela tem identificador inválido.');
        slot.rows.push({ index: rowIndex, id, offset, valueOffset: offset + 8,
          quantity: view.getUint32(offset + 8, true), auxiliary: view.getUint32(offset + 12, true) });
      }
      const counts = new Map();
      for (const row of slot.rows) counts.set(row.id, (counts.get(row.id) || 0) + 1);
      for (const field of FIELDS.slice(0, 2)) if (counts.get(field.id) !== 1)
        fail('XP ou Hacksilver ausente ou duplicado neste slot.');
      slot.duplicateIds = [...counts].filter(([, count]) => count > 1).map(([id]) => id);
      slot.table = { start: table, end: table + count * 16, count, count8, count4 };
      slot.available = true;
    } catch (error) { slot.reason = error.message; }
    return slot;
  }
  function parse(input, filename = 'game.sav') {
    const bytes = asBytes(input);
    if (bytes.length !== FILE_SIZE) fail('O tamanho deste arquivo ainda não corresponde ao perfil de PC suportado.');
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    // Os oito bytes iniciais variam entre arquivos legítimos. Validar o
    // contêiner e as tabelas de cada slot, sem normalizar esse campo.
    if (view.getUint32(8, true) !== 4 || !view.getUint32(12, true) ||
      view.getUint32(16, true) !== 208 || view.getUint32(20, true) !== SLOT_SIZE || view.getUint32(24, true) !== bytes.length)
      fail('O cabeçalho deste arquivo ainda não corresponde ao perfil de God of War 2018 para PC.');
    const slots = Array.from({ length: SLOT_COUNT }, (_, index) => readSlot(bytes, index));
    if (!slots.some(slot => slot.available)) fail('Nenhum slot com tabela de quantidades reconhecida foi encontrado.');
    const latest = slots.filter(slot => slot.available).reduce((best, slot) => !best || slot.timestamp > best.timestamp ? slot : best, null);
    return { filename, size: bytes.length, build: view.getUint32(12, true), headerSize: HEADER_SIZE,
      slotSize: SLOT_SIZE, slots, latestSlot: latest.index, supported: slots.filter(slot => slot.available).length };
  }
  function roundTrip(input) {
    const bytes = asBytes(input), model = parse(bytes), output = new Uint8Array(bytes.length);
    output.set(bytes.subarray(0, model.headerSize));
    for (const slot of model.slots) output.set(bytes.subarray(slot.base, slot.end), slot.base);
    return output;
  }
  function patch(input, requests = []) {
    const original = asBytes(input), model = parse(original);
    if (!Array.isArray(requests)) fail('O plano de alterações deve ser uma lista.');
    const keys = new Set(), selected = [];
    for (const request of requests) {
      if (!request || !Number.isInteger(request.slot) || request.slot < 0 || request.slot >= SLOT_COUNT)
        fail('Escolha um slot reconhecido.');
      const slot = model.slots[request.slot], field = lookup(request.id);
      if (!slot.available) fail('Slot ' + slot.number + ': ' + slot.reason);
      if (!field) fail('Esse registro está disponível somente para consulta nesta versão.');
      if (slot.duplicateIds.includes(field.id)) fail('O registro selecionado está duplicado; sua edição foi bloqueada.');
      const row = slot.rows.find(row => row.id === field.id);
      if (!row) fail('O recurso selecionado não existe neste slot.');
      if (!Number.isSafeInteger(request.quantity) || request.quantity < 0 || request.quantity > MAX_QUANTITY)
        fail('Informe uma quantidade inteira entre 0 e 2.147.483.647.');
      const key = slot.index + ':' + row.id;
      if (keys.has(key)) fail('Há duas alterações para o mesmo registro do mesmo slot.');
      keys.add(key);
      if (row.quantity !== request.quantity) selected.push({ slot, field, row, quantity: request.quantity });
    }
    const output = original.slice(), view = new DataView(output.buffer), log = [];
    for (const change of selected) {
      view.setUint32(change.row.valueOffset, change.quantity, true);
      log.push({ slot: change.slot.number, slotIndex: change.slot.index, id: change.row.id, name: change.field.name,
        provisional: change.field.provisional, before: change.row.quantity, after: change.quantity,
        offset: change.row.valueOffset, length: 4 });
    }
    let cursor = 0;
    for (const change of selected.slice().sort((a, b) => a.row.valueOffset - b.row.valueOffset)) {
      if (!equal(original.subarray(cursor, change.row.valueOffset), output.subarray(cursor, change.row.valueOffset)))
        fail('Dados fora das quantidades escolhidas foram alterados.');
      cursor = change.row.valueOffset + 4;
    }
    if (!equal(original.subarray(cursor), output.subarray(cursor))) fail('Dados fora das quantidades escolhidas foram alterados.');
    const verified = parse(output, model.filename);
    for (const entry of log) {
      const row = verified.slots[entry.slotIndex].rows.find(row => row.id === entry.id);
      if (!row || row.quantity !== entry.after || row.valueOffset !== entry.offset) fail('A releitura da quantidade não confere.');
    }
    return { bytes: output, model: verified, log };
  }
  return Object.freeze({ VERSION, HEADER_SIZE, SLOT_SIZE, SLOT_COUNT, TABLE_OFFSET, FILE_SIZE, MAX_QUANTITY, FIELDS, lookup, hex, parse, roundTrip, patch });
});
