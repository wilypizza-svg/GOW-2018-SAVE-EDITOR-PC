/* Retirada validada por R01..R08 e pelos oito saves regravados no jogo.
   Reutiliza o gravador nativo; preserva mapas e referências existentes. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('./inventory.js'),require('./enchantments.js'),require('./compatibility.js'),require('../data/inventory-removal.json'));
 else root.Forja2018Removal=factory(root.Forja2018,root.Forja2018NativeRecords,root.Forja2018Inventory,root.Forja2018Enchantments,root.Forja2018Compatibility,JSON.parse(document.getElementById('removal-data').textContent));
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,inventory,enchantments,compat,data){
 'use strict';
 const EQUIPMENT='inventory-remove-equipment',ENCHANTMENT='inventory-remove-enchantment',TYPES=Object.freeze([EQUIPMENT,ENCHANTMENT]),KINDS=new Set(data.kinds);
 const fail=m=>{throw new Error(m);},join=parts=>{const b=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let at=0;for(const p of parts){b.set(p,at);at+=p.length;}return b;};
 function listsOf(raw){const v=native.view(raw);let at=72;const lists=[];for(let k=0;k<2;k++){const n=v.getUint32(at,true);if(n>64||at+4+n*4>raw.length)fail('Lista de efeitos inválida.');at+=4;const list=[];for(let j=0;j<n;j++,at+=4)list.push(v.getUint32(at,true));lists.push(list);}return {lists,at};}
 const uniqueFirst=new Set(inventory.FACTORIES.filter(p=>p.classification==='unique'||enchantments.classifyRaw(native.fromHex(p.raw)).unique).flatMap(p=>listsOf(native.fromHex(p.raw)).lists[0]));
 function describe(raw){
  if(raw.length<84||native.idOf(raw)!=='3B056E1555DABD5D')fail('Instância de encantamento inválida.');
  const v=native.view(raw),parsed=listsOf(raw);let at=parsed.at;const count=v.getUint32(at,true);at+=4;
  if(count>64||at+12*count!==raw.length)fail('A lista de atributos não confere.');
  const stats=[];let valid=v.getUint32(60,true)===1;const seen=new Set();
  for(let j=0;j<count;j++,at+=12){const id=core.hex(raw.subarray(at,at+8)),value=v.getFloat32(at+8,true);if(seen.has(id)||!Number.isFinite(value)||value<0||value>1000000)valid=false;seen.add(id);if(enchantments.STATS[id])stats.push({id,name:enchantments.STATS[id],value});}
  const rule=enchantments.classifyRaw(raw),unique=rule.unique||parsed.lists[0].some(id=>uniqueFirst.has(id));
  const common=valid&&!unique&&stats.length>0&&data.commonConstructors.some(c=>c.type===core.hex(raw.subarray(64,72))&&c.prefix===core.hex(raw.subarray(16,32)));
  const uid=v.getUint32(48,true),binding=core.hex(raw.subarray(8,16)),link=v.getUint32(52,true),socket=v.getUint32(56,true);
  return {uid,id:'enchantment-'+uid,name:(rule.name?rule.name+' · ':'')+stats.map(s=>s.name+' '+new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2}).format(s.value)).join(' · '),binding,link,socket,stats,common,unique,valid};
 }
 function rootRecords(tx){return tx.removalRoots||tx.state.objects.map(o=>({uid:o.uid,raw:tx.bytes.slice(o.start,o.end)}));}
 function enchantmentState(o){
  const d=describe(o.raw);let reason='';
  if(d.unique)reason='Encantamento único: remoção preservada fora desta função.';
  else if(!d.common)reason='O formato deste encantamento ainda não tem remoção confirmada.';
  else if(d.binding!=='0000000000000000'||d.link!==0xFFFFFFFF||d.socket!==0xFFFFFFFF)reason='Retire o encantamento do encaixe pelo jogo antes de removê-lo.';
  return {...d,available:!reason,reason};
 }
 function equipmentState(tx,p){
  const base={id:p.id,name:p.name,kind:p.kind,variant:p.variant,owned:native.quantity(tx,p.id)===1,available:false,needsUnequippedConfirmation:p.key==null,releaseCount:0,reason:''};
  try{
   if(!KINDS.has(p.kind)||p.mode==='quantity'||p.mode==='runic-quantity-template')fail('Esta categoria não oferece remoção.');
   const state=inventory.profileState(tx,p);if(!state.available)fail(state.reason);
   if(!base.owned){base.available=true;return base;}
   if(p.key!=null&&native.mapEntry(tx,1,p.key))fail('A peça está equipada. Desequipe-a no jogo antes de remover.');
   const ids=new Set(p.ids),bound=rootRecords(tx).filter(o=>ids.has(core.hex(o.raw.subarray(8,16)))),sockets=new Set();
   for(const g of tx.state.groups)for(const o of g.objects)if(ids.has(core.hex(tx.bytes.subarray(o.start+8,o.start+16))))fail('Existe um vínculo em uma seção ainda não mapeada.');
   for(const o of bound){const e=describe(o.raw);if(!e.common||e.socket>2||sockets.has(e.socket))fail('Retire os encantamentos únicos ou não reconhecidos dessa peça pelo jogo antes de remover.');sockets.add(e.socket);}
   for(const r of tx.finals)if(ids.has(native.idOf(r))&&native.view(r).getUint32(8,true)!==0)fail('Há um marcador de outra natureza para esta peça.');
   return {...base,available:true,releaseCount:bound.length,stage:state.stage,reason:bound.length?'Os '+bound.length+' encantamentos comuns serão devolvidos soltos ao inventário.':'A peça e suas melhorias serão retiradas; os demais itens ficam preservados.'};
  }catch(e){return {...base,reason:e.message};}
 }
 function inspect(input,index,parsed){
  try{const tx=native.read(input,index,parsed);compat.requireNative(tx,'Remoção de inventário');return {available:true,equipment:inventory.PROFILES.filter(p=>KINDS.has(p.kind)&&p.mode!=='quantity'&&p.mode!=='runic-quantity-template').map(p=>equipmentState(tx,p)),enchantments:rootRecords(tx).map(enchantmentState),reason:''};}
  catch(e){return {available:false,equipment:[],enchantments:[],reason:e.message};}
 }
 function removeEquipment(tx,r){
  const p=inventory.PROFILES.find(p=>p.id===r.id&&KINDS.has(p.kind));if(!p)fail('Equipamento fora do catálogo de remoção.');
  const s=equipmentState(tx,p);if(!s.available)fail(s.reason);if(!s.owned)return null;
  if(s.needsUnequippedConfirmation&&r.confirmUnequipped!==true)fail('Confirme que a peça já está desequipada no jogo.');
  const ids=new Set(p.ids),released=[];
  for(const o of tx.removalRoots)if(ids.has(core.hex(o.raw.subarray(8,16)))){o.raw.fill(0,8,16);native.view(o.raw).setUint32(52,0xFFFFFFFF,true);native.view(o.raw).setUint32(56,0xFFFFFFFF,true);released.push(o.uid);}
  for(const id of p.ids){const row=native.unique(tx.rows,id);if(row){const q=native.view(row).getUint32(8,true);if(q!==0&&q!==1)fail('Quantidade de equipamento inválida.');native.view(row).setUint32(8,0,true);}}
  tx.finals=tx.finals.filter(row=>!ids.has(native.idOf(row)));
  return {name:p.name+' · remover',before:1,after:0,beforeLabel:'Presente',afterLabel:'Removido'+(released.length?' · '+released.length+' encantamentos devolvidos':''),removedIds:[...p.ids],releasedUids:released,removedUids:[],levelMapsPreserved:true};
 }
 function removeEnchantment(tx,r){
  const at=tx.removalRoots.findIndex(o=>o.uid===r.uid);if(at<0)return null;const s=enchantmentState(tx.removalRoots[at]);if(!s.available)fail(s.reason);
  const notice=new Uint8Array(8);native.view(notice).setUint32(0,r.uid,true);
  if(tx.finals.some(row=>native.idOf(row)===core.hex(notice)&&native.view(row).getUint32(8,true)===2))fail('O encantamento ainda tem um aviso de aquisição pendente. Abra e salve o inventário pelo jogo.');
  tx.removalRoots.splice(at,1);return {name:'Encantamento '+r.uid+' · '+s.name+' · remover',before:1,after:0,beforeLabel:'Uma instância solta',afterLabel:'Instância removida',removedIds:[],releasedUids:[],removedUids:[r.uid]};
 }
 function patch(input,requests=[]){
  const original=native.bytesOf(input),model=core.parse(original),seen=new Set(),groups=new Map();if(!Array.isArray(requests))fail('Plano de remoção inválido.');
  for(const r of requests){
   if(!r||!TYPES.includes(r.type)||!Number.isInteger(r.slot)||!model.slots[r.slot]?.available)fail('Escolha um slot reconhecido.');
   if(r.type===ENCHANTMENT&&(!Number.isInteger(r.uid)||r.uid<0||r.uid>=0xFFFFFFFF||r.id!=='enchantment-'+r.uid))fail('Identidade de encantamento inválida.');
   const key=r.slot+':'+r.id;if(seen.has(key))fail('Há duas remoções do mesmo item.');seen.add(key);if(!groups.has(r.slot))groups.set(r.slot,[]);groups.get(r.slot).push(r);
  }
  let bytes=original;const log=[],layout=[];
  for(const [index,rs]of groups){
   const tx=native.read(bytes,index);compat.requireNative(tx,'Remoção de inventário');tx.removalRoots=rootRecords(tx);const originalGroupBytes=tx.bytes.slice(tx.state.objectEnd,tx.state.statsEnd),pending=[];
   for(const r of rs){const change=r.type===EQUIPMENT?removeEquipment(tx,r):removeEnchantment(tx,r);if(change)pending.push({r,change});}
   if(!pending.length)continue;
   tx.objectsAndGroups=join([...tx.removalRoots.map(o=>o.raw),originalGroupBytes]);tx.slot={...tx.slot,table:{...tx.slot.table,count4:tx.removalRoots.length}};
   const result=native.write(tx),next=native.read(result.bytes,index,result.model);
   if(result.layout.oldestFinalRowsDiscarded!==0||next.refs.length!==tx.refs.length||!native.equal(join(next.refs),join(tx.refs)))fail('As referências da remoção não conferem.');
   if(!native.equal(next.bytes.subarray(next.state.objectEnd,next.state.statsEnd),originalGroupBytes))fail('Um grupo de instâncias mudou.');
   if(next.state.objects.length!==tx.removalRoots.length)fail('A contagem de encantamentos não confere.');
   tx.removalRoots.forEach((o,i)=>{const n=next.state.objects[i];if(n.uid!==o.uid||!native.equal(next.bytes.subarray(n.start,n.end),o.raw))fail('Uma identidade ou efeito do inventário mudou.');});
   for(let i=0;i<3;i++)if(!native.equal(join(next.maps[i].entries),join(tx.maps[i].entries)))fail('Um mapa de progressão mudou.');
   for(const {r,change}of pending){for(const id of change.removedIds)if(native.quantity(next,id)!==null&&native.quantity(next,id)!==0)fail('O equipamento retirado ainda está ativo.');for(const uid of change.removedUids)if(next.state.objects.some(o=>o.uid===uid))fail('A instância retirada reapareceu.');log.push({type:r.type,id:r.id,slot:index+1,slotIndex:index,...change,experimental:false,confirmedCases:data.confirmedCases.map(c=>c.case)});}
   const removed=tx.state.objects.length-tx.removalRoots.length,released=pending.reduce((n,p)=>n+p.change.releasedUids.length,0);
   bytes=result.bytes;layout.push({...result.layout,operation:'inventory-removal',attributeInstancesPreserved:removed===0&&released===0,untargetedAttributeInstancesPreserved:true,remainingInstanceIdentitiesAndEffectsPreserved:true,removedAttributeInstances:removed,releasedEnchantmentInstances:released});
  }
  return {bytes,model:core.parse(bytes),log,layout,validation:{removalChanges:log.length,removalNativeResavesVerified:data.nativeResavesVerified,removalPreservesReferencesAndMaps:true,removalPreservesOtherInstances:true,hacksilverAndResourcesPreserved:true}};
 }
 return Object.freeze({EQUIPMENT,ENCHANTMENT,TYPES,inspect,equipmentState,describe,patch});
});
