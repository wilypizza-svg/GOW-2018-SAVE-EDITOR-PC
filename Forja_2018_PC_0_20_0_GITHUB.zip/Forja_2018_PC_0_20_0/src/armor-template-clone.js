/* Clona as linhas nativas do Cod of War (NG+, 8 -> 8+ -> 9) e transpõe
   a identidade para Zeus. O estado final de Zeus vem da amostra funcionando.
   As referências de compra do doador não identificam receitas de Zeus. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('../data/armor-set-template.json'),require('./equipment-record-clone.js'),require('./compatibility.js'));
  else root.Forja2018ArmorClone=factory(root.Forja2018,root.Forja2018NativeRecords,JSON.parse(document.getElementById('armor-clone-data').textContent),root.Forja2018EquipmentClone,root.Forja2018Compatibility);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,data,recordClone,compat){
  'use strict';
  const TYPE='armor-set-template',ID=data.id;
  const BASE_IDS=Object.freeze(data.parts.map(p=>p.targetIds[0]));
  const IDS=Object.freeze(data.parts.flatMap(p=>p.targetIds)),managed=new Set(IDS);
  const fail=m=>{throw new Error(m);};
  const globalRows=data.globalRows.map(native.fromHex),finalRows=data.targetFinalRows.map(native.fromHex);
  const globals=globalRows.map(raw=>({key:native.view(raw).getUint32(0,true),stage:native.view(raw).getUint32(4,true)}));
  if(data.build!==4757534||data.level!==9||data.parts.length!==3||IDS.length!==9||new Set(IDS).size!==9||globals.length!==3||finalRows.length!==6)fail('Molde de Zeus inválido.');
  for(const p of data.parts){
    if(p.labels.join('/')!=='8/8+/9'||p.sourceRows.length!==3||p.sourceBoundInstances!==0)fail('O doador não corresponde ao molde sem encantamentos.');
    p.sourceRows.forEach((raw,k)=>{const b=native.fromHex(raw);if(b.length!==16||native.idOf(b)!==p.sourceIds[k]||native.view(b).getUint32(8,true)!==1)fail('Linha nativa do molde inválida.');});
    if(native.view(native.fromHex(p.sourceGlobalRow)).getUint32(4,true)!==2)fail('O doador não está na etapa máxima.');
  }
  for(const r of finalRows)if(r.length!==16||!managed.has(native.idOf(r))||BASE_IDS.includes(native.idOf(r))||native.view(r).getUint32(8,true)!==0)fail('Registro final de Zeus inválido.');
  function checkRequest(r){
    if(r.id!==ID||r.level!==9)fail('Este molde inclui somente o conjunto Zeus completo no nível 9.');
    if(r.allowExperimental!==true)fail('Ative a inclusão experimental para testar a clonagem de Zeus. Talvez corrompa seu save.');
  }
  function inspectTx(tx){
    try{
      compat.requireNative(tx,'Clonagem do conjunto de Zeus');
      let complete=true,owned=0;
      for(const id of IDS){const q=native.quantity(tx,id);if(q!==null&&q!==0&&q!==1)fail('Há uma quantidade inválida em Zeus.');if(q!==1)complete=false;}
      for(const id of BASE_IDS)if(native.quantity(tx,id)===1)owned++;
      for(const g of globals){
        const global=native.mapEntry(tx,0,g.key),stored=native.mapEntry(tx,1,g.key);
        if(global&&native.view(global).getUint32(4,true)>2||stored&&(native.view(stored).getUint32(4,true)>2||stored[8]!==1))fail('O estado de nível de Zeus não corresponde ao molde.');
        if(!global||native.view(global).getUint32(4,true)!==2||stored&&native.view(stored).getUint32(4,true)!==2)complete=false;
      }
      for(const id of IDS){
        const row=native.unique(tx.finals,id),wanted=finalRows.find(r=>native.idOf(r)===id);
        if(row&&native.view(row).getUint32(8,true)!==0)fail('O identificador de Zeus está sendo usado por outro tipo de registro final.');
        if(wanted?!row||!native.equal(row,wanted):!!row)complete=false;
      }
      return {available:true,ownedPieces:owned,fullyRegistered:complete,level:9};
    }catch(e){return {available:false,fullyRegistered:false,reason:e.message};}
  }
  function apply(tx,r){
    checkRequest(r);const state=inspectTx(tx);if(!state.available)fail(state.reason);if(state.fullyRegistered)return null;
    let added=0;
    for(const p of data.parts)for(let k=0;k<3;k++){
      const id=p.targetIds[k];if(recordClone.copyRow(tx,id,p.sourceRows[k]))added++;
    }
    for(let i=0;i<globals.length;i++){
      const g=globals[i],raw=native.fromHex(data.parts[i].sourceGlobalRow);
      native.view(raw).setUint32(0,g.key,true);
      if(!native.equal(raw,globalRows[i]))fail('A transposição do mapa não coincide com a amostra de Zeus.');
      const existing=native.mapEntry(tx,0,g.key);
      if(existing)native.view(existing).setUint32(4,g.stage,true);else native.addGlobal(tx,g.key,g.stage);
      const stored=native.mapEntry(tx,1,g.key);if(stored)native.view(stored).setUint32(4,g.stage,true);
    }
    // Reproduz o histórico final observado depois de Zeus funcionar no jogo:
    // seis melhorias, sem recriar os três avisos da aquisição das bases.
    tx.finals=tx.finals.filter(row=>!managed.has(native.idOf(row)));
    tx.finals.push(...finalRows.map(raw=>raw.slice()));
    validate(tx);
    return {name:data.name,before:null,after:9,beforeLabel:'Zeus ausente ou com registros diferentes do molde',
      afterLabel:'Conjunto completo no 9 · clonagem experimental',
      acquired:state.ownedPieces<3,fullArmorTemplate:true,templateSource:'Cod of War NG+ · 8 → 8+ → 9',
      copiedPrimaryTemplates:9,addedPrimaryRows:added,levelMapWritten:true,
      targetIds:[...IDS],globalKeys:globals.map(g=>g.key),nativeFinalRows:6,
      donorPurchaseReferencesCopied:false,donorInstancesCopied:false,
      currentEquipmentPreserved:true,actualConstructionVerifiedInGame:tx.slot.build===data.build,referenceBuild:data.build,sourceBuild:tx.slot.build,confirmedScenario:'testes_05_e_06_e_inclusao_pelo_editor_reportados_pelo_usuario',mixedPommelScenarioVerified:tx.slot.build===data.build,
      warning:'Talvez corrompa seu save',uids:[]};
  }
  function validate(tx){const state=inspectTx(tx);if(!state.available||!state.fullyRegistered)fail(state.reason||'A releitura do conjunto clonado não coincide com o molde.');return state;}
  return Object.freeze({TYPE,ID,BASE_IDS,IDS,checkRequest,inspectTx,apply,validate});
});
