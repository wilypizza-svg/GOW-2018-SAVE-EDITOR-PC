/* Recompõe somente a seção ativa reconhecida. O mundo, as instâncias,
   os blocos desconhecidos e a reserva absoluta permanecem preservados. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./resource-edit.js'));
  else root.Forja2018NativeRecords=factory(root.Forja2018,root.Forja2018Resources);
})(typeof globalThis!=='undefined'?globalThis:this,function(core,resources){
  'use strict';
  const MAX_FINALS=512;
  const fail=m=>{throw new Error(m);};
  const bytesOf=b=>b instanceof Uint8Array?new Uint8Array(b.buffer,b.byteOffset,b.byteLength):b instanceof ArrayBuffer?new Uint8Array(b):fail('Escolha um game.sav.');
  const view=b=>new DataView(b.buffer,b.byteOffset,b.byteLength);
  const fromHex=s=>{if(!/^(?:[0-9A-F]{2})+$/.test(s))fail('Identificador inválido.');return Uint8Array.from(s.match(/../g),x=>parseInt(x,16));};
  const equal=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
  const join=parts=>{const b=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let p=0;for(const x of parts){b.set(x,p);p+=x.length;}return b;};
  function read(input,index,parsed){
    const bytes=bytesOf(input),model=parsed||core.parse(bytes),slot=model.slots[index],state=resources.inspect(bytes,index,model);
    if(!slot?.available||!state.available)fail(state.reason||'Escolha um slot reconhecido.');
    const rows=slot.rows.map(r=>bytes.slice(r.offset,r.offset+16)),refs=[];
    for(let p=slot.table.end;p<state.objectStart;p+=8)refs.push(bytes.slice(p,p+8));
    const maps=state.frames.slice(0,3).map((f,i)=>{
      const prefix=i===1?8:0,stride=i?9:8,count=view(bytes).getUint32(f.start+2+prefix,true),entries=[];
      if(i===1&&!['C65F861310000000','ED8AAF0950420000','19682628084AEA38'].includes(core.hex(bytes.subarray(f.start+2,f.start+10))))fail('O cabeçalho do mapa persistido não foi reconhecido.');
      if(count>4096||prefix+4+stride*count!==f.length)fail('O mapa interno não corresponde às amostras.');
      const keys=new Set();
      for(let k=0;k<count;k++){
        const p=f.start+2+prefix+4+k*stride,raw=bytes.slice(p,p+stride),key=view(raw).getUint32(0,true);
        if(keys.has(key)||stride===9&&raw[8]>1)fail('Há chaves ou marcadores inválidos no mapa.');
        keys.add(key);entries.push(raw);
      }
      return {prefix:bytes.slice(f.start+2,f.start+2+prefix),stride,entries};
    });
    const finals=[];for(let p=state.frames[3].start+4;p<state.activeEnd;p+=16)finals.push(bytes.slice(p,p+16));
    return {bytes,model,slot,state,rows,refs,maps,finals,
      objectsAndGroups:bytes.slice(state.objectStart,state.statsEnd),prefix:bytes.slice(slot.base+0x10400,slot.table.start)};
  }
  const idOf=r=>core.hex(r.subarray(0,8));
  function unique(rows,id,required=false){const found=rows.filter(r=>idOf(r)===id);if(found.length>1||required&&!found.length)fail('Registro ausente ou repetido: '+id);return found[0]||null;}
  function quantity(tx,id){const row=unique(tx.rows,id);return row?view(row).getUint32(8,true):null;}
  function putQuantity(tx,id,value,allowAdd=false){
    if(!Number.isSafeInteger(value)||value<0||value>core.MAX_QUANTITY)fail('Quantidade inválida.');
    let row=unique(tx.rows,id);
    if(!row){if(!allowAdd)fail('O registro necessário não existe: '+id);row=tx.rows[0].slice();row.set(fromHex(id));view(row).setUint32(12,tx.rows.length,true);tx.rows.push(row);}
    view(row).setUint32(8,value,true);
  }
  function ensureFinal(tx,id,metadata){
    const row=unique(tx.finals,id),wanted=fromHex(metadata);
    if(wanted.length!==8)fail('Marcador inválido.');
    if(row){if(!equal(row.subarray(8),wanted))fail('O marcador existente difere da amostra: '+id);return;}
    tx.finals.push(join([fromHex(id),wanted]));
  }
  function insertRefAfter(tx,id,anchor){
    if(unique(tx.refs,id))return;
    const found=unique(tx.refs,anchor,true),index=tx.refs.indexOf(found);
    tx.refs.splice(index+1,0,fromHex(id));
  }
  function mapEntry(tx,frame,key){const entries=tx.maps[frame].entries.filter(r=>view(r).getUint32(0,true)===key);if(entries.length>1)fail('Chave repetida.');return entries[0]||null;}
  function addGlobal(tx,key,value){
    if(mapEntry(tx,0,key))fail('A peça já tem um registro de nível.');
    const row=new Uint8Array(8);view(row).setUint32(0,key,true);view(row).setUint32(4,value,true);
    const entries=tx.maps[0].entries;
    if(entries.some((r,i)=>i&&view(entries[i-1]).getUint32(0,true)>=view(r).getUint32(0,true)))fail('A ordenação do mapa global não foi reconhecida.');
    const i=entries.findIndex(r=>view(r).getUint32(0,true)>key);entries.splice(i<0?entries.length:i,0,row);
  }
  function write(tx){
    const {bytes,slot,state}=tx,header=tx.prefix.slice();
    const added=tx.newObjects||[],seen=new Set(state.objects.map(o=>o.uid));
    if(added.length>32)fail('Inclua no máximo 32 instâncias por operação.');
    for(const raw of added){
      if(!(raw instanceof Uint8Array)||raw.length<84||idOf(raw)!=='3B056E1555DABD5D')fail('Instância nova inválida.');
      const uid=view(raw).getUint32(48,true);
      if(seen.has(uid)||uid===0xFFFFFFFF)fail('A identidade da instância já está em uso.');
      seen.add(uid);
    }
    const split=state.objectEnd-state.objectStart;
    const objectsAndGroups=added.length?join([tx.objectsAndGroups.subarray(0,split),...added,tx.objectsAndGroups.subarray(split)]):tx.objectsAndGroups;
    const stats=join([header,...tx.rows,...tx.refs,objectsAndGroups]);
    if(tx.rows.length>4096||tx.refs.length>20000)fail('O limite dos registros foi atingido.');
    const h=view(stats);h.setUint32(5,stats.length-9,true);h.setUint32(17,tx.rows.length,true);h.setUint32(21,tx.refs.length,true);
    h.setUint32(25,slot.table.count4+added.length,true);
    const frames=tx.maps.map(m=>{
      const count=new Uint8Array(4);view(count).setUint32(0,m.entries.length,true);
      const body=join([m.prefix,count,...m.entries]),head=new Uint8Array(2);
      if(body.length>65535)fail('O mapa excede o limite de tamanho.');
      view(head).setUint16(0,body.length,true);return join([head,body]);
    });
    // Fila de registros recentes observada no jogo: preserva os últimos 512.
    // A proteção fica no gravador para abranger também operações combinadas.
    const finalQueueDiscarded=Math.max(0,tx.finals.length-MAX_FINALS);
    const finalBody=join(finalQueueDiscarded?tx.finals.slice(-MAX_FINALS):tx.finals),finalHead=fromHex('2EFA0000');
    if(finalBody.length>65535)fail('A seção de marcadores excede o limite.');
    view(finalHead).setUint16(2,finalBody.length,true);
    const active=join([stats,...frames,finalHead,finalBody]),start=slot.base+0x10400,newEnd=start+active.length;
    if(newEnd+4096>slot.base+0x30400)fail('Não há reserva estrutural reconhecida para esta operação.');
    const output=bytes.slice();output.set(active,start);view(output).setUint32(slot.base+0x124,active.length,true);
    // Fora da seção ativa apenas o tamanho ativo pode ser alterado.
    if(!equal(bytes.subarray(0,slot.base+0x124),output.subarray(0,slot.base+0x124))||
      !equal(bytes.subarray(slot.base+0x128,start),output.subarray(slot.base+0x128,start))||
      !equal(bytes.subarray(newEnd),output.subarray(newEnd)))fail('Dados fora da seção ativa foram alterados.');
    const model=core.parse(output),next=resources.inspect(output,slot.index,model);
    if(!next.available||next.activeEnd!==newEnd||next.statsSize!==stats.length-9||
      model.slots[slot.index].table.count!==tx.rows.length||model.slots[slot.index].table.count8!==tx.refs.length||
      model.slots[slot.index].table.count4!==slot.table.count4+added.length||
      !equal(output.subarray(next.objectStart,next.statsEnd),objectsAndGroups))fail('A releitura da seção ativa não confere.');
    return {bytes:output,model,layout:{slot:slot.number,addedBytes:active.length-state.activeSize,
      primaryBefore:slot.table.count,primaryAfter:tx.rows.length,referencesBefore:slot.table.count8,referencesAfter:tx.refs.length,
      attributeInstancesPreserved:true,newAttributeInstances:added.length,unknownMapsPreserved:true,unusedTailPreserved:true,finalQueueLimit:MAX_FINALS,oldestFinalRowsDiscarded:finalQueueDiscarded,inGameTestedHere:false}};
  }
  return Object.freeze({MAX_FINALS,bytesOf,view,fromHex,equal,read,write,unique,idOf,quantity,putQuantity,ensureFinal,insertRefAfter,mapEntry,addGlobal});
});
