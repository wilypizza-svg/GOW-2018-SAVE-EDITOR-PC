/* Moldes de progressão por tipo, variante, nível inicial e número de etapas.
   Os IDs da família substituem os do molde; índices PC desconhecidos não são
   copiados de outra peça. Reconhecimento do nível pelo jogo é experimental. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./equipment.js'),require('./loot-catalog.js'),require('../data/inventory-profiles.json'));
 else root.Forja2018InventoryCatalog=factory(root.Forja2018Equipment,root.Forja2018Loot,JSON.parse(document.getElementById('inventory-data').textContent));
})(typeof globalThis!=='undefined'?globalThis:this,function(equipment,loot,data){
 'use strict';
 // IDs exatos: os três PinkSet normais falharam como grupo; Cod of War NG+ usa outros IDs.
 const EXCLUDED_IDS=Object.freeze(['B1DFE124C69AF353','82D3E124C69AF353',
   'E777B23D510B6DE1','924731D16B9635D0','4351BAA3FE4070D3']);
 const known=new Set(data.profiles.map(p=>p.id));
 const checkedLoot=item=>{
   const row=loot.lookup(item.id);if(!row||row.internalName.trim()!==item.internalName.trim())return null;
   const kind=equipment.lookup(item.id)?.family.kind,expected={chest:'chestarmor',wrist:'wristarmor',waist:'waistarmor',axe:'axepommel',blades:'bladespommel',talisman:'talisman'}[kind];
   const actual=String(row.subCategory||'').replace(/[^a-z]/gi,'').toLowerCase();
   return expected&&actual&&expected!==actual?null:row;
 };
 const armorKey=s=>s.replace(/^KratosArmor(?:Chest|Wrist|Legs)_/,'KratosArmor_');
 const baseLevels=new Map();
 for(const f of equipment.families){const base=f.stages.find(s=>s.order===0&&!s.isUpgrade),level=base&&checkedLoot(base)?.level;
   if(base&&Number.isFinite(level))baseLevels.set(armorKey(f.key),level);
 }
 const profiles=equipment.families.filter(f=>['chest','wrist','waist','axe','blades','talisman'].includes(f.kind)&&
   !/(?:_PreOrder|_Starter|_Default|_Debug|_Test)(?:_|$)/i.test(f.key)).map(f=>{
   const bases=f.stages.filter(s=>s.order===0&&!s.isUpgrade);
   if(bases.length!==1||known.has(bases[0].id)||EXCLUDED_IDS.includes(bases[0].id)||/^UB\d+_/i.test(bases[0].internalName)||/PLACEHOLDER/i.test(bases[0].internalName+' '+bases[0].name))return null;
   if(!f.stages.every((s,i)=>s.order===i))return null;
   const base=bases[0],meta=checkedLoot(base),name=meta?.gameName||f.name;
   const variant=/_NGP(?:_|$)/.test(base.internalName)||/_Bonus0[123](?:_|$)/.test(base.internalName)?'NG+':'normal';
   const level=f.kind==='blades'&&variant==='NG+'?8:meta?.level??baseLevels.get(armorKey(f.key))??null;
   const prototype=data.profiles.find(p=>p.kind===f.kind&&p.variant===variant&&p.mode==='history'&&p.stages.length===f.stages.length&&String(level)===p.stages[0].label);
   const stages=f.stages.map((s,k)=>({label:prototype?prototype.stages[k].label:k===0?(level===null?'Base':String(level)):
     checkedLoot(s)?.level!==undefined?String(checkedLoot(s).level):'Melhoria '+k,refs:[],finals:[]}));
   return Object.freeze({id:base.id,key:null,name:name.replace(/\s*\[Base\]$/i,''),kind:f.kind,
    variant,autoFullSet:['4339AAC6C42CC83D','6AD139EBB39080CB','222E23BC9F1A3F0C'].includes(base.id),build:data.build,mode:'history-template',experimentalTemplate:true,ids:f.stages.map(s=>s.id),
    familyIds:f.stages.map(s=>s.id),referenceIds:[],stages,levelFromTable:level,
    prototypeId:prototype?.id||null,prototypeLabels:prototype?.stages.map(s=>s.label)||null,
    flagMetadata:prototype?prototype.stages.map((s,k)=>s.finals.find(f=>f.id===prototype.ids[k])?.metadata||'00000000F67F0000'):null});
 }).filter(Boolean);
 return Object.freeze({profiles:Object.freeze(profiles),EXCLUDED_IDS});
});
