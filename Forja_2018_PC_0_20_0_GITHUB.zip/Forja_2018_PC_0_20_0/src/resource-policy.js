/* Política explícita de inventário. Limite do editor não é limite do jogo.
   Os itens únicos seguem total 0/1; inclusão não muda flags de missão. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./loot-catalog.js').catalog);
  else root.Forja2018ResourcePolicy = factory(root.Forja2018, root.Forja2018Loot.catalog);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, catalog) {
  'use strict';
  const extra = [
    ['68FE54101D9E9F5D', 'Materiais de melhoria', 1], ['6D326716A5D804FF', 'Niflheim', 99999],
    ['A77F6D97ED4CF464', 'Chaves de Muspelheim', 1], ['B67B6D97ED4CF464', 'Chaves de Muspelheim', 1],
    ['45476D97ED4CF464', 'Chaves de Muspelheim', 1], ['54436D97ED4CF464', 'Chaves de Muspelheim', 1], ['634F6D97ED4CF464', 'Chaves de Muspelheim', 1],
    ['1E0E64AC3296C6E7', 'Lenda dos anões', 1], ['8EA4875CD3D4A902', 'Lenda dos anões', 1], ['EC3F370D42DC5103', 'Lenda dos anões', 1],
    ['23822D3BDC66EFEB', 'Capacetes de Valquírias', 1], ['30862D3BDC66EFEB', 'Capacetes de Valquírias', 1],
    ['419A2D3BDC66EFEB', 'Capacetes de Valquírias', 1], ['569E2D3BDC66EFEB', 'Capacetes de Valquírias', 1],
    ['67922D3BDC66EFEB', 'Capacetes de Valquírias', 1], ['74962D3BDC66EFEB', 'Capacetes de Valquírias', 1],
    ['85EB2D3BDC66EFEB', 'Capacetes de Valquírias', 1], ['8AEF2D3BDC66EFEB', 'Capacetes de Valquírias', 1], ['FFAE6FD160FBD7E9', 'Capacetes de Valquírias', 1]
  ];
  const fields = core.FIELDS.map(item => Object.freeze({ ...item, max: core.MAX_QUANTITY, suggested: ['Experiência', 'Moeda'].includes(item.category) ? 2000000000 : 99999,
    gameCapKnown: false, unique: false, legacy: true }));
  for (const [id, category, suggested] of extra) {
    const item = catalog.lookup(id);
    if (!item || !/^[A-F0-9]{16}$/.test(id)) throw new Error('Catálogo incompleto para o recurso ' + id);
    fields.push(Object.freeze({ ...item, category, editable: true, max: suggested === 1 ? 1 : core.MAX_QUANTITY,
      suggested, unique: suggested === 1, gameCapKnown: false, legacy: false }));
  }
  const byId = new Map(fields.map(field => [field.id, field]));
  const IDS = Object.freeze({ xp: '8A9A9B831CF67C9C', hs: '9E5240D27406E85A', mist: 'A3CE6E0F87FFC5BA', anchor: '6D326716A5D804FF',
    frozen: 'EDB4476E71735CC3', chilling: 'E563B049BAB288DB', chaos: '888DE11A0DA6CFDC', inferno: '68FE54101D9E9F5D', skap: '26FA272A8BF271FA', queen: 'FFAE6FD160FBD7E9' });
  const kits = Object.freeze([
    { id: 'xp-hs', name: 'XP e Hacksilver', ids: [IDS.xp, IDS.hs], suggested: 2000000000 },
    { id: 'main', name: 'Materiais principais e Skap Slag', ids: core.FIELDS.filter(x => x.category === 'Recursos').map(x => x.id), suggested: 99999 },
    { id: 'weapon-materials', name: 'Materiais do machado e das lâminas', ids: [IDS.frozen, IDS.chilling, IDS.chaos, IDS.inferno], suggested: 99999 },
    { id: 'niflheim', name: 'Ecos da Névoa e Âncora de Névoa', ids: [IDS.mist, IDS.anchor], suggested: 99999 },
    { id: 'muspelheim-keys', name: 'Cinco chaves de Muspelheim', ids: extra.filter(x => x[1] === 'Chaves de Muspelheim').map(x => x[0]), suggested: 1 },
    { id: 'dwarven', name: 'Três recursos da lenda dos anões', ids: extra.filter(x => x[1] === 'Lenda dos anões').map(x => x[0]), suggested: 1 },
    { id: 'helmets', name: 'Oito capacetes de Valquírias', ids: extra.filter(x => x[1] === 'Capacetes de Valquírias' && x[0] !== IDS.queen).map(x => x[0]), suggested: 1 },
    { id: 'helmets-queen', name: 'Nove capacetes, incluindo Sigrun', ids: extra.filter(x => x[1] === 'Capacetes de Valquírias').map(x => x[0]), suggested: 1 },
    { id: 'skap', name: 'Skap Slag', ids: [IDS.skap], suggested: 99999 }
  ].map(kit => Object.freeze({ ...kit, ids: Object.freeze(kit.ids) })));
  function buildKit(slot, kitId, quantity) {
    const kit = kits.find(kit => kit.id === kitId);
    if (!slot?.available || !kit || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > core.MAX_QUANTITY) throw new Error('Escolha um pacote e uma quantidade inteira válida.');
    return kit.ids.map(id => {
      const field = byId.get(id), rows = slot.rows.filter(row => row.id === id);
      if (rows.length > 1) throw new Error('O pacote contém um recurso duplicado neste slot.');
      const desired = field.unique ? 1 : Math.max(rows[0]?.quantity || 0, quantity);
      if (desired > field.max) throw new Error('O estoque ultrapassa o limite do editor para ' + field.name + '.');
      return { slot: slot.index, id, quantity: desired };
    });
  }
  return Object.freeze({ FIELDS: Object.freeze(fields), lookup: id => byId.get(id) || null, KITS: kits, IDS, buildKit });
});
