/* Inclusão de recursos em 2018 PC. O gravador de quantidades da 0.2.0
   permanece separado. Só o trecho ativo do slot selecionado é deslocado.
   A inclusão nova precisa de confirmação no jogo; não cria equipamentos. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'));
  else root.Forja2018Resources = factory(root.Forja2018);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core) {
  'use strict';
  const START = 0x10400, END = 0x30400, MARGIN = 4096, MAX_ADDITIONS = 32;
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const viewOf = bytes => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const equal = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);
  function inspect(input, slotIndex, parsed) {
    try {
      const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
      if (!slot?.available) fail('Escolha um slot com tabela reconhecida.');
      const view = viewOf(bytes), base = slot.base, limit = base + END;
      const u32 = p => { if (p < base || p + 4 > limit) fail('Limite do bloco de recursos inválido.'); return view.getUint32(p, true); };
      const signature = (p, value) => core.hex(bytes.subarray(p, p + value.length / 2)) === value;
      const statsHeader = slot.table.start - 24, statsSize = u32(statsHeader), statsEnd = statsHeader + 4 + statsSize;
      // O byte entre 0100 e FAFF é a dificuldade, não parte fixa da assinatura.
      // As amostras 1 -> 2 também mudam o u32 de +0x110. A gramática completa
      // abaixo valida os registros e preserva o código, inclusive o código 0.
      if (statsHeader !== base + START + 5 || !signature(base + START, '0100') || !signature(base + START + 3, 'FAFF') ||
        bytes[base + START + 2] > 3 || u32(base + 0x110) !== bytes[base + START + 2] ||
        !signature(statsHeader + 4, '5F2243C695480000') || statsEnd > limit || statsEnd <= slot.table.end)
        fail('A disposição interna deste slot ainda não permite acrescentar registros.');
      // Depois das quantidades há IDs e objetos com listas de tamanho variável.
      // O terceiro contador não é uma simples lista de inteiros de 4 bytes.
      let cursor = slot.table.end + slot.table.count8 * 8;
      function readObjects(objectCount) {
        const objects = [], uids = new Set();
        for (let i = 0; i < objectCount; i++) {
          const start = cursor;
          if (start + 84 > statsEnd || !signature(start, '3B056E1555DABD5D')) fail('Uma instância de atributos não foi reconhecida.');
          const uid = u32(start + 48);
          if (uids.has(uid)) fail('Há instâncias de atributos repetidas.');
          uids.add(uid); cursor += 72;
          for (let list = 0; list < 2; list++) {
            const count = u32(cursor); cursor += 4;
            if (count > 64 || cursor + count * 4 + 4 > statsEnd) fail('Uma lista interna de atributos não confere.');
            cursor += count * 4;
          }
          const count = u32(cursor); cursor += 4;
          if (count > 64 || cursor + count * 12 > statsEnd) fail('A lista de valores de uma instância não confere.');
          cursor += count * 12;
          objects.push({ start, end: cursor, uid });
        }
        return objects;
      }
      const objects = readObjects(slot.table.count4), objectEnd = cursor, groups = [];
      // As tabelas finais também possuem contadores. Sua extensão depende do
      // conteúdo do slot: 148 bytes nos primeiros exemplos, 220 no novo save.
      // Percorrer os registros evita confundir essa variação com falta de espaço.
      for (const marker of ['EA2555A4149BE338', '4B30662F58A15983', 'B0BDD5E2372DB672']) {
        const start = cursor;
        if (start + 20 > statsEnd || !signature(start, marker)) fail('Uma tabela final de atributos não foi reconhecida.');
        const count = u32(start + 8), count8 = u32(start + 12), count4 = u32(start + 16);
        if (count > 4096 || count8 > 20000 || count4 > 20000) fail('A contagem de uma tabela final não confere.');
        cursor += 20 + count * 16 + count8 * 8;
        if (cursor > statsEnd) fail('Uma tabela final ultrapassa a seção de atributos.');
        const entries = readObjects(count4);
        groups.push({ marker, start, end: cursor, count, count8, count4, objects: entries });
      }
      if (cursor !== statsEnd) fail('O término da seção de atributos não coincide com seus registros.');
      const frames = [];
      for (let i = 0; i < 3; i++) {
        if (cursor + 2 > limit) fail('Uma seção posterior está incompleta.');
        const length = view.getUint16(cursor, true), end = cursor + 2 + length;
        if (end > limit) fail('Uma seção posterior ultrapassa o bloco do slot.');
        frames.push({ start: cursor, end, length }); cursor = end;
      }
      if (cursor + 4 > limit || !signature(cursor, '2EFA')) fail('A última seção ativa não foi reconhecida.');
      const finalLength = view.getUint16(cursor + 2, true), activeEnd = cursor + 4 + finalLength;
      frames.push({ start: cursor, end: activeEnd, length: finalLength });
      const activeSize = u32(base + 0x124);
      if (finalLength % 16 || activeEnd !== base + START + activeSize || activeEnd > limit)
        fail('O tamanho ativo do slot não confere.');
      const capacity = Math.max(0, Math.min(MAX_ADDITIONS, 4096 - slot.table.count,
        Math.floor((limit - activeEnd - MARGIN) / 16)));
      const choices = core.FIELDS.filter(item => !slot.rows.some(row => row.id === item.id));
      return { available: true, slotIndex, base, capacity, choices, statsHeader, statsSize, statsEnd,
        objectStart: slot.table.end + slot.table.count8 * 8, objectEnd, objects, groups, frames, activeSize, activeEnd,
        reason: !capacity ? 'O limite de inclusão deste slot foi atingido.' : '' };
    } catch (e) { return { available: false, capacity: 0, choices: [], reason: e.message }; }
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original);
    if (!Array.isArray(requests)) fail('O plano de alterações deve ser uma lista.');
    const present = [], groups = new Map(), keys = new Set();
    for (const request of requests) {
      if (!request || !Number.isInteger(request.slot) || !model.slots[request.slot]?.available) fail('Escolha um slot reconhecido.');
      const item = core.lookup(request.id), slot = model.slots[request.slot];
      if (!item) fail('Esse ID não é um recurso editável. Equipamentos e progresso exigem outras estruturas.');
      if (!Number.isSafeInteger(request.quantity) || request.quantity < 0 || request.quantity > core.MAX_QUANTITY)
        fail('Informe um total inteiro entre 0 e 2.147.483.647.');
      const key = request.slot + ':' + request.id;
      if (keys.has(key)) fail('Há duas alterações para o mesmo registro do mesmo slot.');
      keys.add(key);
      if (slot.rows.some(row => row.id === request.id)) present.push(request);
      else if (request.quantity > 0) {
        if (!groups.has(slot.index)) groups.set(slot.index, []);
        groups.get(slot.index).push({ ...request, item });
      }
    }
    const scalar = core.patch(original, present);
    if (!groups.size) return { ...scalar, layout: [], validation: { existingQuantityWriterUnchanged: true, newRecords: 0, inclusionInGameTested: false } };
    const output = scalar.bytes.slice(), view = viewOf(output), log = [...scalar.log], layout = [];
    for (const [slotIndex, additions] of groups) {
      const slot = model.slots[slotIndex], state = inspect(original, slotIndex, model);
      if (!state.available) fail('Slot ' + slot.number + ': ' + state.reason);
      if (additions.length > state.capacity) fail('Inclua no máximo ' + state.capacity + ' recursos novos neste slot por exportação.');
      const delta = additions.length * 16, insertion = slot.table.end, newEnd = state.activeEnd + delta;
      const template = slot.rows.find(row => core.lookup(row.id)?.category === 'Recursos') || slot.rows[0];
      // O final pode conter dados antigos não nulos. Preservamos tudo depois
      // do novo término nas mesmas posições, inclusive os outros 19 slots.
      output.set(scalar.bytes.subarray(insertion, state.activeEnd), insertion + delta);
      additions.forEach((change, i) => {
        const offset = insertion + i * 16;
        output.set(original.subarray(template.offset, template.offset + 16), offset);
        output.set(Uint8Array.from(change.id.match(/../g), value => parseInt(value, 16)), offset);
        view.setUint32(offset + 8, change.quantity, true);
        view.setUint32(offset + 12, slot.table.count + i, true);
        log.push({ type: 'resource-add', slot: slot.number, slotIndex, id: change.id, name: change.item.name,
          before: null, after: change.quantity, offset, length: 16, templateId: template.id,
          originalPreserved: true, experimental: true });
      });
      view.setUint32(state.statsHeader, state.statsSize + delta, true);
      view.setUint32(slot.table.start - 12, slot.table.count + additions.length, true);
      view.setUint32(slot.base + 0x124, state.activeSize + delta, true);
      const nextModel = core.parse(output), next = inspect(output, slotIndex, nextModel), nextSlot = nextModel.slots[slotIndex];
      if (!next.available || next.activeEnd !== newEnd || nextSlot.rows.length !== slot.rows.length + additions.length ||
        nextSlot.table.count8 !== slot.table.count8 || nextSlot.table.count4 !== slot.table.count4)
        fail('A releitura da inclusão não confere. Nenhum arquivo foi exportado.');
      if (!equal(scalar.bytes.subarray(slot.table.start, insertion), output.subarray(slot.table.start, insertion)) ||
        !equal(scalar.bytes.subarray(insertion, state.activeEnd), output.subarray(insertion + delta, newEnd)) ||
        !equal(scalar.bytes.subarray(newEnd, slot.end), output.subarray(newEnd, slot.end)))
        fail('Uma seção original não foi preservada durante a inclusão.');
      additions.forEach((change, i) => {
        const row = nextSlot.rows[slot.rows.length + i];
        if (row.id !== change.id || row.quantity !== change.quantity || row.auxiliary !== slot.table.count + i)
          fail('O registro novo não foi validado.');
      });
      layout.push({ slot: slot.number, addedRecords: additions.length, addedBytes: delta,
        activeEndBefore: state.activeEnd, activeEndAfter: newEnd, originalRecordsPreserved: true,
        attributeInstancesPreserved: true, trailingFramesPreserved: true, unusedTailPreserved: true });
    }
    const verified = core.parse(output);
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    const affected = new Set(requests.map(change => change.slot));
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end)))
      fail('Um salvamento não selecionado foi alterado.');
    return { bytes: output, model: verified, log, layout,
      validation: { existingQuantityWriterUnchanged: true, newRecords: [...groups.values()].reduce((n, group) => n + group.length, 0), inclusionInGameTested: false } };
  }
  return Object.freeze({ VERSION: '0.3.1', MAX_ADDITIONS, inspect, patch });
});
