/* Operações sobre blocos completos de subsave. Nenhum campo do mundo é
   reconstruído. Extração inclui CRC32 para detectar arquivos incompletos. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'), require('./catalog.js'));
  else root.Forja2018Slots = factory(root.Forja2018, root.Forja2018Resources, root.Forja2018Catalog);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources, catalog) {
  'use strict';
  const BUNDLE_HEADER = 64, MAGIC = [70, 79, 82, 74, 65, 49, 56, 83];
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength) : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Escolha um arquivo de PC.');
  const equal = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  const ngpIds = new Set(catalog.items.filter(item => /_NGP(?:_|$)/.test(item.internalName)).map(item => item.id));
  const crcTable = Uint32Array.from({ length: 256 }, (_, n) => { for (let j = 0; j < 8; j++) n = n & 1 ? 0xEDB88320 ^ n >>> 1 : n >>> 1; return n >>> 0; });
  function crc32(bytes) { let crc = 0xFFFFFFFF; for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ crc >>> 8; return (crc ^ 0xFFFFFFFF) >>> 0; }
  function ordered(model) {
    return model.slots.slice().sort((a, b) => Number(b.available) - Number(a.available) || b.timestamp - a.timestamp || a.index - b.index)
      .map(slot => ({ ...slot, ngpItemsPresent: slot.rows.some(row => row.quantity > 0 && ngpIds.has(row.id)),
        difficulty: null, saveType: null, runMode: null }));
  }
  function extract(input, index) {
    const bytes = bytesOf(input), model = core.parse(bytes), slot = model.slots[index];
    if (!slot?.available || !resources.inspect(bytes, index, model).available) fail('Escolha um subsave com estrutura reconhecida.');
    const bundle = new Uint8Array(BUNDLE_HEADER + core.SLOT_SIZE), view = new DataView(bundle.buffer);
    bundle.set(MAGIC); view.setUint32(8, 1, true); view.setUint32(12, core.SLOT_SIZE, true); view.setUint32(16, core.FILE_SIZE, true);
    view.setUint32(20, model.build, true); view.setUint32(24, slot.build, true); view.setUint32(28, index, true);
    bundle.set(bytes.subarray(slot.base, slot.end), BUNDLE_HEADER); view.setUint32(32, crc32(bundle.subarray(BUNDLE_HEADER)), true);
    return { bytes: bundle, slot: slot.number, title: slot.title, timestamp: slot.timestamp, filename: 'GOW2018_slot_' + slot.number + '.forja-slot' };
  }
  function readBundle(input) {
    const bytes = bytesOf(input), view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (bytes.length !== BUNDLE_HEADER + core.SLOT_SIZE || !MAGIC.every((v, i) => bytes[i] === v) || view.getUint32(8, true) !== 1 ||
      view.getUint32(12, true) !== core.SLOT_SIZE || view.getUint32(16, true) !== core.FILE_SIZE || !view.getUint32(20, true) || !view.getUint32(24, true) ||
      view.getUint32(28, true) >= core.SLOT_COUNT || bytes.subarray(36, BUNDLE_HEADER).some(v => v !== 0)) fail('O arquivo não é um subsave Forja 2018 reconhecido.');
    const body = bytes.subarray(BUNDLE_HEADER);
    if (crc32(body) !== view.getUint32(32, true)) fail('O subsave está incompleto ou foi alterado após a extração (CRC32 divergente).');
    const bodyView = new DataView(body.buffer, body.byteOffset, body.byteLength);
    if (bodyView.getUint32(8, true) !== 10 || bodyView.getUint32(12, true) !== view.getUint32(24, true)) fail('O cabeçalho interno do subsave não confere.');
    return { body, sourceBuild: view.getUint32(20, true), slotBuild: view.getUint32(24, true), sourceIndex: view.getUint32(28, true) };
  }
  function inspectSource(input) {
    const bytes = bytesOf(input);
    if (bytes.length === core.FILE_SIZE) {
      const model = core.parse(bytes);
      return { kind: 'full', model, slots: ordered(model).filter(slot => slot.available), bytes: bytes.slice() };
    }
    const bundle = readBundle(bytes), body = bundle.body, view = new DataView(body.buffer, body.byteOffset, body.byteLength);
    const timestamp = view.getUint32(0, true) + view.getUint32(4, true) * 4294967296;
    const rawTitle = body.subarray(16, 256), zero = rawTitle.indexOf(0), title = new TextDecoder('utf-8', { fatal: true }).decode(zero < 0 ? rawTitle : rawTitle.subarray(0, zero)).trim();
    return { kind: 'bundle', bytes: bytes.slice(), slots: [{ index: bundle.sourceIndex, number: bundle.sourceIndex + 1, title, timestamp, build: bundle.slotBuild }] };
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original), seen = new Set(), operations = [];
    if (!Array.isArray(requests)) fail('Plano de subsaves inválido.');
    for (const request of requests) {
      if (!request || !['slot-delete', 'slot-import'].includes(request.type) || request.id !== 'subsave' || !Number.isInteger(request.slot) || !model.slots[request.slot]) fail('Escolha uma posição válida de subsave.');
      if (seen.has(request.slot)) fail('Há duas operações sobre o mesmo subsave.'); seen.add(request.slot);
      const slot = model.slots[request.slot];
      if (!slot.available && !slot.empty) fail('A posição de destino contém dados não reconhecidos.');
      if (request.type === 'slot-delete') {
        if (!slot.available) continue;
        operations.push({ request, slot, body: null });
      } else {
        const source = readBundle(request.bundle);
        const builds = new Set(model.slots.filter(slot => slot.available).map(slot => slot.build));
        if (!builds.has(source.slotBuild)) fail('A versão interna do subsave não aparece nos slots reconhecidos deste arquivo.');
        operations.push({ request, slot, source, body: source.body });
      }
    }
    const output = original.slice(), log = [], layout = [];
    for (const operation of operations) {
      const { slot, body, request, source } = operation;
      if (body && equal(original.subarray(slot.base, slot.end), body)) continue;
      if (body) output.set(body, slot.base); else output.fill(0, slot.base, slot.end);
      log.push({ type: request.type, id: 'subsave', slot: slot.number, slotIndex: slot.index,
        name: body ? 'Importar subsave completo' : 'Excluir subsave da cópia', before: slot.available ? slot.title : null, after: body ? 'Subsave importado' : 'Vazio',
        beforeLabel: slot.available ? slot.title : 'Vazio', afterLabel: body ? 'Conteúdo completo importado' : 'Posição vazia',
        sourceSlot: source ? source.sourceIndex + 1 : null, sourceBuild: source?.sourceBuild ?? null,
        globalBuildDiffers: source ? source.sourceBuild !== model.build : false, experimental: true });
      layout.push({ slot: slot.number, operation: request.type, fullBlockBytes: core.SLOT_SIZE, globalHeaderPreserved: true, inGameTestedHere: false });
    }
    const verified = core.parse(output, model.filename);
    for (const { slot, body } of operations) {
      const next = verified.slots[slot.index];
      if (body && (!next.available || !resources.inspect(output, slot.index, verified).available || !equal(output.subarray(slot.base, slot.end), body))) fail('A releitura do subsave importado não confere.');
      if (!body && (!next.empty || output.subarray(slot.base, slot.end).some(v => v !== 0))) fail('A posição excluída não ficou vazia.');
    }
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho global foi alterado.');
    const affected = new Set(operations.map(operation => operation.slot.index));
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um subsave não selecionado foi alterado.');
    return { bytes: output, model: verified, log, layout, validation: { slotOperationsInGameTested: false, slotImports: log.filter(x => x.type === 'slot-import').length,
      slotDeletions: log.filter(x => x.type === 'slot-delete').length, unselectedSlotsPreserved: true, globalHeaderPreserved: true } };
  }
  return Object.freeze({ VERSION: '0.9.0', BUNDLE_HEADER, ordered, crc32, extract, readBundle, inspectSource, patch });
});
