/* Melhoria de Defender's Cuirass, Reinforce1 -> Reinforce2, observada em PC.
   Sincroniza dois mapas, uma flag e as referências/marcadores demonstrados.
   Não replica ponteiros, timestamps nem consumo da compra feita no jogo.
   Outros perfis permanecem bloqueados até terem seus vínculos mapeados. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'));
  else root.Forja2018ArmorLevels = factory(root.Forja2018, root.Forja2018Resources);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources) {
  'use strict';
  const PROFILE = Object.freeze({ id: 'armor-defender-chest', name: "Defender's Cuirass", kind: 'chest',
    baseId: 'EEA7E31201646AAF', previousId: '4B9C550D079A0AE1', nextId: '5898550D079A0AE1', mapKey: 607,
    oldReferences: Object.freeze(['985E5DF0300D402F', 'E58958B05C01970E']), nextReference: '212CB488175777C7',
    flagMetadata: '00000000F67F0000', referenceMetadata: '01000000F27F0000', fromStage: 1, toStage: 2 });
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const viewOf = bytes => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const fromHex = value => Uint8Array.from(value.match(/../g), part => parseInt(part, 16));
  const equal = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);
  const profileFor = id => id === PROFILE.id ? PROFILE : null;
  function inspect(input, slotIndex, profileId = PROFILE.id, parsed) {
    try {
      const profile = profileFor(profileId);
      if (!profile) fail('Esta família de armadura ainda não possui uma melhoria mapeada.');
      const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
      if (!slot?.available) fail('Escolha um slot reconhecido.');
      const state = resources.inspect(bytes, slotIndex, model), view = viewOf(bytes);
      if (!state.available) fail(state.reason);
      const u32 = offset => view.getUint32(offset, true), signature = (offset, id) => core.hex(bytes.subarray(offset, offset + id.length / 2)) === id;
      function map(frame, prefix, stride) {
        const payload = frame.start + 2, count = u32(payload + prefix);
        if (count > 4096 || prefix + 4 + count * stride !== frame.length) fail('Um mapa de melhorias não corresponde ao formato reconhecido.');
        const entries = [], keys = new Set();
        for (let i = 0; i < count; i++) {
          const offset = payload + prefix + 4 + i * stride, key = u32(offset);
          if (keys.has(key) || stride === 9 && bytes[offset + 8] > 1) fail('Há chaves ou marcadores inválidos no mapa de melhorias.');
          keys.add(key); entries.push({ key, value: u32(offset + 4), valueOffset: offset + 4, flag: stride === 9 ? bytes[offset + 8] : null });
        }
        return entries;
      }
      const globalMap = map(state.frames[0], 0, 8), storedFrame = state.frames[1];
      if (!['C65F861310000000', 'ED8AAF0950420000'].some(marker => signature(storedFrame.start + 2, marker))) fail('O mapa persistido de melhorias não foi reconhecido.');
      const storedMap = map(storedFrame, 8, 9), global = globalMap.find(entry => entry.key === profile.mapKey), stored = storedMap.find(entry => entry.key === profile.mapKey);
      if (!global || !stored || global.value !== stored.value || stored.flag !== 1 || ![1, 2].includes(global.value))
        fail('Os dois registros desta armadura não correspondem à melhoria demonstrada.');
      for (const id of [profile.baseId, profile.previousId]) if (slot.rows.filter(row => row.id === id && row.quantity === 1).length !== 1 || slot.duplicateIds.includes(id))
        fail('Os marcadores de posse desta armadura estão ausentes ou ambíguos.');
      const stage = global.value, result = { available: true, canUpgrade: false, profileId, profile, stage, slotIndex, slot, state, globalMap, storedMap, global, stored,
        reason: stage === 2 ? 'O peitoral já está na Melhoria 2 deste perfil.' : '' };
      if (stage === 2) {
        if (slot.rows.filter(row => row.id === profile.nextId && row.quantity === 1).length !== 1 || slot.duplicateIds.includes(profile.nextId)) fail('O marcador da melhoria atual não confere.');
        return result;
      }
      if (slot.rows.some(row => row.id === profile.nextId)) fail('A melhoria de destino já possui um registro incompatível neste slot.');
      const references = [];
      for (let i = 0; i < slot.table.count8; i++) references.push({ id: core.hex(bytes.subarray(slot.table.end + 8 * i, slot.table.end + 8 * i + 8)), offset: slot.table.end + 8 * i });
      const old = profile.oldReferences.map(id => references.filter(reference => reference.id === id));
      if (old.some(matches => matches.length !== 1) || old[1][0].offset !== old[0][0].offset + 8 || references.some(reference => reference.id === profile.nextReference))
        fail('As referências desta melhoria estão ausentes, repetidas ou fora do formato demonstrado.');
      const final = state.frames[3], trackers = [];
      for (let offset = final.start + 4; offset < final.end; offset += 16) trackers.push({ id: core.hex(bytes.subarray(offset, offset + 8)), offset });
      const flagTemplates = trackers.filter(row => row.id === profile.previousId), referenceTemplates = trackers.filter(row => row.id === profile.oldReferences[0]);
      if (flagTemplates.length !== 1 || referenceTemplates.length !== 1 || !signature(flagTemplates[0].offset + 8, profile.flagMetadata) ||
        !signature(referenceTemplates[0].offset + 8, profile.referenceMetadata) || trackers.some(row => [profile.nextId, profile.nextReference].includes(row.id)))
        fail('Os modelos completos de marcador desta melhoria não foram reconhecidos.');
      if (state.activeEnd + 40 + 4096 > slot.base + 0x30400 || final.length + 32 > 65535 || slot.table.count >= 4096)
        fail('O limite estrutural para esta melhoria foi atingido.');
      return { ...result, canUpgrade: true, referenceOffset: old[0][0].offset, flagTemplate: flagTemplates[0].offset, referenceTemplate: referenceTemplates[0].offset };
    } catch (error) { return { available: false, canUpgrade: false, stage: null, profileId, reason: error.message }; }
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original);
    if (!Array.isArray(requests)) fail('Plano de melhorias de armadura inválido.');
    const selected = [], keys = new Set();
    for (const request of requests) {
      if (!request || request.type !== 'armor-level' || !profileFor(request.id) || request.stage !== 2 ||
        !Number.isInteger(request.slot) || !model.slots[request.slot]?.available) fail('Escolha a melhoria de armadura mapeada nesta versão.');
      const key = request.slot + ':' + request.id;
      if (keys.has(key)) fail('Há duas melhorias para a mesma armadura no mesmo slot.');
      keys.add(key);
      const current = inspect(original, request.slot, request.id, model);
      if (current.available && current.stage === 2) continue;
      if (!current.available || !current.canUpgrade) fail(current.reason);
      selected.push(current);
    }
    const output = original.slice(), view = viewOf(output), log = [], layout = [];
    for (const current of selected) {
      const { profile, slot, state } = current, final = state.frames[3];
      const previous = slot.rows.find(row => row.id === profile.previousId), flag = original.slice(previous.offset, previous.offset + 16);
      flag.set(fromHex(profile.nextId)); const flagView = viewOf(flag); flagView.setUint32(8, 1, true); flagView.setUint32(12, slot.table.count, true);
      const newTrackers = new Uint8Array(32);
      newTrackers.set(original.subarray(current.flagTemplate, current.flagTemplate + 16)); newTrackers.set(fromHex(profile.nextId));
      newTrackers.set(original.subarray(current.referenceTemplate, current.referenceTemplate + 16), 16); newTrackers.set(fromHex(profile.nextReference), 16);
      const edits = [{ start: slot.table.end, remove: 0, bytes: flag },
        { start: current.referenceOffset, remove: 16, bytes: fromHex(profile.nextReference) }, { start: state.activeEnd, remove: 0, bytes: newTrackers }];
      let read = slot.table.end, write = read;
      const segments = [{ start: slot.base, end: read, dest: slot.base }];
      for (const edit of edits) {
        if (edit.start < read || edit.start > state.activeEnd) fail('As operações da melhoria se sobrepõem.');
        output.set(original.subarray(read, edit.start), write); segments.push({ start: read, end: edit.start, dest: write });
        write += edit.start - read; output.set(edit.bytes, write); write += edit.bytes.length; read = edit.start + edit.remove;
      }
      const newEnd = state.activeEnd + 40;
      if (write !== newEnd) fail('O tamanho da melhoria não confere.');
      segments.push({ start: newEnd, end: slot.end, dest: newEnd });
      const fields = [{ offset: state.statsHeader, width: 4, value: state.statsSize + 8 },
        { offset: slot.table.start - 12, width: 4, value: slot.table.count + 1 },
        { offset: slot.table.start - 8, width: 4, value: slot.table.count8 - 1 },
        { offset: slot.base + 0x124, width: 4, value: state.activeSize + 40 },
        { offset: final.start + 8 + 2, width: 2, value: final.length + 32 },
        { offset: current.global.valueOffset + 8, width: 4, value: 2 },
        { offset: current.stored.valueOffset + 8, width: 4, value: 2 }];
      fields.forEach(field => view[field.width === 2 ? 'setUint16' : 'setUint32'](field.offset, field.value, true));
      for (const segment of segments) {
        const end = segment.dest + segment.end - segment.start; let cursor = segment.dest;
        for (const field of fields.filter(field => field.offset >= segment.dest && field.offset < end).sort((a, b) => a.offset - b.offset)) {
          const source = segment.start + cursor - segment.dest;
          if (!equal(original.subarray(source, source + field.offset - cursor), output.subarray(cursor, field.offset))) fail('Dados não relacionados à melhoria foram alterados.');
          cursor = field.offset + field.width;
        }
        const source = segment.start + cursor - segment.dest;
        if (!equal(original.subarray(source, segment.end), output.subarray(cursor, end))) fail('Um trecho original da armadura não foi preservado.');
      }
      const verified = core.parse(output), after = inspect(output, slot.index, profile.id, verified), nextSlot = verified.slots[slot.index];
      if (!after.available || after.stage !== 2 || after.state.activeEnd !== newEnd || nextSlot.table.count !== slot.table.count + 1 ||
        nextSlot.table.count8 !== slot.table.count8 - 1 || nextSlot.table.count4 !== slot.table.count4) fail('A releitura da melhoria de armadura não confere.');
      for (const row of slot.rows) {
        const next = nextSlot.rows.find(item => item.id === row.id);
        if (!next || next.quantity !== row.quantity || next.auxiliary !== row.auxiliary) fail('Um item ou recurso anterior foi alterado.');
      }
      const added = nextSlot.rows[nextSlot.rows.length - 1];
      if (added.id !== profile.nextId || added.quantity !== 1 || added.auxiliary !== slot.table.count) fail('O novo marcador da melhoria não foi validado.');
      const nextReferences = [];
      for (let i = 0; i < nextSlot.table.count8; i++) nextReferences.push(core.hex(output.subarray(nextSlot.table.end + i * 8, nextSlot.table.end + (i + 1) * 8)));
      if (nextReferences.filter(id => id === profile.nextReference).length !== 1 || profile.oldReferences.some(id => nextReferences.includes(id))) fail('As novas referências da melhoria não conferem.');
      if (!equal(output.subarray(after.state.frames[3].end - 32, after.state.frames[3].end), newTrackers)) fail('Os marcadores finais da melhoria não conferem.');
      log.push({ type: 'armor-level', id: profile.id, slot: slot.number, slotIndex: slot.index, name: profile.name + ' · melhoria',
        before: 1, after: 2, beforeLabel: 'Melhoria 1 · Reinforce1', afterLabel: 'Melhoria 2 · Reinforce2', experimental: true,
        synchronizedLevelFields: fields.slice(-2).map(field => field.offset) });
      layout.push({ slot: slot.number, operation: 'armor-level', profile: profile.id, addedPrimaryRecords: 1, removedReferences: 2, addedReferences: 1,
        addedFinalRecords: 2, addedBytes: 40, activeEndBefore: state.activeEnd, activeEndAfter: newEnd,
        resourcesPreserved: true, enchantmentsPreserved: true, inGameTestedHere: false });
    }
    const affected = new Set(selected.map(current => current.slot.index));
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um slot não selecionado foi alterado.');
    return { bytes: output, model: core.parse(output), log, layout,
      validation: { armorLevelInGameTested: false, armorLevelTransitions: log.length, armorLevelsResourcesPreserved: true, armorLevelsExistingEnchantmentsPreserved: true } };
  }
  return Object.freeze({ VERSION: '0.6.0', PROFILE, profiles: Object.freeze([PROFILE]), inspect, patch });
});
