/* Perfis ENC_01..10 e modelos completos NG observados em saves nativos.
   O molde local fornece o cabeçalho compatível; perfil e efeitos completos
   vêm da instância validada. Encaixes e identidades anteriores são preservados. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('./compatibility.js'),require('./enchantments.js'),require('../data/enchantment-acquisition.json'));
 else root.Forja2018EnchantmentAcquisition=factory(root.Forja2018,root.Forja2018NativeRecords,root.Forja2018Compatibility,root.Forja2018Enchantments,JSON.parse(document.getElementById('enchantment-acquisition-data').textContent));
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,compat,enchantments,data){
 'use strict';
 const PROFILES=Object.freeze(data.profiles.map(p=>Object.freeze(p))),byId=new Map(PROFILES.map(p=>[p.id,p]));
 const fail=m=>{throw new Error(m);},handles=id=>byId.has(id),lookup=id=>byId.get(id)||null;
 function lists(raw){
  const v=native.view(raw);let at=72;const result=[];
  for(let k=0;k<2;k++){const n=v.getUint32(at,true);if(n>64)fail('Lista do perfil inválida.');at+=4;const values=[];for(let i=0;i<n;i++,at+=4)values.push(v.getUint32(at,true));result.push(values);}
  return result;
 }
 const recipes=new Map(PROFILES.map(p=>{const raw=native.fromHex(p.raw),rule=enchantments.classifyRaw(raw);if(!rule.recognized||rule.classification!==p.classification||native.view(raw).getUint32(60,true)!==1)fail('Perfil de aquisição inválido.');return [p.id,{raw,lists:lists(raw)}];}));
 function objects(tx){
  return [...tx.state.objects.map(o=>({uid:o.uid,raw:tx.bytes.subarray(o.start,o.end)})),...(tx.newObjects||[]).map(raw=>({uid:native.view(raw).getUint32(48,true),raw}))];
 }
 function conversionState(tx,p){
  const present=p.ingredientIds.filter(id=>(native.quantity(tx,id)||0)>0);
  return {conversionRecommended:p.ingredientIds.length>0,conversionMaterialsPresent:present.length>0,conversionNotice:p.ingredientIds.length?'É PREFERÍVEL fazer a conversão pelo jogo. Você também pode adicionar esta marca pelo editor; as peças e os materiais serão preservados. A coexistência da Marca Perfeita de Týr com seu conjunto completo foi testada no jogo.':''};
 }
 const sameLists=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 function instanceMatches(o,recipe){return native.equal(o.raw.subarray(16,48),recipe.raw.subarray(16,48))&&native.equal(o.raw.subarray(64,72),recipe.raw.subarray(64,72))&&sameLists(lists(o.raw),recipe.lists);}
 function localTemplate(all,recipe,allowCatalogType=false){
  let templates=all.filter(o=>native.view(o.raw).getUint32(60,true)===1&&native.equal(o.raw.subarray(64,72),recipe.raw.subarray(64,72))&&lists(o.raw)[0].length>0);
  // Os modelos NG novos carregam o construtor completo da amostra nativa.
  // Na mesma gramática PC, apenas o cabeçalho comum é obtido localmente;
  // o tipo e os efeitos sempre vêm juntos do modelo, sem inferir IDs.
  if(!templates.length&&allowCatalogType)templates=all.filter(o=>native.view(o.raw).getUint32(60,true)===1&&lists(o.raw)[0].length>0);
  if(!templates.length)fail('Falta um bloco de encantamento compatível neste slot. Obtenha um encantamento desse tipo pelo jogo antes de incluir este perfil.');
  templates.sort((a,b)=>a.uid-b.uid);return templates[0].uid;
 }
 function inspectTx(tx,id){
  try{
   compat.requireNative(tx,'Inclusão de encantamentos');
   const p=lookup(id);if(!p)fail('Encantamento sem um modelo completo validado.');
   const recipe=recipes.get(id),all=objects(tx),conversion=conversionState(tx,p);
   if(p.acquisitionMode==='instance'){
    const matches=all.filter(o=>instanceMatches(o,recipe));
    if(p.classification==='unique'){
     const related=all.filter(o=>lists(o.raw)[0].some(value=>recipe.lists[0].includes(value)));
     if(matches.length>1||!matches.length&&related.some(o=>!instanceMatches(o,recipe)))fail('Já existe outro registro deste encantamento único. O perfil existente será preservado.');
    }
    const common={available:true,validatedAcquisition:true,classification:p.classification,unique:p.classification==='unique',sourceBuild:tx.slot.build,crossBuild:tx.slot.build!==p.build,...conversion};
    if(matches.length)return {...common,owned:true,quantity:matches.length,uid:matches[0].uid,reason:'Este modelo já consta no inventário; as instâncias existentes serão preservadas.'};
    return {...common,owned:false,quantity:0,localTemplateUid:localTemplate(all,recipe,true),reason:''};
   }
   const matches=all.filter(o=>instanceMatches(o,recipe));
   if(p.classification==='unique'&&!matches.length&&all.some(o=>lists(o.raw)[0].some(value=>recipe.lists[0].includes(value))))fail('Já existe outro registro deste encantamento único. O perfil existente será preservado.');
   const q=native.quantity(tx,id)??0;
   if(q>1||matches.length>1)fail('Há múltiplos registros deste perfil; a inclusão de cópias adicionais ainda não foi validada.');
   if(matches.length){
    const o=matches[0];if(q!==1||!native.equal(o.raw.subarray(16,48),recipe.raw.subarray(16,48))||JSON.stringify(lists(o.raw))!==JSON.stringify(recipe.lists))fail('O contador e a instância deste encantamento divergem.');
    return {available:true,owned:true,quantity:1,uid:o.uid,validatedAcquisition:true,classification:p.classification,unique:p.classification==='unique',sourceBuild:tx.slot.build,crossBuild:tx.slot.build!==p.build,...conversion,reason:'Este encantamento já consta no inventário.'};
   }
   if(q!==0)fail('O contador deste encantamento existe, mas sua instância não foi reconhecida.');
   return {available:true,owned:false,quantity:0,localTemplateUid:localTemplate(all,recipe),validatedAcquisition:true,classification:p.classification,unique:p.classification==='unique',sourceBuild:tx.slot.build,crossBuild:tx.slot.build!==p.build,...conversion,reason:''};
  }catch(e){return {available:false,owned:false,quantity:null,validatedAcquisition:true,reason:e.message};}
 }
 function nextUid(tx){
  const used=tx.state.objects.concat(...tx.state.groups.map(g=>g.objects)).map(o=>o.uid);
  for(const raw of tx.newObjects||[])used.push(native.view(raw).getUint32(48,true));
  for(const row of tx.finals)if(native.view(row).getUint32(8,true)===2&&native.view(row).getUint32(4,true)===0)used.push(native.view(row).getUint32(0,true));
  const uid=Math.max(0,...used)+1;if(!Number.isSafeInteger(uid)||uid>=0xFFFFFFFF)fail('Não foi possível reservar uma identidade livre.');return uid;
 }
 function apply(tx,r){
  const p=lookup(r.id);if(!p)fail('Encantamento sem um modelo completo validado.');
  if(r.count!==undefined&&r.count!==1)fail('Esta inclusão adiciona uma unidade ausente por perfil. Cópias adicionais ainda não foram validadas.');
  if(r.keepTalisman)fail('Este perfil não oferece alteração de ingredientes de conversão.');
  const state=inspectTx(tx,r.id);if(!state.available)fail(state.reason);if(state.owned)return null;
  const recipe=recipes.get(r.id),template=objects(tx).find(o=>o.uid===state.localTemplateUid),raw=new Uint8Array(recipe.raw.length),uid=nextUid(tx),v=native.view(raw);
  raw.set(template.raw.subarray(0,72));raw.set(recipe.raw.subarray(16,48),16);raw.set(recipe.raw.subarray(64,72),64);raw.set(recipe.raw.subarray(72),72);
  raw.fill(0,8,16);v.setUint32(48,uid,true);v.setUint32(52,0xFFFFFFFF,true);v.setUint32(56,0xFFFFFFFF,true);v.setUint32(60,1,true);
  const expected=recipe.raw.slice();expected.fill(0,8,16);const ev=native.view(expected);ev.setUint32(48,uid,true);ev.setUint32(52,0xFFFFFFFF,true);ev.setUint32(56,0xFFFFFFFF,true);
  if(!native.equal(raw,expected))fail('O bloco local não reproduz o modelo validado.');
  tx.newObjects||=[];tx.newObjects.push(raw);
  if(p.acquisitionMode==='instance'){
   if(p.counterId){const q=native.quantity(tx,p.counterId);if(q===null||q===0)native.putQuantity(tx,p.counterId,1,true);if(!native.unique(tx.finals,p.counterId))native.ensureFinal(tx,p.counterId,p.recipeMetadata);}
  }else {native.putQuantity(tx,r.id,1,true);native.ensureFinal(tx,r.id,p.recipeMetadata);}
  return {name:p.name,before:0,after:1,beforeLabel:'Ausente',afterLabel:'Uma unidade no inventário',uids:[uid],localTemplateUid:state.localTemplateUid,classification:p.classification,unique:p.classification==='unique',validatedAcquisition:true,confirmedCases:[...p.confirmedCases],looseBinding:true,instanceAcquisitionNoticeAdded:false,existingInstancesAndSocketsPreserved:true,recipeEffectsPreserved:true,...conversionState(tx,p),conversionResourcesPreserved:true,nativeModel:p.nativeModel===true,newModelAwaitingGameTest:p.gameValidated===false};
 }
 function validateTx(tx,id){
  const s=inspectTx(tx,id);if(!s.available||!s.owned||s.quantity!==1)fail(s.reason||'A releitura do encantamento incluído não confere.');return s;
 }
 return Object.freeze({PROFILES,handles,lookup,inspectTx,apply,validateTx});
});
