/* Copia linhas de equipamento de amostras PC, com identidades do destino.
   Cada equipamento continua sendo uma coleção de registros: a linha de posse,
   as melhorias e, quando identificado, seu próprio mapa de nível. Nenhuma
   chave de nível ou referência de compra é herdada de outra identidade. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./native-records.js'),require('../data/equipment-record-templates.json'));
 else root.Forja2018EquipmentClone=factory(root.Forja2018,root.Forja2018NativeRecords,JSON.parse(document.getElementById('equipment-clone-data').textContent));
})(typeof globalThis!=='undefined'?globalThis:this,function(core,native,data){
 'use strict';
 const fail=m=>{throw new Error(m);},models=new Map();
 if(data.build!==4757534)fail('Versão do catálogo de moldes inválida.');
 for(const t of data.templates){
  if(models.has(t.id)||t.sourceKind!==t.kind||t.sourceVariant!==t.variant||t.boundInstances!==0||!t.sourceRows.length||t.sourceRows.length!==t.sourceIds.length)fail('Molde de equipamento inválido.');
  t.sourceRows.forEach((raw,k)=>{const row=native.fromHex(raw);if(row.length!==16||native.idOf(row)!==t.sourceIds[k]||native.view(row).getUint32(8,true)!==1)fail('Linha nativa de equipamento inválida.');});
  for(const raw of t.sourceFinalRows){const row=native.fromHex(raw);if(row.length!==16||!t.sourceIds.includes(native.idOf(row))||native.view(row).getUint32(8,true)!==0)fail('Histórico final do molde inválido.');}
  models.set(t.id,t);
 }
 function modelFor(p){const t=models.get(p.id);if(!t||t.kind!==p.kind||t.variant!==p.variant)fail('Não há molde nativo compatível para esta categoria e variante.');return t;}
 function copyRow(tx,id,source){
  const raw=typeof source==='string'?native.fromHex(source):source.slice();
  if(raw.length!==16||native.view(raw).getUint32(8,true)!==1)fail('O modelo não é uma linha única de equipamento.');
  const existing=native.unique(tx.rows,id);if(existing){native.view(existing).setUint32(8,1,true);return false;}
  raw.set(native.fromHex(id));native.view(raw).setUint32(12,tx.rows.length,true);tx.rows.push(raw);return true;
 }
 function copyHistory(tx,p,stage){
  const t=modelFor(p);let added=0;
  for(let k=0;k<=stage;k++){
   // Todas as melhorias observadas usam o mesmo formato de linha de 16 bytes.
   // Se a progressão difere, só esse formato é reutilizado; nenhum nível é
   // inferido a partir do doador. O ID da etapa vem da família do destino.
   const raw=t.sourceRows[Math.min(k,t.sourceRows.length-1)];
   if(k>0&&t.sourceRows.length<2)fail('Falta uma linha nativa de melhoria para esta categoria.');
   if(copyRow(tx,p.ids[k],raw))added++;
  }
  return {nativeRecordClone:true,addedPrimaryRows:added,copiedPrimaryTemplates:stage+1,
   templateSourceId:t.sourceId,exactIdentityTemplate:t.exactIdentity,templateProgressionMatched:t.progressionMatched,
   templateEvidence:t.source,donorPurchaseReferencesCopied:false,donorInstancesCopied:false};
 }
 function normalizeFinals(tx,p,stage,newStage){
  const t=modelFor(p),ids=new Set(p.ids),before=tx.finals.length;
  // O estado já reconhecido pelo jogo não precisa de novo aviso de aquisição.
  // Zeus, Týr e Retribuição + têm exemplos sem o marcador da peça base.
  // Aplicar esse estado aos demais moldes permanece experimental.
  for(const row of tx.finals)if(ids.has(native.idOf(row))&&native.view(row).getUint32(8,true)!==0)fail('O ID de equipamento está sendo usado por outro tipo de registro final.');
  const base=native.unique(tx.finals,p.id);if(base)tx.finals=tx.finals.filter(row=>native.idOf(row)!==p.id);
  let added=0;
  // Registros de melhorias já presentes são preservados, inclusive os que
  // desapareceram naturalmente após o jogo reconhecer uma etapa antiga.
  if(newStage)for(let k=1;k<=stage;k++){
   if(native.unique(tx.finals,p.ids[k]))continue;
   const sourceId=t.sourceIds[Math.min(k,t.sourceIds.length-1)],raw=t.sourceFinalRows.find(raw=>raw.startsWith(sourceId));
   if(!raw)continue;const row=native.fromHex(raw);row.set(native.fromHex(p.ids[k]));tx.finals.push(row);added++;
  }
  return {acquisitionNoticeRecreated:false,removedBaseNotices:before+added-tx.finals.length,addedUpgradeNotices:added};
 }
 return Object.freeze({modelFor,copyRow,copyHistory,normalizeFinals,models:Object.freeze(data.templates)});
});
