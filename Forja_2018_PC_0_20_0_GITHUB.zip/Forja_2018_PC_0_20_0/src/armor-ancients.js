/* Pauldron of the Ancients normal: duas transições observadas em PC.
   0 -> 1 acrescenta uma referência de 8 bytes sem marcador final próprio.
   1 -> 2 conserva as referências. Cada etapa acrescenta sua flag e tracker.
   Os modelos são copiados do slot; campos desconhecidos ficam preservados. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'), require('./resource-edit.js'), require('./equipment.js'));
  else root.Forja2018Ancients = factory(root.Forja2018, root.Forja2018Resources, root.Forja2018Equipment);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (core, resources, equipment) {
  'use strict';
  const PROFILE = Object.freeze({ id: 'armor-ancients-chest', name: 'Pauldron of the Ancients', kind: 'chest',
    baseId: '9E8ADECDD9C87B97', history: Object.freeze(['447C88023A4B7596', 'B50188023A4B7596']), mapKey: 649,
    anchor: 'E6767C713DB60238', addedReference: 'F7727C713DB60238',
    flagMetadata: '00000000F67F0000', anchorMetadata: '01000000F37F0000' });
  const upgradeIds = new Set(equipment.upgrades.map(item => item.id));
  const fail = message => { throw new Error(message); };
  const bytesOf = input => input instanceof Uint8Array ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
    : input instanceof ArrayBuffer ? new Uint8Array(input) : fail('Selecione um game.sav de PC.');
  const viewOf = bytes => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const fromHex = value => Uint8Array.from(value.match(/../g), part => parseInt(part, 16));
  const equal = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);
  function inspect(input, slotIndex, parsed) {
    try {
      const bytes = bytesOf(input), model = parsed || core.parse(bytes), slot = model.slots[slotIndex];
      if (!slot?.available) fail('Escolha um slot reconhecido.');
      const state = resources.inspect(bytes, slotIndex, model), view = viewOf(bytes);
      if (!state.available) fail(state.reason);
      const u32 = p => view.getUint32(p, true), signature = (p, value) => core.hex(bytes.subarray(p, p + value.length / 2)) === value;
      function map(frame, prefix, stride) {
        const payload = frame.start + 2, count = u32(payload + prefix), entries = new Map();
        if (count > 4096 || prefix + 4 + count * stride !== frame.length) fail('Um mapa de níveis não corresponde ao formato observado.');
        for (let i = 0; i < count; i++) {
          const p = payload + prefix + 4 + i * stride, key = u32(p);
          if (entries.has(key) || stride === 9 && bytes[p + 8] > 1) fail('Há chaves ou marcadores inválidos no mapa de níveis.');
          entries.set(key, { value: u32(p + 4), offset: p + 4, flag: stride === 9 ? bytes[p + 8] : null });
        }
        return entries;
      }
      if (!['C65F861310000000', 'ED8AAF0950420000'].some(marker => signature(state.frames[1].start + 2, marker))) fail('O mapa persistido não foi reconhecido.');
      const global = map(state.frames[0], 0, 8).get(PROFILE.mapKey), stored = map(state.frames[1], 8, 9).get(PROFILE.mapKey);
      if (!global || !stored || stored.flag !== 1 || global.value !== stored.value || ![0, 1, 2].includes(global.value)) fail('Os dois registros do peitoral dos Ancestrais estão ausentes ou divergentes.');
      const stage = global.value, final = state.frames[3], trackers = [];
      for (let p = final.start + 4; p < final.end; p += 16) trackers.push({ id: core.hex(bytes.subarray(p, p + 8)), offset: p });
      function owned(id) { const rows = slot.rows.filter(row => row.id === id); return rows.length === 1 && rows[0].quantity === 1 ? rows[0] : null; }
      const base = owned(PROFILE.baseId);
      if (!base) fail('A peça base está ausente ou ambígua.');
      for (let i = 0; i < PROFILE.history.length; i++) {
        const id = PROFILE.history[i], rows = slot.rows.filter(row => row.id === id), ts = trackers.filter(row => row.id === id);
        if (i < stage) {
          if (!owned(id) || ts.length !== 1 || !signature(ts[0].offset + 8, PROFILE.flagMetadata)) fail('O histórico da melhoria não confere.');
        } else if (rows.length || ts.length) fail('Há uma melhoria posterior já registrada. Use o seletor de nível para preservar esse histórico.');
      }
      const refs = [];
      for (let i = 0; i < slot.table.count8; i++) refs.push({ id: core.hex(bytes.subarray(slot.table.end + i * 8, slot.table.end + (i + 1) * 8)), offset: slot.table.end + i * 8 });
      const anchors = refs.filter(row => row.id === PROFILE.anchor), added = refs.filter(row => row.id === PROFILE.addedReference), anchorTrackers = trackers.filter(row => row.id === PROFILE.anchor);
      if (anchors.length !== 1 || anchorTrackers.length !== 1 || !signature(anchorTrackers[0].offset + 8, PROFILE.anchorMetadata) ||
        stage === 0 && added.length || stage > 0 && (added.length !== 1 || added[0].offset !== anchors[0].offset + 8) ||
        trackers.some(row => row.id === PROFILE.addedReference)) fail('As referências do peitoral não correspondem às amostras observadas.');
      const templates = trackers.filter(row => upgradeIds.has(row.id) && owned(row.id) && signature(row.offset + 8, PROFILE.flagMetadata));
      // O marcador da peça base não aparece na seção final das três amostras.
      // Usa-se um marcador completo de melhoria já registrado e reconhecido.
      const template = trackers.find(row => row.id === PROFILE.history[stage - 1] && templates.includes(row)) || templates[0];
      const options = [];
      for (let target = stage + 1; target <= 2; target++) {
        const steps = target - stage, refDelta = stage === 0 ? 8 : 0, delta = steps * 32 + refDelta;
        if (template && slot.table.count + steps <= 4096 && final.length + steps * 16 <= 65535 &&
          state.activeEnd + delta + 4096 <= slot.base + 0x30400) options.push(target);
      }
      return { available: true, canUpgrade: options.length > 0, stage, options, profile: PROFILE, slotIndex, slot, state, base, global, stored,
        referenceInsertion: anchors[0].offset + 8, flagTemplate: template?.offset ?? null,
        reason: stage === 2 ? 'O peitoral já está na Melhoria 2.' : options.length ? '' : 'Não há modelo de marcador ou espaço reconhecido para esta melhoria.' };
    } catch (error) { return { available: false, canUpgrade: false, options: [], stage: null, reason: error.message }; }
  }
  function step(input, current) {
    const original = bytesOf(input), output = original.slice(), view = viewOf(output), { slot, state } = current;
    const target = current.stage + 1, id = PROFILE.history[target - 1], refDelta = current.stage === 0 ? 8 : 0, statsDelta = 16 + refDelta, totalDelta = statsDelta + 16;
    if (!current.options.includes(target)) fail(current.reason || 'A transição não foi reconhecida.');
    const previous = current.stage === 0 ? current.base : slot.rows.find(row => row.id === PROFILE.history[current.stage - 1]);
    const row = original.slice(previous.offset, previous.offset + 16); row.set(fromHex(id));
    const rowView = viewOf(row); rowView.setUint32(8, 1, true); rowView.setUint32(12, slot.table.count, true);
    const tracker = original.slice(current.flagTemplate, current.flagTemplate + 16); tracker.set(fromHex(id));
    const edits = [{ start: slot.table.end, bytes: row }];
    if (refDelta) edits.push({ start: current.referenceInsertion, bytes: fromHex(PROFILE.addedReference) });
    edits.push({ start: state.activeEnd, bytes: tracker });
    const segments = [{ start: slot.base, end: slot.table.end, dest: slot.base }];
    let read = slot.table.end, write = read;
    for (const edit of edits) {
      if (edit.start < read || edit.start > state.activeEnd) fail('As operações da melhoria se sobrepõem.');
      output.set(original.subarray(read, edit.start), write); segments.push({ start: read, end: edit.start, dest: write });
      write += edit.start - read; output.set(edit.bytes, write); write += edit.bytes.length; read = edit.start;
    }
    const newEnd = state.activeEnd + totalDelta;
    if (write !== newEnd) fail('O tamanho da melhoria não confere.');
    segments.push({ start: newEnd, end: slot.end, dest: newEnd });
    const fields = [{ offset: state.statsHeader, width: 4, value: state.statsSize + statsDelta },
      { offset: slot.table.start - 12, width: 4, value: slot.table.count + 1 },
      { offset: slot.table.start - 8, width: 4, value: slot.table.count8 + refDelta / 8 },
      { offset: slot.base + 0x124, width: 4, value: state.activeSize + totalDelta },
      { offset: state.frames[3].start + statsDelta + 2, width: 2, value: state.frames[3].length + 16 },
      { offset: current.global.offset + statsDelta, width: 4, value: target },
      { offset: current.stored.offset + statsDelta, width: 4, value: target }];
    fields.forEach(field => view[field.width === 2 ? 'setUint16' : 'setUint32'](field.offset, field.value, true));
    for (const segment of segments) {
      const end = segment.dest + segment.end - segment.start; let cursor = segment.dest;
      for (const field of fields.filter(field => field.offset >= segment.dest && field.offset < end).sort((a, b) => a.offset - b.offset)) {
        const source = segment.start + cursor - segment.dest;
        if (!equal(original.subarray(source, source + field.offset - cursor), output.subarray(cursor, field.offset))) fail('Dados externos à melhoria foram alterados.');
        cursor = field.offset + field.width;
      }
      const source = segment.start + cursor - segment.dest;
      if (!equal(original.subarray(source, segment.end), output.subarray(cursor, end))) fail('Um trecho original não foi preservado.');
    }
    const after = inspect(output, slot.index), nextSlot = core.parse(output).slots[slot.index];
    if (!after.available || after.stage !== target || after.state.activeEnd !== newEnd || nextSlot.table.count !== slot.table.count + 1 ||
      nextSlot.table.count8 !== slot.table.count8 + refDelta / 8 || nextSlot.table.count4 !== slot.table.count4) fail('A releitura da melhoria não confere.');
    for (const old of slot.rows) {
      const next = nextSlot.rows.find(row => row.id === old.id);
      if (!next || next.quantity !== old.quantity || next.auxiliary !== old.auxiliary) fail('Um registro anterior foi alterado.');
    }
    const added = nextSlot.rows.at(-1);
    if (added.id !== id || added.quantity !== 1 || added.auxiliary !== slot.table.count || !equal(output.subarray(newEnd - 16, newEnd), tracker)) fail('Os novos marcadores não conferem.');
    return { bytes: output, layout: { slot: slot.number, operation: 'armor-ancients-level', profile: PROFILE.id, from: current.stage, to: target,
      addedPrimaryRecords: 1, addedReferences: refDelta / 8, addedFinalRecords: 1, addedBytes: totalDelta,
      activeEndBefore: state.activeEnd, activeEndAfter: newEnd, resourcesPreserved: true, enchantmentsPreserved: true, inGameTestedHere: false } };
  }
  function patch(input, requests = []) {
    const original = bytesOf(input), model = core.parse(original), keys = new Set();
    if (!Array.isArray(requests)) fail('Plano de melhorias inválido.');
    for (const request of requests) {
      if (!request || request.type !== 'armor-ancients-level' || request.id !== PROFILE.id || !Number.isInteger(request.slot) || !model.slots[request.slot]?.available ||
        !Number.isInteger(request.stage) || ![0, 1, 2].includes(request.stage)) fail('Escolha uma etapa reconhecida do peitoral dos Ancestrais.');
      const key = request.slot + ':' + request.id;
      if (keys.has(key)) fail('Há duas melhorias para a mesma peça no mesmo slot.'); keys.add(key);
      const current = inspect(original, request.slot, model);
      if (!current.available || request.stage < current.stage || request.stage !== current.stage && !current.options.includes(request.stage)) fail(current.reason || 'A etapa não está disponível.');
    }
    let output = original.slice(); const log = [], layout = [];
    for (const request of requests) {
      const before = inspect(output, request.slot);
      if (before.stage === request.stage) continue;
      let current = before;
      while (current.stage < request.stage) {
        const result = step(output, current); output = result.bytes; layout.push(result.layout); current = inspect(output, request.slot);
      }
      if (!current.available || current.stage !== request.stage) fail('A etapa final não confere.');
      log.push({ type: 'armor-ancients-level', slot: request.slot + 1, slotIndex: request.slot, id: PROFILE.id, name: PROFILE.name,
        before: before.stage, after: request.stage, beforeLabel: before.stage ? 'Melhoria ' + before.stage : 'Base · sem reforço', afterLabel: 'Melhoria ' + request.stage, experimental: true });
    }
    if (!equal(original.subarray(0, core.HEADER_SIZE), output.subarray(0, core.HEADER_SIZE))) fail('O cabeçalho geral foi alterado.');
    const affected = new Set(requests.map(request => request.slot));
    for (const slot of model.slots) if (!affected.has(slot.index) && !equal(original.subarray(slot.base, slot.end), output.subarray(slot.base, slot.end))) fail('Um slot não selecionado foi alterado.');
    return { bytes: output, model: core.parse(output), log, layout, validation: { ancientsInGameTested: false, ancientsNativeTransitions: layout.length } };
  }
  return Object.freeze({ VERSION: '0.8.0', PROFILE, inspect, patch });
});
