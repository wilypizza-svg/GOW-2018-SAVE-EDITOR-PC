/* Ataques das duas armas. Os quatro índices controlados continuam no módulo
   de inventário. A expansão só inclui ausentes no nível 3, sem inventar chaves
   de nível, copiar receitas da loja ou modificar ataques já possuídos. */
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./native-records.js'),require('../data/runic-catalog.json'),require('./compatibility.js'));
 else root.Forja2018Runics=factory(root.Forja2018NativeRecords,JSON.parse(document.getElementById('runic-data').textContent),root.Forja2018Compatibility);
})(typeof globalThis!=='undefined'?globalThis:this,function(native,data,compat){
 'use strict';
 const fail=m=>{throw new Error(m);},ids=new Set(data.items.map(p=>p.id));
 const isTemplate=p=>p?.mode==='runic-quantity-template';
 const profiles=Object.freeze(data.items.filter(p=>!p.mapped).map(p=>Object.freeze({...p,key:null,build:data.build,
  variant:'normal',sharedCampaign:true,mode:'runic-quantity-template',experimentalTemplate:true,
  ids:[p.id],referenceIds:[],stages:[1,2,3].map(level=>({label:String(level),refs:[],finals:[]}))})));
 function localTemplate(tx,target){
  return tx.rows.find(row=>native.idOf(row)!==target&&ids.has(native.idOf(row))&&[1,2,3].includes(native.view(row).getUint32(8,true)));
 }
 function state(tx,p){
  compat.requireNative(tx,'Inclusão de ataques rúnicos');
  const qty=native.quantity(tx,p.id);
  if(qty!==null&&![1,2,3].includes(qty))fail('O contador deste rúnico está fora dos níveis reconhecidos; inclusão bloqueada.');
  if(qty===null&&!localTemplate(tx,p.id))fail('Consiga pelo menos um ataque rúnico no jogo antes de incluir outros.');
  return {available:true,owned:qty!==null,stage:qty===null?null:qty-1,highest:qty===null?-1:qty-1,
   actualLevelKnown:true,runicTemplate:true,readOnlyOwned:qty!==null};
 }
 function apply(tx,r,p){
  const s=state(tx,p);
  if(r.stage!==2)fail('A expansão rúnica inclui ataques ausentes somente no nível 3.');
  if(s.owned){
   if(s.stage===2)return null;
   fail('Este rúnico já existe. Faça as melhorias no jogo; seu índice PC próprio ainda não foi mapeado.');
  }
  if(r.allowExperimental!==true)fail('Ative a inclusão experimental para os novos rúnicos. Talvez corrompa seu save.');
  const row=localTemplate(tx,p.id).slice();row.set(native.fromHex(p.id));
  native.view(row).setUint32(8,3,true);native.view(row).setUint32(12,tx.rows.length,true);tx.rows.push(row);
  return {before:null,after:2,beforeLabel:'Ausente',afterLabel:'Nível 3 · inclusão rúnica experimental',name:p.name,
   acquired:true,runicTemplate:true,experimentalTemplate:true,levelMapWritten:false,
   existingRunicsPreserved:true,warning:'Talvez corrompa seu save'};
 }
 return Object.freeze({profiles,items:Object.freeze(data.items),isTemplate,state,apply});
});
