'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,query,downloads,$}=require('./test_dom_harness.cjs');
const inv=require('./src/inventory'),nat=require('./src/native-records'),ench=require('./src/enchantments'),camp=require('./src/campaign');
const fixture=JSON.parse(fs.readFileSync(process.argv[2]));
const choose=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
const ok=()=>assert.equal($('error').hidden,true,$('error').textContent),eq=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
const read=prefix=>{const s=fixture.find(s=>s.path&&s.file.startsWith('game('+prefix));return {...s,bytes:new Uint8Array(fs.readFileSync(s.path))};};
async function load(s){api.loadBytes(s.bytes);api.selectSlot(s.index);ok();}
(async()=>{
 const normal=read('AntesDeComprarUmPeitoral');await load(normal);api.chooseView('equipment');
 assert.equal($('inventory-apply').disabled,false);await choose('inventory-kind','chest');await choose('inventory-item','615B1370AEBED3EA');
 assert.equal($('inventory-stage').value,'2');await $('inventory-apply').click();ok();
 let result=api.exportBytes();assert.equal(nat.quantity(nat.read(result.bytes,normal.index),'615B1370AEBED3EA'),1);assert.equal(api.getState().changes[0].type,'inventory-equipment');
 let saved=result.bytes;await choose('inventory-stage',999);await $('inventory-apply').click();assert.equal($('error').hidden,false);eq(api.exportBytes().bytes,saved);
 await $('reset-changes').click();ok();assert.equal(api.getState().log.length,0);
 await $('original-download').click();eq(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),normal.bytes);
 const p=read('AntesDeConseguirUmpomoNivel8');await load(p);api.chooseView('equipment');await choose('inventory-kind','axe');await choose('inventory-item','AD675AD0CB86655D');
 assert.ok($('inventory-stage').innerHTML.includes('8+'));await choose('inventory-stage',1);await $('inventory-apply').click();ok();assert.equal(inv.inspect(api.exportBytes().bytes,p.index).profiles.find(x=>x.id==='AD675AD0CB86655D').stage,1);
 const k=read('AntesDeConseguirUmEncantamentoUnico(Kvasir)');await load(k);api.chooseView('enchantments');await choose('enchantment-create-item',inv.KVASIR);
 assert.equal($('kvasir-options').hidden,false);assert.equal($('kvasir-keep').checked,false);assert.equal($('enchantment-create-apply').disabled,false);
 assert.ok(fs.readFileSync(path.join(__dirname,'Abrir_Editor.html'),'utf8').includes('<strong>Talvez corrompa seu save.</strong>'));
 await $('enchantment-create-apply').click();ok();result=api.exportBytes();assert.equal(api.getState().changes.find(x=>x.id===inv.KVASIR).keepTalisman,false);
 for(const id of inv.SACRIFICE)assert.equal(nat.quantity(nat.read(result.bytes,k.index),id),0);
 await query('[data-undo]').find(b=>b.dataset.undo===k.index+':'+inv.KVASIR).click();ok();assert.equal(api.getState().log.length,0);assert.equal($('kvasir-keep').checked,false);
 await choose('enchantment-create-item',inv.KVASIR);$('kvasir-keep').checked=true;await $('enchantment-create-apply').click();ok();result=api.exportBytes();
 for(const id of inv.SACRIFICE)assert.equal(nat.quantity(nat.read(result.bytes,k.index),id),1);
 assert.equal(api.getState().log.find(x=>x.id===inv.KVASIR).warning,'Talvez corrompa seu save');
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.validation.experimentalKvasirCoexistence,true);assert.ok(report.changes.some(x=>x.warning==='Talvez corrompa seu save'));
 await load(k);assert.equal($('kvasir-keep').checked,false);api.chooseView('enchantments');await choose('enchantment-create-item',inv.MENACE);await choose('enchantment-create-count',2,'input');await $('enchantment-create-apply').click();ok();
 result=api.exportBytes();const uid=api.getState().log.find(x=>x.type==='enchantment-create').uids[0],state=ench.inspect(result.bytes,k.index);assert.ok(state.targets.length);
 await choose('enchantment-target',state.targets[0].uid);assert.ok($('enchantment-model').innerHTML.includes('value="'+uid+'"'));await choose('enchantment-model',uid);await $('enchantment-apply').click();ok();assert.ok(api.getState().log.some(x=>x.type==='enchantment-copy'));
 api.chooseView('changes');await query('[data-undo]').find(b=>b.dataset.undo===k.index+':'+inv.MENACE).click();ok();assert.equal(api.getState().log.length,0);assert.equal(api.getState().changes.length,0);
 const rage=read('AntesDoUpgradeDeFuria');await load(rage);api.chooseView('campaign');assert.equal($('horns-total').value,'5');await choose('horns-total',9,'input');await $('horns-apply').click();ok();assert.equal(camp.totals(api.exportBytes().model.slots[rage.index],camp.HORNS).total,9);
 const stone=read('AntesDeComprarApedra');await load(stone);api.chooseView('campaign');assert.equal($('berserker-apply').disabled,false);await $('berserker-apply').click();ok();assert.equal(camp.berserkerState(api.exportBytes().bytes,stone.index).owned,true);
 const summary={version:'0.11.0',htmlExecutedInVm:true,newEquipmentControlsAndActualEventsPassed:true,ngpIntermediateLevelSelectable:true,
 kvasirUncheckedByDefault:true,exactRiskWarningVisible:true,defaultSacrificeAndExplicitKeepPassed:true,riskRecordedInExportReport:true,
 undoCreationRemovesDependentCopies:true,invalidForcedClickPreservesDraft:true,originalDownloadUnchanged:true,hornsAndBerserkerControlsPassed:true,
 browserVisualTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_11_0.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
