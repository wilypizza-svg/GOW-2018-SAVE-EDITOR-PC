"""Leitor Python independente; não importa nem executa os módulos JavaScript."""
import hashlib
import json
import struct
import sys
from pathlib import Path

HEADER, SLOT, START = 4160, 1677512, 0x10400
u32 = lambda b,p: struct.unpack_from('<I',b,p)[0]
u16 = lambda b,p: struct.unpack_from('<H',b,p)[0]
hx = lambda b: b.hex().upper()

def decode(b,index):
    base=HEADER+index*SLOT
    start=base+START
    assert b[start:start+2]==b'\1\0' and b[start+3:start+5]==b'\xfa\xff'
    assert u32(b,base+0x110)==b[start+2]
    size,count,refs,objects=u32(b,start+5),u32(b,start+17),u32(b,start+21),u32(b,start+25)
    endstats=start+9+size
    p=start+29
    rows={}
    for _ in range(count):
        raw=b[p:p+16];id=hx(raw[:8]);assert id not in rows
        rows[id]=(u32(raw,8),raw,p);p+=16
    references=[hx(b[k:k+8]) for k in range(p,p+refs*8,8)];p+=refs*8
    def objlist(p,n):
        result=[];uids=set()
        for _ in range(n):
            begin=p;assert hx(b[p:p+8])=='3B056E1555DABD5D'
            uid=u32(b,p+48);assert uid not in uids;uids.add(uid)
            p+=72
            for _ in range(2):
                n=u32(b,p);assert n<=64;p+=4+n*4
            n=u32(b,p);assert n<=64;p+=4+n*12
            assert p<=endstats
            result.append(dict(uid=uid,raw=b[begin:p]))
        return p,result
    p,instances=objlist(p,objects)
    groups=[]
    for marker in ['EA2555A4149BE338','4B30662F58A15983','B0BDD5E2372DB672']:
        begin=p;assert hx(b[p:p+8])==marker
        n,n8,n4=u32(b,p+8),u32(b,p+12),u32(b,p+16)
        p+=20+16*n+8*n8
        p,_=objlist(p,n4);groups.append(b[begin:p])
    assert p==endstats
    maps=[]
    for k in range(3):
        end=p+2+u16(b,p);p+=2
        if k==1:p+=8
        n=u32(b,p);p+=4;entries={}
        for _ in range(n):
            key=u32(b,p);assert key not in entries
            raw=b[p:p+(9 if k else 8)];entries[key]=(u32(raw,4),raw);p+=len(raw)
        assert p==end;maps.append(entries)
    assert b[p:p+2]==b'\x2e\xfa'
    end=p+4+u16(b,p+2);p+=4
    finals={}
    while p<end:
        id=hx(b[p:p+8]);assert id not in finals;finals[id]=b[p:p+16];p+=16
    assert end==start+u32(b,base+0x124) and end+4096<=base+0x30400
    return dict(base=base,start=start,end=end,rows=rows,refs=references,objects=instances,groups=groups,maps=maps,finals=finals)

root=Path(__file__).resolve().parent
profiles=json.loads((root/'data/inventory-profiles.json').read_text())
byid={p['id']:p for p in profiles['profiles']}
factory={p['id']:p for p in profiles['enchantments']}
manifest=json.loads(Path(sys.argv[1]).read_text())
kv='3CACEA8D28B756B4'
sacrifice=['44C4565F57AD8B0C','B7AB0C2C27078684','A65DA1787B482B84','874E711224448484']
checks=[]
for case in manifest:
    a,b=Path(case['source']).read_bytes(),Path(case['output']).read_bytes()
    assert hashlib.sha256(a).hexdigest()==case['sourceSha256']
    assert hashlib.sha256(b).hexdigest()==case['outputSha256']
    x,y=decode(a,case['index']),decode(b,case['index'])
    assert len(a)==len(b)==33554400
    assert a[:x['base']+0x124]==b[:x['base']+0x124]
    assert a[x['base']+0x128:x['start']]==b[x['base']+0x128:x['start']]
    assert a[y['end']:]==b[y['end']:]
    changedrows=set();changedrefs=set();changedmaps=set();changedfinals=set();expectedobjects=[]
    for r in case['requests']:
        if r.get('type')=='inventory-equipment':
            p=byid[r['id']];stage=r['stage'];changedrows.update(p['ids']);changedrefs.update(p['referenceIds']);changedmaps.add(p['key']);changedfinals.update(p['ids']+p['referenceIds'])
            assert y['maps'][0][p['key']][0]==stage
            if p['key'] in x['maps'][1]:assert y['maps'][1][p['key']][0]==stage
            if p['mode']=='quantity':assert y['rows'][p['id']][0]==stage+1
            else:
                for id in p['ids'][:stage+1]:assert y['rows'][id][0]==1
        elif r.get('type')=='enchantment-create':
            p=factory[r['id']];count=r.get('count',1);changedrows.add(p['id']);changedfinals.add(p['id'])
            assert y['rows'][p['id']][0]==x['rows'].get(p['id'],(0,))[0]+count
            expectedobjects.extend([p]*count)
            if p['id']==kv:
                changedrows.add('9E5240D27406E85A')
                assert y['rows']['9E5240D27406E85A'][0]==x['rows']['9E5240D27406E85A'][0]-40000
                if not r.get('keepTalisman',False):
                    changedrows.update(sacrifice);changedmaps.add(959);changedrefs.add('9469F5C56C4DF108');changedfinals.update(sacrifice+['9469F5C56C4DF108'])
                    assert 959 not in y['maps'][0]
                    for id in sacrifice:assert y['rows'][id][0]==0
                else:
                    for id in sacrifice:assert y['rows'][id]==x['rows'][id]
        elif r.get('type')=='blood-mead-horns':
            ids=['E54B545124A5891E','89DADD432CFF222C','1B7F1BA84084222C','1AEEE86352596537'];changedrows.update(ids)
            for id,value in zip(ids,[r['total']%3,r['total'],r['total'],r['total']//3]):assert y['rows'][id][0]==value
        elif r.get('type')=='berserker-stone':
            changedrows.update(['3832900B4A8A614B','024373073A80CFB5']);changedrefs.add('9CACC83BC2F1FDD4');changedfinals.update(['3832900B4A8A614B','9CACC83BC2F1FDD4'])
            assert y['rows']['3832900B4A8A614B'][0]==1 and y['rows']['024373073A80CFB5'][0]==0
        else:
            assert r.get('type') is None;changedrows.add(r['id']);assert y['rows'][r['id']][0]==r['quantity']
    assert y['objects'][:len(x['objects'])]==x['objects']
    new=y['objects'][len(x['objects']):];assert len(new)==len(expectedobjects)
    for obj,p in zip(new,expectedobjects):
        raw=obj['raw'];template=bytes.fromhex(p['raw'])
        assert raw[:48]==template[:48] and raw[60:]==template[60:]
        assert u32(raw,52)==0xffffffff and u32(raw,56)==0xffffffff
        assert obj['uid'] not in [o['uid'] for o in x['objects']]
        id=hx(struct.pack('<Q',obj['uid']));changedfinals.add(id)
        assert hx(y['finals'][id][8:])==p['uidMetadata']
    for id,(_,raw,_) in x['rows'].items():
        if id not in changedrows:assert y['rows'][id][1]==raw
    assert [v for v in x['refs'] if v not in changedrefs]==[v for v in y['refs'] if v not in changedrefs]
    assert {k:v for k,v in x['finals'].items() if k not in changedfinals}=={k:v for k,v in y['finals'].items() if k not in changedfinals}
    for frame in range(3):
        assert {k:v for k,v in x['maps'][frame].items() if frame==2 or k not in changedmaps}=={k:v for k,v in y['maps'][frame].items() if frame==2 or k not in changedmaps}
    assert x['groups']==y['groups']
    checks.append(dict(name=case['name'],fileSizePreserved=True,unrelatedRowsObjectsGroupsMapsPreserved=True,otherSlotsWorldAndAbsoluteTailPreserved=True))
summary=dict(version='0.11.0',language='Python',independentParser=True,cases=checks,inGameTestedHere=False)
(root/'VERIFICACAO_INDEPENDENTE_0_11_0.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(dict(independentParser=True,cases=len(checks),passed=True)))
