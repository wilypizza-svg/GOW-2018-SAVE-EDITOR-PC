/* Eventos reais do HTML em DOM simulado; não afirma renderização visual. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{api,$,query,downloads}=require('./test_dom_harness.cjs');
const {document}=require('./test_dom_harness.cjs');
const core=require('./src/core'),camp=require('./src/campaign'),inv=require('./src/inventory'),weapon=require('./src/weapon-levels'),nat=require('./src/native-records'),selection=require('./src/inventory-selection');
const [a,b]=process.argv.slice(2);
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):e.name.endsWith('.sav')?[path.join(dir,e.name)]:[]);}
const sources=[...files(a),...files(b)],load=prefix=>{const file=sources.find(p=>path.basename(p).toLowerCase().startsWith(('game('+prefix).toLowerCase()));assert.ok(file,prefix);const bytes=new Uint8Array(fs.readFileSync(file)),m=core.parse(bytes);api.loadBytes(bytes,path.basename(file));api.selectSlot(m.latestSlot);return {bytes,index:m.latestSlot};};
const ok=()=>assert.equal($('error').hidden,true,$('error').textContent),change=async(id,value)=>{$(id).value=value;await $(id).fire('change');},same=(a,b)=>assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async()=>{
 for(const id of ['attach-choice','attach-apply','enchantment-target','enchantment-model','enchantment-apply','enchantment-stat-record','enchantment-filter-apply']) assert.equal(document.getElementById(id),undefined,id);
 const html=fs.readFileSync(path.join(__dirname,'Abrir_Editor.html'),'utf8');
 assert.ok(!html.includes('Forja2018EnchantmentStats'));

 const early=load('UnicoProblema');api.chooseView('campaign');
 assert.equal($('apples-total').disabled,false);assert.equal($('apples-total').value,'1');assert.equal($('horns-total').disabled,false);assert.equal($('horns-total').value,'0');
 $('apples-total').value='9';await $('apples-apply').click();ok();$('horns-total').value='9';await $('horns-apply').click();ok();
 let out=api.exportBytes();assert.equal(camp.totals(out.model.slots[early.index],camp.APPLES).total,9);assert.equal(camp.totals(out.model.slots[early.index],camp.HORNS).total,9);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.14.1');assert.equal(report.changes.length,2);
 const undo=query('[data-undo]').find(e=>e.dataset.undo===early.index+':idunn-apples');assert.ok(undo);await undo.click();ok();out=api.exportBytes();assert.equal(camp.totals(out.model.slots[early.index],camp.APPLES).total,1);
 await $('reset-changes').click();ok();await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),early.bytes);
 api.chooseView('levels');assert.match($('level-note').textContent,/primeiro upgrade/);assert.equal($('level-apply').disabled,true);assert.equal($('blades-level-apply').disabled,true);
 assert.equal(query('[data-view]').find(e=>e.dataset.view==='levels').hidden,false);

 const blades=load('AntesDoPrimeiroUpgradeBlades');api.chooseView('levels');assert.equal($('blades-level-original').textContent,'Nível 1');await change('blades-level-target','5');assert.equal($('blades-level-apply').disabled,false);await $('blades-level-apply').click();ok();
 assert.equal(weapon.inspect(api.exportBytes().bytes,blades.index,'blades-main-level').current,5);
 api.chooseView('equipment');await change('inventory-kind','blades');assert.equal($('inventory-item').children.filter(e=>e.tagName==='option').length,21);
 await change('inventory-variant','NG+');assert.equal($('inventory-item').children.filter(e=>e.tagName==='option').length,5);
 await change('inventory-item','B19A13C4B34FA37F');await change('inventory-stage','2');await $('inventory-apply').click();ok();
 assert.equal(inv.inspect(api.exportBytes().bytes,blades.index).profiles.find(p=>p.id==='B19A13C4B34FA37F').stage,2);
 const draft=api.exportBytes().bytes;
 await change('inventory-item','A8850E68CC1A3CB4');$('inventory-experimental').checked=true;await $('inventory-experimental').fire('change');
 assert.equal($('inventory-apply').disabled,true);assert.match($('inventory-note').textContent,/Edição suspensa/);
 await $('inventory-apply').click();assert.equal($('error').hidden,false);same(api.exportBytes().bytes,draft);
 await $('reset-changes').click();ok();

 const axe=load('DepoisDoPrimeiroUpgradeMachado');api.chooseView('levels');assert.equal($('level-original').textContent,'Nível 2');await change('level-target','6');await $('level-apply').click();ok();assert.equal(weapon.inspect(api.exportBytes().bytes,axe.index,'axe-main-level').current,6);

 const normal=load('AntesDeConseguirCaboNivel6');api.chooseView('equipment');await change('inventory-variant','normal');const set=selection.SETS.find(s=>s.id==='KratosArmor_NifTankSet_Tier06::normal');await change('inventory-set',set.id);assert.equal($('inventory-set-apply').disabled,false);await $('inventory-set-apply').click();ok();
 for(const p of set.parts)assert.equal(inv.inspect(api.exportBytes().bytes,normal.index).profiles.find(q=>q.id===p.id).stage,2);

 const bestla=load('AntesDeComprarEncantamentoDaLoja');api.chooseView('enchantments');await change('enchantment-create-item','7DD0A7B4B01F5116');$('enchantment-create-count').value='1';await $('enchantment-create-apply').click();ok();assert.equal(nat.quantity(nat.read(api.exportBytes().bytes,bestla.index),'7DD0A7B4B01F5116'),1);


 assert.match($('enchantment-create-note').textContent,/Bestla.*solto ao inventário/);
 const created=api.getState().log.find(e=>e.type==='enchantment-create');
 function loose(uid){const out=api.exportBytes(),row=nat.read(out.bytes,bestla.index).state.objects.find(o=>o.uid===uid),v=nat.view(out.bytes);assert.ok(row);assert.equal(core.hex(out.bytes.subarray(row.start+8,row.start+16)),'0000000000000000');assert.equal(v.getUint32(row.start+52,true),0xFFFFFFFF);assert.equal(v.getUint32(row.start+56,true),0xFFFFFFFF);}
 for(const uid of created.uids)loose(uid);
 await change('duplicate-slot',String(bestla.index));
 $('duplicate-experimental').checked=true;await $('duplicate-experimental').fire('change');
 assert.equal($('duplicate-apply').disabled,false);$('duplicate-count').value='2';await $('duplicate-apply').click();ok();
 const duplicated=api.getState().log.find(e=>e.type==='enchantment-duplicate');assert.ok(duplicated);for(const uid of duplicated.uids)loose(uid);
 await query('[data-undo]').find(e=>e.dataset.undo===bestla.index+':'+duplicated.id).click();ok();assert.equal(api.getState().changes.length,1);assert.equal(api.getState().changes[0].type,'enchantment-create');
 await query('[data-undo]').find(e=>e.dataset.undo===bestla.index+':'+created.id).click();ok();assert.equal(api.getState().changes.length,0);await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),bestla.bytes);
 const stone=load('RepondoDepois');api.selectSlot(3);api.chooseView('campaign');assert.equal($('berserker-apply').disabled,false);assert.match($('berserker-note').textContent,/Repõe/);await $('berserker-apply').click();ok();assert.ok(camp.berserkerState(api.exportBytes().bytes,3).owned);
 const result={version:'0.14.1',executedHtmlInSimulatedDom:true,earlyApplesAndHornsEnabled:true,capacityExportUndoResetOriginalAndReportPassed:true,
 weaponControlsVisibleAndFunctional:true,missingFirstAxePropertyExplained:true,lockedBladesDisabled:true,all21BladeHandlesAndFiveNgpOptionsListed:true,
 bladeLevelAndNewHandleCombined:true,unmappedNgpHandleDisabledAndForcedClickPreservesDraft:true,ivaldiSetAddedWithoutExperimentalFlag:true,bestlaCreationPassed:true,slotControlsAbsent:true,creationAndDuplicationProduceLooseItems:true,independentCreationAndDuplicationUndoPassed:true,berserkerRestockPassed:true,browserVisualTested:false,inGameTestedHere:false};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_14_1.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
