# Forja 2018 PC 0.18.0 — roteiro de primeiro uso

Este roteiro acompanha o editor offline de God of War 2018 para PC. A edição acontece numa cópia em memória. A versão 0.18.0 integra as remoções confirmadas nos testes R01 a R08; as funções anteriores continuam disponíveis.

## 1. Preparar e abrir

1. Feche o jogo. Guarde uma cópia do arquivo completo que o jogo usa, normalmente identificado nos nossos testes como `game.sav`.
2. Abra `Forja_2018_PC_0_18_0.html` no navegador. Não exige instalação nem conexão para editar.
3. Clique em **Abrir arquivo** e escolha a cópia do save de PC. O arquivo completo dos testes tem 33.554.400 bytes e contém vários salvamentos internos.
4. Em **Gerenciar saves**, confira título e data. A lista começa pelo mais recente. Clique em **Editar** no salvamento desejado.

**Resultado esperado:** o resumo mostra o salvamento selecionado. O número interno do slot ajuda a identificá-lo no editor; ele não é a posição na lista do jogo. Todos os passos seguintes afetam o slot escolhido.

## 2. Primeiro ensaio: um recurso existente

1. Entre em **Recursos** e pesquise um material que você já possui.
2. Informe um total final fácil de reconhecer, por exemplo 1234, respeitando o limite indicado para o item.
3. Prepare o ajuste e abra **Alterações**. Confira o item, o slot, o valor original e o desejado.
4. Use **Desfazer** nessa linha para verificar que consegue voltar ao estado anterior. Prepare novamente se quiser manter a alteração.

**Resultado esperado:** apenas a quantidade escolhida entra na revisão. A revisão permite cancelar antes de exportar.

## 3. Recursos ausentes e pacotes

1. Em **Recursos**, escolha um recurso do catálogo, incluindo um ausente, quando a opção estiver disponível para a estrutura do seu save.
2. Em **Pacotes de recursos**, escolha o grupo que deseja testar e a quantidade mínima dos itens empilháveis.
3. Confira a prévia. Um item único segue seu limite; um estoque já maior fica preservado pelo pacote.
4. Prepare o pacote e veja os itens individualmente em **Alterações**.

**Resultado esperado:** os recursos ausentes reconhecidos são acrescentados e os existentes chegam ao total solicitado conforme a política do pacote. Não é necessário selecionar os materiais um por um.

## 4. Atributos e metas

1. Em **Atributos por orvalhos**, escolha um atributo e prepare um bônus permanente moderado para o primeiro teste.
2. O bônus dos orvalhos soma-se ao equipamento. Confira a quantidade proposta e a revisão.
3. Em **Calcular metas**, informe o valor exibido no jogo no save original e o total desejado usando o mesmo equipamento. Prepare a quantidade calculada de orvalhos.

**Resultado esperado:** a revisão identifica os orvalhos usados no cálculo. O valor final exibido no jogo pode respeitar limites próprios do jogo. Faça a comparação com o mesmo conjunto equipado.

## 5. Adicionar equipamento, conjunto e rúnico

1. Em **Equipamentos e melhorias**, filtre o tipo de peça e a variante normal/NG+.
2. Pesquise um item ausente. Escolha uma etapa que esteja disponível e clique em **Adicionar ou ajustar nível**.
3. Para um conjunto, use **Adicionar conjunto de armadura**. Confira as três peças na revisão. As já possuídas são preservadas pelo lote.
4. Para testar uma inclusão em grupo, escolha um filtro pequeno e use **Adicionar ausentes deste filtro**.
5. Para ataques rúnicos do Machado ou das Lâminas, escolha a categoria correspondente. Os perfis com nível mapeado permitem a escolha indicada; outros usam inclusão fixa no nível 3 e preservam os já possuídos.

**Resultado esperado:** cada item preparado aparece em **Alterações**. Os níveis iniciais e os upgrades variam entre famílias; `8+` é uma etapa intermediária. O filtro NG+ indica a variante do item, não converte a campanha em NG+.

## 6. Adicionar encantamento

1. Em **Encantamentos**, escolha um dos 17 perfis disponíveis.
2. Prepare uma unidade ausente e confira a revisão.
3. Quando houver peças para a conversão de uma marca, siga a orientação para fabricar pelo jogo.

**Resultado esperado:** o encantamento novo fica solto no inventário. Equipe-o pelo jogo. A edição direta de encaixes continua fora do editor. A duplicação genérica permanece separada em **Avançado**, com sua cobertura própria.

## 7. Remover equipamento — novidade da 0.18.0

1. Pelo jogo, desequipe a peça que deseja retirar e faça um salvamento. Abra essa cópia no editor.
2. Em **Equipamentos e melhorias**, use os filtros e o quadro **Remover equipamento**.
3. Escolha a peça possuída. Quando aparecer **A peça já está desequipada no jogo**, marque após conferir essa condição.
4. Leia a prévia. Encantamentos comuns dos formatos reconhecidos são devolvidos soltos ao inventário. Se houver um encantamento único ou não reconhecido, retire-o da peça pelo jogo antes de preparar a remoção.
5. Clique em **Preparar remoção da peça** e confira **Alterações**.
6. Para desfazer, use a ação da linha ou **Desfazer tudo**.

**Resultado esperado:** a peça e as melhorias de sua família ficam inativas. Os mapas de nível e os outros itens são preservados. A retirada não credita o preço de venda; Hacksilver e materiais mantêm os valores da edição atual.

Para conferir a devolução, use uma peça com encantamentos comuns reconhecidos e leia a quantidade indicada na prévia. Depois de carregar no jogo, confira os encantamentos no inventário e equipe-os em outra peça com encaixes disponíveis.

## 8. Remover uma instância comum

1. Retire o encantamento de qualquer encaixe pelo jogo e salve.
2. Abra o arquivo no editor e vá a **Encantamentos → Remover encantamento comum**.
3. Escolha a instância pelos atributos e pelo número do registro. Esse número distingue cópias dentro do salvamento.
4. Prepare a retirada e confira a revisão.

**Resultado esperado:** somente a instância selecionada é retirada. Os outros encantamentos ficam preservados. A função oferece os construtores comuns reconhecidos pelas amostras; únicos e formatos ainda não classificados ficam fora dessa remoção.

## 9. Campanha e níveis

- **Campanha e inventário:** teste separadamente o total de maçãs de Iðunn, a capacidade de fúria por chifres e as cifras de Niflheim/Muspelheim. Observe os limites da tela e confira a revisão.
- **Escolher nível:** use as opções reconhecidas para Machado e Lâminas. No NG normal, um registro inicial ausente ainda pode exigir a primeira melhoria pelo jogo. As armas precisam ter seus registros liberados.
- **Dificuldade:** permanecem os modos já mapeados e disponíveis na tela. A dificuldade máxima não foi liberada nesta versão.
- **NG+ com histórico incompleto das armas:** há um ensaio separado. A 0.18.0 mantém o bloqueio desse caso até a validação do teste no jogo. Isso também não ativa a opção NG+ do menu.

## 10. Revisar, exportar e conferir no jogo

1. Em **Alterações**, confira o slot e todas as linhas. Para o primeiro uso, exporte um grupo pequeno de mudanças.
2. Clique em **Baixar game.sav editado**. Guarde também **Baixar relatório** para identificar o que foi preparado.
3. Com o jogo fechado, aplique a cópia editada no lugar correto e com o nome usado pelo arquivo original. Preserve o backup.
4. Entre em **Carregar jogo** e escolha pelo título/data o salvamento que editou.
5. Abra a categoria alterada, confira os itens e saia do inventário.
6. Faça um novo salvamento manual, volte ao menu e carregue esse novo salvamento. Confira novamente as alterações.

**Resultado esperado:** o jogo carrega, o inventário abre e fecha, e a modificação persiste após o salvamento nativo.

Se for relatar um teste, envie o arquivo salvo pelo próprio jogo e diga quais ações fez no editor e em que momento houve uma falha, se houver. O relatório do editor é útil para reproduzir a sequência.

## Sequência curta para testar a nova versão

1. Alterar um recurso existente e desfazer.
2. Preparar um pacote pequeno.
3. Acrescentar uma peça ausente.
4. Adicionar um encantamento disponível.
5. Retirar uma peça melhorada e conferir que os demais equipamentos continuam presentes.
6. Retirar uma instância comum solta.
7. Retirar uma peça com encantamentos comuns e reutilizar os encantamentos devolvidos.
8. Salvar e recarregar no jogo.

Gerenciar subsaves — extrair, importar ou excluir uma posição — pode ser testado numa cópia separada. **Baixar original** devolve o arquivo inicialmente aberto.
