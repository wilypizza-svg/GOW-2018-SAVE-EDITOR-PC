/* Aquisição, lote, preservação e limites dos modelos NG completos. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),out=path.join(ws,'analysis_0_19_0/testes');fs.mkdirSync(out,{recursive:true});
const core=require('./src/core'),nat=require('./src/native-records'),acq=require('./src/enchantment-acquisition'),inv=require('./src/inventory'),ench=require('./src/enchantments'),plan=require('./src/plan'),old=require('../Forja_2018_PC_0_18_0/src/plan');
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b,m)=>assert(nat.equal(a,b),m),request=(p,slot)=>({slot,type:'enchantment-create',id:p.id,count:1});
const reports=[],inputs=new Map();
function preserve(original,result,index){
 const a=nat.read(original,index),b=nat.read(result.bytes,index);for(const o of a.state.objects){const n=b.state.objects.find(n=>n.uid===o.uid);assert(n,'UID anterior desapareceu');same(original.subarray(o.start,o.end),result.bytes.subarray(n.start,n.end),'Instância anterior modificada');}
 same(a.bytes.subarray(a.state.objectEnd,a.state.statsEnd),b.bytes.subarray(b.state.objectEnd,b.state.statsEnd),'Grupo anterior modificado');
 for(let i=0;i<3;i++){assert.equal(a.maps[i].entries.length,b.maps[i].entries.length);a.maps[i].entries.forEach((r,j)=>same(r,b.maps[i].entries[j],'Mapa modificado'));}
 same(original.subarray(0,core.HEADER_SIZE),result.bytes.subarray(0,core.HEADER_SIZE),'Cabeçalho geral modificado');
 for(const s of core.parse(original).slots)if(s.index!==index)same(original.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end),'Outro slot modificado');
 same(original.subarray(a.slot.base+0x128,a.slot.base+0x10400),result.bytes.subarray(a.slot.base+0x128,a.slot.base+0x10400),'Mundo modificado');
 const unique=new Set(b.state.objects.map(o=>o.uid));assert.equal(unique.size,b.state.objects.length);assert(b.finals.length<=512);return {a,b};
}
assert.equal(core.VERSION,'0.19.0');assert.equal(acq.PROFILES.length,107);assert.equal(inv.FACTORIES.length,107);assert.equal(acq.PROFILES.filter(p=>p.variant==='Normal').length,92);
for(const p of acq.PROFILES)assert.equal(ench.classifyRaw(nat.fromHex(p.raw)).classification,p.classification);
const files=['entrega_encantamentos_02/ENC_02_CONTROLE_Normal.sav','upload/game(MarcaPerfeitaDoTYR+SETCOMPLETODOTYR).sav','upload/game(NGP_01_ARMAS_MAXIMAS(Funcionou)).sav'];
for(const file of files){
 const original=read(file),m=core.parse(original),slot=m.latestSlot,initial=nat.read(original,slot),hash=sha(original);inputs.set(file,hash);
 const requests=acq.PROFILES.filter(p=>{const s=acq.inspectTx(initial,p.id);return s.available&&!s.owned;}).map(p=>request(p,slot));
 const result=plan.patch(original,requests),{a,b}=preserve(original,result,slot);assert.equal(result.log.length,requests.length);same(plan.patch(result.bytes,requests).bytes,result.bytes,'Reaplicar lote duplicou instâncias');
 for(const r of requests){const p=acq.lookup(r.id),s=acq.inspectTx(b,r.id);assert(s.available&&s.owned);const object=b.state.objects.find(o=>o.uid===s.uid),raw=result.bytes.subarray(object.start,object.end),recipe=nat.fromHex(p.raw);same(raw.subarray(16,48),recipe.subarray(16,48));same(raw.subarray(64),recipe.subarray(64));assert.equal(nat.view(raw).getUint32(52,true),0xFFFFFFFF);assert.equal(nat.view(raw).getUint32(56,true),0xFFFFFFFF);same(raw.subarray(8,16),new Uint8Array(8));if(p.acquisitionMode==='instance')assert.equal(nat.quantity(b,p.id),null,'ID lógico foi gravado na tabela binária');}
 const managed=new Set(requests.map(r=>{const p=acq.lookup(r.id);return p.acquisitionMode==='instance'?p.counterId:p.id;}).filter(Boolean));
 for(const row of a.rows)if(!managed.has(nat.idOf(row))){const n=nat.unique(b.rows,nat.idOf(row));same(row,n,'Contador anterior modificado');}
 const normalRequests=requests.filter(r=>acq.lookup(r.id).variant==='Normal');
 const target=path.join(out,'CATALOGO_'+(reports.length+1)+'.sav');fs.writeFileSync(target,result.bytes);
 reports.push({file,sourceSha256:hash,slot:slot+1,build:a.slot.build,included:requests.length,newNormalIncluded:normalRequests.length,ownedBefore:acq.PROFILES.filter(p=>acq.inspectTx(initial,p.id).owned).length,sha256:sha(result.bytes),output:target,requests,previousInstancesPreserved:true,otherSlotsAndWorldPreserved:true,idempotent:true});
}
// Todos os modelos novos também são exercitados sem seus exemplares prévios.
const base=read(files[0]),slot=core.parse(base).latestSlot,source=nat.read(base,slot),baseObjects=source.state.objects.map(o=>base.slice(o.start,o.end));
const parsedLists=raw=>{let at=72;const v=nat.view(raw),out=[];for(let k=0;k<2;k++){const n=v.getUint32(at,true);at+=4;const values=[];for(let j=0;j<n;j++,at+=4)values.push(v.getUint32(at,true));out.push(values);}return out;};
const newProfiles=acq.PROFILES.filter(p=>p.nativeModel),nonCatalog=baseObjects.filter(raw=>!newProfiles.some(p=>{const model=nat.fromHex(p.raw),lists=parsedLists(raw);return p.classification==='unique'&&lists[0].some(x=>p.signature.lists[0].includes(x))||nat.equal(raw.subarray(16,48),model.subarray(16,48))&&nat.equal(raw.subarray(64,72),model.subarray(64,72))&&JSON.stringify(lists)===JSON.stringify(p.signature.lists);}));
assert(nonCatalog.length>0);const roots=nonCatalog,groups=base.slice(source.state.objectEnd,source.state.statsEnd),pieces=[...roots,groups],joined=new Uint8Array(pieces.reduce((n,x)=>n+x.length,0));let at=0;for(const p of pieces){joined.set(p,at);at+=p.length;}source.objectsAndGroups=joined;source.slot={...source.slot,table:{...source.slot.table,count4:roots.length}};const fixture=nat.write(source).bytes,fixtureTx=nat.read(fixture,slot);
const syntheticRequests=newProfiles.filter(p=>{const s=acq.inspectTx(fixtureTx,p.id);return s.available&&!s.owned;}).map(p=>request(p,slot));assert.equal(syntheticRequests.length,90);
const synthetic=plan.patch(fixture,syntheticRequests);preserve(fixture,synthetic,slot);assert.equal(synthetic.log.length,90);same(plan.patch(synthetic.bytes,syntheticRequests).bytes,synthetic.bytes);fs.writeFileSync(out+'/TODOS_90_FIXTURE_TECNICO.sav',synthetic.bytes);
let sequential=fixture;for(const r of syntheticRequests)sequential=plan.patch(sequential,[r]).bytes;same(synthetic.bytes,sequential,'Lote e sequência divergiram');
// Sete aquisições controladas: inclusive duas listas no Signo Robusto.
const pairReports=[];for(const pair of require('../analysis_0_19_0/catalog_samples.json')){
 const profile=newProfiles.find(p=>p.sourceEvidence.some(e=>e.sha256===pair.after.sha256));assert(profile);
 const b=read(pair.before.file),m=core.parse(b),t=nat.read(b,m.latestSlot),state=acq.inspectTx(t,profile.id);assert(state.available&&!state.owned,profile.name+': '+state.reason);
 const r=plan.patch(b,[request(profile,m.latestSlot)]);preserve(b,r,m.latestSlot);assert.equal(r.log.length,1);pairReports.push({id:profile.id,name:profile.name,firstEffects:profile.signature.lists[0],newUid:r.log[0].uids[0],nativeSampleSha256:pair.after.sha256});
}
// Aviso de conversão é informativo; inclui cinco marcas preservando todas as peças.
const conversion=acq.PROFILES.filter(p=>p.ingredientIds.length),tx=nat.read(base,slot);
for(const p of conversion)for(const id of p.ingredientIds)nat.putQuantity(tx,id,1,true);
const withIngredients=nat.write(tx).bytes,rt=nat.read(withIngredients,slot),conversionRequests=conversion.map(p=>request(p,slot));for(const p of conversion){const s=acq.inspectTx(rt,p.id);assert(s.available&&!s.owned);assert(s.conversionRecommended&&s.conversionMaterialsPresent);assert.match(s.conversionNotice,/PREFERÍVEL/);}
const converted=plan.patch(withIngredients,conversionRequests),ct=nat.read(converted.bytes,slot);for(const p of conversion){assert(acq.inspectTx(ct,p.id).owned);for(const id of p.ingredientIds)assert.equal(nat.quantity(ct,id),1);}
same(nat.unique(rt.rows,'9E5240D27406E85A'),nat.unique(ct.rows,'9E5240D27406E85A'));preserve(withIngredients,converted,slot);
const reference=old.patch(base,acq.PROFILES.filter(p=>!p.nativeModel).map(p=>request(p,slot))),now=plan.patch(base,acq.PROFILES.filter(p=>!p.nativeModel).map(p=>request(p,slot)));same(reference.bytes,now.bytes,'Os 17 perfis anteriores mudaram a saída');
const invalid=newProfiles[0],req=request(invalid,slot);for(const count of [0,2,-1,1.5,'1'])assert.throws(()=>plan.patch(fixture,[{...req,count}]),/uma unidade/);assert.throws(()=>plan.patch(fixture,[req,req]),/dois pedidos/);assert.throws(()=>plan.patch(fixture,[{...req,id:'sem-modelo'}]),/receita/);
for(const [file,hash]of inputs)assert.equal(sha(read(file)),hash);
const report={passed:true,version:core.VERSION,profiles:107,normal:92,ngplus:15,newNormal:90,allNewProfilesExercised:true,syntheticFixtureOnlyForCompleteCoverage:true,nativeControlledAcquisitions:pairReports,realSaveBatches:reports,oneAbsentUnitPerProfile:true,allExistingInstancesAndSocketsPreserved:true,uniqueProfilesNotDuplicated:true,conversionNoticeNonBlocking:true,allFivePerfectMarksAllowedWithIngredients:true,conversionEquipmentAndHacksilverPreserved:true,allSeventeenLegacyOutputsByteIdentical:true,batchAndSequentialIdentical:true,newAcquisitionsAwaitUserGameTest:true};fs.writeFileSync(__dirname+'/VERIFICACAO_CATALOGO_0_19_0.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:true,newProfiles:90,controlledPairs:7,batches:reports.map(r=>r.included),fiveConversions:true,legacyByteIdentical:true}));
