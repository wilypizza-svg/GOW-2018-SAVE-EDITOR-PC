'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { api, query, downloads, $ } = require('./test_dom_harness.cjs');
const writer = require('./src/plan'), levels = require('./src/levels');
const bytes = new Uint8Array(fs.readFileSync(process.argv[2]));
const same = (a, b) => assert.ok(Buffer.from(a).equals(Buffer.from(b)));
(async () => {
  api.loadBytes(bytes); api.chooseView('levels'); assert.equal($('levels-controls').hidden, true);
  api.selectSlot(11); api.chooseView('levels'); assert.equal($('levels-controls').hidden, false);
  assert.equal($('level-original').textContent, 'Nível 5'); assert.equal($('level-apply').disabled, true);
  $('level-target').value='6'; await $('level-target').fire('change'); assert.equal($('level-apply').disabled,false);
  await $('level-apply').click(); assert.equal($('error').hidden, true, $('error').textContent);
  const request = { slot: 11, id: levels.ID, type: 'axe-level', level: 6 };
  same(api.exportBytes().bytes, writer.patch(bytes, [request]).bytes);
  assert.equal($('level-edited').textContent, 'Nível 6'); assert.equal($('level-apply').disabled, true);
  assert.ok($('changes-body').innerHTML.includes('Machado Leviatã'));
  $('quantity-search').value = 'CC1B3E5C878842B3'; await $('quantity-search').fire('input');
  $('quantity-item').value = 'CC1B3E5C878842B3'; await $('quantity-item').fire('change'); $('quantity-value').value = '22';
  await $('quantity-value').fire('input'); await $('quantity-apply').click(); assert.equal($('error').hidden, true, $('error').textContent);
  const plan = [request, { slot: 11, id: 'CC1B3E5C878842B3', quantity: 22 }];
  same(api.exportBytes().bytes, writer.patch(bytes, plan).bytes);
  await $('report-download').click(); const exportedReport = JSON.parse(await downloads.at(-1).blob.text());
  assert.equal(exportedReport.validation.preservesBytesOutsideQuantityFields, false); assert.equal(exportedReport.validation.levelTargetsInGameTested, false);
  await $('export-top').click(); assert.equal(downloads.at(-1).name, 'game.sav'); same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()), api.exportBytes().bytes);
  await query('[data-undo]').find(button => button.dataset.undo === '11:' + levels.ID).click();
  same(api.exportBytes().bytes, writer.patch(bytes, plan.slice(1)).bytes); assert.equal($('level-edited').textContent, 'Nível 5');
  await $('reset-changes').click(); assert.equal(api.getState().log.length, 0); api.selectSlot(0); api.chooseView('levels');
  assert.equal($('level-original').textContent, 'Nível 4'); assert.equal($('level-apply').disabled, true);
  $('level-target').value='6'; await $('level-target').fire('change'); await $('level-apply').click(); assert.equal($('error').hidden, false); assert.equal(api.getState().log.length, 0);
  const report = { version: '0.9.0', levelsPageAndSupportedTransitionVerified: true, slot12ExplicitlySelected: true,
    oldAndEditedLevelsDisplayed: true, resourceAndLevelChangesCombined: true, undoAndResetVerified: true,
    unsupportedTransitionDisabledAndRejected: true, reportAndDownloadVerified: true, visualBrowserTested: false, inGameTestedHere: false };
  fs.writeFileSync(path.join(__dirname, 'VERIFICACAO_NIVEIS_INTERFACE_0_9_0.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
