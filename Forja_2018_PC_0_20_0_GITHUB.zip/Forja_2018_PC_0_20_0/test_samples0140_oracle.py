"""Leitura independente das saídas preparadas, sem importar o JavaScript.
Uso: python3 test_samples0140_oracle.py PASTA_DE_SAIDAS
"""
from pathlib import Path
import ast, hashlib, json, re, struct, sys

root=Path(__file__).parent
out=Path(sys.argv[1])
reader=root/'test_clone_native_reader.py'
definition=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=0)
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse']
profiles={p['id']:p for p in json.loads((root/'data/inventory-profiles.json').read_text())['profiles']}
weapons={p['id']:p for p in json.loads((root/'data/weapon-profiles.json').read_text())['profiles']}
catalog=json.loads((root/'data/catalog.json').read_text())['items']
families={}
for item in catalog:
    name=item['internalName']
    key=re.sub(r'_Reinforce\d+','',name)
    families.setdefault(key,[]).append(item)
for members in families.values():
    members.sort(key=lambda x:int(re.search(r'_Reinforce(\d+)',x['internalName']).group(1)) if re.search(r'_Reinforce(\d+)',x['internalName']) else 0)
    base=members[0]
    profiles.setdefault(base['id'],dict(id=base['id'],ids=[m['id'] for m in members],referenceIds=[],key=None))
apples=['8EC8B40DE6B3AC68','2085C71C79E4ED7E','B42DDFD1FBD3ED7E','D6833365C3296802']
horns=['E54B545124A5891E','89DADD432CFF222C','1B7F1BA84084222C','1AEEE86352596537']
def objects(data,state):
    n=struct.unpack_from('<I',data,state['start']+25)[0]
    cursor=state['row_end']+len(state['refs'])
    records={}
    for _ in range(n):
        start=cursor;uid=struct.unpack_from('<I',data,cursor+48)[0];cursor+=72
        for _ in range(2):
            count=struct.unpack_from('<I',data,cursor)[0];cursor+=4+4*count
        count=struct.unpack_from('<I',data,cursor)[0];cursor+=4+12*count
        assert uid not in records
        records[uid]=data[start:cursor]
    return records,data[cursor:state['start']+9+struct.unpack_from('<I',data,state['start']+5)[0]]
def mapping(frame,number):
    prefix,stride=(8 if number==1 else 0),(8 if number==0 else 9)
    count=struct.unpack_from('<I',frame,2+prefix)[0]
    return {struct.unpack_from('<I',frame,6+prefix+i*stride)[0]:frame[6+prefix+i*stride:6+prefix+(i+1)*stride] for i in range(count)}
cases=json.loads((out/'manifest.json').read_text())['cases']
results=[]
for case in cases:
    original=Path(case['source']).read_bytes();edited=(out/case['name']/'game.sav').read_bytes()
    assert hashlib.sha256(original).hexdigest()==case['sourceSha256']
    assert hashlib.sha256(edited).hexdigest()==case['sha256']
    ns['SLOT_INDEX']=case['slot']-1
    a,b=parse(original),parse(edited)
    allowed_rows,allowed_refs,allowed_finals,allowed_keys=set(),set(),set(),set()
    expected_quantities={};expected_maps={};scene_offsets=[]
    for request in case['requests']:
        kind=request['type']
        if kind in ['idunn-apples','blood-mead-horns']:
            ids=apples if kind=='idunn-apples' else horns
            total=request['total']
            expected_quantities.update(zip(ids,[total%3,total,total,total//3]))
            allowed_rows.update(ids)
        elif kind=='inventory-equipment':
            p=profiles[request['id']]
            allowed_rows.update(p['ids']);allowed_refs.update(p['referenceIds']);allowed_finals.update(p['ids']+p['referenceIds'])
            expected_quantities.update({id:1 for id in p['ids'][:request['stage']+1]})
            if p['key'] is not None:
                allowed_keys.add(p['key']);expected_maps[(0,p['key'])]=request['stage']
        elif kind=='enchantment-create':
            allowed_rows.add(request['id']);allowed_finals.add(request['id'])
            old_rows={r[:8].hex().upper():struct.unpack_from('<I',r,8)[0] for r in a['rows']}
            expected_quantities[request['id']]=old_rows.get(request['id'],0)+request['count']
        elif kind=='weapon-level':
            p=weapons[request['id']]
            allowed_rows.update(p['history']);allowed_refs.update(p['recipeReferenceIds']);allowed_finals.update(p['history'])
            for step in p['steps']:
                allowed_refs.update(r['id'] for r in step['refs']);allowed_finals.update(r['id'] for r in step['refs'])
            expected_quantities.update({id:1 for id in p['history'][:request['level']-1]})
            allowed_keys.add(p['key']);expected_maps[(0,p['key'])]=request['level']-1;expected_maps[(1,p['key'])]=request['level']-1
            marker=bytes.fromhex(p['sceneMarker']);scene=original[a['base']+0x400:a['start']]
            assert scene.count(marker)==1
            offset=a['base']+0x400+scene.index(marker)+len(marker);scene_offsets.append(offset)
            assert struct.unpack_from('<I',edited,offset)[0]==request['level']-1
        else:
            raise AssertionError(kind)
    for log in case['log']:
        for uid in log.get('uids',[]):allowed_finals.add(struct.pack('<Q',uid).hex().upper())
    old_rows={r[:8].hex().upper():r for r in a['rows']};new_rows={r[:8].hex().upper():r for r in b['rows']}
    for id,row in old_rows.items():
        if id not in allowed_rows:assert new_rows[id]==row
    assert set(new_rows)-set(old_rows)<=allowed_rows
    for id,value in expected_quantities.items():assert struct.unpack_from('<I',new_rows[id],8)[0]==value
    split=lambda raw,stride:[raw[p:p+stride] for p in range(0,len(raw),stride)]
    assert [r for r in split(a['refs'],8) if r.hex().upper() not in allowed_refs]==[r for r in split(b['refs'],8) if r.hex().upper() not in allowed_refs]
    for number in range(3):
        aa,bb=mapping(a['frames'][number],number),mapping(b['frames'][number],number)
        assert {k:v for k,v in aa.items() if k not in allowed_keys}=={k:v for k,v in bb.items() if k not in allowed_keys}
        for (frame,key),value in expected_maps.items():
            if frame==number:assert struct.unpack_from('<I',bb[key],4)[0]==value
    aa=split(a['finals'][4:],16);bb=split(b['finals'][4:],16)
    assert [r for r in aa if r[:8].hex().upper() not in allowed_finals]==[r for r in bb if r[:8].hex().upper() not in allowed_finals]
    oo,og=objects(original,a);no,ng=objects(edited,b)
    assert og==ng
    for uid,raw in oo.items():assert no[uid]==raw
    new_uids={uid for log in case['log'] for uid in log.get('uids',[])}
    assert set(no)-set(oo)==new_uids
    for uid in new_uids:
        assert no[uid][8:16]==b'\x00'*8
        assert struct.unpack_from('<II',no[uid],52)==(0xffffffff,0xffffffff)
    prefix=bytearray(original[:a['start']])
    prefix[a['base']+0x124:a['base']+0x128]=edited[a['base']+0x124:a['base']+0x128]
    for offset in scene_offsets:prefix[offset:offset+4]=edited[offset:offset+4]
    assert prefix==edited[:b['start']]
    assert original[max(a['end'],b['end']):]==edited[max(a['end'],b['end']):]
    for index in range(20):
        if index==case['slot']-1:continue
        start=4160+index*1677512;assert original[start:start+1677512]==edited[start:start+1677512]
    results.append({'case':case['name'],'slot':case['slot'],'passed':True})
report={'version':'0.14.0','independentLanguage':'Python','passed':True,'cases':results,'inGameTestedHere':False}
(root/'VERIFICACAO_INDEPENDENTE_0_14_0.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
