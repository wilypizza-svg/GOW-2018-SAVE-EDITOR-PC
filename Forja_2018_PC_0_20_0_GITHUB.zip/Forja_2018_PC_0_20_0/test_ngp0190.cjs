'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const ws=path.resolve(process.argv[2]||path.join(__dirname,'..')),core=require('./src/core'),nat=require('./src/native-records'),weapon=require('./src/weapon-levels'),plan=require('./src/plan'),old=require('../Forja_2018_PC_0_18_0/src/weapon-levels');
const read=p=>new Uint8Array(fs.readFileSync(path.resolve(ws,p))),same=(a,b,m)=>assert(nat.equal(a,b),m),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const file='analysis_0_18_0/fixtures/game(20261025-031453).sav',bytes=read(file),model=core.parse(bytes),slot=model.latestSlot,base=nat.read(bytes,slot),requests=weapon.PROFILES.map(p=>({slot,type:weapon.TYPE,id:p.id,level:p.max}));
for(const p of weapon.PROFILES){assert(!old.inspect(bytes,slot,p.id).available);const s=weapon.inspect(bytes,slot,p.id);assert(s.available&&s.partialHistoryMapped);assert(s.options.find(x=>x.value===p.max).available);}
const result=plan.patch(bytes,requests),trial=read('analysis_0_18_0/ngp_trial/NGP_01_ARMAS_MAXIMAS/game.sav');same(result.bytes,trial,'A implementação divergiu do save testado pelo usuário');
const returned=read('upload/game(NGP_01_ARMAS_MAXIMAS(Funcionou)).sav'),rm=core.parse(returned),rt=nat.read(returned,rm.latestSlot);
for(const p of weapon.PROFILES){const s=weapon.inspect(returned,rm.latestSlot,p.id);assert(s.available&&s.current===p.max&&s.partialHistoryMapped);for(const id of p.history)assert.equal(nat.quantity(rt,id),1);}
same(plan.patch(returned,requests.map(r=>({...r,slot:rm.latestSlot}))).bytes,returned);
const after=nat.read(result.bytes,slot);same(base.objectsAndGroups,after.objectsAndGroups);same(bytes.subarray(base.slot.base+0x128,base.slot.base+0x10400),result.bytes.subarray(base.slot.base+0x128,base.slot.base+0x10400));
for(const s of model.slots)if(s.index!==slot)same(bytes.subarray(s.base,s.end),result.bytes.subarray(s.base,s.end));same(plan.patch(result.bytes,requests).bytes,result.bytes);
const blocked=[];
function reject(label,mutate,id='blades-main-level'){
 const b=bytes.slice();mutate(b);const s=weapon.inspect(b,slot,id);assert(!s.available,label);assert.throws(()=>weapon.patch(b,[{slot,type:weapon.TYPE,id,level:weapon.PROFILES.find(p=>p.id===id).max}]));blocked.push(label);
}
for(const flag of ['5343978C802835DB','DBC20322187668AD'])reject('Flag NG+ ausente '+flag,b=>{const tx=nat.read(b,slot);const row=tx.slot.rows.find(r=>r.id===flag);nat.view(b).setUint32(row.offset+8,0,true);});
reject('Mapas divergentes',b=>{const tx=nat.read(b,slot),p=weapon.PROFILES[1],f=tx.state.frames[1],prefix=8,count=nat.view(b).getUint32(f.start+2+prefix,true);for(let k=0;k<count;k++){const at=f.start+2+prefix+4+k*9;if(nat.view(b).getUint32(at,true)===p.key)nat.view(b).setUint32(at+4,1,true);}});
reject('Referência de propriedade não catalogada',b=>{const marker=nat.fromHex(weapon.PROFILES[1].sceneMarker).subarray(8);b.set(marker,base.slot.base+0x8000);});
reject('Contexto de referência alterado',b=>{const marker=nat.fromHex(weapon.PROFILES[1].sceneMarker).subarray(8);const at=Buffer.from(b).indexOf(marker,base.slot.base);b[at-1]^=1;});
reject('Propriedade completa fora da seção de mundo',b=>b.set(nat.fromHex(weapon.PROFILES[1].sceneMarker),base.slot.base+0x40000));
reject('Histórico com lacuna',b=>{const tx=nat.read(b,slot),p=weapon.PROFILES[1];const row=tx.slot.rows.find(r=>r.id===p.history[0]);if(row)nat.view(b).setUint32(row.offset+8,0,true);else{const t=nat.read(b,slot);nat.putQuantity(t,p.history[1],1,true);b.set(nat.write(t).bytes);}});
reject('Machado NG+ no nível 1 ainda não amostrado',b=>{const t=nat.read(b,slot),p=weapon.PROFILES[0];for(const frame of [0,1])nat.view(nat.mapEntry(t,frame,p.key)).setUint32(4,0,true);nat.putQuantity(t,p.history[0],0);b.set(nat.write(t).bytes);},'axe-main-level');
const reg=[];const manifest=JSON.parse(fs.readFileSync(ws+'/analysis_0_14_0/testes/manifest.json'));
for(const c of manifest.cases.filter(c=>['13_','14_'].some(x=>c.name.startsWith(x)))){const b=read(c.source),req=c.requests.filter(r=>r.type===weapon.TYPE),a=weapon.patch(b,req),n=old.patch(b,req);same(a.bytes,n.bytes,'Progressão normal mudou');assert.equal(sha(a.bytes),c.sha256);reg.push(c.name);}
assert.equal(reg.length,2);
const report={passed:true,version:core.VERSION,implementationOutputEqualsGameApprovedTrial:true,sourceSlot:slot+1,nativeReturnSlot:rm.latestSlot+1,sourceSha256:sha(bytes),trialSha256:sha(trial),nativeReturnSha256:sha(returned),currentLevels:[6,5],continuousHistoriesPersisted:true,worldAndObjectsUnchanged:true,contextsRecognizedAfterNativeRelocation:true,oldNormalWeaponExportsByteIdentical:reg,negativeCases:blocked,scope:'NG+ explícito, dois mapas coerentes, histórico contínuo e referências de propriedade nos contextos observados. Machado inicial 2; Lâminas iniciais 1. Não desbloqueia armas nem o menu NG+.'};fs.writeFileSync(__dirname+'/VERIFICACAO_NGMAIS_0_19_0.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:true,gameTrialByteIdentical:true,nativeReturnVerified:true,negativeCases:blocked.length,normalRegressions:reg.length}));
