'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {api,$,query,downloads}=require('./test_dom_harness.cjs'),core=require('./src/core'),nat=require('./src/native-records'),unlock=require('./src/blades-unlock'),weapons=require('./src/weapon-levels'),plan=require('./src/plan'),ciphers=require('./src/ciphers');
const fixtures=path.resolve(process.argv[2]||path.join(__dirname,'../analysis_0_20_0/recovered'));
const source=new Uint8Array(fs.readFileSync(path.join(fixtures,'game(AntesDePegarAsBlades).sav'))),slot=10;
const same=(a,b)=>assert(nat.equal(a,b)),ok=()=>assert($('error').hidden,$('error').textContent),set=async(id,value,event='change')=>{$(id).value=String(value);await $(id).fire(event);};
(async()=>{
 api.loadBytes(source,'game.sav');api.selectSlot(slot);api.chooseView('levels');ok();
 assert(!$('blades-unlock-apply').disabled);assert($('blades-level-target').disabled);assert($('level-target').disabled);
 await $('blades-unlock-apply').click();ok();assert($('blades-unlock-apply').disabled);assert(!$('blades-level-target').disabled);
 assert.equal($('blades-level-target').children.filter(e=>e.tagName==='option').length,5);assert.equal($('blades-level-original').textContent,'Não possuídas');
 assert.match($('blades-level-range').textContent,/desde o início/);await set('blades-level-target',5);assert(!$('blades-level-apply').disabled);
 await $('blades-level-apply').click();ok();assert.equal(api.getState().log.length,2);assert.equal($('blades-level-edited').textContent,'Nível 5');
 const expected=[{slot,type:unlock.TYPE,id:unlock.ID},{slot,type:weapons.TYPE,id:'blades-main-level',level:5}];same(api.exportBytes().bytes,plan.patch(source,expected).bytes);
 api.chooseView('changes');assert.match($('changes-body').innerHTML,/aquisição/);assert.match($('changes-body').innerHTML,/Nível 5/);assert($('cipher-review-warning').hidden);
 await $('export-top').click();assert.equal(downloads.at(-1).name,'game.sav');same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),api.exportBytes().bytes);
 await $('original-download').click();same(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),source);
 await $('report-download').click();const report=JSON.parse(await downloads.at(-1).blob.text());assert.equal(report.version,'0.20.0');assert.equal(report.changes.length,2);
 await query('[data-undo]').find(e=>e.dataset.undo===slot+':blades-main-level').click();ok();assert.equal(api.getState().log.length,1);assert.equal($('blades-level-edited').textContent,'Nível 1');
 api.chooseView('levels');await set('blades-level-target',5);await $('blades-level-apply').click();ok();
 await query('[data-undo]').find(e=>e.dataset.undo===slot+':blades-unlock').click();ok();assert.equal(api.getState().log.length,0);assert($('blades-level-target').disabled);assert(!$('blades-unlock-apply').disabled);
 assert.throws(()=>api.exportBytes());
 // Quantidade inválida não substitui o plano válido, nem libera o Machado.
 await $('blades-unlock-apply').click();ok();await set('blades-level-target',6);assert($('blades-level-apply').disabled);await $('blades-level-apply').click();assert(!$('error').hidden);assert.equal(api.getState().log.length,1);
 await $('reset-changes').click();ok();assert($('level-target').disabled);
 // O aviso aparece nos controles e acompanha o lote até a revisão e o JSON.
 api.chooseView('campaign');assert.equal($('cipher-story-warning').textContent,ciphers.STORY_WARNING);
 await set('niflheim-cipher-total',4,'input');await $('niflheim-cipher-apply').click();ok();assert(!$('cipher-review-warning').hidden);assert.equal($('cipher-review-warning').textContent,ciphers.STORY_WARNING);
 await $('report-download').click();const cipherReport=JSON.parse(await downloads.at(-1).blob.text());assert.equal(cipherReport.changes[0].storyWarning,ciphers.STORY_WARNING);
 await query('[data-undo]').find(e=>e.dataset.undo===slot+':niflheim-cipher').click();ok();assert($('cipher-review-warning').hidden);
 // Trocar de slot mantém a inclusão restrita ao salvamento escolhido.
 api.selectSlot(7);api.chooseView('levels');await $('blades-unlock-apply').click();await set('blades-level-target',5);await $('blades-level-apply').click();ok();
 api.selectSlot(10);api.chooseView('levels');assert(!$('blades-unlock-apply').disabled);assert($('blades-level-target').disabled);assert.equal(api.getState().log.length,2);
 await $('reset-changes').click();ok();assert.equal(api.getState().log.length,0);
 // Save nativo já com as Lâminas permite ir direto ao nível 5.
 const native=new Uint8Array(fs.readFileSync(path.join(fixtures,'game(BL_04_INICIO_INVENTARIO(FuncionouPerfeitamente)).sav'))),ns=core.parse(native).latestSlot;
 api.loadBytes(native);api.selectSlot(ns);api.chooseView('levels');assert($('blades-unlock-apply').disabled);assert(!$('blades-level-target').disabled);
 await set('blades-level-target',5);await $('blades-level-apply').click();ok();assert.equal(api.getState().log.length,1);assert.equal(weapons.inspect(api.exportBytes().bytes,ns,'blades-main-level').current,5);
 const result={passed:true,version:core.VERSION,builtHtmlExecuted:true,grantThenMaximumInOneExport:true,acquisitionAndLevelEachAppearInReview:true,undoGrantCascadesOnlyDependentBladeLevel:true,invalidLevelPreservesPlan:true,axeFirstUpgradeGuardPreserved:true,originalAndEditedDownloadsVerified:true,reportIncludesVersionAndCipherWarning:true,cipherWarningInControlsAndReview:true,multiSlotIsolationVerified:true,nativeEarlySaveCanGoDirectlyToFive:true,domSimulationNotVisualBrowserOrGameTest:true};
 fs.writeFileSync(path.join(__dirname,'VERIFICACAO_INTERFACE_0_20_0.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
})().catch(e=>{console.error(e);process.exitCode=1;});
