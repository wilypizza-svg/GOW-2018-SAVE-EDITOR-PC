"""Leitura independente dos saves de inclusão do novo pomo NG+."""
import ast,hashlib,json,struct
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'VERIFICACAO_0_17_3.json').read_text())
reader=root/'test_clone_native_reader.py'
node=next(n for n in ast.parse(reader.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
ns=dict(struct=struct,HEADER=4160,SLOT=1677512,START=0x10400,SIZE=33554400,SLOT_INDEX=report['slot'])
exec(compile(ast.Module(body=[node],type_ignores=[]),str(reader),'exec'),ns)
parse=ns['parse'];source=Path(report['source']).read_bytes();assert hashlib.sha256(source).hexdigest()==report['sourceSha256']
ids=report['newProfile']['ids'];checked=[]
for case in report['cases']:
    data=Path(case['output']).read_bytes();assert len(data)==len(source)==33554400
    assert hashlib.sha256(data).hexdigest()==case['sha256'];a,b=parse(source),parse(data)
    old={r[:8].hex().upper():r for r in a['rows']};new={r[:8].hex().upper():r for r in b['rows']}
    assert len(new)==len(b['rows']);assert set(new)-set(old)==set(ids[:case['stage']+1])
    for id,row in old.items():assert new[id]==row
    for id in ids[:case['stage']+1]:assert struct.unpack_from('<I',new[id],8)[0]==1
    assert a['refs']==b['refs'] and a['objects']==b['objects'] and a['frames']==b['frames']
    assert b['finals'][4:].startswith(a['finals'][4:]);extra=b['finals'][4+len(a['finals'][4:]):]
    assert len(extra)==case['stage']*16
    for p in range(0,len(extra),16):assert extra[p:p+8].hex().upper() in ids[1:case['stage']+1]
    prefix=bytearray(source[:a['start']]);p=a['base']+0x124;prefix[p:p+4]=data[p:p+4];assert prefix==data[:b['start']]
    end=max(a['end'],b['end']);assert source[end:]==data[end:]
    for slot in range(20):
        if slot!=report['slot']:
            p=4160+slot*1677512;assert source[p:p+1677512]==data[p:p+1677512]
    checked.append({'stage':case['label'],'passed':True,'newRows':case['stage']+1,'allOriginalRowsObjectsMapsAndOtherSlotsPreserved':True})
out={'version':'0.17.3','passed':True,'independentLanguage':'Python','cases':checked,'gameValidationPendingForNewNgpItem':True}
(root/'VERIFICACAO_INDEPENDENTE_0_17_3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
