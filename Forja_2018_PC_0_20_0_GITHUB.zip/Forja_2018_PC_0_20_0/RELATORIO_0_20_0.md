# Forja 2018 PC 0.20.0 — relatório de entrega

Data: 26/10/2026. Referência: 0.19.0, preservada integralmente.

## Funções acrescentadas

Em **Níveis**, o usuário pode adicionar as Lâminas do Caos com o cabo padrão quando ainda estiverem ausentes. Depois pode escolher qualquer nível de 1 a 5, inclusive o máximo no início da campanha normal. A aquisição e o nível são operações separadas, podem ser exportadas juntas e aparecem individualmente na revisão. Desfazer a aquisição também remove o nível que depende dela.

A aquisição mantém a seleção atual de arma. A operação não copia o avanço da história, não cria propriedades de mundo e não consome recursos. Ao reduzir um nível já registrado, mantém o histórico de melhorias. Repetir a aquisição ou o mesmo nível não duplica registros.

As cifras de Muspelheim/Niflheim receberam o aviso solicitado por José: evitar a inclusão antes da primeira viagem a Alfheim, devido ao travamento relatado na cena em que Freya pede para mover a ponte de Týr. O aviso aparece nos controles, na revisão de alterações de cifras e em Como usar; acompanha também o relatório JSON. Ele informa o risco sem bloquear a escolha nem tentar inferir automaticamente a etapa da história.

## Ajuste de nível das Lâminas

O novo caminho atende à posse coerente, com os dois mapas de nível, cabo padrão, habilidade e referências iniciais reconhecidos. Exige histórico contínuo. Quando a propriedade secundária está ausente, verifica também que não há referências isoladas desconhecidas dessa propriedade em outras partes do slot. Registra as quatro etapas já mapeadas para alcançar o nível 5, sincronizando os mapas existentes e preservando o mundo.

Quando o campo secundário já existe, a rotina anterior continua em uso. O reconhecimento anterior do NG+ e a proteção do primeiro upgrade do Machado foram mantidos. Mapas divergentes, históricos com lacuna, referências desconhecidas e aquisições parciais não são liberados por essa inclusão.

## Verificações concluídas

| Verificação | Resultado |
|---|---|
| Aquisição perto do evento original | Hash exato do BL_01 aprovado no jogo |
| Aquisição no início | Hash exato do BL_04 aprovado no jogo |
| Níveis 1 a 5 e downgrade | Escrita, releitura, histórico e repetição conferidos |
| Retornos nativos de três cenários | Posse existente preservada; ajuste até 5 conferido localmente |
| Casos inválidos | 16 rejeições verificadas |
| Recursos, equipamentos, rúnicos e encantamento em lote | Exportação idêntica à 0.19.0 sem a operação nova |
| Remoção de equipamento | Exportação idêntica à 0.19.0 |
| Armas no NG+ parcial testado anteriormente | Exportação idêntica à 0.19.0 |
| Cifras | Mesmos bytes; aviso acrescentado ao relatório |
| Interface do HTML gerado | Inclusão, escolha de nível, revisão, desfazer, exportação, original e troca de slot conferidos |
| Leitor Python independente | Cinco arquivos exportados conferidos sem executar o leitor/gravador JavaScript |
| Fila de avisos | Limite de 512 preservado em sonda sintética |

O conjunto binário principal registrou 13 verificações e 16 casos negativos. A comparação do caminho com propriedade secundária das Lâminas usou uma sonda sintética identificada; ela comprova a preservação desse caminho de código, não constitui um novo teste no jogo.

Os hashes dos 204 arquivos da referência 0.19.0 foram conferidos sem alterações. Na nova versão, 192 desses arquivos permanecem idênticos. Os 12 arquivos existentes alterados correspondem à integração, interface, montagem, identificação de versão e documentação. A nova receita de aquisição e seu módulo foram acrescentados separadamente.

Todos os arquivos de dados anteriores permanecem idênticos, incluindo os perfis de armas, equipamentos, rúnicos e encantamentos. O gravador nativo, os gravadores de recursos, a clonagem, o inventário e a remoção também permanecem idênticos. Os casos de regressão conferem a saída binária, além dessa comparação de arquivos.

## Evidência e limite do teste

A aquisição antecipada foi aprovada por José no jogo, inclusive na progressão inicial e após a cutscene original. A implementação integrada reproduz os arquivos aprovados:

- BL_01: `75e71f5b237d06f35b00a39ac7748b878b5dce7b0d645c65809324e1e2c02b3f`.
- BL_04: `59cc5e73c1b4c45430578c198eb93898c74a2683736b89b63147d4ddf94145f3`.

**O ajuste direto ao nível 5 no início da campanha é novo e ainda precisa de confirmação no jogo.** Passou nos testes locais descritos acima; isso não equivale a testar todas as sequências da campanha. A verificação da interface executou o HTML em um DOM simulado, sem uma inspeção visual em navegador real.

O roteiro orienta carregar a cópia, conferir a arma e o nível, alternar armas, fechar o inventário, salvar e recarregar. O retorno útil é o `game.sav` salvo novamente pelo jogo, acompanhado do resultado observado.

## Arquivos

O pacote de uso contém somente o HTML pronto e as instruções. O pacote de código contém o projeto, os testes e os relatórios, sem os saves pessoais nem os arquivos de transferência. Para reconstruir o editor, execute `python3 build.py`.
