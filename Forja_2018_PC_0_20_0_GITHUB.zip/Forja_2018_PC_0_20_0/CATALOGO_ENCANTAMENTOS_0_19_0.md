# Catálogo de encantamentos — Forja 0.19.0

107 perfis: 92 NG normal e 15 NG+. Uma unidade por perfil ausente. Modelos novos ainda precisam da confirmação de inclusão no jogo. Atributos listados são do modelo, não uma alteração dos exemplares já existentes.

| Perfil | Campanha | Tipo | Atributos do modelo | Inclusão |
|---|---|---|---|---|
| Aurvandil's Fiery Shard+ | NG+ | Comum | Vitalidade 20; Força 8 | Testada no jogo |
| Bestla's Frozen Shard+ | NG+ | Comum | Preservados pelo perfil completo | Testada no jogo |
| Borr's Frozen Shard+ | NG+ | Comum | Rúnico 17; Defesa 8 | Testada no jogo |
| Buri's Frozen Shard+ | NG+ | Comum | Sorte 15; Rúnico 8 | Testada no jogo |
| Dagr's Fiery Shard+ | NG+ | Comum | Sorte 16; Rúnico 8 | Testada no jogo |
| Hroodr's Frozen Shard+ | NG+ | Comum | Recarga 18; Vitalidade 8 | Testada no jogo |
| Hymir's Frozen Shard+ | NG+ | Comum | Defesa 26 | Testada no jogo |
| Hyrokkin's Fiery Shard+ | NG+ | Comum | Recarga 19; Vitalidade 8 | Testada no jogo |
| Jarnsaxa's Fiery Shard+ | NG+ | Comum | Recarga 18; Sorte 8 | Testada no jogo |
| Logi's Fiery Shard+ | NG+ | Comum | Defesa 18; Recarga 8 | Testada no jogo |
| Marca Perfeita da Proteção + | NG+ | Único | Defesa 18; Força 8 | Testada no jogo |
| Marca Perfeita de Kvasir + | NG+ | Único | Vitalidade 18; Defesa 8 | Testada no jogo |
| Marca Perfeita de Týr + | NG+ | Único | Sorte 15; Vitalidade 8; Força 8; Rúnico 8; Defesa 8; Recarga 8 | Testada no jogo |
| Marca Perfeita do Viajante + | NG+ | Único | Preservados pelo perfil completo | Testada no jogo |
| Marca Perfeita dos Anciões + | NG+ | Único | Preservados pelo perfil completo | Testada no jogo |
| Asgard's Shard of Existence · nível 6 | Normal | Único | Defesa 12 | Novo modelo — teste pendente |
| Comum · nível 2 · Recarga 3 | Normal | Comum | Recarga 3 | Novo modelo — teste pendente |
| Comum · nível 2 · Rúnico 3 | Normal | Comum | Rúnico 3 | Novo modelo — teste pendente |
| Comum · nível 3 · Defesa 2 | Normal | Comum | Defesa 2 | Novo modelo — teste pendente |
| Comum · nível 3 · Força 2 | Normal | Comum | Força 2 | Novo modelo — teste pendente |
| Comum · nível 3 · Recarga 2 | Normal | Comum | Recarga 2 | Novo modelo — teste pendente |
| Comum · nível 3 · Recarga 3 | Normal | Comum | Recarga 3 | Novo modelo — teste pendente |
| Comum · nível 3 · Rúnico 2 | Normal | Comum | Rúnico 2 | Novo modelo — teste pendente |
| Comum · nível 3 · Sorte 4 · modelo 1 | Normal | Comum | Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 3 · Sorte 4 · modelo 2 | Normal | Comum | Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 3 · Sorte 4 · modelo 3 | Normal | Comum | Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 4 · Defesa 3 · modelo 1 | Normal | Comum | Defesa 3 | Novo modelo — teste pendente |
| Comum · nível 4 · Defesa 3 · modelo 2 | Normal | Comum | Defesa 3 | Novo modelo — teste pendente |
| Comum · nível 4 · Força 4 | Normal | Comum | Força 4 | Novo modelo — teste pendente |
| Comum · nível 4 · Rúnico 4 | Normal | Comum | Rúnico 4 | Novo modelo — teste pendente |
| Comum · nível 4 · Sorte 5 · modelo 1 | Normal | Comum | Sorte 5 | Novo modelo — teste pendente |
| Comum · nível 4 · Sorte 5 · modelo 2 | Normal | Comum | Sorte 5 | Novo modelo — teste pendente |
| Comum · nível 4 · Sorte 5 · modelo 3 | Normal | Comum | Sorte 5 | Novo modelo — teste pendente |
| Comum · nível 4 · Sorte 5 · modelo 4 | Normal | Comum | Sorte 5 | Novo modelo — teste pendente |
| Comum · nível 4 · Vitalidade 3 | Normal | Comum | Vitalidade 3 | Novo modelo — teste pendente |
| Comum · nível 4 · Vitalidade 4 | Normal | Comum | Vitalidade 4 | Novo modelo — teste pendente |
| Comum · nível 5 · Defesa 5 / Força 2 | Normal | Comum | Defesa 5; Força 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Defesa 5 / Vitalidade 2 | Normal | Comum | Defesa 5; Vitalidade 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Defesa 6 | Normal | Comum | Defesa 6 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Recarga 4 / Rúnico 2 | Normal | Comum | Força 0; Recarga 4; Rúnico 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Recarga 4 / Vitalidade 2 | Normal | Comum | Força 0; Recarga 4; Vitalidade 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Sorte 10 | Normal | Comum | Força 0; Sorte 10 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Sorte 6 / Recarga 2 | Normal | Comum | Força 0; Sorte 6; Recarga 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Sorte 6 / Vitalidade 2 | Normal | Comum | Força 0; Sorte 6; Vitalidade 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 0 / Vitalidade 5 / Rúnico 2 | Normal | Comum | Força 0; Vitalidade 5; Rúnico 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Força 8 | Normal | Comum | Força 8 | Novo modelo — teste pendente |
| Comum · nível 5 · Recarga 5 / Rúnico 2 | Normal | Comum | Recarga 5; Rúnico 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Recarga 5 / Vitalidade 2 | Normal | Comum | Recarga 5; Vitalidade 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Rúnico 5 / Recarga 2 | Normal | Comum | Rúnico 5; Recarga 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Rúnico 5 / Vitalidade 2 | Normal | Comum | Rúnico 5; Vitalidade 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Sorte 6 / Força 2 | Normal | Comum | Sorte 6; Força 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Vitalidade 4 / Força 2 | Normal | Comum | Vitalidade 4; Força 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Vitalidade 4 / Recarga 2 | Normal | Comum | Vitalidade 4; Recarga 2 | Novo modelo — teste pendente |
| Comum · nível 5 · Vitalidade 5 / Rúnico 2 | Normal | Comum | Vitalidade 5; Rúnico 2 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Defesa 6 / Rúnico 3 | Normal | Comum | Força 0; Defesa 6; Rúnico 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Recarga 10 | Normal | Comum | Força 0; Recarga 10 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Rúnico 5 / Defesa 3 | Normal | Comum | Força 0; Rúnico 5; Defesa 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Rúnico 7 / Vitalidade 3 | Normal | Comum | Força 0; Rúnico 7; Vitalidade 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Sorte 8 / Recarga 3 | Normal | Comum | Força 0; Sorte 8; Recarga 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Vitalidade 7 / Rúnico 3 | Normal | Comum | Força 0; Vitalidade 7; Rúnico 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 0 / Vitalidade 8 / Defesa 3 | Normal | Comum | Força 0; Vitalidade 8; Defesa 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 11 | Normal | Comum | Força 11 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 7 | Normal | Comum | Força 7 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 7 / Sorte 4 | Normal | Comum | Força 7; Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 8 / Rúnico 3 | Normal | Comum | Força 8; Rúnico 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Força 8 / Sorte 4 | Normal | Comum | Força 8; Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 6 · Recarga 4 / Sorte 4 | Normal | Comum | Recarga 4; Sorte 4 | Novo modelo — teste pendente |
| Comum · nível 6 · Recarga 6 / Vitalidade 3 | Normal | Comum | Recarga 6; Vitalidade 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Recarga 7 / Rúnico 3 | Normal | Comum | Recarga 7; Rúnico 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Rúnico 6 / Defesa 3 | Normal | Comum | Rúnico 6; Defesa 3 | Novo modelo — teste pendente |
| Comum · nível 6 · Sorte 11 | Normal | Comum | Sorte 11 | Novo modelo — teste pendente |
| Comum · nível 6 · Vitalidade 10 | Normal | Comum | Vitalidade 10 | Novo modelo — teste pendente |
| Comum · nível 6 · Vitalidade 7 / Força 3 | Normal | Comum | Vitalidade 7; Força 3 | Novo modelo — teste pendente |
| Comum · nível 7 · Defesa 14 · modelo 1 | Normal | Comum | Defesa 14 | Novo modelo — teste pendente |
| Comum · nível 7 · Defesa 14 · modelo 2 | Normal | Comum | Defesa 14 | Novo modelo — teste pendente |
| Comum · nível 7 · Força 11 | Normal | Comum | Força 11 | Novo modelo — teste pendente |
| Comum · nível 7 · Força 12 | Normal | Comum | Força 12 | Novo modelo — teste pendente |
| Comum · nível 7 · Força 13 | Normal | Comum | Força 13 | Novo modelo — teste pendente |
| Comum · nível 7 · Força 14 | Normal | Comum | Força 14 | Novo modelo — teste pendente |
| Comum · nível 7 · Recarga 11 | Normal | Comum | Recarga 11 | Novo modelo — teste pendente |
| Comum · nível 7 · Recarga 13 | Normal | Comum | Recarga 13 | Novo modelo — teste pendente |
| Comum · nível 7 · Rúnico 10 | Normal | Comum | Rúnico 10 | Novo modelo — teste pendente |
| Comum · nível 7 · Rúnico 13 | Normal | Comum | Rúnico 13 | Novo modelo — teste pendente |
| Comum · nível 7 · Rúnico 14 | Normal | Comum | Rúnico 14 | Novo modelo — teste pendente |
| Comum · nível 7 · Rúnico 9 | Normal | Comum | Rúnico 9 | Novo modelo — teste pendente |
| Comum · nível 7 · Vitalidade 15 | Normal | Comum | Vitalidade 15 | Novo modelo — teste pendente |
| Fragmented Heart of Alfheim · nível 3 | Normal | Único | Vitalidade 4 | Novo modelo — teste pendente |
| Heart of Midgard · nível 5 | Normal | Único | Força 7 | Novo modelo — teste pendente |
| Heart of Vanaheim · nível 4 | Normal | Único | Força 4; Recarga 4 | Novo modelo — teste pendente |
| Hearth of the Valkyrie · nível 6 | Normal | Único | Defesa 8; Vitalidade 8; Recarga 8; Rúnico 8 | Novo modelo — teste pendente |
| Hroodr's Frozen Shard · nível 6 | Normal | Comum | Força 5; Sorte 4 | Novo modelo — teste pendente |
| Muspelheim's Eye of Power · nível 6 | Normal | Único | Força 10; Defesa 10; Vitalidade 10 | Novo modelo — teste pendente |
| Njord's Temporal Stone · nível 6 | Normal | Único | Recarga 12; Rúnico 6; Sorte 6 | Novo modelo — teste pendente |
| Signo Robusto de Sorte · nível 7 | Normal | Comum | Sorte 15 | Novo modelo — teste pendente |
| Símbolo da Ameaça · raro | Normal | Comum | Vitalidade 3 | Testada no jogo |
| Símbolo das Sombras · raro | Normal | Comum | Sorte 5 | Testada no jogo |
| Único · nível 2 · Vitalidade 4 | Normal | Único | Vitalidade 4 | Novo modelo — teste pendente |
| Único · nível 3 · Defesa 4 | Normal | Único | Defesa 4 | Novo modelo — teste pendente |
| Único · nível 4 · Defesa 4 · modelo 1 | Normal | Único | Defesa 4 | Novo modelo — teste pendente |
| Único · nível 4 · Defesa 4 · modelo 2 | Normal | Único | Defesa 4 | Novo modelo — teste pendente |
| Único · nível 4 · Recarga 4 · modelo 1 | Normal | Único | Recarga 4 | Novo modelo — teste pendente |
| Único · nível 4 · Recarga 4 · modelo 2 | Normal | Único | Recarga 4 | Novo modelo — teste pendente |
| Único · nível 4 · Rúnico 4 | Normal | Único | Rúnico 4 | Novo modelo — teste pendente |
| Único · nível 6 · Força 9 | Normal | Único | Força 9 | Novo modelo — teste pendente |
| Único · nível 6 · Recarga 13 | Normal | Único | Recarga 13 | Novo modelo — teste pendente |
| Único · nível 6 · Sorte 8 | Normal | Único | Sorte 8 | Novo modelo — teste pendente |
| Único · nível 7 · Defesa 12 / Força 6 / Rúnico 6 / Vitalidade 6 | Normal | Único | Defesa 12; Força 6; Rúnico 6; Vitalidade 6 | Novo modelo — teste pendente |
